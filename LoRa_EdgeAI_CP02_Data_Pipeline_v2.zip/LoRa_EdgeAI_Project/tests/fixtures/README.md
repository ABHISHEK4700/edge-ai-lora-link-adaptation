# tests/fixtures/ — Synthetic Test Fixtures

**Everything in this folder is fabricated data used ONLY to test that the
preprocessing code behaves correctly.** None of it is real LoRa hardware
data, none of it is a research result, and none of it should ever be cited,
plotted, or reported as a project finding.

This mirrors the same approach used in `tests/test_environment.py` from
Checkpoint 1, where a trivial `y = 2x` relationship was used purely to
confirm scikit-learn could fit a model — not as project data.

## Files

- `synthetic_test_fixture_raw.csv` — a small (12-row), hand-constructed CSV
  matching `ml/preprocessing/schema.RAW_SCHEMA`, used by
  `tests/test_preprocessing.py` to verify:
  - valid rows are kept
  - invalid rows (out-of-range values, missing required fields) are
    correctly detected and dropped
  - rolling/history feature engineering produces the expected columns and
    values, including correctly excluding the current packet's own outcome
    from its own history features

  Its `channel_freq_hz` value (433000000 / 433 MHz) is set to match the
  band of the project's planned hardware (SX1278, 433 MHz) purely so this
  fabricated file doesn't imply a different, incorrect radio band if
  someone skims it later. The value is still entirely synthetic — it was
  not measured from any real device — only the frequency *number* was
  chosen to stay consistent with the real hardware plan and avoid
  confusion.

If you need more/different synthetic test cases in a future checkpoint,
add them here with a clear filename and update
`tests/test_preprocessing.py` accordingly — do not add synthetic data to
`data/raw/`, `data/processed/`, or `data/sample/`.
