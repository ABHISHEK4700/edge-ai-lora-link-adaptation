"""
labeler.py

Checkpoint 3 — Labeling pipeline orchestrator and CLI.

Ties the labeling framework together:

    input CSV  (cleaned raw or Checkpoint 2 processed data)
        |
        v
    assign_contexts()        group packets into comparable channel contexts
        |
        v
    build_oracle_table()     measured evidence per (context, SF, TP)
        |
        v
    select_labels()          one (SF, TP) target per context
        |
        v
    attach_labels()          join targets back onto per-packet feature rows
        |
        +--> <output>_oracle.csv    the evidence table (auditable)
        +--> <output>_labels.csv    one label per context
        +--> <output>                per-packet rows with targets attached

Usage (once real processed data exists):
    python -m ml.labeling.labeler \\
        --input data/processed/some_session_processed.csv \\
        --output data/processed/some_session_labeled.csv \\
        --config ml/labeling/labeling_config.example.json

Every knob is configurable; run with --print-config to dump the effective
configuration, or --write-default-config to emit a starting JSON file.

IMPORTANT — TRAIN/TEST SPLITTING
--------------------------------
Labels are a property of a CONTEXT, not of an individual packet, so many rows
share one label. Splitting train/test randomly by row would put rows from the
same context on both sides of the split and inflate the apparent score. Split
by `context_id` instead (e.g. scikit-learn's GroupKFold or GroupShuffleSplit
with groups=context_id). The `context_id` column is written into the output
precisely so a later checkpoint can do this.

This module does NOT train a model and does NOT generate any measurement
data. It only transforms a CSV the caller supplies.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Optional, Tuple

import pandas as pd

from .config import LabelStatus, LabelingConfig
from .context import CONTEXT_ID_COLUMN, assign_contexts, describe_strategy
from .energy import energy_units
from .oracle import (
    NoValidConfigurationError,
    build_oracle_table,
    select_labels,
    summarise_labels,
)


def attach_labels(
    df: pd.DataFrame,
    labels_df: pd.DataFrame,
    cfg: LabelingConfig,
) -> pd.DataFrame:
    """Join per-context labels back onto per-packet rows.

    Adds `context_id`, the configured label columns, `label_status` and
    `selection_reason`. Rows belonging to an unlabelled context are dropped
    when `cfg.drop_unlabeled_rows` is True, and otherwise kept with NaN
    targets so they can be inspected.

    Does not mutate the inputs.
    """
    with_ctx, _ = assign_contexts(df, cfg)

    if labels_df.empty:
        out = with_ctx.copy()
        out[cfg.label_sf_column] = pd.NA
        out[cfg.label_tp_column] = pd.NA
        out["label_status"] = LabelStatus.NO_LABEL
        out["selection_reason"] = "no labels were produced"
        return out.iloc[0:0].copy() if cfg.drop_unlabeled_rows else out

    join_cols = labels_df[[
        CONTEXT_ID_COLUMN, "label_sf", "label_tp_dbm",
        "label_status", "selection_reason",
    ]].rename(columns={
        "label_sf": cfg.label_sf_column,
        "label_tp_dbm": cfg.label_tp_column,
    })

    merged = with_ctx.merge(join_cols, on=CONTEXT_ID_COLUMN, how="left")

    # Rows whose context never reached the label table at all.
    merged["label_status"] = merged["label_status"].fillna(LabelStatus.NO_LABEL)
    merged["selection_reason"] = merged["selection_reason"].fillna(
        "context absent from label table (no measured configuration inside "
        "the candidate space)"
    )

    if cfg.drop_unlabeled_rows:
        keep = merged[cfg.label_sf_column].notna() & merged[cfg.label_tp_column].notna()
        merged = merged[keep].reset_index(drop=True)

    return merged


def run_labeling(
    input_path: str,
    output_path: str,
    cfg: Optional[LabelingConfig] = None,
    write_sidecars: bool = True,
) -> dict:
    """Run the full labeling pipeline on one CSV file.

    Returns a summary dict describing what was produced. Raises
    FileNotFoundError if `input_path` does not exist, ValueError on a
    configuration or schema problem, and NoValidConfigurationError when the
    'error' policy is active and a context cannot be labelled.
    """
    cfg = cfg or LabelingConfig()
    cfg.validate()

    df = pd.read_csv(input_path)

    oracle_df = build_oracle_table(df, cfg)
    labels_df = select_labels(oracle_df, cfg)
    labeled_df = attach_labels(df, labels_df, cfg)

    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    labeled_df.to_csv(output_file, index=False)

    oracle_path = labels_path = None
    if write_sidecars:
        stem = output_file.with_suffix("")
        oracle_path = Path(f"{stem}_oracle.csv")
        labels_path = Path(f"{stem}_labels.csv")
        oracle_df.to_csv(oracle_path, index=False)
        labels_df.to_csv(labels_path, index=False)

    status_counts = summarise_labels(labels_df)
    evidence_backed = sum(
        status_counts.get(s, 0) for s in LabelStatus.EVIDENCE_BACKED
    )

    return {
        "input_path": str(input_path),
        "output_path": str(output_path),
        "oracle_path": str(oracle_path) if oracle_path else None,
        "labels_path": str(labels_path) if labels_path else None,
        "input_rows": int(len(df)),
        "contexts_found": int(labels_df[CONTEXT_ID_COLUMN].nunique()) if not labels_df.empty else 0,
        "oracle_rows": int(len(oracle_df)),
        "labeled_rows": int(len(labeled_df)),
        "label_status_counts": status_counts,
        "evidence_backed_contexts": evidence_backed,
        "settings": {
            "context_strategy": f"{cfg.context_strategy} ({describe_strategy(cfg)})",
            "min_reliability": cfg.min_reliability,
            "reliability_estimator": cfg.reliability_estimator,
            "energy_method": f"{cfg.energy_method} [{energy_units(cfg.energy_method)}]",
            "cost_basis": cfg.cost_basis,
            "tie_break_rules": list(cfg.tie_break_rules),
            "no_valid_config_policy": cfg.no_valid_config_policy,
            "candidate_sf_values": cfg.candidate_sf_values or "derived from data",
            "candidate_tp_dbm_values": cfg.candidate_tp_dbm_values or "derived from data",
        },
    }


def load_config(path: Optional[str]) -> LabelingConfig:
    """Load a LabelingConfig from JSON, or return defaults when path is None."""
    if path is None:
        return LabelingConfig()
    return LabelingConfig.from_json_file(path)


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Derive (SF, TX power) training labels from measured LoRa link "
            "evidence. Does not train a model."
        )
    )
    parser.add_argument(
        "--input", "-i",
        help="Cleaned raw or Checkpoint 2 processed CSV to label.",
    )
    parser.add_argument(
        "--output", "-o",
        help="Path to write the labeled per-packet CSV to. Two sidecar files "
             "(_oracle.csv, _labels.csv) are written alongside it.",
    )
    parser.add_argument(
        "--config", "-c", default=None,
        help="Path to a labeling config JSON file. Defaults are used if "
             "omitted; see ml/labeling/labeling_config.example.json.",
    )
    parser.add_argument(
        "--print-config", action="store_true",
        help="Print the effective configuration as JSON and exit.",
    )
    parser.add_argument(
        "--write-default-config", metavar="PATH", default=None,
        help="Write a default config JSON to PATH and exit.",
    )
    parser.add_argument(
        "--no-sidecars", action="store_true",
        help="Skip writing the _oracle.csv and _labels.csv sidecar files.",
    )
    return parser


def main(argv=None):
    parser = _build_arg_parser()
    args = parser.parse_args(argv)

    try:
        cfg = load_config(args.config)
        cfg.validate()
    except (ValueError, FileNotFoundError, json.JSONDecodeError) as e:
        print(f"ERROR: invalid labeling configuration: {e}", file=sys.stderr)
        sys.exit(1)

    if args.write_default_config:
        LabelingConfig().to_json_file(args.write_default_config)
        print(f"Wrote default labeling config to {args.write_default_config}")
        sys.exit(0)

    if args.print_config:
        print(json.dumps(cfg.to_dict(), indent=2))
        sys.exit(0)

    if not args.input or not args.output:
        parser.error("--input and --output are required unless --print-config "
                     "or --write-default-config is used.")

    try:
        summary = run_labeling(
            args.input, args.output, cfg=cfg,
            write_sidecars=not args.no_sidecars,
        )
    except FileNotFoundError:
        print(f"ERROR: input file not found: {args.input}", file=sys.stderr)
        print(
            "No real processed data exists yet as of Checkpoint 3 — see "
            "experiments/DATA_COLLECTION_PLAN.md and "
            "experiments/LABELING_STRATEGY.md.",
            file=sys.stderr,
        )
        sys.exit(1)
    except NoValidConfigurationError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(2)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
