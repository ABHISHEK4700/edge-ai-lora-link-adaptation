"""
oracle.py

Checkpoint 3 — Evidence table construction and label selection.

This is the core of the target-label strategy. It implements two steps:

  1. build_oracle_table(df, cfg)
     Aggregate measured packets into one row per (context, SF, TP): how many
     packets were transmitted at that configuration under those channel
     conditions, how many were delivered, the estimated reliability, the mean
     retry count, and the computed energy cost.

  2. select_labels(oracle_df, cfg)
     For each context, choose the single (SF, TP) that is the training target:
     the lowest-energy configuration among those whose MEASURED reliability
     cleared the configured threshold. Every selection carries a
     `label_status` recording whether it was backed by sufficient evidence or
     produced by a fallback policy.

WHY NOT JUST USE THE LOGGED sf / tp_dbm COLUMNS AS LABELS
---------------------------------------------------------
Because those columns record what the device was *told* to use, not what it
*should* have used. Training on them teaches the model to imitate whatever
configuration policy happened to be running during collection, which either
reproduces standard ADR (defeating the project's premise) or reproduces an
arbitrary sweep (learning noise). The label has to be derived from measured
outcomes instead. See experiments/LABELING_STRATEGY.md for the full argument.

WHAT THIS MODULE REQUIRES OF THE DATA
-------------------------------------
It can only compare configurations that were actually measured under
comparable conditions. If a context contains only one configuration, then
"the best configuration in this context" is vacuously that configuration, and
`min_configs_per_context` will reject it rather than emit a meaningless
label. This makes a configuration sweep within each channel condition a hard
requirement of data collection, not an optional extra.

No real or fabricated LoRa measurement data lives in this file. Every number
it produces is computed from a CSV the caller supplies.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from .config import (
    LabelStatus,
    LabelingConfig,
    NoValidConfigPolicy,
    TieBreakRule,
    resolve_candidate_configs,
)
from .context import CONTEXT_ID_COLUMN, assign_contexts
from .energy import config_energy_cost
from .reliability import estimate_reliability

#: Columns produced by build_oracle_table().
ORACLE_COLUMNS = [
    CONTEXT_ID_COLUMN,
    "sf",
    "tp_dbm",
    "n_packets",
    "n_success",
    "pdr_observed",
    "reliability",
    "mean_retry",
    "mean_rssi_dbm",
    "mean_snr_db",
    "payload_bytes_used",
    "energy_cost",
    "sufficient_evidence",
    "meets_reliability",
]

#: Columns produced by select_labels().
LABEL_COLUMNS = [
    CONTEXT_ID_COLUMN,
    "label_sf",
    "label_tp_dbm",
    "label_status",
    "selection_reason",
    "label_reliability",
    "label_energy_cost",
    "n_packets_in_context",
    "n_configs_measured",
    "n_configs_sufficient_evidence",
    "n_configs_feasible",
]


class NoValidConfigurationError(RuntimeError):
    """Raised when no configuration is labellable and the policy is 'error'."""


def build_oracle_table(df: pd.DataFrame, cfg: LabelingConfig) -> pd.DataFrame:
    """Aggregate per-packet rows into per-(context, SF, TP) measured evidence.

    `df` must be a cleaned raw / processed DataFrame carrying at least
    `sf`, `tp_dbm`, `packet_success`, `retry_count`, plus whatever columns the
    configured context strategy needs.

    Returns a DataFrame with ORACLE_COLUMNS. Does not mutate the input.
    """
    cfg.validate()

    required = ["sf", "tp_dbm", "packet_success", "retry_count"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"build_oracle_table: input is missing required column(s) "
            f"{missing}. Run the Checkpoint 2 preprocessing pipeline first "
            f"(see ml/preprocessing/pipeline.py)."
        )

    if df.empty:
        return pd.DataFrame(columns=ORACLE_COLUMNS)

    with_ctx, _ = assign_contexts(df, cfg)

    sf_candidates, tp_candidates = resolve_candidate_configs(
        cfg,
        observed_sf=with_ctx["sf"].dropna().astype(int).tolist(),
        observed_tp=with_ctx["tp_dbm"].dropna().astype(float).tolist(),
    )
    if not sf_candidates or not tp_candidates:
        raise ValueError(
            "No candidate configurations available. Either the input contains "
            "no rows with SF/TX-power inside the configured sanity bounds, or "
            "the explicit candidate lists exclude everything measured. "
            f"SF candidates={sf_candidates}, TX power candidates={tp_candidates}."
        )

    sf_allowed = set(sf_candidates)
    tp_allowed = set(tp_candidates)

    # Restrict to measured configurations inside the candidate space. The
    # framework can only ever select something real data exists for.
    in_space = (
        with_ctx["sf"].astype(int).isin(sf_allowed)
        & with_ctx["tp_dbm"].astype(float).isin(tp_allowed)
    )
    working = with_ctx[in_space].copy()
    if working.empty:
        return pd.DataFrame(columns=ORACLE_COLUMNS)

    working["sf"] = working["sf"].astype(int)
    working["tp_dbm"] = working["tp_dbm"].astype(float)

    # Payload size is held constant within a context so that energy
    # differences reflect SF/TX-power rather than a payload confound.
    payload_by_context = _context_payload_sizes(working, cfg)

    records: List[Dict] = []
    group_cols = [CONTEXT_ID_COLUMN, "sf", "tp_dbm"]

    for (ctx, sf, tp), grp in working.groupby(group_cols, sort=True):
        n_packets = int(len(grp))
        n_success = int(grp["packet_success"].astype(int).sum())
        pdr_observed = n_success / n_packets if n_packets else 0.0

        reliability = estimate_reliability(
            successes=n_success,
            attempts=n_packets,
            estimator=cfg.reliability_estimator,
            z=cfg.wilson_z,
        )
        mean_retry = float(grp["retry_count"].astype(float).mean())
        payload_used = payload_by_context[ctx]

        energy_cost = config_energy_cost(
            sf=int(sf),
            tp_dbm=float(tp),
            payload_bytes=payload_used,
            reliability=reliability,
            mean_retry=mean_retry,
            cfg=cfg,
        )

        sufficient = n_packets >= cfg.min_packets_per_config
        meets = reliability >= cfg.min_reliability
        if meets and cfg.max_mean_retry is not None:
            meets = mean_retry <= cfg.max_mean_retry

        records.append({
            CONTEXT_ID_COLUMN: ctx,
            "sf": int(sf),
            "tp_dbm": float(tp),
            "n_packets": n_packets,
            "n_success": n_success,
            "pdr_observed": pdr_observed,
            "reliability": reliability,
            "mean_retry": mean_retry,
            "mean_rssi_dbm": _safe_mean(grp, "rssi_dbm"),
            "mean_snr_db": _safe_mean(grp, "snr_db"),
            "payload_bytes_used": payload_used,
            "energy_cost": energy_cost,
            "sufficient_evidence": bool(sufficient),
            "meets_reliability": bool(meets),
        })

    return pd.DataFrame(records, columns=ORACLE_COLUMNS)


def select_labels(oracle_df: pd.DataFrame, cfg: LabelingConfig) -> pd.DataFrame:
    """Choose one (SF, TP) target per context from the measured evidence.

    Returns a DataFrame with LABEL_COLUMNS, one row per context. Contexts that
    could not be labelled appear with NaN targets and a `label_status`
    explaining why, unless the policy is 'error'.
    """
    cfg.validate()

    if oracle_df.empty:
        return pd.DataFrame(columns=LABEL_COLUMNS)

    rows: List[Dict] = []
    for ctx, grp in oracle_df.groupby(CONTEXT_ID_COLUMN, sort=True):
        rows.append(_select_one_context(ctx, grp, cfg))

    return pd.DataFrame(rows, columns=LABEL_COLUMNS)


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _select_one_context(ctx: str, grp: pd.DataFrame, cfg: LabelingConfig) -> Dict:
    n_packets_in_context = int(grp["n_packets"].sum())
    n_configs_measured = int(len(grp))

    evidenced = grp[grp["sufficient_evidence"]]
    n_evidenced = int(len(evidenced))

    feasible = evidenced[evidenced["meets_reliability"]]
    n_feasible = int(len(feasible))

    base = {
        CONTEXT_ID_COLUMN: ctx,
        "n_packets_in_context": n_packets_in_context,
        "n_configs_measured": n_configs_measured,
        "n_configs_sufficient_evidence": n_evidenced,
        "n_configs_feasible": n_feasible,
    }

    # --- Guard 1: is there enough evidence in this context at all? ---------
    coverage_problem = None
    if n_packets_in_context < cfg.min_packets_per_context:
        coverage_problem = (
            f"context holds {n_packets_in_context} packets, below "
            f"min_packets_per_context={cfg.min_packets_per_context}"
        )
    elif n_evidenced < cfg.min_configs_per_context:
        coverage_problem = (
            f"only {n_evidenced} configuration(s) have at least "
            f"min_packets_per_config={cfg.min_packets_per_config} packets, "
            f"below min_configs_per_context={cfg.min_configs_per_context}; "
            f"'best configuration' is not meaningful without alternatives to "
            f"compare against"
        )

    if coverage_problem is not None:
        return _apply_fallback(
            base=base,
            grp=grp,
            pool=evidenced if n_evidenced else grp,
            cfg=cfg,
            cause_status=LabelStatus.INSUFFICIENT_CONFIG_COVERAGE,
            reason=coverage_problem,
        )

    # --- Guard 2: did anything clear the reliability threshold? ------------
    if n_feasible == 0:
        best_seen = evidenced["reliability"].max()
        return _apply_fallback(
            base=base,
            grp=grp,
            pool=evidenced,
            cfg=cfg,
            cause_status=None,   # decided by the policy
            reason=(
                f"no configuration reached min_reliability="
                f"{cfg.min_reliability} (best estimated reliability in this "
                f"context was {best_seen:.4f})"
            ),
        )

    # --- Normal path: cheapest configuration that met the threshold --------
    winner = _pick_cheapest(feasible, cfg)
    return {
        **base,
        "label_sf": int(winner["sf"]),
        "label_tp_dbm": float(winner["tp_dbm"]),
        "label_status": LabelStatus.OK,
        "selection_reason": (
            f"lowest energy cost among {n_feasible} configuration(s) meeting "
            f"min_reliability={cfg.min_reliability}"
        ),
        "label_reliability": float(winner["reliability"]),
        "label_energy_cost": float(winner["energy_cost"]),
    }


def _apply_fallback(
    base: Dict,
    grp: pd.DataFrame,
    pool: pd.DataFrame,
    cfg: LabelingConfig,
    cause_status: Optional[str],
    reason: str,
) -> Dict:
    """Handle a context where no configuration is validly labellable."""
    policy = cfg.no_valid_config_policy

    if policy == NoValidConfigPolicy.ERROR:
        raise NoValidConfigurationError(
            f"Context {base[CONTEXT_ID_COLUMN]!r}: {reason}. "
            f"no_valid_config_policy='error', so labeling stopped. Either "
            f"collect more data for this context, relax the thresholds, or "
            f"choose a different policy."
        )

    if policy == NoValidConfigPolicy.DROP:
        return {
            **base,
            "label_sf": np.nan,
            "label_tp_dbm": np.nan,
            "label_status": LabelStatus.NO_LABEL,
            "selection_reason": f"dropped: {reason}",
            "label_reliability": np.nan,
            "label_energy_cost": np.nan,
        }

    candidates = pool if not pool.empty else grp
    if candidates.empty:
        return {
            **base,
            "label_sf": np.nan,
            "label_tp_dbm": np.nan,
            "label_status": LabelStatus.NO_LABEL,
            "selection_reason": f"no candidate configurations at all: {reason}",
            "label_reliability": np.nan,
            "label_energy_cost": np.nan,
        }

    if policy == NoValidConfigPolicy.MOST_RELIABLE:
        winner = _pick_most_reliable(candidates, cfg)
        status = cause_status or LabelStatus.BELOW_THRESHOLD_FALLBACK
        how = "fell back to the most reliable measured configuration"
    elif policy == NoValidConfigPolicy.MAX_ROBUSTNESS:
        winner = _pick_max_robustness(candidates)
        status = cause_status or LabelStatus.MAX_ROBUSTNESS_FALLBACK
        how = (
            "fell back to the most robust measured configuration "
            "(highest SF, then highest TX power) — heuristic, not measured "
            "evidence of optimality"
        )
    else:
        raise ValueError(f"Unhandled no_valid_config_policy {policy!r}.")

    return {
        **base,
        "label_sf": int(winner["sf"]),
        "label_tp_dbm": float(winner["tp_dbm"]),
        "label_status": status,
        "selection_reason": f"{how}: {reason}",
        "label_reliability": float(winner["reliability"]),
        "label_energy_cost": float(winner["energy_cost"]),
    }


def _pick_cheapest(candidates: pd.DataFrame, cfg: LabelingConfig) -> pd.Series:
    """Lowest energy cost, with configured tie-breaking among near-equal costs."""
    costs = candidates["energy_cost"].astype(float)
    min_cost = costs.min()

    if math.isinf(min_cost):
        tied = candidates[np.isinf(costs)]
    else:
        tolerance = cfg.cost_tolerance * max(abs(min_cost), 1.0)
        tied = candidates[costs <= min_cost + tolerance]

    if len(tied) == 1:
        return tied.iloc[0]
    return _break_ties(tied, cfg.tie_break_rules)


def _pick_most_reliable(candidates: pd.DataFrame, cfg: LabelingConfig) -> pd.Series:
    """Highest estimated reliability, then the configured tie-break rules."""
    best = candidates["reliability"].astype(float).max()
    tied = candidates[
        candidates["reliability"].astype(float) >= best - cfg.cost_tolerance
    ]
    if len(tied) == 1:
        return tied.iloc[0]
    return _break_ties(tied, cfg.tie_break_rules)


def _pick_max_robustness(candidates: pd.DataFrame) -> pd.Series:
    """Highest SF, then highest TX power — the conventional 'last resort'."""
    ordered = candidates.sort_values(
        ["sf", "tp_dbm"], ascending=[False, False], kind="mergesort"
    )
    return ordered.iloc[0]


def _break_ties(tied: pd.DataFrame, rules: List[str]) -> pd.Series:
    """Apply the ordered tie-break rules and return the single winner.

    `rules` is validated by LabelingConfig to end in DETERMINISTIC_ID, so this
    always resolves to exactly one row regardless of input ordering.
    """
    sort_cols: List[str] = []
    ascending: List[bool] = []

    for rule in rules:
        if rule == TieBreakRule.LOWER_SF:
            sort_cols.append("sf"); ascending.append(True)
        elif rule == TieBreakRule.HIGHER_SF:
            sort_cols.append("sf"); ascending.append(False)
        elif rule == TieBreakRule.LOWER_TP:
            sort_cols.append("tp_dbm"); ascending.append(True)
        elif rule == TieBreakRule.HIGHER_TP:
            sort_cols.append("tp_dbm"); ascending.append(False)
        elif rule == TieBreakRule.HIGHER_RELIABILITY:
            sort_cols.append("reliability"); ascending.append(False)
        elif rule == TieBreakRule.LOWER_RETRY:
            sort_cols.append("mean_retry"); ascending.append(True)
        elif rule == TieBreakRule.MORE_SAMPLES:
            sort_cols.append("n_packets"); ascending.append(False)
        elif rule == TieBreakRule.DETERMINISTIC_ID:
            sort_cols.extend(["sf", "tp_dbm"]); ascending.extend([True, True])
        else:
            raise ValueError(f"Unknown tie-break rule {rule!r}.")

    ordered = tied.sort_values(sort_cols, ascending=ascending, kind="mergesort")
    return ordered.iloc[0]


def _context_payload_sizes(df: pd.DataFrame, cfg: LabelingConfig) -> Dict[str, int]:
    """Pick one payload size per context, used for every configuration in it.

    Holding payload constant within a context means the energy comparison
    isolates SF and TX power instead of partly measuring payload differences.
    Falls back to `radio.payload_bytes_default` when the column is absent or
    empty for that context.
    """
    default = int(cfg.radio.payload_bytes_default)
    sizes: Dict[str, int] = {}

    for ctx, grp in df.groupby(CONTEXT_ID_COLUMN, sort=False):
        if "payload_bytes" in grp.columns:
            vals = pd.to_numeric(grp["payload_bytes"], errors="coerce").dropna()
            sizes[ctx] = int(round(float(vals.median()))) if len(vals) else default
        else:
            sizes[ctx] = default
    return sizes


def _safe_mean(grp: pd.DataFrame, col: str) -> float:
    if col not in grp.columns:
        return float("nan")
    vals = pd.to_numeric(grp[col], errors="coerce").dropna()
    return float(vals.mean()) if len(vals) else float("nan")


def summarise_labels(labels_df: pd.DataFrame) -> Dict[str, int]:
    """Count contexts by label_status, for logging and test assertions."""
    if labels_df.empty:
        return {status: 0 for status in LabelStatus.ALL}
    counts = labels_df["label_status"].value_counts().to_dict()
    return {status: int(counts.get(status, 0)) for status in LabelStatus.ALL}
