"""
config.py

Checkpoint 3 — Labeling configuration.

Single source of truth for every tunable knob in the labeling framework.
The project's explicit requirement is that the following are CONFIGURABLE,
not hard-coded:

  * reliability threshold
  * candidate SF values
  * candidate TX-power values
  * energy calculation method
  * tie-breaking
  * no-valid-configuration handling

All six live here, plus the radio/airtime parameters and the context
definition they depend on.

DELIBERATELY NOT LOCKED IN
--------------------------
`candidate_sf_values` and `candidate_tp_dbm_values` default to None, which
means "derive the candidate set from whatever configurations actually appear
in the measured data". They are NOT pre-populated with a guessed SF or power
range, because:

  * the legal/limited TX power range depends on the specific SX1278 breakout
    board AND on the regional spectrum regulations that apply at the
    deployment site — neither of which is finalized yet (see
    experiments/DATA_COLLECTION_PLAN.md section 6);
  * pre-populating them would silently bake an unverified assumption into
    every label the framework ever produces.

`sf_sanity_bounds` exists only as a guard against obviously corrupt rows. It
defaults to the same (7, 12) bound already used by the Checkpoint 2 raw
schema, and it too is overridable — some LoRa transceivers support SF5/SF6.

`regulatory_profile` is UNSET by default and is not consulted for any
calculation. It is a place to record the duty-cycle / max-power constraints
once they are confirmed, so that a later checkpoint can enforce them. No
regulatory limit is asserted anywhere in this codebase.

No real or fabricated LoRa measurement data lives in this file.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Enumerated option values (kept as plain strings so they survive JSON config
# round-trips without custom encoders).
# ---------------------------------------------------------------------------

class ContextStrategy:
    """How measured packets are grouped into comparable 'channel contexts'.

    A context is a set of packets believed to have experienced *approximately
    the same* channel conditions, so that different (SF, TP) configurations
    measured inside it can be fairly compared against each other.
    """
    SESSION = "session"                  # one context per (device_id, session_id)
    RSSI_SNR_BIN = "rssi_snr_bin"        # quantise RSSI and SNR into bins
    SESSION_RSSI_SNR_BIN = "session_rssi_snr_bin"   # both of the above
    EXPLICIT_COLUMN = "explicit_column"  # use a column supplied in the CSV

    ALL = (SESSION, RSSI_SNR_BIN, SESSION_RSSI_SNR_BIN, EXPLICIT_COLUMN)


class ReliabilityEstimator:
    """How the reliability (packet delivery ratio) of a configuration is
    estimated from a finite number of measured packets."""
    POINT = "point"                      # successes / attempts
    WILSON_LOWER_BOUND = "wilson_lower_bound"   # conservative lower bound

    ALL = (POINT, WILSON_LOWER_BOUND)


class EnergyMethod:
    """How the energy cost of a configuration is calculated."""

    # Rank by time-on-air only. Depends on SF (and bandwidth/coding rate), not
    # on TX power at all. Requires NO hardware-specific constants. Honest but
    # cannot discriminate between TX power levels.
    AIRTIME_ONLY = "airtime_only"

    # time_on_air * radiated_power_mW, where radiated_power_mW = 10^(dBm/10).
    # Uses only the dBm->mW definition, which is a unit conversion rather than
    # a hardware claim. Ignores both power-amplifier efficiency and the
    # module's fixed baseline current draw, which EXAGGERATES the energy
    # difference between TX power levels and therefore biases labels toward
    # low TX power. See ml/labeling/energy.py for the full caveat.
    AIRTIME_X_LINEAR_POWER = "airtime_x_linear_power"

    # time_on_air * supply_current_mA(tp_dbm) * supply_voltage_v.
    # This is the physically correct method, but it requires a measured or
    # datasheet-sourced current table for the exact module. The table is EMPTY
    # by default and this method raises unless the user supplies one — it will
    # never silently invent hardware numbers.
    MEASURED_CURRENT_TABLE = "measured_current_table"

    ALL = (AIRTIME_ONLY, AIRTIME_X_LINEAR_POWER, MEASURED_CURRENT_TABLE)


class CostBasis:
    """What the energy cost is normalised per."""

    # Energy of a single transmission attempt.
    PER_ATTEMPT = "per_attempt"

    # Energy per *successfully delivered* packet, estimated as
    # energy_per_attempt / reliability. Penalises unreliable configurations,
    # because a lost packet's energy was spent for nothing.
    PER_SUCCESS_PDR = "per_success_pdr"

    # Energy per successfully delivered packet, estimated as
    # energy_per_attempt * (1 + mean_retry_count). Uses the measured retry
    # column instead of inferring attempts from the delivery ratio.
    PER_SUCCESS_RETRIES = "per_success_retries"

    ALL = (PER_ATTEMPT, PER_SUCCESS_PDR, PER_SUCCESS_RETRIES)


class TieBreakRule:
    """Ordered rules applied when two configurations have equal energy cost."""
    LOWER_SF = "lower_sf"                    # prefer faster / shorter airtime
    HIGHER_SF = "higher_sf"                  # prefer more robust
    LOWER_TP = "lower_tp"                    # prefer less radiated power
    HIGHER_TP = "higher_tp"                  # prefer more link margin
    HIGHER_RELIABILITY = "higher_reliability"
    LOWER_RETRY = "lower_retry"
    MORE_SAMPLES = "more_samples"            # prefer the better-evidenced config
    DETERMINISTIC_ID = "deterministic_id"    # final fallback: sort by (sf, tp)

    ALL = (
        LOWER_SF, HIGHER_SF, LOWER_TP, HIGHER_TP,
        HIGHER_RELIABILITY, LOWER_RETRY, MORE_SAMPLES, DETERMINISTIC_ID,
    )


class NoValidConfigPolicy:
    """What to do when NO measured configuration in a context clears the
    reliability threshold (or when the context lacks enough evidence)."""

    # Emit no label. The context is excluded from the training set entirely.
    # Most conservative: never invents a target that evidence doesn't support.
    DROP = "drop"

    # Fall back to the most reliable measured configuration, even though it is
    # below threshold. Flagged in `label_status` so training code can filter,
    # weight, or inspect these rows.
    MOST_RELIABLE = "most_reliable"

    # Fall back to the most robust candidate present (highest SF, then highest
    # TP). Mirrors what a conventional LoRa stack does when a link degrades.
    # Also flagged in `label_status`. NOTE: this is a *heuristic*, not measured
    # evidence of optimality.
    MAX_ROBUSTNESS = "max_robustness"

    # Raise an exception. Useful in CI to catch a data collection run that
    # failed to sweep configurations properly.
    ERROR = "error"

    ALL = (DROP, MOST_RELIABLE, MAX_ROBUSTNESS, ERROR)


class LabelStatus:
    """Provenance flag attached to every emitted label.

    Written into the `label_status` column so that downstream training code in
    a later checkpoint can distinguish evidence-backed labels from fallbacks
    instead of treating them as equally trustworthy.
    """
    OK = "ok"
    BELOW_THRESHOLD_FALLBACK = "below_threshold_fallback"
    MAX_ROBUSTNESS_FALLBACK = "max_robustness_fallback"
    INSUFFICIENT_CONFIG_COVERAGE = "insufficient_config_coverage"
    NO_LABEL = "no_label"

    ALL = (
        OK, BELOW_THRESHOLD_FALLBACK, MAX_ROBUSTNESS_FALLBACK,
        INSUFFICIENT_CONFIG_COVERAGE, NO_LABEL,
    )

    #: Statuses that represent a label actually backed by measured evidence
    #: meeting the configured reliability threshold.
    EVIDENCE_BACKED = (OK,)


# ---------------------------------------------------------------------------
# Radio parameters used by the time-on-air formula.
# ---------------------------------------------------------------------------

@dataclass
class RadioParams:
    """Physical-layer parameters needed to compute LoRa time-on-air.

    These describe how the radio is CONFIGURED during data collection. They
    are not measurements. Defaults correspond to the most common LoRa settings
    and MUST be checked against the actual ESP32 + SX1278 firmware
    configuration before any label produced with them is used for real
    results — a mismatch here silently biases every energy comparison.
    """
    bandwidth_hz: float = 125_000.0
    coding_rate_denominator: int = 5      # 5 => 4/5, 6 => 4/6, 7 => 4/7, 8 => 4/8
    preamble_symbols: int = 8
    explicit_header: bool = True
    crc_enabled: bool = True
    payload_bytes_default: int = 20       # used only if the CSV omits payload_bytes

    #: Low Data Rate Optimization is mandatory when symbol duration is long.
    #: `None` means "decide automatically from symbol time" using
    #: `low_data_rate_optimize_threshold_ms`. Set True/False to force it.
    low_data_rate_optimize: Optional[bool] = None
    low_data_rate_optimize_threshold_ms: float = 16.0

    def validate(self) -> None:
        if self.bandwidth_hz <= 0:
            raise ValueError("RadioParams.bandwidth_hz must be positive.")
        if self.coding_rate_denominator not in (5, 6, 7, 8):
            raise ValueError(
                "RadioParams.coding_rate_denominator must be one of 5, 6, 7, 8 "
                f"(got {self.coding_rate_denominator})."
            )
        if self.preamble_symbols < 0:
            raise ValueError("RadioParams.preamble_symbols must be >= 0.")
        if self.payload_bytes_default < 0:
            raise ValueError("RadioParams.payload_bytes_default must be >= 0.")


@dataclass
class EnergyParams:
    """Parameters for converting a configuration into an energy cost.

    `supply_current_ma_by_tp_dbm` is INTENTIONALLY EMPTY. Populating it with
    plausible-looking numbers would be fabricating hardware data. It must be
    filled from the SX1278 datasheet or, better, from bench measurement of the
    actual board, before EnergyMethod.MEASURED_CURRENT_TABLE can be used.
    """
    supply_voltage_v: float = 3.3

    #: Maps a TX power setting (dBm) to total module supply current (mA).
    #: Empty until real datasheet/bench values are available.
    supply_current_ma_by_tp_dbm: Dict[float, float] = field(default_factory=dict)

    #: If True, interpolate linearly between the two nearest table entries for
    #: a TX power that is not an exact key. If False, an exact key is required.
    interpolate_current_table: bool = True

    def validate(self) -> None:
        if self.supply_voltage_v <= 0:
            raise ValueError("EnergyParams.supply_voltage_v must be positive.")
        for k, v in self.supply_current_ma_by_tp_dbm.items():
            if v <= 0:
                raise ValueError(
                    f"EnergyParams.supply_current_ma_by_tp_dbm[{k}] must be "
                    f"positive (got {v})."
                )


# ---------------------------------------------------------------------------
# Main configuration object.
# ---------------------------------------------------------------------------

@dataclass
class LabelingConfig:
    """Every knob controlling how (SF, TP) training labels are derived."""

    # -- Candidate configuration space (NOT locked in; see module docstring) --
    #: Explicit SF values to consider. None => derive from the measured data.
    candidate_sf_values: Optional[List[int]] = None
    #: Explicit TX power values (dBm) to consider. None => derive from data.
    candidate_tp_dbm_values: Optional[List[float]] = None
    #: Sanity bound used only to reject obviously corrupt SF values.
    sf_sanity_bounds: Tuple[int, int] = (7, 12)
    #: Sanity bound used only to reject obviously corrupt TX power values.
    #: Deliberately wide: the real limit is hardware + region dependent.
    tp_dbm_sanity_bounds: Tuple[float, float] = (-10.0, 30.0)
    #: Free-text record of the confirmed regional constraints. Not used in any
    #: calculation; exists so the assumption is written down rather than
    #: guessed. See experiments/DATA_COLLECTION_PLAN.md.
    regulatory_profile: str = "UNSET"

    # -- Reliability --------------------------------------------------------
    #: A configuration is 'acceptable' if its estimated reliability >= this.
    min_reliability: float = 0.90
    reliability_estimator: str = ReliabilityEstimator.WILSON_LOWER_BOUND
    #: z-score for the Wilson lower bound. 1.645 ~ one-sided 95% confidence.
    wilson_z: float = 1.645
    #: Optional additional constraint on measured retries. None disables it.
    max_mean_retry: Optional[float] = None

    # -- Evidence sufficiency guards ---------------------------------------
    #: A configuration needs at least this many measured packets in a context
    #: before its reliability estimate is trusted at all.
    min_packets_per_config: int = 10
    #: A context must contain at least this many distinct configurations with
    #: sufficient evidence before 'the best one' means anything. With only one
    #: measured configuration, 'best' is vacuous rather than optimal.
    min_configs_per_context: int = 2
    #: A context must contain at least this many packets in total.
    min_packets_per_context: int = 20

    # -- Context definition -------------------------------------------------
    context_strategy: str = ContextStrategy.SESSION_RSSI_SNR_BIN
    #: Width of each RSSI bin in dB (used by the rssi/snr binning strategies).
    rssi_bin_width_db: float = 5.0
    #: Width of each SNR bin in dB.
    snr_bin_width_db: float = 2.5
    #: Column name used when context_strategy == EXPLICIT_COLUMN.
    explicit_context_column: str = "context_id"

    # -- Energy -------------------------------------------------------------
    energy_method: str = EnergyMethod.AIRTIME_X_LINEAR_POWER
    cost_basis: str = CostBasis.PER_SUCCESS_PDR
    radio: RadioParams = field(default_factory=RadioParams)
    energy: EnergyParams = field(default_factory=EnergyParams)

    # -- Tie-breaking -------------------------------------------------------
    #: Applied in order when energy costs are equal (within `cost_tolerance`).
    #: Must end in a deterministic rule so labeling is reproducible.
    tie_break_rules: List[str] = field(default_factory=lambda: [
        TieBreakRule.HIGHER_RELIABILITY,
        TieBreakRule.LOWER_SF,
        TieBreakRule.LOWER_TP,
        TieBreakRule.MORE_SAMPLES,
        TieBreakRule.DETERMINISTIC_ID,
    ])
    #: Relative tolerance for treating two energy costs as equal.
    cost_tolerance: float = 1e-9

    # -- No-valid-configuration handling -----------------------------------
    no_valid_config_policy: str = NoValidConfigPolicy.DROP

    # -- Output -------------------------------------------------------------
    #: If True, rows whose context produced no label are dropped from the
    #: labeled output rather than emitted with empty targets.
    drop_unlabeled_rows: bool = True
    #: Column names for the emitted targets.
    label_sf_column: str = "label_sf"
    label_tp_column: str = "label_tp_dbm"

    # -----------------------------------------------------------------------

    def validate(self) -> None:
        """Raise ValueError on any inconsistent or out-of-range setting."""
        if not 0.0 <= self.min_reliability <= 1.0:
            raise ValueError(
                f"min_reliability must be in [0, 1] (got {self.min_reliability})."
            )
        if self.reliability_estimator not in ReliabilityEstimator.ALL:
            raise ValueError(
                f"reliability_estimator must be one of {ReliabilityEstimator.ALL} "
                f"(got {self.reliability_estimator!r})."
            )
        if self.wilson_z <= 0:
            raise ValueError("wilson_z must be positive.")
        if self.max_mean_retry is not None and self.max_mean_retry < 0:
            raise ValueError("max_mean_retry must be >= 0 or None.")

        if self.min_packets_per_config < 1:
            raise ValueError("min_packets_per_config must be >= 1.")
        if self.min_configs_per_context < 1:
            raise ValueError("min_configs_per_context must be >= 1.")
        if self.min_packets_per_context < 1:
            raise ValueError("min_packets_per_context must be >= 1.")

        if self.context_strategy not in ContextStrategy.ALL:
            raise ValueError(
                f"context_strategy must be one of {ContextStrategy.ALL} "
                f"(got {self.context_strategy!r})."
            )
        if self.rssi_bin_width_db <= 0:
            raise ValueError("rssi_bin_width_db must be positive.")
        if self.snr_bin_width_db <= 0:
            raise ValueError("snr_bin_width_db must be positive.")

        if self.energy_method not in EnergyMethod.ALL:
            raise ValueError(
                f"energy_method must be one of {EnergyMethod.ALL} "
                f"(got {self.energy_method!r})."
            )
        if self.cost_basis not in CostBasis.ALL:
            raise ValueError(
                f"cost_basis must be one of {CostBasis.ALL} "
                f"(got {self.cost_basis!r})."
            )
        if self.energy_method == EnergyMethod.MEASURED_CURRENT_TABLE and not \
                self.energy.supply_current_ma_by_tp_dbm:
            raise ValueError(
                "energy_method='measured_current_table' requires "
                "energy.supply_current_ma_by_tp_dbm to be populated with real "
                "datasheet or bench-measured values for the specific SX1278 "
                "board. It is empty by default on purpose: this framework will "
                "not invent hardware current figures. Either populate it or "
                "choose energy_method='airtime_only' / "
                "'airtime_x_linear_power'."
            )

        if not self.tie_break_rules:
            raise ValueError("tie_break_rules must not be empty.")
        for rule in self.tie_break_rules:
            if rule not in TieBreakRule.ALL:
                raise ValueError(
                    f"Unknown tie-break rule {rule!r}; must be one of "
                    f"{TieBreakRule.ALL}."
                )
        if self.tie_break_rules[-1] != TieBreakRule.DETERMINISTIC_ID:
            raise ValueError(
                "tie_break_rules must end with "
                f"{TieBreakRule.DETERMINISTIC_ID!r} so that labeling is "
                "reproducible run-to-run."
            )
        if self.cost_tolerance < 0:
            raise ValueError("cost_tolerance must be >= 0.")

        if self.no_valid_config_policy not in NoValidConfigPolicy.ALL:
            raise ValueError(
                f"no_valid_config_policy must be one of "
                f"{NoValidConfigPolicy.ALL} (got {self.no_valid_config_policy!r})."
            )

        lo_sf, hi_sf = self.sf_sanity_bounds
        if lo_sf > hi_sf:
            raise ValueError("sf_sanity_bounds must be (low, high) with low <= high.")
        lo_tp, hi_tp = self.tp_dbm_sanity_bounds
        if lo_tp > hi_tp:
            raise ValueError("tp_dbm_sanity_bounds must be (low, high) with low <= high.")

        if self.candidate_sf_values is not None:
            if not self.candidate_sf_values:
                raise ValueError(
                    "candidate_sf_values must be None (derive from data) or a "
                    "non-empty list."
                )
            for sf in self.candidate_sf_values:
                if not lo_sf <= sf <= hi_sf:
                    raise ValueError(
                        f"candidate SF {sf} falls outside sf_sanity_bounds "
                        f"{self.sf_sanity_bounds}. Widen the bounds if this "
                        f"transceiver genuinely supports it."
                    )
        if self.candidate_tp_dbm_values is not None:
            if not self.candidate_tp_dbm_values:
                raise ValueError(
                    "candidate_tp_dbm_values must be None (derive from data) "
                    "or a non-empty list."
                )
            for tp in self.candidate_tp_dbm_values:
                if not lo_tp <= tp <= hi_tp:
                    raise ValueError(
                        f"candidate TX power {tp} dBm falls outside "
                        f"tp_dbm_sanity_bounds {self.tp_dbm_sanity_bounds}."
                    )

        self.radio.validate()
        self.energy.validate()

    # -- Serialisation ------------------------------------------------------

    def to_dict(self) -> dict:
        d = asdict(self)
        # asdict leaves tuples as tuples; JSON turns them into lists anyway.
        d["sf_sanity_bounds"] = list(self.sf_sanity_bounds)
        d["tp_dbm_sanity_bounds"] = list(self.tp_dbm_sanity_bounds)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "LabelingConfig":
        data = dict(data)
        radio_data = data.pop("radio", None)
        energy_data = data.pop("energy", None)

        known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
        unknown = [k for k in data if k not in known]
        if unknown:
            raise ValueError(
                f"Unknown LabelingConfig option(s): {unknown}. Known options: "
                f"{sorted(known)}"
            )

        if "sf_sanity_bounds" in data and data["sf_sanity_bounds"] is not None:
            data["sf_sanity_bounds"] = tuple(data["sf_sanity_bounds"])
        if "tp_dbm_sanity_bounds" in data and data["tp_dbm_sanity_bounds"] is not None:
            data["tp_dbm_sanity_bounds"] = tuple(data["tp_dbm_sanity_bounds"])

        cfg = cls(**data)
        if radio_data is not None:
            cfg.radio = RadioParams(**radio_data)
        if energy_data is not None:
            energy_data = dict(energy_data)
            table = energy_data.get("supply_current_ma_by_tp_dbm") or {}
            # JSON object keys are strings; convert back to floats.
            energy_data["supply_current_ma_by_tp_dbm"] = {
                float(k): float(v) for k, v in table.items()
            }
            cfg.energy = EnergyParams(**energy_data)
        return cfg

    @classmethod
    def from_json_file(cls, path: str | Path) -> "LabelingConfig":
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))

    def to_json_file(self, path: str | Path) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2, sort_keys=False)
            fh.write("\n")


def resolve_candidate_configs(
    cfg: LabelingConfig,
    observed_sf: Sequence[int],
    observed_tp: Sequence[float],
) -> Tuple[List[int], List[float]]:
    """Work out which (SF, TP) values the labeler is allowed to choose from.

    If the config pins explicit candidate lists, those win. Otherwise the
    candidates are derived from what was actually measured — which keeps the
    framework honest: it can only ever pick a configuration that real data
    exists for.

    Values outside the sanity bounds are excluded and reported by the caller.
    """
    lo_sf, hi_sf = cfg.sf_sanity_bounds
    lo_tp, hi_tp = cfg.tp_dbm_sanity_bounds

    if cfg.candidate_sf_values is not None:
        sf_candidates = sorted({int(s) for s in cfg.candidate_sf_values})
    else:
        sf_candidates = sorted({
            int(s) for s in observed_sf if lo_sf <= int(s) <= hi_sf
        })

    if cfg.candidate_tp_dbm_values is not None:
        tp_candidates = sorted({float(t) for t in cfg.candidate_tp_dbm_values})
    else:
        tp_candidates = sorted({
            float(t) for t in observed_tp if lo_tp <= float(t) <= hi_tp
        })

    return sf_candidates, tp_candidates
