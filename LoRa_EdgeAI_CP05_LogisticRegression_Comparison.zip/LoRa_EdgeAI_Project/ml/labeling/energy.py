"""
energy.py

Checkpoint 3 — Pluggable energy cost models.

The labeling rule is "among the configurations that met the reliability
threshold under these channel conditions, pick the cheapest one". This module
defines what "cheapest" means, and makes that choice configurable rather than
baked in, because the three available methods differ in how much
hardware-specific knowledge they require:

  airtime_only
      Cost = time-on-air. Requires no hardware constants at all. Usable today.
      Cannot distinguish TX power levels, since airtime does not depend on
      TX power — so TP labels fall entirely to the tie-break rules.

  airtime_x_linear_power   (default)
      Cost = time-on-air * 10^(tp_dbm/10) mW. The dBm -> mW step is a unit
      definition, not a hardware claim, so this stays honest while still
      discriminating TX power.

      KNOWN BIAS: it models only RADIATED power. A real module also draws a
      substantial fixed baseline current (oscillator, digital logic, receive
      chain) that does not scale with TX power, and its power amplifier has
      finite efficiency. Ignoring both EXAGGERATES the energy difference
      between TX power levels — dropping from 14 dBm to 2 dBm looks like a
      ~16x saving here, while in reality the supply current may fall by well
      under 2x. Consequence: this method is biased toward labelling low TX
      power as optimal. Treat its output as an ordering heuristic, and switch
      to measured_current_table before quoting any energy figure as a result.

  measured_current_table
      Cost = time-on-air * supply_current_mA(tp_dbm) * supply_voltage_V.
      Physically correct and the method that should eventually be used for
      final results. Requires a real current table for the specific SX1278
      board, from the datasheet or bench measurement. The table is EMPTY by
      default and this method raises a clear error rather than substituting
      invented numbers.

No real or fabricated LoRa measurement data lives in this file. In
particular, `EnergyParams.supply_current_ma_by_tp_dbm` ships empty on
purpose.
"""

from __future__ import annotations

from typing import Optional

from .airtime import time_on_air_s
from .config import (
    CostBasis,
    EnergyMethod,
    EnergyParams,
    LabelingConfig,
    RadioParams,
)


class EnergyModelError(RuntimeError):
    """Raised when an energy model cannot be evaluated as configured."""


def dbm_to_mw(dbm: float) -> float:
    """Convert dBm to milliwatts. This is a unit definition: P_mW = 10^(dBm/10)."""
    return 10.0 ** (dbm / 10.0)


def _lookup_supply_current_ma(tp_dbm: float, params: EnergyParams) -> float:
    """Look up module supply current for a TX power from the measured table."""
    table = params.supply_current_ma_by_tp_dbm
    if not table:
        raise EnergyModelError(
            "energy_method='measured_current_table' was selected but "
            "energy.supply_current_ma_by_tp_dbm is empty. This framework will "
            "not invent supply-current figures for the SX1278. Populate the "
            "table from the datasheet or from bench measurement of the actual "
            "board, or switch to energy_method='airtime_only' or "
            "'airtime_x_linear_power'."
        )

    if tp_dbm in table:
        return table[tp_dbm]

    keys = sorted(table)
    if not params.interpolate_current_table:
        raise EnergyModelError(
            f"No supply-current entry for tp_dbm={tp_dbm} and "
            f"interpolate_current_table is False. Known entries: {keys}."
        )

    if tp_dbm < keys[0] or tp_dbm > keys[-1]:
        raise EnergyModelError(
            f"tp_dbm={tp_dbm} is outside the measured supply-current table "
            f"range [{keys[0]}, {keys[-1]}]. Extrapolating beyond measured "
            f"data would be fabrication; extend the table instead."
        )

    lower = max(k for k in keys if k <= tp_dbm)
    upper = min(k for k in keys if k >= tp_dbm)
    if lower == upper:
        return table[lower]
    span = upper - lower
    weight = (tp_dbm - lower) / span
    return table[lower] + weight * (table[upper] - table[lower])


def energy_per_attempt(
    sf: int,
    tp_dbm: float,
    payload_bytes: int,
    method: str,
    radio: RadioParams,
    params: EnergyParams,
) -> float:
    """Cost of ONE transmission attempt at this configuration.

    Units depend on the method and are only ever compared against other
    configurations evaluated with the same method, so the absolute unit does
    not matter for label selection:
      * airtime_only              -> seconds
      * airtime_x_linear_power    -> millijoule-equivalent (mW * s)
      * measured_current_table    -> millijoules (mA * V * s)
    """
    toa_s = time_on_air_s(sf, payload_bytes, radio)

    if method == EnergyMethod.AIRTIME_ONLY:
        return toa_s

    if method == EnergyMethod.AIRTIME_X_LINEAR_POWER:
        return toa_s * dbm_to_mw(tp_dbm)

    if method == EnergyMethod.MEASURED_CURRENT_TABLE:
        current_ma = _lookup_supply_current_ma(tp_dbm, params)
        return toa_s * current_ma * params.supply_voltage_v

    raise EnergyModelError(
        f"Unknown energy method {method!r}; expected one of {EnergyMethod.ALL}."
    )


def apply_cost_basis(
    attempt_energy: float,
    cost_basis: str,
    reliability: Optional[float],
    mean_retry: Optional[float],
) -> float:
    """Normalise a per-attempt energy into the configured cost basis.

    `per_success_*` bases penalise unreliable configurations, on the reasoning
    that energy spent on a packet that never arrived was wasted. Which of the
    two estimates is more appropriate depends on how the firmware actually
    counts retries — a decision recorded in the data collection plan rather
    than assumed here.
    """
    if cost_basis == CostBasis.PER_ATTEMPT:
        return attempt_energy

    if cost_basis == CostBasis.PER_SUCCESS_PDR:
        if reliability is None:
            raise EnergyModelError(
                "cost_basis='per_success_pdr' requires a reliability estimate."
            )
        if reliability <= 0.0:
            return float("inf")   # never delivers: infinite energy per success
        return attempt_energy / reliability

    if cost_basis == CostBasis.PER_SUCCESS_RETRIES:
        if mean_retry is None:
            raise EnergyModelError(
                "cost_basis='per_success_retries' requires a mean retry count."
            )
        if mean_retry < 0:
            raise EnergyModelError(
                f"mean_retry must be >= 0 (got {mean_retry})."
            )
        return attempt_energy * (1.0 + mean_retry)

    raise EnergyModelError(
        f"Unknown cost basis {cost_basis!r}; expected one of {CostBasis.ALL}."
    )


def config_energy_cost(
    sf: int,
    tp_dbm: float,
    payload_bytes: int,
    reliability: Optional[float],
    mean_retry: Optional[float],
    cfg: LabelingConfig,
) -> float:
    """Full energy cost of a configuration under the given LabelingConfig."""
    attempt = energy_per_attempt(
        sf=sf,
        tp_dbm=tp_dbm,
        payload_bytes=payload_bytes,
        method=cfg.energy_method,
        radio=cfg.radio,
        params=cfg.energy,
    )
    return apply_cost_basis(
        attempt_energy=attempt,
        cost_basis=cfg.cost_basis,
        reliability=reliability,
        mean_retry=mean_retry,
    )


def energy_units(method: str) -> str:
    """Human-readable unit label for a method, for reports and CSV headers."""
    return {
        EnergyMethod.AIRTIME_ONLY: "s (time-on-air)",
        EnergyMethod.AIRTIME_X_LINEAR_POWER: "mW*s (radiated, PA efficiency ignored)",
        EnergyMethod.MEASURED_CURRENT_TABLE: "mJ (supply energy)",
    }.get(method, "unknown")
