# `ml/labeling/` — Target-Label Framework (Checkpoint 3)

This package derives supervised **(SF, TP)** training targets from *measured*
LoRa link evidence. It does not train a model, and it contains no real or
fabricated measurement data.

**Read `experiments/LABELING_STRATEGY.md` first.** It explains why the logged
`sf` / `tp_dbm` columns cannot be used as labels, and what the data collection
protocol must guarantee for anything here to be valid.

---

## 1. Module map

| File | Responsibility |
|---|---|
| `config.py` | `LabelingConfig` — every tunable knob, plus validation and JSON round-tripping |
| `context.py` | Groups packets into comparable channel contexts |
| `reliability.py` | Estimates a configuration's delivery reliability from finite samples |
| `airtime.py` | LoRa time-on-air formula (published Semtech SX127x formula) |
| `energy.py` | Pluggable energy cost models |
| `oracle.py` | Builds the per-(context, SF, TP) evidence table and selects one label per context |
| `labeler.py` | Orchestration + CLI |
| `labeling_config.example.json` | A starting config file (identical to the code defaults) |

---

## 2. Quick start

```bash
# Dump the effective configuration
python -m ml.labeling.labeler --print-config

# Write a fresh default config to edit
python -m ml.labeling.labeler --write-default-config my_labeling_config.json

# Run labeling (once real processed data exists)
python -m ml.labeling.labeler \
    --input data/processed/<session>_processed.csv \
    --output data/processed/<session>_labeled.csv \
    --config ml/labeling/labeling_config.example.json
```

Three files are produced:

- `<output>` — per-packet rows with `context_id`, `label_sf`, `label_tp_dbm`,
  `label_status`, `selection_reason` attached
- `<output>_oracle.csv` — the measured evidence table, one row per
  (context, SF, TP). This is the audit trail: every label can be traced back
  to the packet counts that produced it.
- `<output>_labels.csv` — one chosen label per context

---

## 3. The six required knobs

The project requires these to be configurable rather than hard-coded. All six
live in `LabelingConfig`.

### 3.1 Reliability threshold → `min_reliability`

Default `0.90`. A configuration is eligible to be a label only if its
*estimated* reliability reaches this.

Related:

- `reliability_estimator` — `"wilson_lower_bound"` (default) or `"point"`.
  The Wilson lower bound discounts thin evidence, so a configuration measured
  5 times cannot beat one measured 500 times on the strength of a lucky run.
  At a 100% observed delivery ratio the bound is exactly `n / (n + z²)`, so
  with the default `z = 1.645` a configuration needs **≥ 25 packets** to clear
  a 0.90 threshold even if it never dropped one.
- `wilson_z` — 1.645 ≈ one-sided 95%; 1.282 ≈ 90%; 2.326 ≈ 99%.
- `max_mean_retry` — optional extra constraint on measured retries. `null`
  disables it.

### 3.2 Candidate SF values → `candidate_sf_values`

Default `null`, meaning **derive from whatever the data actually contains**.
Deliberately not pre-filled — see section 5.

`sf_sanity_bounds` (default `[7, 12]`) only rejects corrupt rows and is itself
overridable, since some transceivers support SF5/SF6.

### 3.3 Candidate TX power values → `candidate_tp_dbm_values`

Default `null`, same reasoning. `tp_dbm_sanity_bounds` defaults to a
deliberately wide `[-10, 30]` dBm because the real limit depends on the board
*and* on regional regulations that are not finalized.

### 3.4 Energy calculation method → `energy_method`

| Value | Cost | Hardware constants needed |
|---|---|---|
| `airtime_only` | time-on-air | none |
| `airtime_x_linear_power` *(default)* | time-on-air × 10^(dBm/10) mW | none |
| `measured_current_table` | time-on-air × current(dBm) × voltage | a real current table |

`cost_basis` then normalises that per-attempt figure:

- `per_attempt` — raw energy of one transmission
- `per_success_pdr` *(default)* — divided by reliability, so energy spent on
  undelivered packets counts against a configuration
- `per_success_retries` — multiplied by `(1 + mean_retry_count)`

**Two cautions.** `airtime_only` cannot discriminate TX power at all, because
airtime does not depend on it — TP selection falls entirely to the tie-break
rules. And `airtime_x_linear_power` models only radiated power, ignoring the
module's fixed baseline current and its PA efficiency; it therefore
*exaggerates* the saving from lowering TX power and is biased toward
low-power labels. Switch to `measured_current_table` before quoting any energy
number as a result. That table is empty by default and the method raises
rather than substituting invented figures.

### 3.5 Tie-breaking → `tie_break_rules`

An ordered list applied when energy costs are equal within `cost_tolerance`.
Available rules: `higher_reliability`, `lower_sf`, `higher_sf`, `lower_tp`,
`higher_tp`, `lower_retry`, `more_samples`, `deterministic_id`.

The list **must end in `deterministic_id`** (validated), so labeling is
reproducible regardless of row ordering.

### 3.6 No-valid-configuration handling → `no_valid_config_policy`

| Value | Behaviour | `label_status` |
|---|---|---|
| `drop` *(default)* | emit no label; the context is excluded | `no_label` |
| `most_reliable` | fall back to the best-measured configuration anyway | `below_threshold_fallback` |
| `max_robustness` | fall back to highest SF, then highest TP | `max_robustness_fallback` |
| `error` | raise `NoValidConfigurationError` | — |

`drop` is the default because it never invents a target that evidence does not
support. The cost is that the model then sees no examples of genuinely bad
conditions. If you switch to a fallback, the `label_status` column marks those
rows so a later checkpoint can filter, down-weight, or inspect them —
`LabelStatus.EVIDENCE_BACKED` lists the statuses that are fully evidence-backed.

`label_status` answers "is this row trainable?"; `selection_reason` carries the
full human-readable explanation, including *why* a context was dropped.

---

## 4. Evidence sufficiency guards

Three additional guards stop the framework from producing confident-looking
labels from thin data:

- `min_packets_per_config` (default 10) — below this, a configuration's
  reliability estimate is not trusted at all.
- `min_configs_per_context` (default 2) — a context needs at least this many
  well-evidenced configurations before "the best one" means anything. With a
  single measured configuration, "best" is vacuously true, not optimal. **This
  is what makes a configuration sweep a hard requirement of data collection.**
- `min_packets_per_context` (default 20) — total packets in a context.

Raise all three well above their defaults once real session sizes are known;
the defaults are floors for the code to be testable, not recommended values.

---

## 5. What is deliberately NOT decided here

`candidate_sf_values`, `candidate_tp_dbm_values` and `regulatory_profile` are
unset on purpose. The usable SF set and the legal/achievable TX power set
depend on the specific SX1278 breakout board and on the spectrum rules that
apply at the deployment site, neither of which is finalized (see
`experiments/DATA_COLLECTION_PLAN.md` section 6). Pre-filling them with
plausible-looking values would bake an unverified assumption into every label
the framework ever produces.

`regulatory_profile` is a free-text field that no calculation reads. It exists
so the constraint gets written down once confirmed, instead of being assumed.
No regulatory limit is asserted anywhere in this codebase.

---

## 6. Train/test splitting — important

A label is a property of a **context**, not of an individual packet, so many
rows share one label. Splitting randomly by row puts rows from the same
context on both sides of the split and inflates the apparent score.

Split by `context_id` instead — e.g. scikit-learn's `GroupKFold` or
`GroupShuffleSplit` with `groups=context_id`. The `context_id` column is
written into the labeled output for exactly this purpose. See
`experiments/LABELING_STRATEGY.md` section 7 for the related leakage caveat.
