"""
context.py

Checkpoint 3 — Channel context definition.

A "context" is a set of measured packets believed to have experienced
approximately the same channel conditions. Contexts are the unit inside which
different (SF, TP) configurations are compared, so the context definition is
the single most consequential assumption in the whole labeling framework:

  * too coarse  -> configurations measured under genuinely different
                   conditions get compared, and the "best" configuration is
                   an artefact of when each one happened to be measured;
  * too fine    -> each context holds too few configurations to compare, and
                   almost everything fails the evidence-sufficiency guards.

Because there is no way to pick this correctly without real data, the
strategy is configurable and every strategy records which columns it used, so
the choice is visible in the output rather than implicit.

Strategies
----------
  session
      One context per (device_id, session_id). Assumes each collection
      session holds conditions roughly constant while sweeping SF/TP.
      Matches the session structure in experiments/DATA_COLLECTION_PLAN.md.

  rssi_snr_bin
      Quantise measured RSSI and SNR into bins. Groups packets by observed
      channel quality regardless of which session they came from, so evidence
      from different sessions at similar link quality can be pooled.
      Caveat: RSSI/SNR are themselves partly a *consequence* of the chosen
      configuration, so this strategy is not perfectly neutral — see
      experiments/LABELING_STRATEGY.md.

  session_rssi_snr_bin   (default)
      Both. Conservative: never pools across sessions, but still separates
      distinct link qualities within a long or mobile session.

  explicit_column
      Use a context id supplied directly in the CSV. For when the collection
      protocol already records a controlled condition label per row.

No real or fabricated LoRa measurement data lives in this file.
"""

from __future__ import annotations

import math
from typing import List, Tuple

import pandas as pd

from .config import ContextStrategy, LabelingConfig

#: Name of the column this module writes the computed context key into.
CONTEXT_ID_COLUMN = "context_id"


def _bin_index(value: float, width: float) -> int:
    """Map a continuous value onto a bin index of the given width."""
    if width <= 0:
        raise ValueError(f"bin width must be positive (got {width}).")
    return int(math.floor(value / width))


def _bin_label(value: float, width: float) -> str:
    """Human-readable bin label, e.g. '-95.0:-90.0' for an RSSI bin."""
    idx = _bin_index(value, width)
    lo = idx * width
    hi = lo + width
    return f"{lo:g}:{hi:g}"


def assign_contexts(
    df: pd.DataFrame,
    cfg: LabelingConfig,
) -> Tuple[pd.DataFrame, List[str]]:
    """Add a `context_id` column to `df` according to the configured strategy.

    Returns (new_dataframe, source_columns_used). Does not mutate the input.
    """
    strategy = cfg.context_strategy
    out = df.copy()

    if strategy == ContextStrategy.SESSION:
        source_cols = ["device_id", "session_id"]
        _require_columns(out, source_cols, strategy)
        out[CONTEXT_ID_COLUMN] = (
            out["device_id"].astype(str) + "|" + out["session_id"].astype(str)
        )
        return out, source_cols

    if strategy == ContextStrategy.RSSI_SNR_BIN:
        source_cols = ["rssi_dbm", "snr_db"]
        _require_columns(out, source_cols, strategy)
        out[CONTEXT_ID_COLUMN] = (
            "rssi[" + out["rssi_dbm"].map(
                lambda v: _bin_label(v, cfg.rssi_bin_width_db)
            ) + "]|snr[" + out["snr_db"].map(
                lambda v: _bin_label(v, cfg.snr_bin_width_db)
            ) + "]"
        )
        return out, source_cols

    if strategy == ContextStrategy.SESSION_RSSI_SNR_BIN:
        source_cols = ["device_id", "session_id", "rssi_dbm", "snr_db"]
        _require_columns(out, source_cols, strategy)
        out[CONTEXT_ID_COLUMN] = (
            out["device_id"].astype(str) + "|"
            + out["session_id"].astype(str) + "|rssi["
            + out["rssi_dbm"].map(lambda v: _bin_label(v, cfg.rssi_bin_width_db))
            + "]|snr["
            + out["snr_db"].map(lambda v: _bin_label(v, cfg.snr_bin_width_db))
            + "]"
        )
        return out, source_cols

    if strategy == ContextStrategy.EXPLICIT_COLUMN:
        col = cfg.explicit_context_column
        if col not in out.columns:
            raise ValueError(
                f"context_strategy='explicit_column' requires a column named "
                f"{col!r} in the input data, but the available columns are "
                f"{list(out.columns)}. Either add that column during data "
                f"collection or choose a different context_strategy."
            )
        if out[col].isna().any():
            raise ValueError(
                f"Context column {col!r} contains missing values; every row "
                f"must belong to a context."
            )
        out[CONTEXT_ID_COLUMN] = out[col].astype(str)
        return out, [col]

    raise ValueError(
        f"Unknown context_strategy {strategy!r}; expected one of "
        f"{ContextStrategy.ALL}."
    )


def _require_columns(df: pd.DataFrame, cols: List[str], strategy: str) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(
            f"context_strategy={strategy!r} requires column(s) {missing}, "
            f"which are absent from the input. Available columns: "
            f"{list(df.columns)}."
        )


def describe_strategy(cfg: LabelingConfig) -> str:
    """One-line description of the active context strategy, for reports."""
    if cfg.context_strategy == ContextStrategy.SESSION:
        return "one context per (device_id, session_id)"
    if cfg.context_strategy == ContextStrategy.RSSI_SNR_BIN:
        return (
            f"RSSI binned at {cfg.rssi_bin_width_db} dB, "
            f"SNR binned at {cfg.snr_bin_width_db} dB"
        )
    if cfg.context_strategy == ContextStrategy.SESSION_RSSI_SNR_BIN:
        return (
            f"(device_id, session_id) x RSSI bins of {cfg.rssi_bin_width_db} dB "
            f"x SNR bins of {cfg.snr_bin_width_db} dB"
        )
    if cfg.context_strategy == ContextStrategy.EXPLICIT_COLUMN:
        return f"context id taken from column {cfg.explicit_context_column!r}"
    return "unknown"
