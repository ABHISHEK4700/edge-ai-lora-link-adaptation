"""
reliability.py

Checkpoint 3 — Reliability estimation for a measured configuration.

The labeling rule needs to answer "did this (SF, TP) configuration deliver
packets reliably enough under these channel conditions?". That question is
answered from a FINITE number of measured packets, so the estimate carries
sampling uncertainty that the framework should not pretend away.

Two estimators are provided:

  point
      successes / attempts. Simple and unbiased, but optimistic on small
      samples: 5 successes out of 5 reads as 100% reliable, which is weak
      evidence that the configuration is genuinely reliable.

  wilson_lower_bound   (default)
      The lower end of the Wilson score interval for a binomial proportion.
      It answers "what delivery ratio can this configuration be confident of,
      given this many samples?". A configuration measured only a handful of
      times scores lower than one measured hundreds of times with the same
      raw ratio, so thin evidence cannot win a label by luck.

The Wilson score interval is a standard published statistical method for
binomial proportion confidence intervals; using it here is a modelling
choice, not a measurement.

No real or fabricated LoRa measurement data lives in this file.
"""

from __future__ import annotations

import math

from .config import ReliabilityEstimator


def point_estimate(successes: int, attempts: int) -> float:
    """Plain success ratio. Returns 0.0 when there are no attempts."""
    _check(successes, attempts)
    if attempts == 0:
        return 0.0
    return successes / attempts


def wilson_lower_bound(successes: int, attempts: int, z: float = 1.645) -> float:
    """Lower bound of the Wilson score interval for a binomial proportion.

        centre = p_hat + z^2 / (2n)
        margin = z * sqrt( p_hat*(1 - p_hat)/n + z^2 / (4n^2) )
        lower  = (centre - margin) / (1 + z^2/n)

    `z` selects the confidence level: 1.645 corresponds to a one-sided 95%
    bound, 1.282 to one-sided 90%, 2.326 to one-sided 99%. Returns 0.0 when
    there are no attempts.
    """
    _check(successes, attempts)
    if z <= 0:
        raise ValueError(f"z must be positive (got {z}).")
    if attempts == 0:
        return 0.0

    n = float(attempts)
    p_hat = successes / n
    z2 = z * z

    centre = p_hat + z2 / (2.0 * n)
    margin = z * math.sqrt((p_hat * (1.0 - p_hat) / n) + (z2 / (4.0 * n * n)))
    lower = (centre - margin) / (1.0 + z2 / n)

    # Clamp: floating-point error can push the result a hair outside [0, 1].
    return min(1.0, max(0.0, lower))


def estimate_reliability(
    successes: int,
    attempts: int,
    estimator: str = ReliabilityEstimator.WILSON_LOWER_BOUND,
    z: float = 1.645,
) -> float:
    """Dispatch to the configured reliability estimator."""
    if estimator == ReliabilityEstimator.POINT:
        return point_estimate(successes, attempts)
    if estimator == ReliabilityEstimator.WILSON_LOWER_BOUND:
        return wilson_lower_bound(successes, attempts, z=z)
    raise ValueError(
        f"Unknown reliability estimator {estimator!r}; expected one of "
        f"{ReliabilityEstimator.ALL}."
    )


def _check(successes: int, attempts: int) -> None:
    if attempts < 0:
        raise ValueError(f"attempts must be >= 0 (got {attempts}).")
    if successes < 0:
        raise ValueError(f"successes must be >= 0 (got {successes}).")
    if successes > attempts:
        raise ValueError(
            f"successes ({successes}) cannot exceed attempts ({attempts})."
        )
