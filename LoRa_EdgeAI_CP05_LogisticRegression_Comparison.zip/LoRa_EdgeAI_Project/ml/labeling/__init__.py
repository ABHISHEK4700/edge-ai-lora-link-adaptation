"""
ml.labeling — Checkpoint 3: Target-label strategy and labeling framework.

This package turns *measured* LoRa link evidence into supervised training
targets (SF, TP). It does NOT train a model, and it contains NO real or
fabricated measurement data.

Read experiments/LABELING_STRATEGY.md first — it explains WHY labels must be
derived from measured evidence rather than copied from the logged SF/TP
column, and what the data collection protocol must guarantee for the
labeling to be valid.

Public entry points:
    LabelingConfig          — every tunable knob (config.py)
    build_oracle_table()    — per-context, per-configuration evidence table
    select_labels()         — choose one (SF, TP) label per context
    run_labeling()          — full CSV -> oracle table + labeled rows (labeler.py)
"""

from .config import (
    LabelingConfig,
    LabelStatus,
    NoValidConfigPolicy,
    CostBasis,
    ReliabilityEstimator,
)
from .oracle import build_oracle_table, select_labels


def __getattr__(name):
    """Lazily expose labeler.py's entry points (PEP 562).

    Importing them eagerly here would put `ml.labeling.labeler` into
    sys.modules as a side effect of importing the package, which makes
    `python -m ml.labeling.labeler` emit a RuntimeWarning about the module
    being re-executed. Resolving them on first access keeps
    `from ml.labeling import run_labeling` working while leaving the CLI
    invocation clean.
    """
    if name in ("run_labeling", "attach_labels"):
        from . import labeler
        return getattr(labeler, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "LabelingConfig",
    "LabelStatus",
    "NoValidConfigPolicy",
    "CostBasis",
    "ReliabilityEstimator",
    "build_oracle_table",
    "select_labels",
    "run_labeling",
    "attach_labels",
]
