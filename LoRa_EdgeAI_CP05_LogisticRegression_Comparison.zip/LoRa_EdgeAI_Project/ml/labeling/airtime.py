"""
airtime.py

Checkpoint 3 — LoRa time-on-air (airtime) calculation.

Implements the standard published LoRa airtime formula so that the energy
cost of a (SF, TP) configuration can be computed analytically instead of
guessed.

PROVENANCE AND CAVEAT
---------------------
This is the widely-used LoRa modem airtime formula documented by Semtech for
the SX127x family (the SX1278 is in that family). It is a *deterministic
formula*, not measured data and not a research result — given SF, bandwidth,
coding rate, preamble length, payload size and header/CRC settings, it
returns the symbol arithmetic the modem performs.

Before any number produced here is used in a report or a final result:

  * verify the formula and its constants against the datasheet revision for
    the exact SX1278 breakout board being used, and
  * verify the `RadioParams` values match what the ESP32 firmware actually
    configures on the radio.

A mismatch in bandwidth or coding rate silently scales every airtime figure,
which in turn silently biases every energy comparison and therefore every
label. This module deliberately makes those parameters explicit and
configurable rather than assuming them.

No real or fabricated LoRa measurement data lives in this file.
"""

from __future__ import annotations

import math

from .config import RadioParams


def symbol_time_s(sf: int, bandwidth_hz: float) -> float:
    """Duration of one LoRa symbol, in seconds.

        T_sym = 2^SF / BW
    """
    if sf <= 0:
        raise ValueError(f"sf must be positive (got {sf}).")
    if bandwidth_hz <= 0:
        raise ValueError(f"bandwidth_hz must be positive (got {bandwidth_hz}).")
    return (2.0 ** sf) / bandwidth_hz


def _resolve_low_data_rate_optimize(
    sf: int, radio: RadioParams
) -> bool:
    """Decide whether Low Data Rate Optimization (LDRO) applies.

    LDRO is required when the symbol duration becomes long enough that clock
    drift over a symbol becomes significant. If `radio.low_data_rate_optimize`
    is explicitly True or False, that choice is honoured; otherwise it is
    derived by comparing symbol time against
    `radio.low_data_rate_optimize_threshold_ms`.

    The firmware's actual LDRO setting takes precedence over this inference —
    set the flag explicitly once it is known.
    """
    if radio.low_data_rate_optimize is not None:
        return bool(radio.low_data_rate_optimize)
    t_sym_ms = symbol_time_s(sf, radio.bandwidth_hz) * 1000.0
    return t_sym_ms >= radio.low_data_rate_optimize_threshold_ms


def time_on_air_s(
    sf: int,
    payload_bytes: int,
    radio: RadioParams,
) -> float:
    """Total time-on-air of one LoRa packet, in seconds.

        T_preamble = (n_preamble + 4.25) * T_sym

        payloadSymbNb = 8 + max(
            ceil( (8*PL - 4*SF + 28 + 16*CRC - 20*IH)
                  / (4 * (SF - 2*DE)) ) * (CR + 4),
            0 )

        T_payload = payloadSymbNb * T_sym
        T_packet  = T_preamble + T_payload

    where
        PL  = payload length in bytes
        SF  = spreading factor
        CRC = 1 if CRC enabled else 0
        IH  = 1 if implicit header (header disabled) else 0
        DE  = 1 if low data rate optimization enabled else 0
        CR  = coding rate denominator - 4, i.e. 1..4 for 4/5..4/8
    """
    radio.validate()
    if payload_bytes < 0:
        raise ValueError(f"payload_bytes must be >= 0 (got {payload_bytes}).")

    t_sym = symbol_time_s(sf, radio.bandwidth_hz)

    de = 1 if _resolve_low_data_rate_optimize(sf, radio) else 0
    ih = 0 if radio.explicit_header else 1
    crc = 1 if radio.crc_enabled else 0
    cr = radio.coding_rate_denominator - 4      # 1..4

    denominator = 4 * (sf - 2 * de)
    if denominator <= 0:
        raise ValueError(
            f"Invalid combination: sf={sf} with low-data-rate-optimize={de} "
            f"gives a non-positive denominator in the airtime formula."
        )

    numerator = (8 * payload_bytes) - (4 * sf) + 28 + (16 * crc) - (20 * ih)
    payload_symb_nb = 8 + max(math.ceil(numerator / denominator) * (cr + 4), 0)

    t_preamble = (radio.preamble_symbols + 4.25) * t_sym
    t_payload = payload_symb_nb * t_sym
    return t_preamble + t_payload


def time_on_air_ms(sf: int, payload_bytes: int, radio: RadioParams) -> float:
    """Convenience wrapper returning milliseconds."""
    return time_on_air_s(sf, payload_bytes, radio) * 1000.0
