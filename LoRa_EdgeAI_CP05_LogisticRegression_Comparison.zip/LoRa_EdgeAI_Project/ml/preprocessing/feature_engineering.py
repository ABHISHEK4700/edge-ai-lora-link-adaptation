"""
feature_engineering.py

Checkpoint 2 — Feature engineering for LoRa link-quality history.

Turns a cleaned, per-packet raw DataFrame (see clean.py / schema.RAW_SCHEMA)
into a feature-augmented DataFrame by computing rolling "history" statistics
per (device_id, session_id), ordered by packet_seq. This directly implements
the project requirement to use "packet success/failure history" (and recent
RSSI/SNR/retry trends) as model inputs, rather than only the current
packet's instantaneous values.

No real or fabricated LoRa measurement data is embedded in this file.
"""

from typing import Iterable, List
import pandas as pd

from .schema import processed_feature_columns

# Default rolling window sizes (number of prior packets to look back over).
# Kept small and simple for Checkpoint 2; revisit once real data + a chosen
# model architecture in a later checkpoint inform what window sizes are
# actually useful.
DEFAULT_WINDOW_SIZES = [5, 10]


def add_rolling_features(
    df: pd.DataFrame,
    window_sizes: Iterable[int] = DEFAULT_WINDOW_SIZES,
    group_cols: List[str] = ("device_id", "session_id"),
    order_col: str = "packet_seq",
) -> pd.DataFrame:
    """Add rolling history features to a cleaned raw DataFrame.

    For each window size w in window_sizes, adds:
      - rolling_success_rate_w{w}
      - rolling_retry_avg_w{w}
      - rolling_rssi_avg_w{w}
      - rolling_snr_avg_w{w}

    Each rolling statistic at row i is computed over the PRIOR w packets
    (strictly before the current packet, i.e. shifted by 1) within the same
    device_id/session_id group, ordered by order_col. This avoids leaking
    the current packet's own outcome into its own "history" features.

    Rows with fewer than 1 prior packet in their group will have NaN for
    all rolling features (there's no history yet). Downstream training code
    (a future checkpoint) will need to decide how to handle these NaNs
    (e.g. drop first-N rows per session, or impute) — that decision is out
    of scope here.

    Returns a NEW DataFrame; does not mutate the input.
    """
    required_cols = list(group_cols) + [order_col, "packet_success", "retry_count", "rssi_dbm", "snr_db"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(
            f"add_rolling_features: input DataFrame is missing required "
            f"column(s) {missing}. Did you run clean.validate_schema() first?"
        )

    out = df.sort_values(list(group_cols) + [order_col]).reset_index(drop=True).copy()

    grouped = out.groupby(list(group_cols), sort=False)

    for w in window_sizes:
        # shift(1) excludes the current row from its own rolling window.
        success_shifted = grouped["packet_success"].shift(1)
        retry_shifted = grouped["retry_count"].shift(1)
        rssi_shifted = grouped["rssi_dbm"].shift(1)
        snr_shifted = grouped["snr_db"].shift(1)

        out[f"rolling_success_rate_w{w}"] = _rolling_over_groups(out, group_cols, success_shifted, w)
        out[f"rolling_retry_avg_w{w}"] = _rolling_over_groups(out, group_cols, retry_shifted, w)
        out[f"rolling_rssi_avg_w{w}"] = _rolling_over_groups(out, group_cols, rssi_shifted, w)
        out[f"rolling_snr_avg_w{w}"] = _rolling_over_groups(out, group_cols, snr_shifted, w)

    expected_cols = processed_feature_columns(window_sizes)
    missing_out = [c for c in expected_cols if c not in out.columns]
    assert not missing_out, f"internal error: expected columns not produced: {missing_out}"

    return out


def _rolling_over_groups(df: pd.DataFrame, group_cols, shifted_series: pd.Series, window: int) -> pd.Series:
    """Helper: compute a rolling mean of `shifted_series` within each group
    defined by group_cols, respecting the row order already established in
    df. Returns a Series aligned to df's index.
    """
    tmp = shifted_series.copy()
    tmp.index = df.index
    keys = df[list(group_cols)]
    result = (
        tmp.groupby([keys[c] for c in group_cols])
        .rolling(window=window, min_periods=1)
        .mean()
    )
    # The groupby+rolling result has a MultiIndex (group keys..., original index);
    # drop the group-key levels to realign with df's original index.
    result = result.reset_index(level=list(range(len(group_cols))), drop=True)
    return result.reindex(df.index)
