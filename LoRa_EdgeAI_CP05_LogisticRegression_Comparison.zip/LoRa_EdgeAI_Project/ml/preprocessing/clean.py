"""
clean.py

Checkpoint 2 — Raw data loading and validation.

Loads a raw CSV file (matching ml/preprocessing/schema.RAW_SCHEMA) and
validates it: checks required columns are present, coerces dtypes, checks
values fall within the declared valid ranges, and drops/reports rows that
fail validation rather than silently passing bad data downstream.

No real or fabricated LoRa measurement data is embedded in this file.
"""

from dataclasses import dataclass, field
from typing import List
import pandas as pd

from .schema import RAW_SCHEMA, RAW_REQUIRED_COLUMNS


@dataclass
class ValidationReport:
    """Summary of what happened during load_raw_csv/validate_schema."""
    total_rows_read: int = 0
    rows_kept: int = 0
    rows_dropped: int = 0
    missing_required_columns: List[str] = field(default_factory=list)
    drop_reasons: List[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"Rows read:    {self.total_rows_read}",
            f"Rows kept:    {self.rows_kept}",
            f"Rows dropped: {self.rows_dropped}",
        ]
        if self.missing_required_columns:
            lines.append(f"Missing required columns: {self.missing_required_columns}")
        if self.drop_reasons:
            lines.append("Drop reasons (first 10 shown):")
            for reason in self.drop_reasons[:10]:
                lines.append(f"  - {reason}")
        return "\n".join(lines)


def load_raw_csv(path: str) -> pd.DataFrame:
    """Load a raw CSV file into a DataFrame without validation.

    Raises FileNotFoundError if the path doesn't exist, and re-raises any
    pandas parsing error as-is so problems are visible immediately.
    """
    return pd.read_csv(path)


def validate_schema(df: pd.DataFrame) -> "tuple[pd.DataFrame, ValidationReport]":
    """Validate a raw DataFrame against RAW_SCHEMA.

    Returns (clean_df, report):
      - clean_df: rows that passed all required-field and range checks,
        with dtypes coerced to match the schema.
      - report: a ValidationReport describing what was kept/dropped and why.

    This function does NOT mutate the input DataFrame.
    """
    report = ValidationReport(total_rows_read=len(df))

    missing = [c for c in RAW_REQUIRED_COLUMNS if c not in df.columns]
    report.missing_required_columns = missing
    if missing:
        # Cannot proceed meaningfully without required columns.
        report.rows_dropped = report.total_rows_read
        return df.iloc[0:0].copy(), report

    working = df.copy()
    keep_mask = pd.Series(True, index=working.index)

    for field_spec in RAW_SCHEMA:
        col = field_spec.name
        if col not in working.columns:
            # Optional column absent entirely — fine, skip.
            continue

        # Coerce dtype where possible; mark unparseable values for drop.
        if field_spec.dtype in (int, float):
            coerced = pd.to_numeric(working[col], errors="coerce")
            bad_dtype_mask = coerced.isna() & working[col].notna()
            if bad_dtype_mask.any():
                report.drop_reasons.append(
                    f"{bad_dtype_mask.sum()} row(s) had non-numeric '{col}'"
                )
            working[col] = coerced
        # str columns: leave as-is (NaN handling covered below).

        # Required columns must not be null.
        if field_spec.required:
            null_mask = working[col].isna()
            if null_mask.any():
                report.drop_reasons.append(
                    f"{null_mask.sum()} row(s) had missing required '{col}'"
                )
                keep_mask &= ~null_mask

        # Range check (numeric only).
        if field_spec.valid_range is not None and field_spec.dtype in (int, float):
            lo, hi = field_spec.valid_range
            in_range = working[col].between(lo, hi) | working[col].isna()
            out_of_range_mask = ~in_range
            if out_of_range_mask.any():
                report.drop_reasons.append(
                    f"{out_of_range_mask.sum()} row(s) had '{col}' outside "
                    f"valid range [{lo}, {hi}]"
                )
                keep_mask &= ~out_of_range_mask

        # Allowed-values check (e.g. packet_success in {0, 1}).
        if field_spec.allowed_values is not None:
            allowed_mask = working[col].isin(field_spec.allowed_values) | working[col].isna()
            not_allowed_mask = ~allowed_mask
            if not_allowed_mask.any():
                report.drop_reasons.append(
                    f"{not_allowed_mask.sum()} row(s) had '{col}' outside "
                    f"allowed values {field_spec.allowed_values}"
                )
                keep_mask &= ~not_allowed_mask

    clean_df = working[keep_mask].reset_index(drop=True)

    # Cast integer-typed columns cleanly now that NaNs causing drops are gone.
    for field_spec in RAW_SCHEMA:
        if field_spec.dtype is int and field_spec.name in clean_df.columns:
            if clean_df[field_spec.name].notna().all():
                clean_df[field_spec.name] = clean_df[field_spec.name].astype(int)

    report.rows_kept = len(clean_df)
    report.rows_dropped = report.total_rows_read - report.rows_kept

    return clean_df, report
