"""
pipeline.py

Checkpoint 2 — Preprocessing pipeline orchestrator.

Ties together clean.py (load + validate raw data) and
feature_engineering.py (rolling history features) into a single pipeline
that reads a raw CSV (matching schema.RAW_SCHEMA) and writes a processed
CSV (matching schema.RAW_SCHEMA + processed feature columns) to
data/processed/.

Usage (once real raw data exists in data/raw/):
    python -m ml.preprocessing.pipeline \\
        --input data/raw/some_session.csv \\
        --output data/processed/some_session_processed.csv

This script does NOT generate, fabricate, or embed any LoRa measurement
data. It only operates on a CSV file path you provide. As of Checkpoint 2,
no such raw data file exists yet (see PROJECT_STATUS.md) — this module is
provided so the pipeline is ready the moment real data collection begins.
"""

import argparse
import json
import sys
from pathlib import Path

from .clean import load_raw_csv, validate_schema
from .feature_engineering import add_rolling_features, DEFAULT_WINDOW_SIZES


def run_pipeline(input_path: str, output_path: str, window_sizes=DEFAULT_WINDOW_SIZES) -> dict:
    """Run the full preprocessing pipeline on a single raw CSV file.

    Returns a dict summary (also useful for logging/testing):
        {
          "input_path": ...,
          "output_path": ...,
          "validation": {rows_read, rows_kept, rows_dropped, ...},
          "output_rows": int,
          "output_columns": [...],
        }

    Raises FileNotFoundError if input_path doesn't exist.
    """
    raw_df = load_raw_csv(input_path)
    clean_df, report = validate_schema(raw_df)

    if report.missing_required_columns:
        raise ValueError(
            f"Input file {input_path} is missing required columns: "
            f"{report.missing_required_columns}. See ml/preprocessing/schema.py."
        )

    processed_df = add_rolling_features(clean_df, window_sizes=window_sizes)

    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    processed_df.to_csv(output_file, index=False)

    summary = {
        "input_path": str(input_path),
        "output_path": str(output_path),
        "validation": {
            "rows_read": report.total_rows_read,
            "rows_kept": report.rows_kept,
            "rows_dropped": report.rows_dropped,
            "drop_reasons": report.drop_reasons,
        },
        "output_rows": len(processed_df),
        "output_columns": list(processed_df.columns),
    }
    return summary


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the LoRa Edge-AI preprocessing pipeline on a raw CSV file."
    )
    parser.add_argument(
        "--input", "-i", required=True,
        help="Path to a raw CSV file matching ml/preprocessing/schema.RAW_SCHEMA "
             "(e.g. data/raw/session_001.csv).",
    )
    parser.add_argument(
        "--output", "-o", required=True,
        help="Path to write the processed CSV to (e.g. data/processed/session_001_processed.csv).",
    )
    parser.add_argument(
        "--windows", nargs="+", type=int, default=DEFAULT_WINDOW_SIZES,
        help=f"Rolling window sizes to compute (default: {DEFAULT_WINDOW_SIZES}).",
    )
    return parser


def main(argv=None):
    parser = _build_arg_parser()
    args = parser.parse_args(argv)

    try:
        summary = run_pipeline(args.input, args.output, window_sizes=args.windows)
    except FileNotFoundError:
        print(f"ERROR: input file not found: {args.input}", file=sys.stderr)
        print(
            "No raw data exists yet as of Checkpoint 2 — see "
            "experiments/DATA_COLLECTION_PLAN.md and data/raw/README.md.",
            file=sys.stderr,
        )
        sys.exit(1)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
