"""
schema.py

Checkpoint 2 — Data schema definitions.

This module defines the CONTRACT for:
  1. RAW_SCHEMA   — the per-transmission log format that future data
                     collection (real ESP32 + LoRa hardware, per
                     PROJECT_STATUS.md) must produce as CSV rows in
                     data/raw/.
  2. PROCESSED_SCHEMA — the additional columns produced by the
                     preprocessing pipeline (ml/preprocessing/pipeline.py)
                     once raw data exists, written to data/processed/.

No real or fabricated measurement data lives in this file. This is a
schema/contract definition only, so that:
  - the (future) ESP32 logging code has an unambiguous target format
  - the preprocessing pipeline has something concrete to validate against
  - anyone continuing this project (including a new AI assistant session)
    knows exactly what "the data" is supposed to look like before any of
    it exists

See data/raw/README.md for the human-readable version of this schema and
experiments/DATA_COLLECTION_PLAN.md for how this data is intended to be
collected.
"""

from dataclasses import dataclass
from typing import Optional, Tuple, Type


@dataclass(frozen=True)
class FieldSpec:
    """Specification for a single column in a schema."""
    name: str
    dtype: Type
    required: bool
    description: str
    # (min, max) inclusive valid range for numeric fields; None if not
    # applicable (e.g. string fields) or not bounded.
    valid_range: Optional[Tuple[float, float]] = None
    # For fields with a fixed, known set of legal values (e.g. booleans
    # encoded as 0/1). None if not applicable.
    allowed_values: Optional[Tuple] = None


# ---------------------------------------------------------------------------
# RAW SCHEMA
#
# One row = one LoRa transmission attempt (including its retries, summarized
# as a single record) logged by an end device during a data collection
# session. This is the format that data/raw/*.csv files must follow once
# real hardware logging begins.
# ---------------------------------------------------------------------------
RAW_SCHEMA = [
    FieldSpec(
        name="timestamp_utc",
        dtype=str,
        required=True,
        description=(
            "ISO 8601 UTC timestamp of the transmission attempt, "
            "e.g. 2026-09-19T05:30:12.345Z"
        ),
    ),
    FieldSpec(
        name="session_id",
        dtype=str,
        required=True,
        description=(
            "Identifier for the data collection session/run this row "
            "belongs to (e.g. 'sess_2026_09_19_outdoor_lineofsight_01'). "
            "See experiments/DATA_COLLECTION_PLAN.md for session naming "
            "convention."
        ),
    ),
    FieldSpec(
        name="device_id",
        dtype=str,
        required=True,
        description="Identifier of the physical end device that logged this row.",
    ),
    FieldSpec(
        name="packet_seq",
        dtype=int,
        required=True,
        description="Monotonically increasing packet sequence number within the session.",
        valid_range=(0, float("inf")),
    ),
    FieldSpec(
        name="sf",
        dtype=int,
        required=True,
        description="Spreading Factor used for this transmission (LoRa SF7-SF12).",
        valid_range=(7, 12),
    ),
    FieldSpec(
        name="tp_dbm",
        dtype=float,
        required=True,
        description="Transmission power used, in dBm.",
        # Typical LoRa module range; adjust in a future checkpoint once the
        # actual radio module's allowed power levels are confirmed.
        valid_range=(-4, 22),
    ),
    FieldSpec(
        name="rssi_dbm",
        dtype=float,
        required=True,
        description=(
            "Received Signal Strength Indicator in dBm, as measured for "
            "this transmission (e.g. from the gateway ack or last received "
            "downlink)."
        ),
        valid_range=(-150, 0),
    ),
    FieldSpec(
        name="snr_db",
        dtype=float,
        required=True,
        description="Signal-to-Noise Ratio in dB for this transmission.",
        valid_range=(-30, 20),
    ),
    FieldSpec(
        name="retry_count",
        dtype=int,
        required=True,
        description="Number of retransmissions attempted for this packet before success/giving up.",
        valid_range=(0, 255),
    ),
    FieldSpec(
        name="packet_success",
        dtype=int,
        required=True,
        description="1 if the packet was eventually delivered/acknowledged, 0 otherwise.",
        allowed_values=(0, 1),
    ),
    FieldSpec(
        name="payload_bytes",
        dtype=int,
        required=False,
        description="Size of the transmitted payload in bytes (optional context).",
        valid_range=(0, 256),
    ),
    FieldSpec(
        name="channel_freq_hz",
        dtype=float,
        required=False,
        description=(
            "Center frequency of the channel used, in Hz (optional context). "
            "Planned hardware is an SX1278 module (433 MHz band), so real "
            "logged values are expected to fall in that band, e.g. "
            "~433000000."
        ),
        valid_range=(0, float("inf")),
    ),
    FieldSpec(
        name="notes",
        dtype=str,
        required=False,
        description="Free-text notes about this row/session (optional, e.g. environment description).",
    ),
]

# Convenience lookups
RAW_REQUIRED_COLUMNS = [f.name for f in RAW_SCHEMA if f.required]
RAW_ALL_COLUMNS = [f.name for f in RAW_SCHEMA]


# ---------------------------------------------------------------------------
# PROCESSED SCHEMA (additive)
#
# Columns ADDED to a raw row by the preprocessing pipeline's feature
# engineering step. These are "history" features computed from a rolling
# window of prior packets for the same (device_id, session_id), ordered by
# packet_seq, satisfying the project's requirement to use "packet
# success/failure history" as a model input rather than only the current
# packet's values.
#
# The pipeline computes these for each window size in
# feature_engineering.DEFAULT_WINDOW_SIZES (currently [5, 10]).
# ---------------------------------------------------------------------------
def processed_feature_columns(window_sizes):
    """Return the list of engineered column names for the given window sizes."""
    cols = []
    for w in window_sizes:
        cols.extend([
            f"rolling_success_rate_w{w}",
            f"rolling_retry_avg_w{w}",
            f"rolling_rssi_avg_w{w}",
            f"rolling_snr_avg_w{w}",
        ])
    return cols


PROCESSED_FEATURE_DESCRIPTIONS = {
    "rolling_success_rate_w{w}": (
        "Fraction of successful packets among the previous w packets "
        "(same device_id + session_id, ordered by packet_seq). "
        "NaN if fewer than 1 prior packet exists."
    ),
    "rolling_retry_avg_w{w}": (
        "Mean retry_count over the previous w packets. NaN if no prior packets exist."
    ),
    "rolling_rssi_avg_w{w}": (
        "Mean rssi_dbm over the previous w packets. NaN if no prior packets exist."
    ),
    "rolling_snr_avg_w{w}": (
        "Mean snr_db over the previous w packets. NaN if no prior packets exist."
    ),
}
