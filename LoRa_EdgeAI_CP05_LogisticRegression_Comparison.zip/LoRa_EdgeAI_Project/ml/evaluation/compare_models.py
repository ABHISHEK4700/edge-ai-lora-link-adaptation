"""
compare_models.py

Checkpoint 5 — Software-level comparison of the Decision Tree (Checkpoint 4)
and Logistic Regression (Checkpoint 5) candidates.

*** SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT. ***
Every number this module produces comes from the fabricated pipeline
fixture. It compares whether two pieces of code run and what they measure
on that fixture — it is NOT a comparison of which model is better for real
LoRa channel adaptation, and must never be read or reported as one.

WHAT THIS DOES AND DOES NOT DO
-------------------------------
Does:
  * loads two already-trained model bundles (a Decision Tree bundle and a
    Logistic Regression bundle) plus their training metadata JSON files;
  * re-evaluates both on the SAME held-out contexts (same input CSV, same
    test_size/random_state, so the split is identical for both models);
  * reports predictive metrics, model file size, training time and
    inference time for both, side by side;
  * states explicitly, in the report itself, that none of this licenses a
    "better model" claim on synthetic data.

Does NOT:
  * run a statistical significance test — 9 test contexts cannot support
    one, and no test here should be read as implying otherwise;
  * pick a "winner" or recommend a model for deployment;
  * touch, retrain, or modify either model.

Usage:
    python -m ml.evaluation.compare_models \\
        --dt-model      ml/models/decision_tree_sf_tp.joblib \\
        --dt-metadata   ml/models/decision_tree_sf_tp_metadata.json \\
        --lr-model      ml/models/logistic_regression_sf_tp.joblib \\
        --lr-metadata   ml/models/logistic_regression_sf_tp_metadata.json \\
        --input         <labeled.csv> \\
        --report        ml/evaluation/comparison_report.md
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, Optional

from .evaluate import evaluate, load_bundle
from .metrics import SYNTHETIC_BANNER, SYNTHETIC_BANNER_LONG

#: The explicit non-claim this whole module exists to enforce.
NO_SUPERIORITY_CLAIM = (
    "This comparison does NOT show that either model is better than the "
    "other for real LoRa channel adaptation. Both were scored on the same "
    "fabricated, trivially-separable fixture used to validate the "
    "software pipeline. Any difference between them here reflects how "
    "each model family fits that fixture, not real-world merit."
)


def compare(
    dt_model_path: str,
    dt_metadata_path: str,
    lr_model_path: str,
    lr_metadata_path: str,
    input_path: str,
    test_size: float = 0.3,
    random_state: int = 0,
) -> Dict:
    """Evaluate both bundles on the same held-out split and assemble a
    side-by-side comparison dict."""

    dt_bundle = load_bundle(dt_model_path)
    lr_bundle = load_bundle(lr_model_path)

    if list(dt_bundle["feature_columns"]) != list(lr_bundle["feature_columns"]):
        raise ValueError(
            "The two bundles were trained on different feature sets "
            f"(DT: {dt_bundle['feature_columns']!r} vs "
            f"LR: {lr_bundle['feature_columns']!r}). A comparison is only "
            "meaningful when both models see the same inputs — retrain one "
            "so they match before comparing."
        )

    dt_result = evaluate(dt_model_path, input_path,
                          test_size=test_size, random_state=random_state)
    lr_result = evaluate(lr_model_path, input_path,
                          test_size=test_size, random_state=random_state)

    with open(dt_metadata_path, encoding="utf-8") as fh:
        dt_meta = json.load(fh)
    with open(lr_metadata_path, encoding="utf-8") as fh:
        lr_meta = json.load(fh)

    def _predictive(result: Dict) -> Dict:
        m = result["metrics"]
        return {
            "sf_accuracy": m["spreading_factor"]["accuracy"],
            "sf_macro_f1": m["spreading_factor"]["macro_f1"],
            "tp_accuracy": m["tx_power_dbm"]["accuracy"],
            "tp_macro_f1": m["tx_power_dbm"]["macro_f1"],
            "joint_accuracy": m["joint"]["accuracy"],
            "per_context_joint_accuracy": m["per_context"]["joint_accuracy"],
            "n_test_rows": m["spreading_factor"]["n_samples"],
        }

    def _software(meta: Dict) -> Dict:
        mf = meta.get("model_file", {})
        it = meta.get("inference_timing", {})
        return {
            "training_seconds": meta.get("total_training_seconds"),
            "model_file_kilobytes": mf.get("kilobytes"),
            "model_file_bytes": mf.get("bytes"),
            "inference_microseconds_per_row": it.get("per_row_microseconds"),
            "inference_measured_rows": it.get("n_rows"),
            "tuned": meta.get("tuned"),
        }

    comparison = {
        "banner": SYNTHETIC_BANNER,
        "no_superiority_claim": NO_SUPERIORITY_CLAIM,
        "input_path": str(input_path),
        "split": {
            "test_size": test_size,
            "random_state": random_state,
            "note": (
                "Both models were evaluated on an IDENTICAL held-out split "
                "of the same input file (same test_size/random_state), so "
                "the comparison is apples-to-apples for this fixture."
            ),
        },
        "decision_tree": {
            "model_family": dt_bundle.get(
                "model_family", "DecisionTreeClassifier (scikit-learn)"),
            "predictive": _predictive(dt_result),
            "software": _software(dt_meta),
        },
        "logistic_regression": {
            "model_family": lr_bundle.get(
                "model_family", "LogisticRegression (scikit-learn)"),
            "predictive": _predictive(lr_result),
            "software": _software(lr_meta),
        },
        "feature_columns": list(dt_bundle["feature_columns"]),
        "explicit_non_claims": [
            NO_SUPERIORITY_CLAIM,
            "This does NOT demonstrate improved packet delivery ratio for "
            "either model.",
            "This does NOT demonstrate improved latency for either model.",
            "This does NOT demonstrate improved energy consumption for "
            "either model.",
            "This does NOT demonstrate faster adaptation than ADR for "
            "either model.",
            "Neither model is validated for real LoRa communication.",
            "These metrics are NOT evidence of project success for either "
            "candidate.",
            ("The fixture is trivially separable by construction, so high "
             "scores from both models are expected and indicate only that "
             "both pipelines ran correctly."),
        ],
    }
    return comparison


def render_markdown_report(comparison: Dict) -> str:
    """Render the comparison dict as a banner-stamped Markdown report."""
    lines = []
    a = lines.append

    a("# Checkpoint 5 — Decision Tree vs. Logistic Regression "
      "(Software Comparison)")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")
    for para in SYNTHETIC_BANNER_LONG.split("\n\n")[1:]:
        a("> " + para.replace("\n", " "))
        a(">")
    a("")
    a("> **" + comparison["no_superiority_claim"] + "**")
    a("")
    a("---")
    a("")

    a("## 1. What was compared")
    a("")
    dt, lr = comparison["decision_tree"], comparison["logistic_regression"]
    a(f"- **Model A:** {dt['model_family']}")
    a(f"- **Model B:** {lr['model_family']}")
    a(f"- **Input:** `{comparison['input_path']}`")
    a(f"- **Features (identical for both):** {comparison['feature_columns']}")
    a(f"- {comparison['split']['note']}")
    a("")

    a("## 2. Predictive performance on the synthetic fixture")
    a("")
    a("> " + SYNTHETIC_BANNER)
    a("")
    a("| Metric | Decision Tree | Logistic Regression |")
    a("|---|---|---|")
    dp, lp = dt["predictive"], lr["predictive"]
    a(f"| SF accuracy | {dp['sf_accuracy']:.4f} | {lp['sf_accuracy']:.4f} |")
    a(f"| SF macro F1 | {dp['sf_macro_f1']:.4f} | {lp['sf_macro_f1']:.4f} |")
    a(f"| TX power accuracy | {dp['tp_accuracy']:.4f} | {lp['tp_accuracy']:.4f} |")
    a(f"| TX power macro F1 | {dp['tp_macro_f1']:.4f} | {lp['tp_macro_f1']:.4f} |")
    a(f"| Joint exact match | {dp['joint_accuracy']:.4f} | {lp['joint_accuracy']:.4f} |")
    a(f"| Per-context joint accuracy | {dp['per_context_joint_accuracy']:.4f} "
      f"| {lp['per_context_joint_accuracy']:.4f} |")
    a(f"| Test rows scored | {dp['n_test_rows']} | {lp['n_test_rows']} |")
    a("")
    a("> Neither column being higher than the other is evidence of which "
      "model is better for LoRa. See section 4.")
    a("")

    a("## 3. Software-level cost")
    a("")
    ds, ls = dt["software"], lr["software"]
    a("| Metric | Decision Tree | Logistic Regression |")
    a("|---|---|---|")
    a(f"| Training time (s) | {ds['training_seconds']:.6f} "
      f"| {ls['training_seconds']:.6f} |")
    a(f"| Model file size (KB) | {ds['model_file_kilobytes']} "
      f"| {ls['model_file_kilobytes']} |")
    a(f"| Inference time (µs/row) | "
      f"{ds['inference_microseconds_per_row']:.2f} | "
      f"{ls['inference_microseconds_per_row']:.2f} |")
    a(f"| Hyperparameters tuned | {ds['tuned']} | {ls['tuned']} |")
    a("")
    a("> Training and inference times are desktop, scikit-learn "
      "measurements — not ESP32 figures. Model file size is the desktop "
      "joblib serialisation, not an embedded footprint. Both are recorded "
      "here purely to compare the two candidates on a like-for-like basis, "
      "not to estimate on-device cost.")
    a("")

    a("## 4. What this does NOT show")
    a("")
    for claim in comparison["explicit_non_claims"]:
        a(f"- {claim}")
    a("")
    a("---")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")

    return "\n".join(lines)


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Compare a Decision Tree bundle and a Logistic Regression "
            "bundle on identical held-out data. SOFTWARE VALIDATION ONLY "
            "— not a research comparison."
        )
    )
    p.add_argument("--dt-model", required=True, help="Decision Tree .joblib bundle.")
    p.add_argument("--dt-metadata", required=True,
                   help="Decision Tree training metadata JSON.")
    p.add_argument("--lr-model", required=True,
                   help="Logistic Regression .joblib bundle.")
    p.add_argument("--lr-metadata", required=True,
                   help="Logistic Regression training metadata JSON.")
    p.add_argument("--input", "-i", required=True, help="Labeled CSV to evaluate on.")
    p.add_argument("--report", "-r", default=None,
                   help="Path to write a Markdown report to.")
    p.add_argument("--json", default=None,
                   help="Path to write the machine-readable JSON result to.")
    p.add_argument("--test-size", type=float, default=0.3)
    p.add_argument("--random-state", type=int, default=0)
    return p


def main(argv=None):
    args = _build_arg_parser().parse_args(argv)

    try:
        comparison = compare(
            dt_model_path=args.dt_model,
            dt_metadata_path=args.dt_metadata,
            lr_model_path=args.lr_model,
            lr_metadata_path=args.lr_metadata,
            input_path=args.input,
            test_size=args.test_size,
            random_state=args.random_state,
        )
    except FileNotFoundError as e:
        print(f"ERROR: file not found: {e.filename or e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(comparison, fh, indent=2)
            fh.write("\n")

    report = render_markdown_report(comparison)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        with open(args.report, "w", encoding="utf-8") as fh:
            fh.write(report)
        print(f"Wrote report to {args.report}")
    else:
        print(report)


if __name__ == "__main__":
    main()
