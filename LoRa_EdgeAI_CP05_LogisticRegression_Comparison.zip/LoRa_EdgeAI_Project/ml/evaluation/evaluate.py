"""
evaluate.py

Checkpoint 4 — Standalone model evaluation and report generation.

Loads a model bundle saved by ml/training/train_decision_tree.py, runs it
against a labeled CSV, and writes a human-readable Markdown report plus a
machine-readable JSON one.

*** Every report this produces carries the banner:                        ***
***   SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT       ***
*** and will continue to until real hardware data exists. The banner is  ***
*** written by ml/evaluation/metrics.py and is not optional.             ***

Evaluating separately from training is deliberate: it proves the saved model
can be reloaded and used on its own, which is the thing an edge-deployment
checkpoint will actually depend on. A model that only works inside the
process that trained it is not a deliverable.

Usage:
    python -m ml.evaluation.evaluate \\
        --model  ml/models/decision_tree_sf_tp.joblib \\
        --input  <labeled.csv> \\
        --report ml/evaluation/report.md
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from .metrics import (
    SYNTHETIC_BANNER,
    SYNTHETIC_BANNER_LONG,
    classification_metrics,
    joint_exact_match,
    per_context_agreement,
)


def load_bundle(model_path: str) -> Dict:
    """Load and sanity-check a saved model bundle."""
    import joblib

    bundle = joblib.load(model_path)
    required = ["sf_model", "tp_model", "feature_columns"]
    missing = [k for k in required if k not in bundle]
    if missing:
        raise ValueError(
            f"{model_path} is not a valid model bundle — missing {missing}. "
            f"Produce one with python -m ml.training.train_decision_tree."
        )
    return bundle


def evaluate(
    model_path: str,
    input_path: str,
    test_size: float = 0.3,
    random_state: int = 0,
    evaluate_on: str = "holdout",
) -> Dict:
    """Evaluate a saved model bundle against a labeled CSV.

    `evaluate_on`:
      "holdout" — reproduce the context-aware split and score the held-out
                  contexts only. This is the honest default.
      "all"     — score every row, including contexts the model trained on.
                  Useful for a wiring check; the result is optimistic and is
                  flagged as such in the report.
    """
    from ml.training.dataset import (
        build_dataset, context_aware_split, describe_split, load_labeled_frame,
    )

    bundle = load_bundle(model_path)
    feature_columns = bundle["feature_columns"]

    df = load_labeled_frame(input_path)
    X, y_sf, y_tp, groups, summary = build_dataset(
        df, feature_columns=feature_columns
    )

    if evaluate_on == "holdout":
        train_idx, test_idx = context_aware_split(
            groups, test_size=test_size, random_state=random_state
        )
        split_info = describe_split(groups, train_idx, test_idx)
        idx = test_idx
        sf_reference = y_sf[train_idx]
        tp_reference = y_tp[train_idx]
        scope = (
            "held-out contexts only (split reproduced with the same "
            "test_size/random_state used at training time)"
        )
    elif evaluate_on == "all":
        idx = np.arange(len(y_sf))
        split_info = {"note": "no split — every row scored"}
        sf_reference = y_sf
        tp_reference = y_tp
        scope = (
            "ALL rows, including contexts the model was trained on. "
            "This figure is optimistic and must not be reported as "
            "generalisation performance."
        )
    else:
        raise ValueError(
            f"evaluate_on must be 'holdout' or 'all' (got {evaluate_on!r})."
        )

    X_eval = X[idx]
    sf_true, tp_true = y_sf[idx], y_tp[idx]
    groups_eval = groups[idx]

    start = time.perf_counter()
    sf_pred = bundle["sf_model"].predict(X_eval)
    tp_pred = bundle["tp_model"].predict(X_eval)
    predict_seconds = time.perf_counter() - start

    return {
        "banner": SYNTHETIC_BANNER,
        "evaluation_scope": scope,
        "model_path": str(model_path),
        "input_path": str(input_path),
        "model_provenance": bundle.get("provenance", "unknown"),
        "trained_from": bundle.get("trained_from", "unknown"),
        "feature_columns": list(feature_columns),
        "data": summary.as_dict(),
        "split": split_info,
        "prediction_timing": {
            "rows": int(len(X_eval)),
            "seconds": predict_seconds,
            "per_row_microseconds": (predict_seconds / len(X_eval)) * 1e6
            if len(X_eval) else None,
            "caveat": "Build machine with scikit-learn, not an ESP32.",
        },
        "metrics": {
            "spreading_factor": classification_metrics(
                sf_true, sf_pred, "spreading_factor", sf_reference),
            "tx_power_dbm": classification_metrics(
                tp_true, tp_pred, "tx_power_dbm", tp_reference),
            "joint": joint_exact_match(sf_true, sf_pred, tp_true, tp_pred),
            "per_context": per_context_agreement(
                groups_eval, sf_true, sf_pred, tp_true, tp_pred),
        },
    }


def render_markdown_report(result: Dict, metadata: Optional[Dict] = None) -> str:
    """Render an evaluation result as a Markdown report, banner first."""
    lines = []
    a = lines.append

    a("# Checkpoint 4 — Decision Tree Software Validation Report")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")
    for para in SYNTHETIC_BANNER_LONG.split("\n\n")[1:]:
        a("> " + para.replace("\n", " "))
        a(">")
    a("")
    a("---")
    a("")

    a("## 1. What was evaluated")
    a("")
    a(f"- **Model:** `{result['model_path']}`")
    a(f"- **Input:** `{result['input_path']}`")
    a(f"- **Trained from:** `{result['trained_from']}`")
    a(f"- **Scope:** {result['evaluation_scope']}")
    a("")

    d = result["data"]
    a("## 2. Dataset")
    a("")
    a("| Property | Value |")
    a("|---|---|")
    a(f"| Rows in file | {d['rows_in_file']} |")
    a(f"| Rows with an evidence-backed label | {d['rows_after_label_filter']} |")
    a(f"| Usable rows (history features present) | {d['usable_rows']} |")
    a(f"| Contexts | {d['contexts']} |")
    a(f"| Features | {d['n_features']} |")
    a(f"| SF classes | {d['sf_classes']} |")
    a(f"| TX power classes | {d['tp_classes']} |")
    a("")
    a(f"> **Effective sample size is {d['contexts']}, not {d['usable_rows']}.** "
      "One label covers every row of a context, so rows are not independent "
      "samples.")
    a("")

    if "train_contexts" in result["split"]:
        s = result["split"]
        a("## 3. Split")
        a("")
        a(f"Split by `{s['split_by']}`, so no context appears on both sides "
          f"(verified: {s['context_overlap']} overlapping contexts).")
        a("")
        a("| | Contexts | Rows |")
        a("|---|---|---|")
        a(f"| Train | {s['train_contexts']} | {s['train_rows']} |")
        a(f"| Test | {s['test_contexts']} | {s['test_rows']} |")
        a("")

    a("## 4. Metrics")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")

    for key, title in (("spreading_factor", "Spreading Factor"),
                       ("tx_power_dbm", "Transmission Power")):
        m = result["metrics"][key]
        a(f"### 4.{1 if key == 'spreading_factor' else 2} {title}")
        a("")
        a(f"- Accuracy: **{m['accuracy']:.4f}**")
        if "majority_class_baseline" in m:
            b = m["majority_class_baseline"]
            a(f"- Majority-class baseline: **{b['accuracy']:.4f}** "
              f"(always predict `{b['predicted_class']}`)")
            a(f"- Beats baseline: **{m['beats_baseline']}**")
        a(f"- Macro F1: {m['macro_f1']:.4f} | Weighted F1: {m['weighted_f1']:.4f}")
        a("")
        a("| Class | Precision | Recall | F1 | Support |")
        a("|---|---|---|---|---|")
        for c in m["per_class"]:
            a(f"| {c['class']} | {c['precision']:.4f} | {c['recall']:.4f} | "
              f"{c['f1']:.4f} | {c['support']} |")
        a("")

    j = result["metrics"]["joint"]
    pc = result["metrics"]["per_context"]
    a("### 4.3 Joint and per-context")
    a("")
    a(f"- Joint exact match (both SF and TX power correct): "
      f"**{j['accuracy']:.4f}** ({j['n_correct']}/{j['n_samples']} rows)")
    a(f"- Per-context majority vote over {pc['n_contexts']} contexts: "
      f"SF {pc['sf_accuracy']:.4f}, TX power {pc['tp_accuracy']:.4f}, "
      f"joint {pc['joint_accuracy']:.4f}")
    a("")
    a("> Per-context figures count each context once rather than once per "
      "row, which is closer to the true sample size.")
    a("")

    if metadata:
        a("## 5. Model structure")
        a("")
        a("| | SF tree | TX power tree |")
        a("|---|---|---|")
        sf, tp = metadata["sf_tree"], metadata["tp_tree"]
        a(f"| Depth | {sf['actual_depth']} | {tp['actual_depth']} |")
        a(f"| Nodes | {sf['n_nodes']} | {tp['n_nodes']} |")
        a(f"| Leaves | {sf['n_leaves']} | {tp['n_leaves']} |")
        a(f"| Features used | {sf['n_features_used']} | {tp['n_features_used']} |")
        a(f"| Classes | {sf['n_classes']} | {tp['n_classes']} |")
        a(f"| Training time (s) | {sf['training_seconds']:.6f} "
          f"| {tp['training_seconds']:.6f} |")
        a("")
        mf = metadata["model_file"]
        if mf.get("kilobytes") is not None:
            a(f"- Model file: **{mf['kilobytes']} KB** ({mf['bytes']} bytes, "
              f"{mf['format']})")
            a(f"- {mf['note']}")
        it = metadata.get("inference_timing", {})
        if it.get("measured"):
            a(f"- Inference: **{it['per_row_microseconds']:.2f} µs/row** "
              f"over {it['n_rows']} rows")
            a(f"- {it['caveat']}")
        a("")
        a(f"- Tuned: **{metadata['tuned']}** — {metadata['tuning_note']}")
        a("")

    a("## 6. What this does NOT show")
    a("")
    for claim in [
        "Improved packet delivery ratio.",
        "Improved latency.",
        "Improved energy consumption.",
        "Faster adaptation than standard ADR.",
        "Validation for real LoRa communication.",
        "Evidence of project success.",
        "Any property of real hardware, in any respect.",
    ]:
        a(f"- {claim}")
    a("")
    a("The fixture this was run against is trivially separable by "
      "construction: each link tier has a distinct RSSI/SNR band and one "
      "correct answer. A near-perfect score is the expected outcome and "
      "confirms only that the pipeline is wired together correctly.")
    a("")
    a("---")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")

    return "\n".join(lines)


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=("Evaluate a saved Decision Tree bundle. SOFTWARE "
                     "VALIDATION ONLY — not a research run.")
    )
    p.add_argument("--model", "-m", required=True, help="Path to the .joblib bundle.")
    p.add_argument("--input", "-i", required=True, help="Labeled CSV to evaluate on.")
    p.add_argument("--report", "-r", default=None,
                   help="Path to write a Markdown report to.")
    p.add_argument("--json", default=None,
                   help="Path to write the machine-readable JSON result to.")
    p.add_argument("--metadata", default=None,
                   help="Training metadata JSON, to include model structure "
                        "in the report.")
    p.add_argument("--evaluate-on", choices=["holdout", "all"], default="holdout")
    p.add_argument("--test-size", type=float, default=0.3)
    p.add_argument("--random-state", type=int, default=0)
    return p


def main(argv=None):
    args = _build_arg_parser().parse_args(argv)

    try:
        result = evaluate(
            model_path=args.model,
            input_path=args.input,
            test_size=args.test_size,
            random_state=args.random_state,
            evaluate_on=args.evaluate_on,
        )
    except FileNotFoundError as e:
        print(f"ERROR: file not found: {e.filename or e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    metadata = None
    if args.metadata and Path(args.metadata).exists():
        with open(args.metadata, encoding="utf-8") as fh:
            metadata = json.load(fh)

    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(result, fh, indent=2)
            fh.write("\n")

    report = render_markdown_report(result, metadata)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        with open(args.report, "w", encoding="utf-8") as fh:
            fh.write(report)
        print(f"Wrote report to {args.report}")
    else:
        print(report)


if __name__ == "__main__":
    main()
