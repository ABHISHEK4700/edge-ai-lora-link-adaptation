"""
ml.evaluation — Checkpoint 4: model evaluation. Checkpoint 5:
Decision-Tree-vs-Logistic-Regression comparison (ml/evaluation/compare_models.py).

Every report produced by this package carries the SYNTHETIC_BANNER from
ml/evaluation/metrics.py, because as of Checkpoint 5 all metrics still come
from fabricated test-fixture data and measure only that the software runs.
compare_models.py additionally carries an explicit no-superiority-claim in
every report it generates — see that module's docstring.
"""
