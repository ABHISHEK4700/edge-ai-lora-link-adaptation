"""
metrics.py

Checkpoint 4 — Evaluation metrics.

Computes classification metrics for the SF and TX-power predictors, plus the
joint exact-match rate (both correct on the same row), which is what actually
matters: predicting SF correctly while getting TX power wrong still yields an
unusable configuration.

THE BANNER
----------
`SYNTHETIC_BANNER` is stamped on every report this package produces. As of
Checkpoint 4 the only data in this project is fabricated test-fixture data,
so every metric here measures whether the SOFTWARE RUNS — nothing else. It is
not evidence about LoRa, about PDR, about energy, or about the project's
hypothesis.

WHY A MAJORITY-CLASS BASELINE IS ALWAYS REPORTED
------------------------------------------------
An accuracy figure on its own is close to meaningless for an imbalanced
problem: if 80% of contexts want SF12, a model that always predicts SF12
scores 80%. Every report therefore carries the majority-class baseline
alongside the model's score, so the two can be compared directly. If the
model does not clearly beat the baseline, the accuracy number is telling you
about the class distribution rather than the model.

No real or fabricated LoRa measurement data lives in this file.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np

#: Stamped on every generated report while the project has no real data.
SYNTHETIC_BANNER = (
    "SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT"
)

#: Longer form, for report headers.
SYNTHETIC_BANNER_LONG = (
    "SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT\n"
    "\n"
    "Every number below was produced from fabricated test-fixture data, not "
    "from any LoRa hardware. It demonstrates only that the training and "
    "evaluation pipeline executes end to end. It is NOT evidence that the "
    "model works, generalises, or improves packet delivery ratio, latency, "
    "energy consumption or adaptation speed. No claim about real LoRa "
    "communication is supported by any of it. The fixture is trivially "
    "separable by construction, so a high score here is expected and means "
    "nothing beyond 'the code ran'."
)


def majority_class_baseline(y_train: np.ndarray, y_test: np.ndarray) -> Dict:
    """Accuracy of always predicting the training set's most common class."""
    values, counts = np.unique(y_train, return_counts=True)
    majority = values[int(np.argmax(counts))]
    accuracy = float(np.mean(y_test == majority))
    return {
        "strategy": "always predict the most common training class",
        "predicted_class": _py(majority),
        "accuracy": accuracy,
    }


def classification_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    target_name: str,
    y_train: Optional[np.ndarray] = None,
) -> Dict:
    """Accuracy, macro/weighted F1, per-class breakdown, confusion matrix."""
    from sklearn.metrics import (
        accuracy_score, confusion_matrix, f1_score, precision_recall_fscore_support,
    )

    labels = sorted(set(np.unique(y_true).tolist()) | set(np.unique(y_pred).tolist()))

    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, zero_division=0
    )

    per_class = []
    for i, lab in enumerate(labels):
        per_class.append({
            "class": _py(lab),
            "precision": float(precision[i]),
            "recall": float(recall[i]),
            "f1": float(f1[i]),
            "support": int(support[i]),
        })

    out = {
        "target": target_name,
        "banner": SYNTHETIC_BANNER,
        "n_samples": int(len(y_true)),
        "classes": [_py(v) for v in labels],
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "per_class": per_class,
        "confusion_matrix": {
            "labels": [_py(v) for v in labels],
            "rows_are_true_cols_are_predicted": confusion_matrix(
                y_true, y_pred, labels=labels
            ).tolist(),
        },
    }

    if y_train is not None:
        out["majority_class_baseline"] = majority_class_baseline(y_train, y_true)
        out["beats_baseline"] = bool(
            out["accuracy"] > out["majority_class_baseline"]["accuracy"]
        )

    return out


def joint_exact_match(
    y_sf_true: np.ndarray, y_sf_pred: np.ndarray,
    y_tp_true: np.ndarray, y_tp_pred: np.ndarray,
) -> Dict:
    """Fraction of rows where BOTH SF and TX power are predicted correctly.

    This is the metric that reflects usefulness: half a configuration is not
    a configuration. It is always <= min(sf_accuracy, tp_accuracy).
    """
    both = (y_sf_true == y_sf_pred) & (y_tp_true == y_tp_pred)
    return {
        "metric": "joint_exact_match_accuracy",
        "banner": SYNTHETIC_BANNER,
        "description": "both SF and TX power correct on the same row",
        "accuracy": float(np.mean(both)),
        "n_samples": int(len(both)),
        "n_correct": int(np.sum(both)),
    }


def per_context_agreement(
    groups: np.ndarray,
    y_sf_true: np.ndarray, y_sf_pred: np.ndarray,
    y_tp_true: np.ndarray, y_tp_pred: np.ndarray,
) -> Dict:
    """Score at CONTEXT level rather than row level.

    Because one label covers every row of a context, row-level accuracy
    over-counts: a context with 180 rows contributes 180 times as much as a
    context with 1. This aggregates each context by majority vote first, so
    each context counts once — much closer to the real sample size.
    """
    import pandas as pd

    frame = pd.DataFrame({
        "group": groups,
        "sf_true": y_sf_true, "sf_pred": y_sf_pred,
        "tp_true": y_tp_true, "tp_pred": y_tp_pred,
    })

    correct_sf = correct_tp = correct_both = 0
    contexts = frame["group"].nunique()

    for _, grp in frame.groupby("group"):
        sf_true = grp["sf_true"].iloc[0]
        tp_true = grp["tp_true"].iloc[0]
        sf_vote = grp["sf_pred"].mode().iloc[0]
        tp_vote = grp["tp_pred"].mode().iloc[0]
        sf_ok = sf_vote == sf_true
        tp_ok = tp_vote == tp_true
        correct_sf += int(sf_ok)
        correct_tp += int(tp_ok)
        correct_both += int(sf_ok and tp_ok)

    return {
        "metric": "per_context_majority_vote_accuracy",
        "banner": SYNTHETIC_BANNER,
        "description": (
            "each context counts once, via majority vote over its rows — "
            "closer to the true sample size than row-level accuracy"
        ),
        "n_contexts": int(contexts),
        "sf_accuracy": correct_sf / contexts if contexts else 0.0,
        "tp_accuracy": correct_tp / contexts if contexts else 0.0,
        "joint_accuracy": correct_both / contexts if contexts else 0.0,
    }


def _py(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    return v
