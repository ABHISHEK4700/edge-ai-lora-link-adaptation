"""
train_logistic_regression.py

Checkpoint 5 — Logistic Regression training, model saving, and metadata
reporting. A second lightweight ML candidate, trained and evaluated exactly
like Checkpoint 4's Decision Tree, for a software-level comparison.

*** SOFTWARE PIPELINE VALIDATION ONLY. ***
As of Checkpoint 5 the only data in this project is fabricated test-fixture
data. Anything this script produces demonstrates that the pipeline executes
for a second model family. It is not a research result, and it says nothing
about real LoRa behaviour, and it is not evidence that Logistic Regression is
better or worse than the Decision Tree — see ml/evaluation/compare_models.py
for the explicit non-claims that govern any comparison.

WHY LOGISTIC REGRESSION, AND WHY THIS SHAPE
--------------------------------------------
Checkpoint 5's brief is a second lightweight edge-deployable candidate to
compare against the Decision Tree, using the SAME dataset, SAME causal
feature set, and SAME (SF, TP) target framework built in Checkpoints 2-4.
Nothing about the data pipeline changes here; only the model family does.

Two separate LogisticRegression classifiers are trained, one per target
(SF, TP) — mirroring Checkpoint 4's "two trees, not one multi-output model"
decision, for the same reasons: independently inspectable models, and
depth/size/timing reportable per target. A multinomial LogisticRegression
handles the >2-class case natively (softmax over classes), so no
one-vs-rest wrapper is needed.

Unlike a Decision Tree, Logistic Regression is scale-sensitive: features on
different scales (RSSI in dBm vs. a 0-1 success rate) bias the solver's
gradient steps and its L2 regularisation penalises large-magnitude
coefficients unevenly across features. A StandardScaler is therefore fit on
the TRAINING split only and composed into a single `sklearn.Pipeline` with
the classifier, so:

  * the scaler's mean/variance are never computed from test-split rows
    (which would itself be a form of leakage across the context split);
  * the saved bundle is one object that scales and predicts together — a
    caller cannot accidentally skip the scaling step.

DELIBERATELY NOT TUNED
-----------------------
No hyperparameter search, no regularisation-strength sweep, no class
weighting — same discipline as Checkpoint 4. `C=1.0` (scikit-learn's
default inverse regularisation strength) and `max_iter` large enough for
the solver to converge on this fixture are the only choices made, and
`tuned: False` is recorded in the metadata exactly as it was for the tree.

Usage:
    python -m ml.training.train_logistic_regression \\
        --input  <labeled.csv> \\
        --outdir ml/models/
"""

from __future__ import annotations

import argparse
import json
import platform
import sys
import time
import warnings
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from .dataset import (
    GROUP_COLUMN,
    build_dataset,
    context_aware_split,
    describe_split,
    load_labeled_frame,
    resolve_feature_columns,
)

#: Not tuned — see module docstring. max_iter is generous purely so the
#: solver reliably converges on a small fixture; it is not a performance knob.
DEFAULT_C = 1.0
DEFAULT_MAX_ITER = 2000
DEFAULT_SOLVER = "lbfgs"
DEFAULT_TEST_SIZE = 0.3
DEFAULT_RANDOM_STATE = 0

MODEL_FILENAME = "logistic_regression_sf_tp.joblib"
METADATA_FILENAME = "logistic_regression_sf_tp_metadata.json"


def _logreg_stats(pipeline) -> Dict:
    """Structural statistics of a fitted (scaler + LogisticRegression) pipeline."""
    clf = pipeline.named_steps["logreg"]
    n_iter = [int(x) for x in np.atleast_1d(clf.n_iter_)]
    converged = all(n < clf.max_iter for n in n_iter)
    return {
        "solver": clf.solver,
        "C": clf.C,
        "max_iter_configured": clf.max_iter,
        "n_iter": n_iter,
        "converged": converged,
        "n_classes": int(len(clf.classes_)),
        "classes": [_py(c) for c in clf.classes_],
        "n_features_in": int(clf.n_features_in_),
        # Every feature has a coefficient in (multinomial) LogisticRegression;
        # there is no structural sparsity the way a tree has unused features,
        # so this counts coefficients, not "features actually used" as the
        # tree's feature_importances_ > 0 count does.
        "n_coefficients_per_class": int(clf.coef_.shape[1]),
    }


def _coefficients(pipeline, feature_columns) -> Dict:
    """Per-class, per-feature coefficients, for inspectability parity with
    the Decision Tree's feature_importances_.

    scikit-learn's binary LogisticRegression stores a single coefficient
    row (for classes_[1] against classes_[0]), not one row per class — the
    2-class case is handled explicitly here rather than silently truncated
    by zip() against a 2-element classes_ array.
    """
    clf = pipeline.named_steps["logreg"]
    out = {}
    if len(clf.classes_) == 2 and clf.coef_.shape[0] == 1:
        label = f"{_py(clf.classes_[1])}_vs_{_py(clf.classes_[0])}"
        out[label] = {
            name: float(w) for name, w in zip(feature_columns, clf.coef_[0])
        }
    else:
        for cls, row in zip(clf.classes_, clf.coef_):
            out[str(_py(cls))] = {
                name: float(w) for name, w in zip(feature_columns, row)
            }
    return out


def _measure_inference_time(pipeline, X: np.ndarray, repeats: int = 5) -> Dict:
    """Time a batch prediction (scaling + inference together) and derive a
    per-row figure.

    Measured on this build machine with scikit-learn, which is NOT the
    ESP32. It is a pipeline sanity check and a like-for-like comparison
    point against the Decision Tree's own build-machine timing, not an
    edge-latency estimate.
    """
    if len(X) == 0:
        return {"measured": False, "reason": "no rows to predict"}

    timings = []
    for _ in range(repeats):
        start = time.perf_counter()
        pipeline.predict(X)
        timings.append(time.perf_counter() - start)

    best = min(timings)
    return {
        "measured": True,
        "n_rows": int(len(X)),
        "repeats": repeats,
        "batch_seconds_best_of_n": best,
        "per_row_microseconds": (best / len(X)) * 1e6,
        "caveat": (
            "Measured with scikit-learn on the build machine, not on an "
            "ESP32. Not an edge-latency figure. Includes StandardScaler "
            "transform time, since a deployed model must scale its own "
            "inputs."
        ),
    }


def train(
    input_path: str,
    outdir: str,
    C: float = DEFAULT_C,
    max_iter: int = DEFAULT_MAX_ITER,
    solver: str = DEFAULT_SOLVER,
    test_size: float = DEFAULT_TEST_SIZE,
    random_state: int = DEFAULT_RANDOM_STATE,
    include_current_link: bool = False,
    save_model: bool = True,
) -> Dict:
    """Train SF and TX-power Logistic Regression predictors and save the
    model bundle.

    Returns a metadata dict (also written to disk as JSON). Mirrors
    ml.training.train_decision_tree.train() in shape and in every scope
    constraint (same dataset, same features, same targets, same split,
    same synthetic-data banner and non-claims), so the two are directly
    comparable.
    """
    import joblib
    from sklearn.exceptions import ConvergenceWarning
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    from ml.evaluation.metrics import (
        SYNTHETIC_BANNER,
        classification_metrics,
        joint_exact_match,
        per_context_agreement,
    )

    feature_columns = resolve_feature_columns(include_current_link)

    df = load_labeled_frame(input_path)
    X, y_sf, y_tp, groups, summary = build_dataset(
        df, feature_columns=feature_columns
    )

    train_idx, test_idx = context_aware_split(
        groups, test_size=test_size, random_state=random_state
    )
    split_info = describe_split(groups, train_idx, test_idx)

    X_tr, X_te = X[train_idx], X[test_idx]
    sf_tr, sf_te = y_sf[train_idx], y_sf[test_idx]
    tp_tr, tp_te = y_tp[train_idx], y_tp[test_idx]
    groups_te = groups[test_idx]

    def _make_pipeline():
        return Pipeline([
            ("scaler", StandardScaler()),
            ("logreg", LogisticRegression(
                C=C, max_iter=max_iter, solver=solver,
                random_state=random_state,
            )),
        ])

    # --- Train ---------------------------------------------------------
    # A ConvergenceWarning is informative, not silent failure: it is caught
    # and recorded in the metadata (see "converged" in _logreg_stats)
    # rather than left to print to stderr or being suppressed unnoticed.
    sf_pipeline = _make_pipeline()
    with warnings.catch_warnings(record=True) as sf_warnings:
        warnings.simplefilter("always", ConvergenceWarning)
        start = time.perf_counter()
        sf_pipeline.fit(X_tr, sf_tr)
        sf_train_seconds = time.perf_counter() - start

    tp_pipeline = _make_pipeline()
    with warnings.catch_warnings(record=True) as tp_warnings:
        warnings.simplefilter("always", ConvergenceWarning)
        start = time.perf_counter()
        tp_pipeline.fit(X_tr, tp_tr)
        tp_train_seconds = time.perf_counter() - start

    # --- Predict and evaluate -------------------------------------------
    sf_pred = sf_pipeline.predict(X_te)
    tp_pred = tp_pipeline.predict(X_te)

    sf_metrics = classification_metrics(sf_te, sf_pred, "spreading_factor", sf_tr)
    tp_metrics = classification_metrics(tp_te, tp_pred, "tx_power_dbm", tp_tr)
    joint = joint_exact_match(sf_te, sf_pred, tp_te, tp_pred)
    by_context = per_context_agreement(groups_te, sf_te, sf_pred, tp_te, tp_pred)

    # --- Save ------------------------------------------------------------
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    model_path = out / MODEL_FILENAME
    model_bytes = None

    bundle = {
        "sf_model": sf_pipeline,
        "tp_model": tp_pipeline,
        "feature_columns": feature_columns,
        "sf_target": "label_sf",
        "tp_target": "label_tp_dbm",
        "model_family": "LogisticRegression (scikit-learn, multinomial) "
                         "with StandardScaler, one per target",
        "provenance": SYNTHETIC_BANNER,
        "trained_from": str(input_path),
    }
    if save_model:
        joblib.dump(bundle, model_path)
        model_bytes = model_path.stat().st_size

    inference = _measure_inference_time(sf_pipeline, X_te)

    # --- Metadata ----------------------------------------------------------
    metadata = {
        "banner": SYNTHETIC_BANNER,
        "status": "SOFTWARE PIPELINE VALIDATION ONLY — no real hardware data",
        "checkpoint": "CP05",
        "model_family": "LogisticRegression (scikit-learn, multinomial) "
                         "with StandardScaler, one per target",
        "tuned": False,
        "tuning_note": (
            "No hyperparameter search was performed. C uses scikit-learn's "
            "default (1.0) and max_iter was set generously only so the "
            "solver reliably converges on this fixture — neither was found "
            "to be optimal."
        ),
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "scikit_learn": _sklearn_version(),
            "joblib": _joblib_version(),
        },
        "data": summary.as_dict(),
        "split": split_info,
        "hyperparameters": {
            "C": C,
            "max_iter": max_iter,
            "solver": solver,
            "test_size": test_size,
            "random_state": random_state,
            "include_current_link_features": include_current_link,
            "scaling": "StandardScaler, fit on the training split only",
        },
        "sf_logreg": {
            **_logreg_stats(sf_pipeline),
            "training_seconds": sf_train_seconds,
            "convergence_warnings": [str(w.message) for w in sf_warnings],
            "coefficients": _coefficients(sf_pipeline, feature_columns),
        },
        "tp_logreg": {
            **_logreg_stats(tp_pipeline),
            "training_seconds": tp_train_seconds,
            "convergence_warnings": [str(w.message) for w in tp_warnings],
            "coefficients": _coefficients(tp_pipeline, feature_columns),
        },
        "total_training_seconds": sf_train_seconds + tp_train_seconds,
        "inference_timing": inference,
        "model_file": {
            "path": str(model_path) if save_model else None,
            "bytes": model_bytes,
            "kilobytes": round(model_bytes / 1024, 2) if model_bytes else None,
            "format": "joblib (scikit-learn Pipeline objects)",
            "note": (
                "This is the desktop serialisation size, not an ESP32 "
                "footprint. Converting the decision logic to something an "
                "ESP32 can run is a later checkpoint."
            ),
        },
        "metrics": {
            "banner": SYNTHETIC_BANNER,
            "spreading_factor": sf_metrics,
            "tx_power_dbm": tp_metrics,
            "joint": joint,
            "per_context": by_context,
        },
        "explicit_non_claims": [
            "This does NOT demonstrate improved packet delivery ratio.",
            "This does NOT demonstrate improved latency.",
            "This does NOT demonstrate improved energy consumption.",
            "This does NOT demonstrate faster adaptation than ADR.",
            "This model is NOT validated for real LoRa communication.",
            "These metrics are NOT evidence of project success.",
            "This does NOT show Logistic Regression is better or worse "
            "than the Decision Tree — see ml/evaluation/compare_models.py "
            "for a direct, equally-caveated comparison.",
            ("The fixture is trivially separable by construction, so a high "
             "score is expected and indicates only that the code ran."),
        ],
    }

    if save_model:
        with open(out / METADATA_FILENAME, "w", encoding="utf-8") as fh:
            json.dump(metadata, fh, indent=2)
            fh.write("\n")

    return metadata


def _sklearn_version() -> str:
    import sklearn
    return sklearn.__version__


def _joblib_version() -> str:
    import joblib
    return joblib.__version__


def _py(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    return v


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Train Logistic Regression SF/TX-power predictors from a "
            "labeled CSV. SOFTWARE PIPELINE VALIDATION ONLY — not a "
            "research run."
        )
    )
    p.add_argument("--input", "-i", required=True,
                   help="Labeled CSV from ml.labeling.labeler.")
    p.add_argument("--outdir", "-o", default="ml/models",
                   help="Directory to write the model and metadata to.")
    p.add_argument("--C", type=float, default=DEFAULT_C,
                   help=f"Inverse regularisation strength (default {DEFAULT_C}).")
    p.add_argument("--max-iter", type=int, default=DEFAULT_MAX_ITER,
                   help=f"Solver iteration cap (default {DEFAULT_MAX_ITER}).")
    p.add_argument("--solver", default=DEFAULT_SOLVER,
                   choices=["lbfgs", "newton-cg", "sag", "saga"],
                   help=f"scikit-learn solver (default {DEFAULT_SOLVER}).")
    p.add_argument("--test-size", type=float, default=DEFAULT_TEST_SIZE,
                   help=f"Fraction of CONTEXTS held out (default {DEFAULT_TEST_SIZE}).")
    p.add_argument("--random-state", type=int, default=DEFAULT_RANDOM_STATE)
    p.add_argument("--include-current-link", action="store_true",
                   help="Also use the current row's rssi_dbm/snr_db as features. "
                        "Off by default — see ml/training/dataset.py on causality.")
    p.add_argument("--no-save", action="store_true",
                   help="Train and report without writing any model file.")
    return p


def main(argv=None):
    args = _build_arg_parser().parse_args(argv)

    try:
        metadata = train(
            input_path=args.input,
            outdir=args.outdir,
            C=args.C,
            max_iter=args.max_iter,
            solver=args.solver,
            test_size=args.test_size,
            random_state=args.random_state,
            include_current_link=args.include_current_link,
            save_model=not args.no_save,
        )
    except FileNotFoundError:
        print(f"ERROR: input file not found: {args.input}", file=sys.stderr)
        print("Produce one with: python -m ml.labeling.labeler --input "
              "<processed.csv> --output <labeled.csv>", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    from ml.evaluation.metrics import SYNTHETIC_BANNER
    print("=" * 70)
    print(SYNTHETIC_BANNER)
    print("=" * 70)
    print(json.dumps(metadata, indent=2))
    print("=" * 70)
    print(SYNTHETIC_BANNER)
    print("=" * 70)


if __name__ == "__main__":
    main()
