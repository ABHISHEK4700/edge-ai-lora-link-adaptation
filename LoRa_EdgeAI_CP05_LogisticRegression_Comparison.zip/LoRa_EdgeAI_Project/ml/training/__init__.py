"""
ml.training — Checkpoint 4: Decision Tree training. Checkpoint 5: Logistic
Regression training (a second candidate, same dataset/features/targets).

SOFTWARE PIPELINE VALIDATION ONLY. As of Checkpoint 5 the only data in this
project is fabricated test-fixture data, so nothing produced here is a
research result or a claim about real LoRa behaviour, and nothing here is
evidence that one model family is better than the other.

Read ml/training/README.md before using any of this.
"""
