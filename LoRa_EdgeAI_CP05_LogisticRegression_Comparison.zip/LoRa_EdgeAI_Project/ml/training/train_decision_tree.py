"""
train_decision_tree.py

Checkpoint 4 — Decision Tree training, model saving, and metadata reporting.

*** SOFTWARE PIPELINE VALIDATION ONLY. ***
As of Checkpoint 4 the only data in this project is fabricated test-fixture
data. Anything this script produces demonstrates that the pipeline executes.
It is not a research result, and it says nothing about real LoRa behaviour.

WHY TWO TREES RATHER THAN ONE
-----------------------------
SF and TX power are predicted by two separate DecisionTreeClassifiers rather
than one multi-output tree. Reasons:

  * the eventual ESP32 deployment wants small, independently inspectable
    decision functions that can be hand-translated to C if needed;
  * depth, node count and size are reportable per target, which is what the
    edge-deployment checkpoints will need to budget against;
  * a multi-output tree is forced to split on whatever helps both targets at
    once, which couples two decisions that may want different features.

The trade-off: two independent trees can emit a combination that never
occurred in training (a valid SF with an implausible TX power for it). The
joint exact-match metric in ml/evaluation/metrics.py exists to expose that,
and a later checkpoint could switch to predicting the (SF, TP) pair as a
single joint class if it proves to matter.

DELIBERATELY NOT TUNED
----------------------
No hyperparameter search, no pruning sweep, no class weighting. The point of
this checkpoint is to verify the pipeline, not to produce a good model.
`max_depth` defaults to a small value purely to keep the tree inspectable and
edge-deployable, not because it was found to be optimal.

Usage:
    python -m ml.training.train_decision_tree \\
        --input  <labeled.csv> \\
        --outdir ml/models/
"""

from __future__ import annotations

import argparse
import json
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from .dataset import (
    GROUP_COLUMN,
    build_dataset,
    context_aware_split,
    describe_split,
    load_labeled_frame,
    resolve_feature_columns,
)

#: Kept small on purpose: an inspectable, edge-deployable tree, not a tuned one.
DEFAULT_MAX_DEPTH = 6
DEFAULT_MIN_SAMPLES_LEAF = 5
DEFAULT_TEST_SIZE = 0.3
DEFAULT_RANDOM_STATE = 0

MODEL_FILENAME = "decision_tree_sf_tp.joblib"
METADATA_FILENAME = "decision_tree_sf_tp_metadata.json"


def _tree_stats(clf) -> Dict:
    """Structural statistics of a fitted DecisionTreeClassifier."""
    t = clf.tree_
    return {
        "max_depth_configured": clf.max_depth,
        "actual_depth": int(clf.get_depth()),
        "n_nodes": int(t.node_count),
        "n_leaves": int(clf.get_n_leaves()),
        "n_internal_nodes": int(t.node_count - clf.get_n_leaves()),
        "n_features_used": int(np.sum(clf.feature_importances_ > 0)),
        "n_classes": int(len(clf.classes_)),
        "classes": [_py(c) for c in clf.classes_],
    }


def _feature_importances(clf, feature_columns) -> Dict[str, float]:
    return {
        name: float(score)
        for name, score in zip(feature_columns, clf.feature_importances_)
    }


def _measure_inference_time(clf, X: np.ndarray, repeats: int = 5) -> Dict:
    """Time a batch prediction and derive a per-row figure.

    Measured on this build machine with scikit-learn, which is NOT the ESP32.
    It is a pipeline sanity check, not an edge-latency estimate — on-device
    inference is a later checkpoint and will need measuring on real hardware.
    """
    if len(X) == 0:
        return {"measured": False, "reason": "no rows to predict"}

    timings = []
    for _ in range(repeats):
        start = time.perf_counter()
        clf.predict(X)
        timings.append(time.perf_counter() - start)

    best = min(timings)
    return {
        "measured": True,
        "n_rows": int(len(X)),
        "repeats": repeats,
        "batch_seconds_best_of_n": best,
        "per_row_microseconds": (best / len(X)) * 1e6,
        "caveat": (
            "Measured with scikit-learn on the build machine, not on an "
            "ESP32. Not an edge-latency figure."
        ),
    }


def train(
    input_path: str,
    outdir: str,
    max_depth: Optional[int] = DEFAULT_MAX_DEPTH,
    min_samples_leaf: int = DEFAULT_MIN_SAMPLES_LEAF,
    test_size: float = DEFAULT_TEST_SIZE,
    random_state: int = DEFAULT_RANDOM_STATE,
    include_current_link: bool = False,
    save_model: bool = True,
) -> Dict:
    """Train SF and TX-power decision trees and save the model bundle.

    Returns a metadata dict (also written to disk as JSON).
    """
    import joblib
    from sklearn.tree import DecisionTreeClassifier

    from ml.evaluation.metrics import (
        SYNTHETIC_BANNER,
        classification_metrics,
        joint_exact_match,
        per_context_agreement,
    )

    feature_columns = resolve_feature_columns(include_current_link)

    df = load_labeled_frame(input_path)
    X, y_sf, y_tp, groups, summary = build_dataset(
        df, feature_columns=feature_columns
    )

    train_idx, test_idx = context_aware_split(
        groups, test_size=test_size, random_state=random_state
    )
    split_info = describe_split(groups, train_idx, test_idx)

    X_tr, X_te = X[train_idx], X[test_idx]
    sf_tr, sf_te = y_sf[train_idx], y_sf[test_idx]
    tp_tr, tp_te = y_tp[train_idx], y_tp[test_idx]
    groups_te = groups[test_idx]

    # --- Train -------------------------------------------------------------
    sf_clf = DecisionTreeClassifier(
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=random_state,
    )
    start = time.perf_counter()
    sf_clf.fit(X_tr, sf_tr)
    sf_train_seconds = time.perf_counter() - start

    tp_clf = DecisionTreeClassifier(
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        random_state=random_state,
    )
    start = time.perf_counter()
    tp_clf.fit(X_tr, tp_tr)
    tp_train_seconds = time.perf_counter() - start

    # --- Predict and evaluate ---------------------------------------------
    sf_pred = sf_clf.predict(X_te)
    tp_pred = tp_clf.predict(X_te)

    sf_metrics = classification_metrics(sf_te, sf_pred, "spreading_factor", sf_tr)
    tp_metrics = classification_metrics(tp_te, tp_pred, "tx_power_dbm", tp_tr)
    joint = joint_exact_match(sf_te, sf_pred, tp_te, tp_pred)
    by_context = per_context_agreement(groups_te, sf_te, sf_pred, tp_te, tp_pred)

    # --- Save --------------------------------------------------------------
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    model_path = out / MODEL_FILENAME
    model_bytes = None

    bundle = {
        "sf_model": sf_clf,
        "tp_model": tp_clf,
        "feature_columns": feature_columns,
        "sf_target": "label_sf",
        "tp_target": "label_tp_dbm",
        "provenance": SYNTHETIC_BANNER,
        "trained_from": str(input_path),
    }
    if save_model:
        joblib.dump(bundle, model_path)
        model_bytes = model_path.stat().st_size

    inference = _measure_inference_time(sf_clf, X_te)

    # --- Metadata ----------------------------------------------------------
    metadata = {
        "banner": SYNTHETIC_BANNER,
        "status": "SOFTWARE PIPELINE VALIDATION ONLY — no real hardware data",
        "checkpoint": "CP04",
        "model_family": "DecisionTreeClassifier (scikit-learn), one per target",
        "tuned": False,
        "tuning_note": (
            "No hyperparameter search was performed. max_depth and "
            "min_samples_leaf were set to small fixed values to keep the "
            "trees inspectable and edge-deployable, not because they were "
            "found to be optimal."
        ),
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "scikit_learn": _sklearn_version(),
            "joblib": _joblib_version(),
        },
        "data": summary.as_dict(),
        "split": split_info,
        "hyperparameters": {
            "max_depth": max_depth,
            "min_samples_leaf": min_samples_leaf,
            "test_size": test_size,
            "random_state": random_state,
            "include_current_link_features": include_current_link,
        },
        "sf_tree": {
            **_tree_stats(sf_clf),
            "training_seconds": sf_train_seconds,
            "feature_importances": _feature_importances(sf_clf, feature_columns),
        },
        "tp_tree": {
            **_tree_stats(tp_clf),
            "training_seconds": tp_train_seconds,
            "feature_importances": _feature_importances(tp_clf, feature_columns),
        },
        "total_training_seconds": sf_train_seconds + tp_train_seconds,
        "inference_timing": inference,
        "model_file": {
            "path": str(model_path) if save_model else None,
            "bytes": model_bytes,
            "kilobytes": round(model_bytes / 1024, 2) if model_bytes else None,
            "format": "joblib (scikit-learn objects)",
            "note": (
                "This is the desktop serialisation size, not an ESP32 "
                "footprint. Converting the decision logic to something an "
                "ESP32 can run is a later checkpoint."
            ),
        },
        "metrics": {
            "banner": SYNTHETIC_BANNER,
            "spreading_factor": sf_metrics,
            "tx_power_dbm": tp_metrics,
            "joint": joint,
            "per_context": by_context,
        },
        "explicit_non_claims": [
            "This does NOT demonstrate improved packet delivery ratio.",
            "This does NOT demonstrate improved latency.",
            "This does NOT demonstrate improved energy consumption.",
            "This does NOT demonstrate faster adaptation than ADR.",
            "This model is NOT validated for real LoRa communication.",
            "These metrics are NOT evidence of project success.",
            ("The fixture is trivially separable by construction, so a high "
             "score is expected and indicates only that the code ran."),
        ],
    }

    if save_model:
        with open(out / METADATA_FILENAME, "w", encoding="utf-8") as fh:
            json.dump(metadata, fh, indent=2)
            fh.write("\n")

    return metadata


def _sklearn_version() -> str:
    import sklearn
    return sklearn.__version__


def _joblib_version() -> str:
    import joblib
    return joblib.__version__


def _py(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    return v


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Train Decision Tree SF/TX-power predictors from a labeled CSV. "
            "SOFTWARE PIPELINE VALIDATION ONLY — not a research run."
        )
    )
    p.add_argument("--input", "-i", required=True,
                   help="Labeled CSV from ml.labeling.labeler.")
    p.add_argument("--outdir", "-o", default="ml/models",
                   help="Directory to write the model and metadata to.")
    p.add_argument("--max-depth", type=int, default=DEFAULT_MAX_DEPTH,
                   help=f"Tree max depth (default {DEFAULT_MAX_DEPTH}).")
    p.add_argument("--min-samples-leaf", type=int, default=DEFAULT_MIN_SAMPLES_LEAF,
                   help=f"Minimum samples per leaf (default {DEFAULT_MIN_SAMPLES_LEAF}).")
    p.add_argument("--test-size", type=float, default=DEFAULT_TEST_SIZE,
                   help=f"Fraction of CONTEXTS held out (default {DEFAULT_TEST_SIZE}).")
    p.add_argument("--random-state", type=int, default=DEFAULT_RANDOM_STATE)
    p.add_argument("--include-current-link", action="store_true",
                   help="Also use the current row's rssi_dbm/snr_db as features. "
                        "Off by default — see ml/training/dataset.py on causality.")
    p.add_argument("--no-save", action="store_true",
                   help="Train and report without writing any model file.")
    return p


def main(argv=None):
    args = _build_arg_parser().parse_args(argv)

    try:
        metadata = train(
            input_path=args.input,
            outdir=args.outdir,
            max_depth=args.max_depth,
            min_samples_leaf=args.min_samples_leaf,
            test_size=args.test_size,
            random_state=args.random_state,
            include_current_link=args.include_current_link,
            save_model=not args.no_save,
        )
    except FileNotFoundError:
        print(f"ERROR: input file not found: {args.input}", file=sys.stderr)
        print("Produce one with: python -m ml.labeling.labeler --input "
              "<processed.csv> --output <labeled.csv>", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    from ml.evaluation.metrics import SYNTHETIC_BANNER
    print("=" * 70)
    print(SYNTHETIC_BANNER)
    print("=" * 70)
    print(json.dumps(metadata, indent=2))
    print("=" * 70)
    print(SYNTHETIC_BANNER)
    print("=" * 70)


if __name__ == "__main__":
    main()
