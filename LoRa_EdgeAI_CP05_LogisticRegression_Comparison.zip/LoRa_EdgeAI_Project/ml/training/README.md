# `ml/training/` — Model Training (Checkpoint 4, extended in Checkpoint 5)

> **SOFTWARE PIPELINE VALIDATION ONLY.** The project has no real LoRa data
> yet. Everything this package produces demonstrates that the pipeline
> executes — nothing more.

## Pipeline position

```
data/raw/<session>.csv
   -> ml/preprocessing/pipeline.py    (CP2)  clean + rolling history features
   -> ml/labeling/labeler.py          (CP3)  derive (SF, TP) targets
   -> ml/training/train_decision_tree.py       (CP4)  train tree, save, report
   -> ml/training/train_logistic_regression.py (CP5)  train LR,   save, report
   -> ml/evaluation/evaluate.py       (CP4)  reload either bundle, score, report
   -> ml/evaluation/compare_models.py (CP5)  compare both bundles side by side
```

## Modules

| File | Responsibility |
|---|---|
| `dataset.py` | Feature assembly, the leakage guard, and context-aware splitting — shared unchanged by both trainers |
| `train_decision_tree.py` | Trains the two trees, saves the bundle, writes metadata (Checkpoint 4) |
| `train_logistic_regression.py` | Trains two (StandardScaler + LogisticRegression) pipelines, saves the bundle, writes metadata (Checkpoint 5) |

## Two rules this package enforces

**1. Causality.** The device picks SF and TX power *before* transmitting, so
any feature only knowable afterwards is unusable. `BANNED_FEATURE_COLUMNS`
rejects the current row's own `packet_success` and `retry_count` (outcomes of
the transmission being decided) and its own `sf` / `tp_dbm` (the decision
itself). The guard raises rather than warns, at both entry points.

The default feature set is Checkpoint 2's rolling history features, which are
already shifted by one packet. They carry all four project inputs — RSSI,
SNR, success/failure history, retry count — in lagged form.

The current row's `rssi_dbm` / `snr_db` are off by default: in a real log,
row *i*'s RSSI is measured *during* transmission *i*, so using it to choose
that transmission's configuration peeks one step ahead. `--include-current-link`
turns them on for comparison.

**2. Context-aware splitting.** One label covers every row of a context, so a
random row split would put the same context on both sides and let the model
score by recognition. All splitting is by `context_id`.

This also means **the effective sample size is the number of contexts, not
the number of rows.** 5,400 rows across 30 contexts is a 30-sample problem.
Every report states both.

## Model choice

**Checkpoint 4 — Decision Tree.** Two separate `DecisionTreeClassifier`s,
one per target, rather than one multi-output tree — small independently
inspectable decision functions suit the eventual ESP32 port, and
depth/nodes/size are reportable per target. The trade-off is that two
independent trees can emit a combination never seen in training; the joint
exact-match metric exists to expose that.

Not tuned. No hyperparameter search, no pruning sweep, no class weighting.
`max_depth=6` and `min_samples_leaf=5` keep the trees inspectable, not
optimal. Tuning belongs after real data exists.

**Checkpoint 5 — Logistic Regression.** A second lightweight candidate, on
the identical dataset, features and targets. Also two separate models — one
`LogisticRegression` per target — for the same inspectability reasoning as
the tree. Unlike a tree, Logistic Regression is scale-sensitive, so each
model is an `sklearn.Pipeline` of `(StandardScaler, LogisticRegression)`,
with the scaler fit on the training split only (fitting it on the full
dataset before splitting would itself leak test-split statistics into
training). Multinomial (softmax) classification is used natively — no
one-vs-rest wrapper — so 3+ class targets (e.g. spreading factor) are
handled directly.

Not tuned, same discipline as the tree. `C=1.0` is scikit-learn's default
regularisation strength; `max_iter` is set generously purely so the solver
reliably converges on this fixture, and convergence is recorded in the
metadata (`converged: bool`) rather than assumed.

**Neither model is presented as better than the other.**
`ml/evaluation/compare_models.py` evaluates both on an identical held-out
split and reports predictive metrics, model size, training time and
inference time side by side, with an explicit statement in every generated
report that none of it licenses a superiority claim on synthetic data.

## Usage

```bash
# Train the Decision Tree (writes model + metadata)
python -m ml.training.train_decision_tree \
    --input <labeled.csv> --outdir ml/models

# Train Logistic Regression (writes model + metadata)
python -m ml.training.train_logistic_regression \
    --input <labeled.csv> --outdir ml/models

# Train without saving anything (either trainer)
python -m ml.training.train_decision_tree --input <labeled.csv> --no-save
python -m ml.training.train_logistic_regression --input <labeled.csv> --no-save

# Compare the two, once both are trained
python -m ml.evaluation.compare_models \
    --dt-model ml/models/decision_tree_sf_tp.joblib \
    --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \
    --lr-model ml/models/logistic_regression_sf_tp.joblib \
    --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \
    --input <labeled.csv> --report <report.md>

# Verify the whole pipeline against synthetic test-only data
python tests/test_training.py               # Decision Tree (CP4)
python tests/test_logistic_regression.py    # Logistic Regression + comparison (CP5)
```
