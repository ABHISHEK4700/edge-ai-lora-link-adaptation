"""
dataset.py

Checkpoint 4 — Dataset assembly for model training.

Turns the labeled output of the Checkpoint 3 labeling framework into
(X, y_sf, y_tp) arrays, and splits them in a way that does not inflate the
apparent score.

TWO THINGS THIS MODULE EXISTS TO ENFORCE
----------------------------------------

**1. Causality.** The device must choose SF and TX power BEFORE transmitting.
Any feature that is only knowable after the transmission has happened cannot
be used, however predictive it looks. That rules out the current row's own
`packet_success` and `retry_count` (outcomes of the very transmission being
decided) and the current row's own `sf` / `tp_dbm` (the decision itself).
`BANNED_FEATURE_COLUMNS` lists these and `build_feature_matrix()` raises if
one ever appears in a feature list.

Checkpoint 2's rolling features are already strictly causal: they are shifted
by one packet, so a packet's own outcome never enters its own history. They
are therefore the default feature set, and they carry exactly the four inputs
the project specifies — RSSI, SNR, packet success/failure history, and retry
count — in lagged form.

The current row's `rssi_dbm` / `snr_db` are a borderline case and are OFF by
default. In a real log, row i's RSSI is measured during transmission i, so
using it to choose transmission i's configuration peeks one step ahead. A
device would instead use its most recent prior measurement. `--include-
current-link` turns them on for comparison, and the metadata report records
which setting was used.

**2. Context-aware splitting.** A label is a property of a CONTEXT, not of an
individual packet, so ~180 rows share one label. Splitting randomly by row
would put rows from the same context on both sides of the split, and the
model could score well by recognising a context it has already seen. All
splitting here is by `context_id`.

That also means the EFFECTIVE sample size is the number of contexts, not the
number of rows. A file with 5,400 rows and 30 contexts is a 30-sample
problem. `DatasetSummary` reports both so the distinction is visible.

No real or fabricated LoRa measurement data lives in this file.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

#: Strictly causal features, available to the device before it transmits.
#: These come from Checkpoint 2's feature engineering, which shifts by one
#: packet so a packet's own outcome never enters its own history.
DEFAULT_FEATURE_COLUMNS = [
    # packet success/failure history
    "rolling_success_rate_w5",
    "rolling_success_rate_w10",
    # retry count history
    "rolling_retry_avg_w5",
    "rolling_retry_avg_w10",
    # RSSI history
    "rolling_rssi_avg_w5",
    "rolling_rssi_avg_w10",
    # SNR history
    "rolling_snr_avg_w5",
    "rolling_snr_avg_w10",
]

#: Added only when include_current_link=True. See module docstring.
CURRENT_LINK_COLUMNS = ["rssi_dbm", "snr_db"]

#: Columns that must NEVER be used as features, with the reason.
BANNED_FEATURE_COLUMNS = {
    "sf": "the configuration being predicted — using it is label leakage",
    "tp_dbm": "the configuration being predicted — using it is label leakage",
    "label_sf": "this is the target",
    "label_tp_dbm": "this is the target",
    "packet_success": (
        "the outcome of the transmission being decided — not knowable "
        "before choosing a configuration"
    ),
    "retry_count": (
        "the retry count of the transmission being decided — not knowable "
        "before choosing a configuration"
    ),
    "context_id": "a grouping key; using it lets the model memorise contexts",
    "session_id": "a collection artefact, not a channel property",
    "device_id": "a collection artefact, not a channel property",
    "packet_seq": "a collection artefact, not a channel property",
    "timestamp_utc": "a collection artefact, not a channel property",
    "label_status": "labeling metadata, not an input signal",
    "selection_reason": "labeling metadata, not an input signal",
    "notes": "free text, not an input signal",
}

SF_TARGET_COLUMN = "label_sf"
TP_TARGET_COLUMN = "label_tp_dbm"
GROUP_COLUMN = "context_id"


class FeatureLeakageError(ValueError):
    """Raised when a banned column is requested as a model feature."""


@dataclass
class DatasetSummary:
    """What was loaded, and what was thrown away on the way."""
    rows_in_file: int = 0
    rows_after_label_filter: int = 0
    rows_after_nan_filter: int = 0
    contexts: int = 0
    feature_columns: List[str] = field(default_factory=list)
    sf_classes: List = field(default_factory=list)
    tp_classes: List = field(default_factory=list)
    dropped_unlabeled: int = 0
    dropped_nan_features: int = 0

    def as_dict(self) -> dict:
        return {
            "rows_in_file": self.rows_in_file,
            "rows_after_label_filter": self.rows_after_label_filter,
            "rows_after_nan_filter": self.rows_after_nan_filter,
            "usable_rows": self.rows_after_nan_filter,
            "contexts": self.contexts,
            "effective_sample_size_note": (
                "One label per context, so the effective sample size is the "
                "number of contexts, not the number of rows."
            ),
            "feature_columns": list(self.feature_columns),
            "n_features": len(self.feature_columns),
            "sf_classes": [_py(v) for v in self.sf_classes],
            "tp_classes": [_py(v) for v in self.tp_classes],
            "dropped_unlabeled_rows": self.dropped_unlabeled,
            "dropped_nan_feature_rows": self.dropped_nan_features,
        }


def resolve_feature_columns(
    include_current_link: bool = False,
    extra: Optional[List[str]] = None,
) -> List[str]:
    """Build the feature list, rejecting anything banned."""
    cols = list(DEFAULT_FEATURE_COLUMNS)
    if include_current_link:
        cols.extend(CURRENT_LINK_COLUMNS)
    if extra:
        cols.extend(extra)

    for col in cols:
        if col in BANNED_FEATURE_COLUMNS:
            raise FeatureLeakageError(
                f"Column {col!r} cannot be used as a model feature: "
                f"{BANNED_FEATURE_COLUMNS[col]}."
            )
    return cols


def load_labeled_frame(path: str) -> pd.DataFrame:
    """Read a labeled CSV produced by ml.labeling.labeler."""
    df = pd.read_csv(path)
    required = [SF_TARGET_COLUMN, TP_TARGET_COLUMN, GROUP_COLUMN]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(
            f"{path} is missing column(s) {missing}. Run the Checkpoint 3 "
            f"labeling framework first: python -m ml.labeling.labeler "
            f"--input <processed.csv> --output <labeled.csv>"
        )
    return df


def build_dataset(
    df: pd.DataFrame,
    feature_columns: Optional[List[str]] = None,
    include_current_link: bool = False,
    evidence_backed_only: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, DatasetSummary]:
    """Assemble (X, y_sf, y_tp, groups, summary) from a labeled DataFrame.

    Rows without a label, and rows whose rolling features are still NaN
    (the first packets of each context, which have no history yet), are
    dropped and counted in the summary rather than imputed. Checkpoint 2
    deliberately left that decision to training code; dropping is chosen here
    because imputing a history that does not exist would invent input data.

    `evidence_backed_only=True` keeps only rows whose `label_status` is one of
    Checkpoint 3's evidence-backed statuses, so fallback labels never enter
    training silently.
    """
    cols = feature_columns or resolve_feature_columns(include_current_link)

    for col in cols:
        if col in BANNED_FEATURE_COLUMNS:
            raise FeatureLeakageError(
                f"Column {col!r} cannot be used as a model feature: "
                f"{BANNED_FEATURE_COLUMNS[col]}."
            )

    summary = DatasetSummary(rows_in_file=len(df), feature_columns=list(cols))

    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(
            f"Feature column(s) {missing} are absent. Did the input go "
            f"through the Checkpoint 2 preprocessing pipeline "
            f"(ml/preprocessing/pipeline.py) before labeling?"
        )

    work = df.copy()

    # 1. Keep only rows that actually carry a target.
    has_label = work[SF_TARGET_COLUMN].notna() & work[TP_TARGET_COLUMN].notna()
    if evidence_backed_only and "label_status" in work.columns:
        from ml.labeling.config import LabelStatus
        has_label &= work["label_status"].isin(LabelStatus.EVIDENCE_BACKED)
    summary.dropped_unlabeled = int((~has_label).sum())
    work = work[has_label]
    summary.rows_after_label_filter = len(work)

    # 2. Drop rows whose causal history features are not yet available.
    complete = work[cols].notna().all(axis=1)
    summary.dropped_nan_features = int((~complete).sum())
    work = work[complete].reset_index(drop=True)
    summary.rows_after_nan_filter = len(work)

    if work.empty:
        raise ValueError(
            "No usable rows remain after filtering. Check that the labeling "
            "step produced evidence-backed labels — if every context was "
            "dropped, the input data has no configuration sweep to learn from."
        )

    X = work[cols].to_numpy(dtype=float)
    y_sf = work[SF_TARGET_COLUMN].to_numpy()
    y_tp = work[TP_TARGET_COLUMN].to_numpy()
    groups = work[GROUP_COLUMN].to_numpy()

    summary.contexts = int(pd.Series(groups).nunique())
    summary.sf_classes = sorted(pd.unique(y_sf).tolist())
    summary.tp_classes = sorted(pd.unique(y_tp).tolist())

    return X, y_sf, y_tp, groups, summary


def context_aware_split(
    groups: np.ndarray,
    test_size: float = 0.3,
    random_state: int = 0,
) -> Tuple[np.ndarray, np.ndarray]:
    """Split row indices so that no context appears on both sides.

    Returns (train_idx, test_idx). Uses GroupShuffleSplit, which partitions by
    group rather than by row — the split discipline Checkpoint 3's strategy
    document requires.
    """
    from sklearn.model_selection import GroupShuffleSplit

    n_groups = int(pd.Series(groups).nunique())
    if n_groups < 2:
        raise ValueError(
            f"Cannot split by context: only {n_groups} context(s) present. "
            f"A train/test split needs at least 2, and meaningfully more to "
            f"say anything. This usually means the input data lacks a "
            f"configuration sweep across varied channel conditions."
        )

    splitter = GroupShuffleSplit(
        n_splits=1, test_size=test_size, random_state=random_state
    )
    train_idx, test_idx = next(splitter.split(np.zeros(len(groups)), groups=groups))
    return train_idx, test_idx


def describe_split(groups: np.ndarray, train_idx, test_idx) -> dict:
    """Summarise a split, and assert no context straddles it."""
    train_groups = set(pd.unique(groups[train_idx]).tolist())
    test_groups = set(pd.unique(groups[test_idx]).tolist())
    overlap = train_groups & test_groups
    if overlap:
        raise AssertionError(
            f"Context leakage: {len(overlap)} context(s) appear in both the "
            f"train and test split: {sorted(overlap)[:5]}"
        )
    return {
        "train_rows": int(len(train_idx)),
        "test_rows": int(len(test_idx)),
        "train_contexts": len(train_groups),
        "test_contexts": len(test_groups),
        "context_overlap": 0,
        "split_by": GROUP_COLUMN,
    }


def _py(v):
    """Convert numpy scalars to plain Python for JSON serialisation."""
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    return v
