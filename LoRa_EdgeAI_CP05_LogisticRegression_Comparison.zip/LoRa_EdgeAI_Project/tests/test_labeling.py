"""
test_labeling.py

Checkpoint 3 — Labeling framework verification.

Verifies that the labeling code in ml/labeling/ behaves correctly, using ONLY
the fabricated fixture at tests/fixtures/synthetic_labeling_fixture_raw.csv
(see tests/fixtures/README.md). No real LoRa data is used, produced, or
implied, and nothing here is a research result.

What is checked:
  1.  Modules import.
  2.  The synthetic fixture exists and has the expected shape.
  3.  Configuration validation rejects contradictory settings.
  4.  The time-on-air formula behaves correctly (doubles per SF step,
      scales inversely with bandwidth, grows with payload).
  5.  Reliability estimators behave correctly, including the exact
      closed form of the Wilson bound at a 100% delivery ratio.
  6.  Energy models rank configurations as expected, and the
      measured-current method refuses to run on an empty table instead of
      inventing numbers.
  7.  Context assignment puts each fixture session in exactly one context.
  8.  The oracle table reproduces the fixture's hand-computed packet counts.
  9.  Label selection picks the configuration that is cheapest among those
      meeting the reliability threshold (context A).
 10.  Reliability threshold is configurable and changing it changes the label.
 11.  Candidate SF / TX-power sets are configurable and restrict selection.
 12.  Energy method is configurable and changes which configuration wins.
 13.  Tie-breaking is configurable and deterministic.
 14.  No-valid-configuration handling honours all four policies (context B).
 15.  The evidence-coverage guard refuses to label an unswept context (C).
 16.  The full pipeline runs end-to-end to a temp directory.
 17.  Labels attach to per-packet rows without leaking into the feature set.
 18.  Config JSON round-trips.
 19.  data/raw, data/processed and data/sample remain untouched.

Run with:
    python tests/test_labeling.py

Exit code 0 -> all checks passed
Exit code 1 -> at least one check failed
"""

import json
import math
import shutil
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

FIXTURE_PATH = (
    PROJECT_ROOT / "tests" / "fixtures" / "synthetic_labeling_fixture_raw.csv"
)

# Context ids the fixture is built to produce under the default strategy.
CTX_A = "dev_lab_fixture|sess_lab_fixture_A|rssi[-90:-85]|snr[7.5:10]"
CTX_B = "dev_lab_fixture|sess_lab_fixture_B|rssi[-115:-110]|snr[-12.5:-10]"
CTX_C = "dev_lab_fixture|sess_lab_fixture_C|rssi[-100:-95]|snr[0:2.5]"


def _load_fixture():
    import pandas as pd
    return pd.read_csv(FIXTURE_PATH)


def _row(df, ctx):
    """Return the single label row for a context."""
    from ml.labeling.context import CONTEXT_ID_COLUMN
    match = df[df[CONTEXT_ID_COLUMN] == ctx]
    assert len(match) == 1, f"expected exactly one label row for {ctx}"
    return match.iloc[0]


# ---------------------------------------------------------------------------

def check_imports():
    print("[CHECK] labeling modules import correctly")
    try:
        from ml.labeling import (  # noqa: F401
            LabelingConfig, build_oracle_table, select_labels, run_labeling,
        )
        from ml.labeling import airtime, context, energy, oracle, reliability  # noqa: F401
    except ImportError as e:
        print(f"  -> FAIL: could not import labeling modules ({e})")
        return False
    print("  -> OK")
    return True


def check_fixture_exists():
    print("[CHECK] synthetic labeling fixture exists and has expected shape")
    if not FIXTURE_PATH.exists():
        print("  -> FAIL: fixture not found; run "
              "tests/fixtures/make_synthetic_labeling_fixture.py")
        return False
    df = _load_fixture()
    ok = True
    if len(df) != 210:
        print(f"  -> FAIL: expected 210 fixture rows, got {len(df)}")
        ok = False
    if df["session_id"].nunique() != 3:
        print(f"  -> FAIL: expected 3 sessions, got {df['session_id'].nunique()}")
        ok = False
    if ok:
        print("  -> OK (210 fabricated rows across 3 sessions)")
    return ok


def check_config_validation():
    print("[CHECK] configuration validation rejects contradictory settings")
    from ml.labeling import LabelingConfig
    from ml.labeling.config import EnergyMethod

    cases = [
        ("min_reliability above 1", dict(min_reliability=1.5)),
        ("unknown estimator", dict(reliability_estimator="vibes")),
        ("unknown energy method", dict(energy_method="magic")),
        ("unknown cost basis", dict(cost_basis="whatever")),
        ("unknown policy", dict(no_valid_config_policy="shrug")),
        ("empty tie-break rules", dict(tie_break_rules=[])),
        ("non-deterministic final tie-break", dict(tie_break_rules=["lower_sf"])),
        ("SF candidate outside sanity bounds", dict(candidate_sf_values=[99])),
        ("negative bin width", dict(rssi_bin_width_db=-1.0)),
        ("measured-current method with empty table",
         dict(energy_method=EnergyMethod.MEASURED_CURRENT_TABLE)),
    ]

    ok = True
    for name, kwargs in cases:
        try:
            LabelingConfig(**kwargs).validate()
        except ValueError:
            continue
        print(f"  -> FAIL: '{name}' should have been rejected but was accepted")
        ok = False

    # Unknown option names must be caught on load rather than silently ignored.
    try:
        LabelingConfig.from_dict({"not_a_real_option": 1})
        print("  -> FAIL: unknown config option was silently accepted")
        ok = False
    except ValueError:
        pass

    try:
        LabelingConfig().validate()
    except ValueError as e:
        print(f"  -> FAIL: default config should be valid, but raised: {e}")
        ok = False

    if ok:
        print(f"  -> OK ({len(cases)} invalid configs rejected, defaults valid)")
    return ok


def check_airtime_formula():
    print("[CHECK] time-on-air formula scales correctly with SF, bandwidth, payload")
    from ml.labeling.airtime import symbol_time_s, time_on_air_s
    from ml.labeling.config import RadioParams

    radio = RadioParams()
    ok = True

    # Symbol time must double for each SF increment: T_sym = 2^SF / BW.
    for sf in range(7, 12):
        ratio = symbol_time_s(sf + 1, radio.bandwidth_hz) / symbol_time_s(sf, radio.bandwidth_hz)
        if not math.isclose(ratio, 2.0, rel_tol=1e-12):
            print(f"  -> FAIL: symbol time SF{sf}->SF{sf+1} ratio {ratio}, expected 2.0")
            ok = False

    # Airtime must increase monotonically with SF.
    airtimes = [time_on_air_s(sf, 20, radio) for sf in range(7, 13)]
    if airtimes != sorted(airtimes):
        print(f"  -> FAIL: airtime not monotonically increasing in SF: {airtimes}")
        ok = False

    # Doubling bandwidth must halve airtime (same symbol count).
    wide = RadioParams(bandwidth_hz=250_000.0, low_data_rate_optimize=False)
    narrow = RadioParams(bandwidth_hz=125_000.0, low_data_rate_optimize=False)
    ratio = time_on_air_s(7, 20, narrow) / time_on_air_s(7, 20, wide)
    if not math.isclose(ratio, 2.0, rel_tol=1e-9):
        print(f"  -> FAIL: halving bandwidth changed airtime by {ratio}x, expected 2.0")
        ok = False

    # A larger payload must not be faster.
    if time_on_air_s(7, 50, radio) <= time_on_air_s(7, 10, radio):
        print("  -> FAIL: larger payload did not increase airtime")
        ok = False

    # A stronger coding rate must not be faster.
    if time_on_air_s(7, 20, RadioParams(coding_rate_denominator=8)) <= \
            time_on_air_s(7, 20, RadioParams(coding_rate_denominator=5)):
        print("  -> FAIL: coding rate 4/8 was not slower than 4/5")
        ok = False

    # Invalid inputs must raise rather than return a plausible number.
    for bad in (lambda: symbol_time_s(0, 125_000.0),
                lambda: symbol_time_s(7, 0.0),
                lambda: time_on_air_s(7, -1, radio)):
        try:
            bad()
            print("  -> FAIL: invalid airtime input did not raise")
            ok = False
        except ValueError:
            pass

    if ok:
        print("  -> OK (symbol time doubles per SF, scales with BW/payload/CR)")
    return ok


def check_reliability_estimators():
    print("[CHECK] reliability estimators behave correctly on finite samples")
    from ml.labeling.reliability import (
        estimate_reliability, point_estimate, wilson_lower_bound,
    )

    ok = True

    if not math.isclose(point_estimate(15, 30), 0.5):
        print("  -> FAIL: point estimate of 15/30 is not 0.5")
        ok = False
    if point_estimate(0, 0) != 0.0:
        print("  -> FAIL: point estimate with no attempts should be 0.0")
        ok = False

    # At a 100% delivery ratio the Wilson lower bound is exactly n/(n+z^2).
    z = 1.645
    for n in (5, 12, 30, 100):
        expected = n / (n + z * z)
        got = wilson_lower_bound(n, n, z=z)
        if not math.isclose(got, expected, rel_tol=1e-12):
            print(f"  -> FAIL: wilson({n}/{n}) = {got}, expected {expected}")
            ok = False

    # Thin evidence must score strictly lower than thick evidence.
    if not wilson_lower_bound(5, 5) < wilson_lower_bound(30, 30) < wilson_lower_bound(300, 300):
        print("  -> FAIL: Wilson bound did not increase with sample size at equal ratio")
        ok = False

    # The bound must be conservative relative to the point estimate.
    if not wilson_lower_bound(27, 30) < point_estimate(27, 30):
        print("  -> FAIL: Wilson lower bound was not below the point estimate")
        ok = False

    # Bounds stay inside [0, 1].
    for s, n in ((0, 10), (10, 10), (1, 1), (0, 1)):
        v = wilson_lower_bound(s, n)
        if not 0.0 <= v <= 1.0:
            print(f"  -> FAIL: wilson({s}/{n}) = {v} outside [0, 1]")
            ok = False

    # Impossible inputs must raise.
    for bad in (lambda: point_estimate(11, 10), lambda: wilson_lower_bound(-1, 10)):
        try:
            bad()
            print("  -> FAIL: impossible success/attempt counts did not raise")
            ok = False
        except ValueError:
            pass

    try:
        estimate_reliability(1, 1, estimator="nonsense")
        print("  -> FAIL: unknown estimator name did not raise")
        ok = False
    except ValueError:
        pass

    if ok:
        print("  -> OK (Wilson bound matches n/(n+z^2) at 100%, penalises thin evidence)")
    return ok


def check_energy_models():
    print("[CHECK] energy models rank configurations correctly and refuse invented data")
    from ml.labeling.config import (
        CostBasis, EnergyMethod, EnergyParams, RadioParams,
    )
    from ml.labeling.energy import (
        EnergyModelError, apply_cost_basis, dbm_to_mw, energy_per_attempt,
    )

    radio = RadioParams()
    params = EnergyParams()
    ok = True

    if not math.isclose(dbm_to_mw(0.0), 1.0, rel_tol=1e-12):
        print("  -> FAIL: 0 dBm is not 1 mW")
        ok = False
    if not math.isclose(dbm_to_mw(20.0), 100.0, rel_tol=1e-12):
        print("  -> FAIL: 20 dBm is not 100 mW")
        ok = False

    # airtime_only must ignore TX power entirely.
    a = energy_per_attempt(7, 2.0, 20, EnergyMethod.AIRTIME_ONLY, radio, params)
    b = energy_per_attempt(7, 20.0, 20, EnergyMethod.AIRTIME_ONLY, radio, params)
    if not math.isclose(a, b):
        print("  -> FAIL: airtime_only should not vary with TX power")
        ok = False

    # airtime_x_linear_power must increase with TX power and with SF.
    low = energy_per_attempt(7, 2.0, 20, EnergyMethod.AIRTIME_X_LINEAR_POWER, radio, params)
    high = energy_per_attempt(7, 14.0, 20, EnergyMethod.AIRTIME_X_LINEAR_POWER, radio, params)
    slow = energy_per_attempt(9, 2.0, 20, EnergyMethod.AIRTIME_X_LINEAR_POWER, radio, params)
    if not low < high:
        print("  -> FAIL: higher TX power was not more expensive")
        ok = False
    if not low < slow:
        print("  -> FAIL: higher SF was not more expensive at equal TX power")
        ok = False

    # The measured-current method must refuse an empty table, not guess.
    try:
        energy_per_attempt(7, 14.0, 20, EnergyMethod.MEASURED_CURRENT_TABLE, radio, params)
        print("  -> FAIL: measured_current_table ran with an empty table")
        ok = False
    except EnergyModelError:
        pass

    # With a caller-supplied table it must work, interpolate, and refuse to
    # extrapolate beyond the measured range.
    supplied = EnergyParams(supply_current_ma_by_tp_dbm={2.0: 20.0, 14.0: 40.0})
    mid = energy_per_attempt(7, 8.0, 20, EnergyMethod.MEASURED_CURRENT_TABLE, radio, supplied)
    lo = energy_per_attempt(7, 2.0, 20, EnergyMethod.MEASURED_CURRENT_TABLE, radio, supplied)
    hi = energy_per_attempt(7, 14.0, 20, EnergyMethod.MEASURED_CURRENT_TABLE, radio, supplied)
    if not lo < mid < hi:
        print("  -> FAIL: interpolation between table entries is not monotonic")
        ok = False
    try:
        energy_per_attempt(7, 20.0, 20, EnergyMethod.MEASURED_CURRENT_TABLE, radio, supplied)
        print("  -> FAIL: extrapolated beyond the measured current table")
        ok = False
    except EnergyModelError:
        pass

    # Cost bases.
    if not math.isclose(apply_cost_basis(10.0, CostBasis.PER_ATTEMPT, 0.5, 1.0), 10.0):
        print("  -> FAIL: per_attempt should pass energy through unchanged")
        ok = False
    if not math.isclose(apply_cost_basis(10.0, CostBasis.PER_SUCCESS_PDR, 0.5, None), 20.0):
        print("  -> FAIL: per_success_pdr should divide by reliability")
        ok = False
    if not math.isclose(apply_cost_basis(10.0, CostBasis.PER_SUCCESS_RETRIES, None, 1.0), 20.0):
        print("  -> FAIL: per_success_retries should multiply by (1 + mean_retry)")
        ok = False
    if apply_cost_basis(10.0, CostBasis.PER_SUCCESS_PDR, 0.0, None) != float("inf"):
        print("  -> FAIL: a configuration that never delivers should cost infinity")
        ok = False

    if ok:
        print("  -> OK (ranking correct; empty current table refused, not invented)")
    return ok


def check_context_assignment():
    print("[CHECK] each fixture session maps to exactly one channel context")
    from ml.labeling import LabelingConfig
    from ml.labeling.config import ContextStrategy
    from ml.labeling.context import CONTEXT_ID_COLUMN, assign_contexts

    df = _load_fixture()
    ok = True

    out, _ = assign_contexts(df, LabelingConfig())
    n_ctx = out[CONTEXT_ID_COLUMN].nunique()
    if n_ctx != 3:
        print(f"  -> FAIL: default strategy produced {n_ctx} contexts, expected 3")
        ok = False
    for ctx in (CTX_A, CTX_B, CTX_C):
        if ctx not in set(out[CONTEXT_ID_COLUMN]):
            print(f"  -> FAIL: expected context {ctx!r} was not produced")
            ok = False

    # The session strategy must also give 3 (one per session).
    out2, _ = assign_contexts(
        df, LabelingConfig(context_strategy=ContextStrategy.SESSION))
    if out2[CONTEXT_ID_COLUMN].nunique() != 3:
        print("  -> FAIL: session strategy did not produce 3 contexts")
        ok = False

    # Narrower bins must not produce fewer contexts than wider bins.
    wide, _ = assign_contexts(df, LabelingConfig(
        context_strategy=ContextStrategy.RSSI_SNR_BIN,
        rssi_bin_width_db=50.0, snr_bin_width_db=50.0))
    narrow, _ = assign_contexts(df, LabelingConfig(
        context_strategy=ContextStrategy.RSSI_SNR_BIN,
        rssi_bin_width_db=1.0, snr_bin_width_db=0.5))
    if not narrow[CONTEXT_ID_COLUMN].nunique() > wide[CONTEXT_ID_COLUMN].nunique():
        print("  -> FAIL: narrower bins did not produce more contexts")
        ok = False

    # A missing explicit context column must raise a clear error.
    try:
        assign_contexts(df, LabelingConfig(
            context_strategy=ContextStrategy.EXPLICIT_COLUMN,
            explicit_context_column="does_not_exist"))
        print("  -> FAIL: missing explicit context column did not raise")
        ok = False
    except ValueError:
        pass

    if ok:
        print("  -> OK (3 contexts under the default strategy, bin width honoured)")
    return ok


def check_oracle_table():
    print("[CHECK] oracle table reproduces the fixture's hand-computed evidence")
    from ml.labeling import LabelingConfig, build_oracle_table
    from ml.labeling.context import CONTEXT_ID_COLUMN

    oracle = build_oracle_table(_load_fixture(), LabelingConfig())
    ok = True

    if len(oracle) != 7:
        print(f"  -> FAIL: expected 7 (context, SF, TP) rows, got {len(oracle)}")
        ok = False

    # The fixture was written with these exact counts.
    expected = {
        (CTX_A, 7, 2.0): (30, 15),
        (CTX_A, 7, 14.0): (30, 30),
        (CTX_A, 9, 2.0): (30, 30),
        (CTX_A, 9, 14.0): (30, 30),
        (CTX_B, 7, 14.0): (30, 6),
        (CTX_B, 12, 14.0): (30, 18),
        (CTX_C, 8, 14.0): (30, 30),
    }
    for (ctx, sf, tp), (n, s) in expected.items():
        match = oracle[
            (oracle[CONTEXT_ID_COLUMN] == ctx)
            & (oracle["sf"] == sf)
            & (oracle["tp_dbm"] == tp)
        ]
        if len(match) != 1:
            print(f"  -> FAIL: no oracle row for {(ctx, sf, tp)}")
            ok = False
            continue
        row = match.iloc[0]
        if row["n_packets"] != n or row["n_success"] != s:
            print(f"  -> FAIL: {(sf, tp)} has {row['n_packets']}/{row['n_success']}, "
                  f"expected {n}/{s}")
            ok = False

    # Wilson bound at 30/30 must equal 30/(30 + 1.645^2).
    perfect = oracle[(oracle["n_success"] == 30) & (oracle["n_packets"] == 30)]
    expected_rel = 30 / (30 + 1.645 ** 2)
    for _, row in perfect.iterrows():
        if not math.isclose(row["reliability"], expected_rel, rel_tol=1e-9):
            print(f"  -> FAIL: reliability {row['reliability']} != {expected_rel}")
            ok = False

    # Only the sub-threshold configurations should be marked infeasible.
    infeasible = oracle[~oracle["meets_reliability"]]
    if len(infeasible) != 3:
        print(f"  -> FAIL: expected 3 sub-threshold configs, got {len(infeasible)}")
        ok = False

    if ok:
        print("  -> OK (7 configurations, counts and reliabilities as constructed)")
    return ok


def check_label_selection():
    print("[CHECK] label selection picks the cheapest configuration meeting the threshold")
    from ml.labeling import LabelingConfig, build_oracle_table, select_labels
    from ml.labeling.config import LabelStatus

    cfg = LabelingConfig()
    oracle = build_oracle_table(_load_fixture(), cfg)
    labels = select_labels(oracle, cfg)
    ok = True

    a = _row(labels, CTX_A)
    if a["label_status"] != LabelStatus.OK:
        print(f"  -> FAIL: context A status {a['label_status']}, expected 'ok'")
        ok = False
    if a["n_configs_feasible"] != 3:
        print(f"  -> FAIL: context A had {a['n_configs_feasible']} feasible configs, expected 3")
        ok = False

    # Cross-check the winner against the oracle table directly: it must be the
    # minimum-cost row among those meeting the threshold, not merely 'some row'.
    feasible = oracle[
        (oracle["context_id"] == CTX_A) & oracle["meets_reliability"]
    ]
    cheapest = feasible.loc[feasible["energy_cost"].idxmin()]
    if a["label_sf"] != cheapest["sf"] or a["label_tp_dbm"] != cheapest["tp_dbm"]:
        print(f"  -> FAIL: selected (SF{a['label_sf']}, {a['label_tp_dbm']} dBm) but the "
              f"cheapest feasible is (SF{cheapest['sf']}, {cheapest['tp_dbm']} dBm)")
        ok = False

    # The sub-threshold configuration (SF7 @ 2 dBm) is the cheapest overall.
    # It must NOT win, which is the whole point of the reliability constraint.
    all_a = oracle[oracle["context_id"] == CTX_A]
    global_cheapest = all_a.loc[all_a["energy_cost"].idxmin()]
    if global_cheapest["meets_reliability"]:
        print("  -> FAIL: fixture no longer exercises the constraint "
              "(cheapest config also meets threshold)")
        ok = False
    elif a["label_sf"] == global_cheapest["sf"] and a["label_tp_dbm"] == global_cheapest["tp_dbm"]:
        print("  -> FAIL: selected the cheapest configuration despite it failing "
              "the reliability threshold")
        ok = False

    if ok:
        print(f"  -> OK (chose SF{int(a['label_sf'])} @ {a['label_tp_dbm']} dBm; "
              f"cheaper but unreliable config correctly rejected)")
    return ok


def check_reliability_threshold_is_configurable():
    print("[CHECK] reliability threshold is configurable and changes the outcome")
    from ml.labeling import LabelingConfig, build_oracle_table, select_labels
    from ml.labeling.config import LabelStatus, ReliabilityEstimator

    df = _load_fixture()
    ok = True

    # A very low threshold admits the sub-threshold configuration in context A,
    # which is also the cheapest, so the label must change.
    strict = LabelingConfig()
    lax = LabelingConfig(min_reliability=0.10)

    strict_label = _row(select_labels(build_oracle_table(df, strict), strict), CTX_A)
    lax_label = _row(select_labels(build_oracle_table(df, lax), lax), CTX_A)

    if lax_label["n_configs_feasible"] <= strict_label["n_configs_feasible"]:
        print("  -> FAIL: lowering the threshold did not admit more configurations")
        ok = False
    if (lax_label["label_sf"], lax_label["label_tp_dbm"]) == \
            (strict_label["label_sf"], strict_label["label_tp_dbm"]):
        print("  -> FAIL: lowering the threshold did not change the chosen label")
        ok = False

    # An impossible threshold must make every context unlabellable.
    impossible = LabelingConfig(min_reliability=1.0)
    imp_labels = select_labels(build_oracle_table(df, impossible), impossible)
    if not (imp_labels["label_status"] == LabelStatus.NO_LABEL).all():
        print("  -> FAIL: a threshold of 1.0 still produced labels")
        ok = False

    # Switching estimator changes the estimate for the same raw counts.
    point_cfg = LabelingConfig(reliability_estimator=ReliabilityEstimator.POINT)
    point_oracle = build_oracle_table(df, point_cfg)
    wilson_oracle = build_oracle_table(df, LabelingConfig())
    if not (point_oracle["reliability"] >= wilson_oracle["reliability"] - 1e-12).all():
        print("  -> FAIL: point estimates should never be below Wilson lower bounds")
        ok = False
    if math.isclose(point_oracle["reliability"].sum(), wilson_oracle["reliability"].sum()):
        print("  -> FAIL: switching estimator had no effect")
        ok = False

    if ok:
        print("  -> OK (threshold and estimator both change the outcome as expected)")
    return ok


def check_candidate_sets_are_configurable():
    print("[CHECK] candidate SF / TX-power sets are configurable and restrict selection")
    from ml.labeling import LabelingConfig, build_oracle_table, select_labels
    from ml.labeling.config import LabelStatus

    df = _load_fixture()
    ok = True

    # Default: nothing pinned, candidates derived from the data.
    default_cfg = LabelingConfig()
    if default_cfg.candidate_sf_values is not None or \
            default_cfg.candidate_tp_dbm_values is not None:
        print("  -> FAIL: candidate sets should default to None (derived from data), "
              "so no SF/TP range is locked in before hardware is finalized")
        ok = False

    # Restricting SF to {7} must force context A's label to SF7 or leave it
    # unlabelled — it can never return SF9.
    only_sf7 = LabelingConfig(candidate_sf_values=[7])
    lab = _row(select_labels(build_oracle_table(df, only_sf7), only_sf7), CTX_A)
    if lab["label_status"] == LabelStatus.OK and lab["label_sf"] != 7:
        print(f"  -> FAIL: restricted to SF7 but selected SF{lab['label_sf']}")
        ok = False

    # Restricting TX power to {14} must exclude the 2 dBm configurations.
    only_14 = LabelingConfig(candidate_tp_dbm_values=[14.0])
    oracle_14 = build_oracle_table(df, only_14)
    if (oracle_14["tp_dbm"] != 14.0).any():
        print("  -> FAIL: a non-candidate TX power survived into the oracle table")
        ok = False
    lab14 = _row(select_labels(oracle_14, only_14), CTX_A)
    if lab14["label_status"] == LabelStatus.OK and lab14["label_tp_dbm"] != 14.0:
        print("  -> FAIL: restricted to 14 dBm but selected a different power")
        ok = False

    # A candidate set disjoint from the data must fail loudly, not silently.
    try:
        build_oracle_table(df, LabelingConfig(candidate_sf_values=[11]))
        # SF11 is absent from the fixture -> the table should be empty.
        empty = build_oracle_table(df, LabelingConfig(candidate_sf_values=[11]))
        if not empty.empty:
            print("  -> FAIL: candidate SF absent from the data still produced rows")
            ok = False
    except ValueError:
        pass

    if ok:
        print("  -> OK (defaults derive from data; explicit sets restrict selection)")
    return ok


def check_energy_method_is_configurable():
    print("[CHECK] energy method is configurable and changes which configuration wins")
    from ml.labeling import LabelingConfig, build_oracle_table, select_labels
    from ml.labeling.config import CostBasis, EnergyMethod, TieBreakRule

    df = _load_fixture()
    ok = True

    # airtime_only ignores TX power, so with a lower-TP tie-break the winner
    # must be the lowest SF at the lowest power among feasible configurations.
    airtime_cfg = LabelingConfig(
        energy_method=EnergyMethod.AIRTIME_ONLY,
        cost_basis=CostBasis.PER_ATTEMPT,
        tie_break_rules=[TieBreakRule.LOWER_TP, TieBreakRule.DETERMINISTIC_ID],
    )
    airtime_label = _row(
        select_labels(build_oracle_table(df, airtime_cfg), airtime_cfg), CTX_A)
    if airtime_label["label_sf"] != 7:
        print(f"  -> FAIL: airtime_only should favour the lowest feasible SF, "
              f"got SF{airtime_label['label_sf']}")
        ok = False

    # The default linear-power method trades airtime against radiated power and
    # reaches a different answer on the same data.
    default_label = _row(
        select_labels(build_oracle_table(df, LabelingConfig()), LabelingConfig()), CTX_A)
    if (default_label["label_sf"], default_label["label_tp_dbm"]) == \
            (airtime_label["label_sf"], airtime_label["label_tp_dbm"]):
        print("  -> FAIL: changing the energy method had no effect on the label")
        ok = False

    # Cost basis must change the computed costs.
    per_attempt = build_oracle_table(
        df, LabelingConfig(cost_basis=CostBasis.PER_ATTEMPT))
    per_success = build_oracle_table(
        df, LabelingConfig(cost_basis=CostBasis.PER_SUCCESS_PDR))
    if math.isclose(per_attempt["energy_cost"].sum(), per_success["energy_cost"].sum()):
        print("  -> FAIL: changing the cost basis had no effect")
        ok = False
    if not (per_success["energy_cost"] >= per_attempt["energy_cost"] - 1e-12).all():
        print("  -> FAIL: per-success cost should never be below per-attempt cost")
        ok = False

    # A supplied current table must be usable end-to-end.
    from ml.labeling.config import EnergyParams
    measured = LabelingConfig(
        energy_method=EnergyMethod.MEASURED_CURRENT_TABLE,
        energy=EnergyParams(supply_current_ma_by_tp_dbm={2.0: 20.0, 14.0: 40.0}),
    )
    measured_oracle = build_oracle_table(df, measured)
    if measured_oracle.empty or measured_oracle["energy_cost"].isna().any():
        print("  -> FAIL: measured current table did not produce usable costs")
        ok = False

    if ok:
        print("  -> OK (airtime_only, linear-power and measured-table all differ)")
    return ok


def check_tie_breaking_is_configurable():
    print("[CHECK] tie-breaking is configurable and deterministic")
    from ml.labeling import LabelingConfig
    from ml.labeling.config import TieBreakRule
    from ml.labeling.oracle import _break_ties
    import pandas as pd

    ok = True

    # Two configurations tied on cost, differing on SF/TP/reliability/samples.
    tied = pd.DataFrame([
        {"sf": 7, "tp_dbm": 14.0, "reliability": 0.91, "mean_retry": 0.5,
         "n_packets": 30, "energy_cost": 1.0},
        {"sf": 9, "tp_dbm": 2.0, "reliability": 0.95, "mean_retry": 0.1,
         "n_packets": 60, "energy_cost": 1.0},
    ])

    cases = [
        ([TieBreakRule.LOWER_SF, TieBreakRule.DETERMINISTIC_ID], 7),
        ([TieBreakRule.HIGHER_SF, TieBreakRule.DETERMINISTIC_ID], 9),
        ([TieBreakRule.LOWER_TP, TieBreakRule.DETERMINISTIC_ID], 9),
        ([TieBreakRule.HIGHER_TP, TieBreakRule.DETERMINISTIC_ID], 7),
        ([TieBreakRule.HIGHER_RELIABILITY, TieBreakRule.DETERMINISTIC_ID], 9),
        ([TieBreakRule.LOWER_RETRY, TieBreakRule.DETERMINISTIC_ID], 9),
        ([TieBreakRule.MORE_SAMPLES, TieBreakRule.DETERMINISTIC_ID], 9),
    ]
    for rules, expected_sf in cases:
        winner = _break_ties(tied, rules)
        if winner["sf"] != expected_sf:
            print(f"  -> FAIL: rules {rules[0]} chose SF{winner['sf']}, "
                  f"expected SF{expected_sf}")
            ok = False

    # Result must not depend on input row order.
    for rules, expected_sf in cases:
        reversed_winner = _break_ties(tied.iloc[::-1].copy(), rules)
        if reversed_winner["sf"] != expected_sf:
            print(f"  -> FAIL: rule {rules[0]} is order-dependent")
            ok = False

    # deterministic_id alone must resolve a full tie reproducibly.
    fully_tied = pd.DataFrame([
        {"sf": 9, "tp_dbm": 14.0, "reliability": 0.9, "mean_retry": 0.0,
         "n_packets": 30, "energy_cost": 1.0},
        {"sf": 7, "tp_dbm": 14.0, "reliability": 0.9, "mean_retry": 0.0,
         "n_packets": 30, "energy_cost": 1.0},
    ])
    w1 = _break_ties(fully_tied, [TieBreakRule.DETERMINISTIC_ID])
    w2 = _break_ties(fully_tied.iloc[::-1].copy(), [TieBreakRule.DETERMINISTIC_ID])
    if w1["sf"] != w2["sf"] or w1["sf"] != 7:
        print("  -> FAIL: deterministic_id did not resolve a full tie reproducibly")
        ok = False

    # A rule list not ending in deterministic_id must be rejected by config.
    try:
        LabelingConfig(tie_break_rules=[TieBreakRule.LOWER_SF]).validate()
        print("  -> FAIL: non-deterministic tie-break list was accepted")
        ok = False
    except ValueError:
        pass

    if ok:
        print(f"  -> OK ({len(cases)} rules honoured, order-independent)")
    return ok


def check_no_valid_config_handling():
    print("[CHECK] no-valid-configuration handling honours all four policies")
    from ml.labeling import LabelingConfig, build_oracle_table, select_labels
    from ml.labeling.config import LabelStatus, NoValidConfigPolicy
    from ml.labeling.oracle import NoValidConfigurationError

    df = _load_fixture()
    ok = True

    # Context B: both configurations are far below threshold.
    drop_cfg = LabelingConfig(no_valid_config_policy=NoValidConfigPolicy.DROP)
    b_drop = _row(select_labels(build_oracle_table(df, drop_cfg), drop_cfg), CTX_B)
    if b_drop["label_status"] != LabelStatus.NO_LABEL:
        print(f"  -> FAIL: 'drop' gave status {b_drop['label_status']}")
        ok = False
    if not (b_drop["label_sf"] != b_drop["label_sf"]):   # NaN check
        print("  -> FAIL: 'drop' still emitted an SF label")
        ok = False

    # most_reliable must pick SF12 (18/30) over SF7 (6/30).
    mr_cfg = LabelingConfig(no_valid_config_policy=NoValidConfigPolicy.MOST_RELIABLE)
    b_mr = _row(select_labels(build_oracle_table(df, mr_cfg), mr_cfg), CTX_B)
    if b_mr["label_status"] != LabelStatus.BELOW_THRESHOLD_FALLBACK:
        print(f"  -> FAIL: 'most_reliable' gave status {b_mr['label_status']}")
        ok = False
    if b_mr["label_sf"] != 12:
        print(f"  -> FAIL: 'most_reliable' chose SF{b_mr['label_sf']}, expected SF12")
        ok = False

    # max_robustness must pick the highest SF, then highest TP.
    rb_cfg = LabelingConfig(no_valid_config_policy=NoValidConfigPolicy.MAX_ROBUSTNESS)
    b_rb = _row(select_labels(build_oracle_table(df, rb_cfg), rb_cfg), CTX_B)
    if b_rb["label_status"] != LabelStatus.MAX_ROBUSTNESS_FALLBACK:
        print(f"  -> FAIL: 'max_robustness' gave status {b_rb['label_status']}")
        ok = False
    if b_rb["label_sf"] != 12:
        print(f"  -> FAIL: 'max_robustness' chose SF{b_rb['label_sf']}, expected SF12")
        ok = False

    # error must raise.
    err_cfg = LabelingConfig(no_valid_config_policy=NoValidConfigPolicy.ERROR)
    try:
        select_labels(build_oracle_table(df, err_cfg), err_cfg)
        print("  -> FAIL: 'error' policy did not raise")
        ok = False
    except NoValidConfigurationError:
        pass

    # Fallback labels must stay distinguishable from evidence-backed ones.
    if b_mr["label_status"] in LabelStatus.EVIDENCE_BACKED:
        print("  -> FAIL: a fallback label was marked evidence-backed")
        ok = False

    if ok:
        print("  -> OK (drop / most_reliable / max_robustness / error all honoured)")
    return ok


def check_evidence_coverage_guard():
    print("[CHECK] a context with no configuration sweep is not confidently labelled")
    from ml.labeling import LabelingConfig, build_oracle_table, select_labels
    from ml.labeling.config import LabelStatus, NoValidConfigPolicy

    df = _load_fixture()
    ok = True

    # Context C holds ONE perfectly reliable configuration and nothing to
    # compare it against. 'Best' is vacuous, so it must not be labelled 'ok'.
    cfg = LabelingConfig()
    c = _row(select_labels(build_oracle_table(df, cfg), cfg), CTX_C)
    if c["label_status"] == LabelStatus.OK:
        print("  -> FAIL: a single-configuration context was labelled as "
              "evidence-backed")
        ok = False
    if c["n_configs_sufficient_evidence"] != 1:
        print(f"  -> FAIL: context C should hold 1 well-evidenced config, "
              f"got {c['n_configs_sufficient_evidence']}")
        ok = False

    # Under a fallback policy the cause must still be recorded as a coverage
    # problem rather than silently reported as a threshold failure.
    mr_cfg = LabelingConfig(no_valid_config_policy=NoValidConfigPolicy.MOST_RELIABLE)
    c_mr = _row(select_labels(build_oracle_table(df, mr_cfg), mr_cfg), CTX_C)
    if c_mr["label_status"] != LabelStatus.INSUFFICIENT_CONFIG_COVERAGE:
        print(f"  -> FAIL: expected insufficient_config_coverage, "
              f"got {c_mr['label_status']}")
        ok = False
    if "min_configs_per_context" not in str(c_mr["selection_reason"]):
        print("  -> FAIL: the coverage failure reason was not recorded")
        ok = False

    # Relaxing the guard to 1 must let it through, proving the guard is what
    # blocked it rather than some unrelated condition.
    relaxed = LabelingConfig(min_configs_per_context=1)
    c_relaxed = _row(select_labels(build_oracle_table(df, relaxed), relaxed), CTX_C)
    if c_relaxed["label_status"] != LabelStatus.OK:
        print(f"  -> FAIL: relaxing min_configs_per_context did not allow a label "
              f"(status {c_relaxed['label_status']})")
        ok = False

    # Raising min_packets_per_config above the fixture's 30 must invalidate
    # every configuration's evidence.
    thick = LabelingConfig(min_packets_per_config=500)
    thick_labels = select_labels(build_oracle_table(df, thick), thick)
    if (thick_labels["n_configs_sufficient_evidence"] != 0).any():
        print("  -> FAIL: a configuration passed a 500-packet evidence requirement")
        ok = False

    if ok:
        print("  -> OK (unswept context refused; guard confirmed to be the cause)")
    return ok


def check_full_pipeline():
    print("[CHECK] full labeling pipeline runs end-to-end to a temp location")
    from ml.labeling import LabelingConfig, run_labeling
    from ml.labeling.labeler import main as labeler_main
    import pandas as pd

    tmp_dir = Path(tempfile.mkdtemp(prefix="lora_edgeai_label_test_"))
    out_path = tmp_dir / "synthetic_labeled.csv"
    ok = True

    try:
        summary = run_labeling(str(FIXTURE_PATH), str(out_path), cfg=LabelingConfig())

        for p in (out_path, Path(summary["oracle_path"]), Path(summary["labels_path"])):
            if not p.exists():
                print(f"  -> FAIL: expected output {p.name} was not written")
                ok = False

        if ok:
            labeled = pd.read_csv(out_path)
            # Default config drops unlabelled rows; only context A survives.
            if len(labeled) != 120:
                print(f"  -> FAIL: expected 120 labelled rows (context A), "
                      f"got {len(labeled)}")
                ok = False
            for col in ("context_id", "label_sf", "label_tp_dbm", "label_status"):
                if col not in labeled.columns:
                    print(f"  -> FAIL: output is missing column '{col}'")
                    ok = False
            if ok and labeled["label_sf"].isna().any():
                print("  -> FAIL: labelled output contains NaN targets")
                ok = False

        # Keeping unlabelled rows must retain every input row instead.
        keep_path = tmp_dir / "keep_all.csv"
        run_labeling(str(FIXTURE_PATH), str(keep_path),
                     cfg=LabelingConfig(drop_unlabeled_rows=False))
        kept = pd.read_csv(keep_path)
        if len(kept) != 210:
            print(f"  -> FAIL: drop_unlabeled_rows=False kept {len(kept)} rows, expected 210")
            ok = False

        # A missing input file must exit cleanly with code 1, not traceback.
        try:
            labeler_main([
                "--input", str(tmp_dir / "nope.csv"),
                "--output", str(tmp_dir / "unused.csv"),
            ])
            print("  -> FAIL: missing input file did not exit")
            ok = False
        except SystemExit as e:
            if e.code != 1:
                print(f"  -> FAIL: missing input exited with code {e.code}, expected 1")
                ok = False
            if (tmp_dir / "unused.csv").exists():
                print("  -> FAIL: an output file was created despite the failure")
                ok = False

    except Exception as e:
        print(f"  -> FAIL: pipeline raised an exception ({type(e).__name__}: {e})")
        ok = False
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    if ok:
        print("  -> OK (labels + oracle + label table written; error path clean)")
    return ok


def check_no_feature_leakage():
    print("[CHECK] labels attach to rows without leaking targets into the features")
    from ml.labeling import LabelingConfig, attach_labels, build_oracle_table, select_labels

    df = _load_fixture()
    cfg = LabelingConfig()
    labels = select_labels(build_oracle_table(df, cfg), cfg)
    attached = attach_labels(df, labels, cfg)
    ok = True

    # Every original column must survive the join.
    missing = [c for c in df.columns if c not in attached.columns]
    if missing:
        print(f"  -> FAIL: attach_labels dropped column(s) {missing}")
        ok = False

    # The label must be a per-context constant, not a per-row copy of the
    # logged configuration — that would be the behavioural-cloning failure the
    # whole strategy exists to avoid.
    for ctx, grp in attached.groupby("context_id"):
        if grp["label_sf"].nunique() != 1 or grp["label_tp_dbm"].nunique() != 1:
            print(f"  -> FAIL: context {ctx} has more than one label")
            ok = False

    # Within context A the fixture swept SF and TP, so the logged columns vary
    # while the label does not. Confirm they are genuinely different columns.
    ctx_a = attached[attached["context_id"] == CTX_A]
    if ctx_a["sf"].nunique() <= 1:
        print("  -> FAIL: fixture context A no longer sweeps SF")
        ok = False
    elif (ctx_a["sf"] == ctx_a["label_sf"]).all():
        print("  -> FAIL: label_sf is identical to the logged sf column")
        ok = False

    if ok:
        print("  -> OK (one label per context; label distinct from logged config)")
    return ok


def check_config_round_trip():
    print("[CHECK] labeling config round-trips through JSON")
    from ml.labeling import LabelingConfig
    from ml.labeling.config import EnergyParams, NoValidConfigPolicy

    ok = True
    tmp_dir = Path(tempfile.mkdtemp(prefix="lora_edgeai_cfg_test_"))
    try:
        original = LabelingConfig(
            min_reliability=0.85,
            candidate_sf_values=[7, 8, 9],
            candidate_tp_dbm_values=[2.0, 14.0],
            no_valid_config_policy=NoValidConfigPolicy.MOST_RELIABLE,
            energy=EnergyParams(supply_current_ma_by_tp_dbm={2.0: 20.0, 14.0: 40.0}),
        )
        path = tmp_dir / "cfg.json"
        original.to_json_file(path)
        loaded = LabelingConfig.from_json_file(path)

        if loaded.to_dict() != original.to_dict():
            print("  -> FAIL: config did not survive the JSON round trip")
            ok = False
        # JSON object keys are strings; they must come back as floats.
        if set(loaded.energy.supply_current_ma_by_tp_dbm) != {2.0, 14.0}:
            print("  -> FAIL: current table keys were not restored as numbers")
            ok = False

        # The shipped example config must be loadable and valid.
        example = PROJECT_ROOT / "ml" / "labeling" / "labeling_config.example.json"
        if not example.exists():
            print("  -> FAIL: labeling_config.example.json is missing")
            ok = False
        else:
            cfg = LabelingConfig.from_json_file(example)
            cfg.validate()
            if cfg.candidate_sf_values is not None or cfg.candidate_tp_dbm_values is not None:
                print("  -> FAIL: the example config pins SF/TP ranges; they must "
                      "stay unset until hardware and region are finalized")
                ok = False
            with open(example, encoding="utf-8") as fh:
                if json.load(fh)["energy"]["supply_current_ma_by_tp_dbm"]:
                    print("  -> FAIL: the example config ships a supply-current table; "
                          "it must stay empty until real values exist")
                    ok = False
    except Exception as e:
        print(f"  -> FAIL: config round trip raised ({type(e).__name__}: {e})")
        ok = False
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    if ok:
        print("  -> OK (round trip exact; example config valid and unpinned)")
    return ok


def check_no_pollution_of_real_data_dirs():
    print("[CHECK] real data/ directories remain untouched by this test run")
    ok = True
    for sub in ["raw", "processed", "sample"]:
        d = PROJECT_ROOT / "data" / sub
        contents = [p.name for p in d.iterdir()] if d.exists() else []
        unexpected = [c for c in contents if c not in (".gitkeep", "README.md")]
        if unexpected:
            print(f"  -> FAIL: data/{sub}/ contains unexpected files: {unexpected}")
            ok = False
    if ok:
        print("  -> OK (data/raw, data/processed, data/sample still contain only "
              "README.md/.gitkeep)")
    return ok


def main():
    print("=" * 68)
    print("LoRa Edge-AI Project — Checkpoint 3 Labeling Framework Verification")
    print("=" * 68)

    checks = [
        check_imports,
        check_fixture_exists,
        check_config_validation,
        check_airtime_formula,
        check_reliability_estimators,
        check_energy_models,
        check_context_assignment,
        check_oracle_table,
        check_label_selection,
        check_reliability_threshold_is_configurable,
        check_candidate_sets_are_configurable,
        check_energy_method_is_configurable,
        check_tie_breaking_is_configurable,
        check_no_valid_config_handling,
        check_evidence_coverage_guard,
        check_full_pipeline,
        check_no_feature_leakage,
        check_config_round_trip,
        check_no_pollution_of_real_data_dirs,
    ]

    results = [check() for check in checks]

    print("=" * 68)
    if all(results):
        print("ALL CHECKS PASSED")
        print("Labeling framework is verified against synthetic test data.")
        print("No model was trained and no real data was used or produced.")
        print("=" * 68)
        sys.exit(0)
    else:
        print(f"{results.count(False)} CHECK(S) FAILED")
        print("=" * 68)
        sys.exit(1)


if __name__ == "__main__":
    main()
