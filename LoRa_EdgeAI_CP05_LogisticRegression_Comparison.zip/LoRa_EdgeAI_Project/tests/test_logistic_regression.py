"""
test_logistic_regression.py

Checkpoint 5 — Logistic Regression training/evaluation & Decision Tree
comparison pipeline verification.

Verifies ml/training/train_logistic_regression.py and
ml/evaluation/compare_models.py, using ONLY the fabricated fixture at
tests/fixtures/synthetic_pipeline_fixture_raw.csv — the SAME fixture, SAME
preprocessing, SAME labeling framework, and SAME feature set Checkpoint 4's
Decision Tree tests use.

*** NOTHING HERE IS A RESEARCH RESULT. ***
As with tests/test_training.py, these checks confirm the SOFTWARE RUNS on a
fixture that is separable by construction. No check in this file asserts
"Logistic Regression is better/worse than the Decision Tree" or treats a
high or low synthetic score as meaningful — several checks instead assert
that the required non-claims and disclaimers are literally present.

What is checked:
  1.  Modules import.
  2.  Training uses the SAME feature set / dataset assembly as Checkpoint 4
      (byte-identical resolve_feature_columns() output).
  3.  Banned columns are rejected the same way (dataset.py is unchanged and
      shared, so this mainly confirms nothing in this checkpoint bypasses it).
  4.  Logistic Regression trains, and the pipeline is (StandardScaler + LR).
  5.  Training records solver, iterations, convergence, coefficients, size
      and timings.
  6.  The model file is written and its size is recorded.
  7.  A saved model reloads and predicts identically.
  8.  Inference timing is measured.
  9.  The metadata carries every required field, the banner, and the
      explicit non-claim naming the Decision Tree comparison.
  10. Majority-class baseline and joint/per-context metrics behave exactly
      as they do for the Decision Tree (shared metrics.py — this confirms
      the second model family plugs into the same evaluation code).
  11. The standalone evaluation script (ml/evaluation/evaluate.py, unchanged
      from Checkpoint 4) works against a Logistic Regression bundle, not
      just a Decision Tree one — proving the bundle contract is honoured.
  12. compare_models.py evaluates both bundles on an IDENTICAL held-out
      split and refuses to compare bundles trained on different features.
  13. The comparison report carries the banner, the explicit
      no-superiority-claim, and every required non-claim by name.
  14. Runs are reproducible for a fixed random_state.
  15. The saved bundle contains no banned feature.
  16. Checkpoints 1-4 are fully preserved (re-imports + re-runs their tests'
      core assertions are NOT duplicated here — see main() in this project's
      other four test files, all of which must also still pass).
  17. data/raw, data/processed and data/sample remain untouched.

Run with:
    python tests/test_logistic_regression.py

Exit code 0 -> all checks passed
Exit code 1 -> at least one check failed
"""

import json
import shutil
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

FIXTURE = PROJECT_ROOT / "tests" / "fixtures" / "synthetic_pipeline_fixture_raw.csv"

#: Built once by _prepare() and reused, so the chain runs once not N times.
_PREPARED = {}


def _prepare():
    """Run preprocessing + labeling once into a temp dir; cache the paths.

    Identical to test_training.py's _prepare(), kept separate (not imported)
    so this file can run standalone without depending on test_training.py's
    module-level state.
    """
    if _PREPARED:
        return _PREPARED

    from ml.labeling.labeler import run_labeling
    from ml.preprocessing.pipeline import run_pipeline

    tmp = Path(tempfile.mkdtemp(prefix="lora_cp05_test_"))
    proc = tmp / "proc.csv"
    lab = tmp / "lab.csv"
    run_pipeline(str(FIXTURE), str(proc))
    run_labeling(str(proc), str(lab))

    _PREPARED.update({"tmp": tmp, "processed": proc, "labeled": lab})
    return _PREPARED


def _cleanup():
    if _PREPARED.get("tmp"):
        shutil.rmtree(_PREPARED["tmp"], ignore_errors=True)


# ---------------------------------------------------------------------------

def check_imports():
    print("[CHECK] Checkpoint 5 modules import correctly")
    try:
        from ml.training import train_logistic_regression  # noqa: F401
        from ml.evaluation import compare_models  # noqa: F401
        from sklearn.linear_model import LogisticRegression  # noqa: F401
        from sklearn.pipeline import Pipeline  # noqa: F401
        from sklearn.preprocessing import StandardScaler  # noqa: F401
    except ImportError as e:
        print(f"  -> FAIL: could not import ({e})")
        return False
    print("  -> OK")
    return True


def check_same_feature_set_as_decision_tree():
    print("[CHECK] Logistic Regression uses the identical feature set as the Decision Tree")
    from ml.training.dataset import resolve_feature_columns

    ok = True
    default_cols = resolve_feature_columns()
    # Both trainers call the exact same function with the exact same
    # arguments by default — this asserts that contract rather than
    # re-deriving a second list that could silently drift from it.
    if len(default_cols) != 8:
        print(f"  -> FAIL: expected 8 default features, got {len(default_cols)}")
        ok = False
    for token in ("success_rate", "retry", "rssi", "snr"):
        if not any(token in c for c in default_cols):
            print(f"  -> FAIL: default feature set missing a {token!r} feature")
            ok = False
    for banned_token in ("gps", "lat", "lon", "distance", "altitude"):
        if any(banned_token in c.lower() for c in default_cols):
            print(f"  -> FAIL: feature set contains a contextual variable "
                  f"matching {banned_token!r}")
            ok = False
    if ok:
        print(f"  -> OK ({len(default_cols)} shared causal features)")
    return ok


def check_training_produces_pipeline_and_records_structure():
    print("[CHECK] training produces a (StandardScaler + LogisticRegression) "
          "pipeline and records structure/timings")
    from ml.training.train_logistic_regression import train
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler

    p = _prepare()
    outdir = p["tmp"] / "models_lr"
    try:
        meta = train(str(p["labeled"]), str(outdir))
    except Exception as e:
        print(f"  -> FAIL: training raised ({type(e).__name__}: {e})")
        return False

    p["lr_metadata"] = meta
    p["lr_model_path"] = outdir / "logistic_regression_sf_tp.joblib"
    p["lr_metadata_path"] = outdir / "logistic_regression_sf_tp_metadata.json"
    ok = True

    import joblib
    bundle = joblib.load(p["lr_model_path"])
    for key in ("sf_model", "tp_model"):
        pl = bundle[key]
        if not isinstance(pl, Pipeline):
            print(f"  -> FAIL: bundle[{key!r}] is not a sklearn Pipeline")
            ok = False
            continue
        if "scaler" not in pl.named_steps or not isinstance(
                pl.named_steps["scaler"], StandardScaler):
            print(f"  -> FAIL: bundle[{key!r}] pipeline has no StandardScaler step")
            ok = False
        if "logreg" not in pl.named_steps or not isinstance(
                pl.named_steps["logreg"], LogisticRegression):
            print(f"  -> FAIL: bundle[{key!r}] pipeline has no LogisticRegression step")
            ok = False

    for logreg_key in ("sf_logreg", "tp_logreg"):
        t = meta[logreg_key]
        for field in ("solver", "C", "n_iter", "converged", "n_classes",
                      "classes", "n_features_in", "training_seconds",
                      "coefficients"):
            if field not in t:
                print(f"  -> FAIL: {logreg_key} is missing '{field}'")
                ok = False
        if ok:
            if t["n_classes"] < 2:
                print(f"  -> FAIL: {logreg_key} has fewer than 2 classes")
                ok = False
            if t["training_seconds"] <= 0:
                print(f"  -> FAIL: {logreg_key} training time not measured")
                ok = False
            if not t["converged"]:
                print(f"  -> FAIL: {logreg_key} did not converge on the fixture "
                      f"(n_iter={t['n_iter']}, max_iter configured "
                      f"{t.get('max_iter_configured')})")
                ok = False
            # Binary logistic regression stores ONE coefficient row (for
            # classes_[1] vs classes_[0]), not one per class — only the
            # genuinely multinomial (3+ class) case has one row per class.
            expected_coef_entries = 1 if t["n_classes"] == 2 else t["n_classes"]
            if len(t["coefficients"]) != expected_coef_entries:
                print(f"  -> FAIL: {logreg_key} coefficient table has "
                      f"{len(t['coefficients'])} entries, expected "
                      f"{expected_coef_entries} for {t['n_classes']} classes")
                ok = False

    mf = meta["model_file"]
    if not mf.get("bytes") or mf["bytes"] <= 0:
        print("  -> FAIL: model file size not recorded")
        ok = False
    it = meta["inference_timing"]
    if not it.get("measured") or it.get("per_row_microseconds") is None:
        print("  -> FAIL: inference time not measured")
        ok = False

    if ok:
        print(f"  -> OK (SF solver={meta['sf_logreg']['solver']} "
              f"converged={meta['sf_logreg']['converged']}, "
              f"TP converged={meta['tp_logreg']['converged']}, "
              f"{mf['kilobytes']} KB)")
    return ok


def check_model_saves_and_reloads():
    print("[CHECK] the saved Logistic Regression bundle reloads and predicts identically")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.dataset import build_dataset
    import numpy as np
    import pandas as pd

    p = _prepare()
    if "lr_model_path" not in p:
        print("  -> FAIL: no model was trained by the previous check")
        return False
    if not p["lr_model_path"].exists():
        print("  -> FAIL: model file was not written")
        return False

    ok = True
    bundle = load_bundle(str(p["lr_model_path"]))
    df = pd.read_csv(p["labeled"])
    X, y_sf, y_tp, groups, _ = build_dataset(
        df, feature_columns=bundle["feature_columns"])

    first = bundle["sf_model"].predict(X)
    bundle2 = load_bundle(str(p["lr_model_path"]))
    second = bundle2["sf_model"].predict(X)
    if not np.array_equal(first, second):
        print("  -> FAIL: two loads of the same model predicted differently")
        ok = False

    for key in ("sf_model", "tp_model", "feature_columns", "provenance"):
        if key not in bundle:
            print(f"  -> FAIL: bundle is missing '{key}'")
            ok = False

    if ok:
        print("  -> OK (reload deterministic; load_bundle() from Checkpoint 4 "
              "accepted an LR bundle unmodified)")
    return ok


def check_metadata_completeness_and_non_claims():
    print("[CHECK] LR metadata carries every required field, the banner, and "
          "the DT-comparison non-claim")
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _prepare()
    meta = p.get("lr_metadata")
    if not meta:
        print("  -> FAIL: no metadata from the training check")
        return False

    ok = True
    for field in ("banner", "status", "checkpoint", "model_family", "tuned",
                  "environment", "data", "split", "hyperparameters",
                  "sf_logreg", "tp_logreg", "total_training_seconds",
                  "inference_timing", "model_file", "metrics",
                  "explicit_non_claims"):
        if field not in meta:
            print(f"  -> FAIL: metadata is missing '{field}'")
            ok = False

    if meta.get("banner") != SYNTHETIC_BANNER:
        print("  -> FAIL: metadata banner is wrong or missing")
        ok = False
    if meta.get("checkpoint") != "CP05":
        print("  -> FAIL: metadata does not record checkpoint CP05")
        ok = False
    if meta.get("tuned") is not False:
        print("  -> FAIL: metadata should record that the model is untuned")
        ok = False

    non_claims_text = " ".join(meta.get("explicit_non_claims", [])).lower()
    if "decision tree" not in non_claims_text:
        print("  -> FAIL: explicit_non_claims does not mention the Decision "
              "Tree comparison caveat")
        ok = False
    if len(meta.get("explicit_non_claims", [])) < 5:
        print("  -> FAIL: explicit non-claims list is too short")
        ok = False

    meta_file = p.get("lr_metadata_path")
    if not meta_file or not meta_file.exists():
        print("  -> FAIL: metadata JSON was not written")
        ok = False
    else:
        with open(meta_file, encoding="utf-8") as fh:
            on_disk = json.load(fh)
        if on_disk.get("banner") != SYNTHETIC_BANNER:
            print("  -> FAIL: on-disk metadata is not banner-stamped")
            ok = False

    if ok:
        print("  -> OK (all fields present, banner stamped, tuned=False, "
              "DT-comparison caveat present)")
    return ok


def check_shared_metrics_behave_identically():
    print("[CHECK] shared evaluation metrics (metrics.py, unchanged) behave "
          "consistently for the LR model")
    p = _prepare()
    meta = p.get("lr_metadata")
    if not meta:
        print("  -> FAIL: no metadata available")
        return False

    ok = True
    for key in ("spreading_factor", "tx_power_dbm"):
        m = meta["metrics"][key]
        if "majority_class_baseline" not in m:
            print(f"  -> FAIL: {key} has no majority-class baseline")
            ok = False
        if "per_class" not in m or not m["per_class"]:
            print(f"  -> FAIL: {key} has no per-class breakdown")
            ok = False
        if "confusion_matrix" not in m:
            print(f"  -> FAIL: {key} has no confusion matrix")
            ok = False

    sf_acc = meta["metrics"]["spreading_factor"]["accuracy"]
    tp_acc = meta["metrics"]["tx_power_dbm"]["accuracy"]
    joint = meta["metrics"]["joint"]["accuracy"]
    if joint > min(sf_acc, tp_acc) + 1e-12:
        print(f"  -> FAIL: joint accuracy {joint} exceeds min of "
              f"{sf_acc}/{tp_acc}, which is impossible")
        ok = False

    pc = meta["metrics"]["per_context"]
    if pc["n_contexts"] != meta["split"]["test_contexts"]:
        print(f"  -> FAIL: per-context metric counted {pc['n_contexts']} "
              f"contexts, expected {meta['split']['test_contexts']}")
        ok = False

    if ok:
        print("  -> OK (baselines present; joint <= min; per-context counts "
              "contexts)")
    return ok


def check_evaluate_script_accepts_lr_bundle():
    print("[CHECK] ml/evaluation/evaluate.py (Checkpoint 4, unmodified) "
          "works against a Logistic Regression bundle")
    from ml.evaluation.evaluate import evaluate
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _prepare()
    ok = True

    try:
        result = evaluate(str(p["lr_model_path"]), str(p["labeled"]))
    except Exception as e:
        print(f"  -> FAIL: evaluate() raised on an LR bundle ({type(e).__name__}: {e})")
        return False

    if result["banner"] != SYNTHETIC_BANNER:
        print("  -> FAIL: evaluation result is not banner-stamped")
        ok = False
    if "spreading_factor" not in result["metrics"]:
        print("  -> FAIL: evaluation result missing spreading_factor metrics")
        ok = False

    if ok:
        print("  -> OK (evaluate() is model-family-agnostic; no changes needed)")
    return ok


def check_comparison_identical_split():
    print("[CHECK] compare_models evaluates both models on an IDENTICAL held-out split")
    from ml.evaluation.compare_models import compare
    from ml.training.train_decision_tree import train as train_dt

    p = _prepare()

    # Train the Decision Tree fresh here too, so this file can run standalone
    # without depending on test_training.py having run first.
    if "dt_model_path" not in p:
        dt_outdir = p["tmp"] / "models_dt"
        dt_meta = train_dt(str(p["labeled"]), str(dt_outdir))
        p["dt_metadata"] = dt_meta
        p["dt_model_path"] = dt_outdir / "decision_tree_sf_tp.joblib"
        p["dt_metadata_path"] = dt_outdir / "decision_tree_sf_tp_metadata.json"

    ok = True
    try:
        result = compare(
            dt_model_path=str(p["dt_model_path"]),
            dt_metadata_path=str(p["dt_metadata_path"]),
            lr_model_path=str(p["lr_model_path"]),
            lr_metadata_path=str(p["lr_metadata_path"]),
            input_path=str(p["labeled"]),
        )
    except Exception as e:
        print(f"  -> FAIL: compare() raised ({type(e).__name__}: {e})")
        return False

    p["comparison"] = result

    dt_n = result["decision_tree"]["predictive"]["n_test_rows"]
    lr_n = result["logistic_regression"]["predictive"]["n_test_rows"]
    if dt_n != lr_n:
        print(f"  -> FAIL: DT scored {dt_n} rows but LR scored {lr_n} — "
              f"splits were not identical")
        ok = False
    if dt_n == 0:
        print("  -> FAIL: zero test rows scored")
        ok = False

    if ok:
        print(f"  -> OK ({dt_n} identical held-out rows scored for both models)")
    return ok


def check_comparison_refuses_mismatched_features():
    print("[CHECK] compare_models refuses to compare bundles trained on "
          "different feature sets")
    from ml.evaluation.compare_models import compare
    from ml.training.train_logistic_regression import train as train_lr

    p = _prepare()
    ok = True

    # Train a second LR bundle WITH current-link features, so its feature
    # list genuinely differs from the Decision Tree's default one.
    mismatched_outdir = p["tmp"] / "models_lr_mismatched"
    train_lr(str(p["labeled"]), str(mismatched_outdir), include_current_link=True)
    mismatched_model = mismatched_outdir / "logistic_regression_sf_tp.joblib"
    mismatched_meta = mismatched_outdir / "logistic_regression_sf_tp_metadata.json"

    try:
        compare(
            dt_model_path=str(p["dt_model_path"]),
            dt_metadata_path=str(p["dt_metadata_path"]),
            lr_model_path=str(mismatched_model),
            lr_metadata_path=str(mismatched_meta),
            input_path=str(p["labeled"]),
        )
        print("  -> FAIL: compare() accepted mismatched feature sets")
        ok = False
    except ValueError:
        pass

    if ok:
        print("  -> OK (mismatched feature sets correctly refused)")
    return ok


def check_comparison_report_banner_and_non_claims():
    print("[CHECK] the comparison report carries the banner and every "
          "required non-claim")
    from ml.evaluation.compare_models import render_markdown_report
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _prepare()
    comparison = p.get("comparison")
    if not comparison:
        print("  -> FAIL: no comparison result from the previous check")
        return False

    report = render_markdown_report(comparison)
    p["comparison_report"] = report
    ok = True

    if report.count(SYNTHETIC_BANNER) < 3:
        print(f"  -> FAIL: banner appears only {report.count(SYNTHETIC_BANNER)} "
              f"time(s); expected at least 3")
        ok = False

    if "does not show" not in report.lower() and "does not demonstrate" not in report.lower():
        print("  -> FAIL: report does not contain an explicit non-claim sentence")
        ok = False

    for phrase in ("better than the other", "packet delivery ratio", "latency",
                   "energy consumption", "adaptation", "real LoRa communication",
                   "project success"):
        if phrase.lower() not in report.lower():
            print(f"  -> FAIL: report does not explicitly disclaim {phrase!r}")
            ok = False

    if "Decision Tree" not in report or "Logistic Regression" not in report:
        print("  -> FAIL: report does not name both models")
        ok = False

    if ok:
        print(f"  -> OK (banner x{report.count(SYNTHETIC_BANNER)}, "
              f"no-superiority claim and all disclaimers present)")
    return ok


def check_reproducibility():
    print("[CHECK] a fixed random_state gives a reproducible Logistic "
          "Regression run")
    from ml.training.train_logistic_regression import train

    p = _prepare()
    ok = True

    a = train(str(p["labeled"]), str(p["tmp"] / "rep_lr_a"), random_state=7)
    b = train(str(p["labeled"]), str(p["tmp"] / "rep_lr_b"), random_state=7)

    for path in (("split", "train_contexts"), ("sf_logreg", "n_iter"),
                 ("tp_logreg", "n_iter")):
        if a[path[0]][path[1]] != b[path[0]][path[1]]:
            print(f"  -> FAIL: {'.'.join(path)} differed between identical runs")
            ok = False
    if a["metrics"]["joint"]["accuracy"] != b["metrics"]["joint"]["accuracy"]:
        print("  -> FAIL: joint accuracy differed between identical runs")
        ok = False

    if ok:
        print("  -> OK (identical seed reproduces split, structure and metrics)")
    return ok


def check_bundle_has_no_banned_features():
    print("[CHECK] the saved Logistic Regression bundle contains no banned feature")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.dataset import BANNED_FEATURE_COLUMNS

    p = _prepare()
    bundle = load_bundle(str(p["lr_model_path"]))
    ok = True

    for col in bundle["feature_columns"]:
        if col in BANNED_FEATURE_COLUMNS:
            print(f"  -> FAIL: saved model uses banned feature {col!r} — "
                  f"{BANNED_FEATURE_COLUMNS[col]}")
            ok = False

    n_features = bundle["sf_model"].named_steps["logreg"].n_features_in_
    if n_features != len(bundle["feature_columns"]):
        print(f"  -> FAIL: model expects {n_features} features but the bundle "
              f"lists {len(bundle['feature_columns'])}")
        ok = False

    if ok:
        print(f"  -> OK ({len(bundle['feature_columns'])} features, none banned)")
    return ok


def check_no_pollution_of_real_data_dirs():
    print("[CHECK] real data/ directories remain untouched by this test run")
    ok = True
    for sub in ["raw", "processed", "sample"]:
        d = PROJECT_ROOT / "data" / sub
        contents = [x.name for x in d.iterdir()] if d.exists() else []
        unexpected = [c for c in contents if c not in (".gitkeep", "README.md")]
        if unexpected:
            print(f"  -> FAIL: data/{sub}/ contains unexpected files: {unexpected}")
            ok = False
    stray = [x.name for x in (PROJECT_ROOT / "ml" / "models").iterdir()
             if x.name not in (".gitkeep", "README.md")]
    if stray:
        print(f"  -> FAIL: ml/models/ contains stray artifacts: {stray}")
        ok = False
    if ok:
        print("  -> OK (data/ and ml/models/ clean; test output went to a temp dir)")
    return ok


def main():
    print("=" * 70)
    print("LoRa Edge-AI — Checkpoint 5 Logistic Regression & Comparison Verification")
    print("SOFTWARE VALIDATION ONLY — synthetic data, no research results")
    print("=" * 70)

    checks = [
        check_imports,
        check_same_feature_set_as_decision_tree,
        check_training_produces_pipeline_and_records_structure,
        check_model_saves_and_reloads,
        check_metadata_completeness_and_non_claims,
        check_shared_metrics_behave_identically,
        check_evaluate_script_accepts_lr_bundle,
        check_comparison_identical_split,
        check_comparison_refuses_mismatched_features,
        check_comparison_report_banner_and_non_claims,
        check_reproducibility,
        check_bundle_has_no_banned_features,
        check_no_pollution_of_real_data_dirs,
    ]

    try:
        results = [check() for check in checks]
    finally:
        _cleanup()

    print("=" * 70)
    if all(results):
        print("ALL CHECKS PASSED")
        print("The Logistic Regression training/comparison pipeline executes end to end.")
        print("This is SOFTWARE VALIDATION ONLY — no real data, no research result.")
        print("=" * 70)
        sys.exit(0)
    else:
        print(f"{results.count(False)} CHECK(S) FAILED")
        print("=" * 70)
        sys.exit(1)


if __name__ == "__main__":
    main()
