"""
test_preprocessing.py

Checkpoint 2 — Preprocessing pipeline verification.

Runs the preprocessing pipeline (ml/preprocessing/*) against the synthetic
test fixture in tests/fixtures/synthetic_test_fixture_raw.csv and checks
that:
  1. Schema validation keeps the valid rows and drops exactly the invalid
     rows the fixture was deliberately constructed with.
  2. Feature engineering produces the expected rolling-history columns.
  3. Rolling features do NOT leak the current packet's own outcome into
     its own history (i.e. the first packet in a group has NaN history,
     and later packets' history matches a hand-computed expectation).

IMPORTANT: This test uses ONLY the fabricated fixture in tests/fixtures/,
which is clearly labeled as synthetic test data (see
tests/fixtures/README.md). It does not use, produce, or imply the
existence of any real LoRa research data. Output is written to a
temporary directory, NOT into data/processed/, so this test never pollutes
the real project data folders.

Run with:
    python tests/test_preprocessing.py

Exit code 0 -> all checks passed
Exit code 1 -> at least one check failed
"""

import math
import shutil
import sys
import tempfile
from pathlib import Path

# Allow running this script directly (python tests/test_preprocessing.py)
# by adding the project root to sys.path.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

FIXTURE_PATH = PROJECT_ROOT / "tests" / "fixtures" / "synthetic_test_fixture_raw.csv"


def check_imports():
    print("[CHECK] preprocessing modules import correctly")
    try:
        from ml.preprocessing import clean, feature_engineering, pipeline, schema  # noqa: F401
    except ImportError as e:
        print(f"  -> FAIL: could not import preprocessing modules ({e})")
        return False
    print("  -> OK")
    return True


def check_fixture_exists():
    print(f"[CHECK] synthetic test fixture exists at {FIXTURE_PATH.relative_to(PROJECT_ROOT)}")
    if not FIXTURE_PATH.exists():
        print("  -> FAIL: fixture file not found")
        return False
    print("  -> OK")
    return True


def check_schema_validation():
    print("[CHECK] schema validation drops exactly the deliberately-invalid rows")
    from ml.preprocessing.clean import load_raw_csv, validate_schema

    try:
        raw_df = load_raw_csv(str(FIXTURE_PATH))
        clean_df, report = validate_schema(raw_df)
    except Exception as e:
        print(f"  -> FAIL: validate_schema raised an exception ({e})")
        return False

    # The fixture was constructed with 12 total rows, 3 deliberately invalid
    # (out-of-range sf, invalid packet_success, missing required rssi_dbm).
    expected_total = 12
    expected_dropped = 3
    expected_kept = expected_total - expected_dropped

    ok = True
    if report.total_rows_read != expected_total:
        print(f"  -> FAIL: expected {expected_total} total rows, got {report.total_rows_read}")
        ok = False
    if report.rows_kept != expected_kept:
        print(f"  -> FAIL: expected {expected_kept} kept rows, got {report.rows_kept}")
        ok = False
    if report.rows_dropped != expected_dropped:
        print(f"  -> FAIL: expected {expected_dropped} dropped rows, got {report.rows_dropped}")
        ok = False
    if len(clean_df) != expected_kept:
        print(f"  -> FAIL: clean_df has {len(clean_df)} rows, expected {expected_kept}")
        ok = False

    if ok:
        print(f"  -> OK ({report.rows_kept} kept, {report.rows_dropped} dropped, as expected)")
    return ok


def check_feature_engineering():
    print("[CHECK] rolling feature engineering produces expected columns and values")
    from ml.preprocessing.clean import load_raw_csv, validate_schema
    from ml.preprocessing.feature_engineering import add_rolling_features
    from ml.preprocessing.schema import processed_feature_columns

    raw_df = load_raw_csv(str(FIXTURE_PATH))
    clean_df, _ = validate_schema(raw_df)

    try:
        processed_df = add_rolling_features(clean_df, window_sizes=[5])
    except Exception as e:
        print(f"  -> FAIL: add_rolling_features raised an exception ({e})")
        return False

    ok = True

    expected_cols = processed_feature_columns([5])
    for col in expected_cols:
        if col not in processed_df.columns:
            print(f"  -> FAIL: expected column '{col}' missing from output")
            ok = False
    if not ok:
        return False

    # First packet in the (only) group must have NaN history (no prior packets).
    first_row = processed_df.iloc[0]
    if not math.isnan(first_row["rolling_success_rate_w5"]):
        print("  -> FAIL: first packet's rolling_success_rate_w5 should be NaN (no prior history)")
        ok = False

    # Second packet's history should be based solely on the first packet.
    second_row = processed_df.iloc[1]
    expected_second_success_rate = float(first_row["packet_success"])
    if not math.isclose(second_row["rolling_success_rate_w5"], expected_second_success_rate, abs_tol=1e-9):
        print(
            f"  -> FAIL: second packet's rolling_success_rate_w5 = "
            f"{second_row['rolling_success_rate_w5']}, expected {expected_second_success_rate}"
        )
        ok = False

    # Sixth packet's w=5 rolling success rate should be the mean of the
    # PRECEDING 5 packets' packet_success values (packets at positions 0-4).
    if len(processed_df) >= 6:
        preceding_five_mean = processed_df.iloc[0:5]["packet_success"].astype(float).mean()
        sixth_row_value = processed_df.iloc[5]["rolling_success_rate_w5"]
        if not math.isclose(sixth_row_value, preceding_five_mean, abs_tol=1e-9):
            print(
                f"  -> FAIL: 6th packet's rolling_success_rate_w5 = {sixth_row_value}, "
                f"expected {preceding_five_mean} (mean of preceding 5 packets)"
            )
            ok = False

    if ok:
        print("  -> OK (columns present, no self-leakage, rolling values match hand computation)")
    return ok


def check_full_pipeline_cli():
    print("[CHECK] full pipeline (run_pipeline) writes a valid processed CSV to a temp location")
    from ml.preprocessing.pipeline import run_pipeline
    import pandas as pd

    tmp_dir = Path(tempfile.mkdtemp(prefix="lora_edgeai_test_"))
    output_path = tmp_dir / "synthetic_test_fixture_processed.csv"

    ok = True
    try:
        summary = run_pipeline(str(FIXTURE_PATH), str(output_path))

        if not output_path.exists():
            print("  -> FAIL: pipeline did not write an output file")
            ok = False
        else:
            written_df = pd.read_csv(output_path)
            if len(written_df) != summary["output_rows"]:
                print("  -> FAIL: written CSV row count doesn't match summary")
                ok = False
            if written_df.empty:
                print("  -> FAIL: written CSV is empty")
                ok = False
    except Exception as e:
        print(f"  -> FAIL: run_pipeline raised an exception ({e})")
        ok = False
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)

    if ok:
        print("  -> OK (pipeline ran end-to-end and wrote a valid processed CSV to a temp dir)")
    return ok


def check_no_pollution_of_real_data_dirs():
    """Sanity check: confirm this test script did not leave anything behind
    in the real data/raw, data/processed, or data/sample directories."""
    print("[CHECK] real data/ directories remain untouched by this test run")
    ok = True
    for sub in ["raw", "processed", "sample"]:
        d = PROJECT_ROOT / "data" / sub
        contents = [p.name for p in d.iterdir()] if d.exists() else []
        unexpected = [c for c in contents if c not in (".gitkeep", "README.md")]
        if unexpected:
            print(f"  -> FAIL: data/{sub}/ contains unexpected files: {unexpected}")
            ok = False
    if ok:
        print("  -> OK (data/raw, data/processed, data/sample still contain only README.md/.gitkeep)")
    return ok


def main():
    print("=" * 60)
    print("LoRa Edge-AI Project — Checkpoint 2 Preprocessing Verification")
    print("=" * 60)

    checks = [
        check_imports,
        check_fixture_exists,
        check_schema_validation,
        check_feature_engineering,
        check_full_pipeline_cli,
        check_no_pollution_of_real_data_dirs,
    ]

    results = [check() for check in checks]

    print("=" * 60)
    if all(results):
        print("ALL CHECKS PASSED")
        print("Preprocessing pipeline is verified against synthetic test data.")
        print("=" * 60)
        sys.exit(0)
    else:
        failed_count = results.count(False)
        print(f"{failed_count} CHECK(S) FAILED")
        print("=" * 60)
        sys.exit(1)


if __name__ == "__main__":
    main()
