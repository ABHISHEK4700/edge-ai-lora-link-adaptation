"""
test_training.py

Checkpoint 4 — Training & evaluation pipeline verification.

Verifies the Decision Tree training and evaluation pipeline in ml/training/
and ml/evaluation/, using ONLY the fabricated fixture at
tests/fixtures/synthetic_pipeline_fixture_raw.csv.

*** NOTHING HERE IS A RESEARCH RESULT. ***
These checks confirm the SOFTWARE RUNS. The fixture is trivially separable by
construction, so the model is expected to score near-perfectly on it; that
tells you nothing about LoRa. Accordingly, no check in this file asserts
"accuracy must be high" as if that were evidence of quality — the accuracy
assertions exist only to catch a pipeline that has become wired up wrong.

What is checked:
  1.  Modules import.
  2.  The synthetic pipeline fixture exists and has the expected shape.
  3.  The full chain preprocessing -> labeling -> dataset runs.
  4.  Banned columns are rejected as features (leakage guard).
  5.  The default feature set carries all four project inputs and nothing
      that is unknowable before transmitting.
  6.  Dataset assembly drops unlabelled and NaN-history rows and counts them.
  7.  Splitting is by context, with zero context overlap.
  8.  Splitting refuses to run when there are too few contexts.
  9.  Training records depth, node count, leaves and training time.
 10.  The model file is written and its size is recorded.
 11.  A saved model reloads and predicts identically.
 12.  Inference timing is measured.
 13.  The metadata carries every required field and the banner.
 14.  A majority-class baseline is reported alongside every accuracy.
 15.  Joint exact match never exceeds either individual accuracy.
 16.  Per-context scoring counts contexts, not rows.
 17.  The evaluation script runs standalone and writes a report.
 18.  The report carries the banner and the explicit non-claims.
 19.  Runs are reproducible for a fixed random_state.
 20.  The saved bundle contains no banned feature.
 21.  data/raw, data/processed and data/sample remain untouched.

Run with:
    python tests/test_training.py

Exit code 0 -> all checks passed
Exit code 1 -> at least one check failed
"""

import json
import shutil
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

FIXTURE = PROJECT_ROOT / "tests" / "fixtures" / "synthetic_pipeline_fixture_raw.csv"

#: Built once by _prepare() and reused, so the chain runs once not 20 times.
_PREPARED = {}


def _prepare():
    """Run preprocessing + labeling once into a temp dir; cache the paths."""
    if _PREPARED:
        return _PREPARED

    from ml.labeling.labeler import run_labeling
    from ml.preprocessing.pipeline import run_pipeline

    tmp = Path(tempfile.mkdtemp(prefix="lora_cp04_test_"))
    proc = tmp / "proc.csv"
    lab = tmp / "lab.csv"
    run_pipeline(str(FIXTURE), str(proc))
    run_labeling(str(proc), str(lab))

    _PREPARED.update({"tmp": tmp, "processed": proc, "labeled": lab})
    return _PREPARED


def _cleanup():
    if _PREPARED.get("tmp"):
        shutil.rmtree(_PREPARED["tmp"], ignore_errors=True)


# ---------------------------------------------------------------------------

def check_imports():
    print("[CHECK] training and evaluation modules import correctly")
    try:
        from ml.training import dataset, train_decision_tree  # noqa: F401
        from ml.evaluation import evaluate, metrics  # noqa: F401
        import joblib  # noqa: F401
        from sklearn.tree import DecisionTreeClassifier  # noqa: F401
    except ImportError as e:
        print(f"  -> FAIL: could not import ({e})")
        return False
    print("  -> OK")
    return True


def check_fixture():
    print("[CHECK] synthetic pipeline fixture exists and has expected shape")
    import pandas as pd

    if not FIXTURE.exists():
        print("  -> FAIL: fixture missing; run "
              "tests/fixtures/make_synthetic_pipeline_fixture.py")
        return False

    df = pd.read_csv(FIXTURE)
    ok = True
    if len(df) != 6480:
        print(f"  -> FAIL: expected 6480 rows, got {len(df)}")
        ok = False
    if df["session_id"].nunique() != 36:
        print(f"  -> FAIL: expected 36 sessions, got {df['session_id'].nunique()}")
        ok = False
    if sorted(df["sf"].unique()) != [7, 9, 12]:
        print(f"  -> FAIL: unexpected SF grid {sorted(df['sf'].unique())}")
        ok = False
    if ok:
        print("  -> OK (6480 fabricated rows, 36 sessions, SF grid {7,9,12})")
    return ok


def check_chain_runs():
    print("[CHECK] preprocessing -> labeling -> dataset chain runs end to end")
    import pandas as pd

    try:
        p = _prepare()
    except Exception as e:
        print(f"  -> FAIL: chain raised ({type(e).__name__}: {e})")
        return False

    ok = True
    labels = pd.read_csv(str(p["labeled"]).replace(".csv", "_labels.csv"))
    if len(labels) != 36:
        print(f"  -> FAIL: expected 36 contexts, got {len(labels)}")
        ok = False
    labelled = (labels["label_status"] == "ok").sum()
    if labelled != 30:
        print(f"  -> FAIL: expected 30 labelled contexts, got {labelled}")
        ok = False
    # Tier 6 is deliberately unlabellable.
    if (labels["label_status"] == "no_label").sum() != 6:
        print("  -> FAIL: expected 6 deliberately-unlabellable contexts")
        ok = False

    if ok:
        print("  -> OK (36 contexts, 30 labelled, 6 correctly refused)")
    return ok


def check_feature_leakage_guard():
    print("[CHECK] banned columns are rejected as model features")
    from ml.training.dataset import (
        BANNED_FEATURE_COLUMNS, FeatureLeakageError, build_dataset,
        resolve_feature_columns,
    )
    import pandas as pd

    ok = True
    # Every banned column must be refused by resolve_feature_columns.
    for col in BANNED_FEATURE_COLUMNS:
        try:
            resolve_feature_columns(extra=[col])
            print(f"  -> FAIL: banned column {col!r} was accepted as a feature")
            ok = False
        except FeatureLeakageError:
            pass

    # The most dangerous ones must also be refused at build_dataset level.
    df = pd.read_csv(_prepare()["labeled"])
    for col in ("sf", "tp_dbm", "label_sf", "packet_success", "retry_count"):
        try:
            build_dataset(df, feature_columns=["rolling_snr_avg_w5", col])
            print(f"  -> FAIL: build_dataset accepted banned feature {col!r}")
            ok = False
        except FeatureLeakageError:
            pass

    if ok:
        print(f"  -> OK ({len(BANNED_FEATURE_COLUMNS)} banned columns refused "
              f"at both entry points)")
    return ok


def check_default_feature_set():
    print("[CHECK] the default feature set covers the four project inputs, causally")
    from ml.training.dataset import (
        BANNED_FEATURE_COLUMNS, CURRENT_LINK_COLUMNS, resolve_feature_columns,
    )

    cols = resolve_feature_columns()
    ok = True

    # All four stated project inputs must be represented.
    for signal, token in (("RSSI", "rssi"), ("SNR", "snr"),
                          ("success/failure history", "success_rate"),
                          ("retry count", "retry")):
        if not any(token in c for c in cols):
            print(f"  -> FAIL: no feature represents {signal}")
            ok = False

    # Nothing banned may be present.
    for c in cols:
        if c in BANNED_FEATURE_COLUMNS:
            print(f"  -> FAIL: default feature set contains banned column {c!r}")
            ok = False

    # Current-link columns must be OFF by default and ON when asked.
    for c in CURRENT_LINK_COLUMNS:
        if c in cols:
            print(f"  -> FAIL: {c!r} should be off by default (acausal)")
            ok = False
    with_current = resolve_feature_columns(include_current_link=True)
    for c in CURRENT_LINK_COLUMNS:
        if c not in with_current:
            print(f"  -> FAIL: include_current_link did not add {c!r}")
            ok = False

    # No GPS/distance/contextual extras crept in.
    for banned_token in ("gps", "lat", "lon", "distance", "altitude"):
        if any(banned_token in c.lower() for c in cols):
            print(f"  -> FAIL: feature set contains a contextual variable "
                  f"matching {banned_token!r}")
            ok = False

    if ok:
        print(f"  -> OK ({len(cols)} causal features; current-link off by default)")
    return ok


def check_dataset_assembly():
    print("[CHECK] dataset assembly drops unlabelled and NaN-history rows, and counts them")
    from ml.training.dataset import build_dataset
    import pandas as pd

    df = pd.read_csv(_prepare()["labeled"])
    X, y_sf, y_tp, groups, summary = build_dataset(df)
    ok = True

    if len(X) != len(y_sf) or len(X) != len(groups):
        print("  -> FAIL: X / y / groups lengths disagree")
        ok = False
    if summary.contexts != 30:
        print(f"  -> FAIL: expected 30 contexts, got {summary.contexts}")
        ok = False
    # 36 contexts x 1 first-packet-without-history = 30 for labelled contexts.
    if summary.dropped_nan_features != 30:
        print(f"  -> FAIL: expected 30 NaN-history rows dropped, "
              f"got {summary.dropped_nan_features}")
        ok = False
    if X.shape[1] != len(summary.feature_columns):
        print("  -> FAIL: feature matrix width disagrees with feature list")
        ok = False
    import numpy as np
    if np.isnan(X).any():
        print("  -> FAIL: NaN survived into the feature matrix")
        ok = False
    if len(set(y_sf.tolist())) < 2:
        print("  -> FAIL: fewer than 2 SF classes — nothing to classify")
        ok = False

    # An all-unlabelled frame must fail loudly, not silently produce nothing.
    empty = df.copy()
    empty["label_sf"] = None
    empty["label_tp_dbm"] = None
    try:
        build_dataset(empty)
        print("  -> FAIL: an entirely unlabelled frame did not raise")
        ok = False
    except ValueError:
        pass

    if ok:
        print(f"  -> OK ({len(X)} usable rows, {summary.contexts} contexts, "
              f"{summary.dropped_nan_features} no-history rows dropped)")
    return ok


def check_context_aware_split():
    print("[CHECK] the split is by context, with zero context overlap")
    from ml.training.dataset import (
        build_dataset, context_aware_split, describe_split,
    )
    import numpy as np
    import pandas as pd

    df = pd.read_csv(_prepare()["labeled"])
    X, y_sf, y_tp, groups, _ = build_dataset(df)
    ok = True

    train_idx, test_idx = context_aware_split(groups, test_size=0.3, random_state=0)
    info = describe_split(groups, train_idx, test_idx)

    if info["context_overlap"] != 0:
        print("  -> FAIL: contexts appear on both sides of the split")
        ok = False
    if info["train_contexts"] + info["test_contexts"] != 30:
        print("  -> FAIL: split lost or duplicated contexts")
        ok = False
    if info["test_contexts"] < 2:
        print(f"  -> FAIL: only {info['test_contexts']} test contexts")
        ok = False
    if len(set(train_idx) & set(test_idx)):
        print("  -> FAIL: row indices overlap between train and test")
        ok = False

    # Contrast: a naive row-level split WOULD leak, which is why this matters.
    rng = np.random.RandomState(0)
    perm = rng.permutation(len(groups))
    naive_train, naive_test = perm[:int(0.7 * len(perm))], perm[int(0.7 * len(perm)):]
    naive_overlap = set(groups[naive_train]) & set(groups[naive_test])
    if not naive_overlap:
        print("  -> FAIL: a naive row split did not leak, so this fixture no "
              "longer demonstrates why context splitting is required")
        ok = False

    if ok:
        print(f"  -> OK ({info['train_contexts']} train / "
              f"{info['test_contexts']} test contexts, 0 overlap; "
              f"a naive row split would have leaked {len(naive_overlap)})")
    return ok


def check_split_refuses_too_few_contexts():
    print("[CHECK] splitting refuses to run with too few contexts")
    from ml.training.dataset import context_aware_split
    import numpy as np

    ok = True
    for groups in (np.array(["a"] * 50), np.array([])):
        try:
            context_aware_split(groups)
            print("  -> FAIL: split accepted fewer than 2 contexts")
            ok = False
        except ValueError:
            pass
    if ok:
        print("  -> OK (single-context and empty inputs both refused)")
    return ok


def check_training_records_structure():
    print("[CHECK] training records tree depth, nodes, leaves, size and timings")
    from ml.training.train_decision_tree import train

    p = _prepare()
    outdir = p["tmp"] / "models"
    try:
        meta = train(str(p["labeled"]), str(outdir))
    except Exception as e:
        print(f"  -> FAIL: training raised ({type(e).__name__}: {e})")
        return False

    p["metadata"] = meta
    p["model_path"] = outdir / "decision_tree_sf_tp.joblib"
    ok = True

    for tree_key in ("sf_tree", "tp_tree"):
        t = meta[tree_key]
        for field in ("actual_depth", "n_nodes", "n_leaves",
                      "n_features_used", "training_seconds",
                      "feature_importances"):
            if field not in t:
                print(f"  -> FAIL: {tree_key} is missing '{field}'")
                ok = False
        if ok:
            if t["actual_depth"] < 1:
                print(f"  -> FAIL: {tree_key} has depth {t['actual_depth']}")
                ok = False
            if t["n_nodes"] < t["n_leaves"]:
                print(f"  -> FAIL: {tree_key} has fewer nodes than leaves")
                ok = False
            if t["n_leaves"] < 2:
                print(f"  -> FAIL: {tree_key} is a single leaf — nothing learned")
                ok = False
            if t["training_seconds"] <= 0:
                print(f"  -> FAIL: {tree_key} training time not measured")
                ok = False

    mf = meta["model_file"]
    if not mf.get("bytes") or mf["bytes"] <= 0:
        print("  -> FAIL: model file size not recorded")
        ok = False
    it = meta["inference_timing"]
    if not it.get("measured") or it.get("per_row_microseconds") is None:
        print("  -> FAIL: inference time not measured")
        ok = False

    if ok:
        print(f"  -> OK (SF depth {meta['sf_tree']['actual_depth']}/"
              f"{meta['sf_tree']['n_nodes']} nodes, TP depth "
              f"{meta['tp_tree']['actual_depth']}/{meta['tp_tree']['n_nodes']} "
              f"nodes, {mf['kilobytes']} KB)")
    return ok


def check_model_saves_and_reloads():
    print("[CHECK] the saved model reloads and predicts identically")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.dataset import build_dataset
    import numpy as np
    import pandas as pd

    p = _prepare()
    if "model_path" not in p:
        print("  -> FAIL: no model was trained by the previous check")
        return False
    if not p["model_path"].exists():
        print("  -> FAIL: model file was not written")
        return False

    ok = True
    bundle = load_bundle(str(p["model_path"]))
    df = pd.read_csv(p["labeled"])
    X, y_sf, y_tp, groups, _ = build_dataset(
        df, feature_columns=bundle["feature_columns"])

    first = bundle["sf_model"].predict(X)
    bundle2 = load_bundle(str(p["model_path"]))
    second = bundle2["sf_model"].predict(X)
    if not np.array_equal(first, second):
        print("  -> FAIL: two loads of the same model predicted differently")
        ok = False

    for key in ("sf_model", "tp_model", "feature_columns", "provenance"):
        if key not in bundle:
            print(f"  -> FAIL: bundle is missing '{key}'")
            ok = False

    # A non-bundle file must be rejected rather than half-loaded.
    import joblib
    bad = p["tmp"] / "notabundle.joblib"
    joblib.dump({"something": 1}, bad)
    try:
        load_bundle(str(bad))
        print("  -> FAIL: an invalid bundle was accepted")
        ok = False
    except ValueError:
        pass

    if ok:
        print("  -> OK (reload deterministic; invalid bundle refused)")
    return ok


def check_metadata_completeness():
    print("[CHECK] metadata carries every required field plus the banner")
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _prepare()
    meta = p.get("metadata")
    if not meta:
        print("  -> FAIL: no metadata from the training check")
        return False

    ok = True
    for field in ("banner", "status", "checkpoint", "model_family", "tuned",
                  "environment", "data", "split", "hyperparameters",
                  "sf_tree", "tp_tree", "total_training_seconds",
                  "inference_timing", "model_file", "metrics",
                  "explicit_non_claims"):
        if field not in meta:
            print(f"  -> FAIL: metadata is missing '{field}'")
            ok = False

    if meta.get("banner") != SYNTHETIC_BANNER:
        print("  -> FAIL: metadata banner is wrong or missing")
        ok = False
    if meta.get("tuned") is not False:
        print("  -> FAIL: metadata should record that the model is untuned")
        ok = False
    if meta.get("metrics", {}).get("banner") != SYNTHETIC_BANNER:
        print("  -> FAIL: metrics block is not banner-stamped")
        ok = False
    if len(meta.get("explicit_non_claims", [])) < 5:
        print("  -> FAIL: explicit non-claims list is too short")
        ok = False

    # The written JSON must match and stay loadable.
    meta_file = p["tmp"] / "models" / "decision_tree_sf_tp_metadata.json"
    if not meta_file.exists():
        print("  -> FAIL: metadata JSON was not written")
        ok = False
    else:
        with open(meta_file, encoding="utf-8") as fh:
            on_disk = json.load(fh)
        if on_disk.get("banner") != SYNTHETIC_BANNER:
            print("  -> FAIL: on-disk metadata is not banner-stamped")
            ok = False

    if ok:
        print("  -> OK (all fields present, banner stamped, tuned=False)")
    return ok


def check_baseline_and_joint_metrics():
    print("[CHECK] baselines are reported and joint accuracy is consistent")
    from ml.evaluation.metrics import (
        classification_metrics, joint_exact_match, majority_class_baseline,
        per_context_agreement,
    )
    import numpy as np

    ok = True
    meta = _prepare().get("metadata")
    if not meta:
        print("  -> FAIL: no metadata available")
        return False

    for key in ("spreading_factor", "tx_power_dbm"):
        m = meta["metrics"][key]
        if "majority_class_baseline" not in m:
            print(f"  -> FAIL: {key} has no majority-class baseline")
            ok = False
        if "per_class" not in m or not m["per_class"]:
            print(f"  -> FAIL: {key} has no per-class breakdown")
            ok = False
        if "confusion_matrix" not in m:
            print(f"  -> FAIL: {key} has no confusion matrix")
            ok = False

    # Joint accuracy can never exceed either individual accuracy.
    sf_acc = meta["metrics"]["spreading_factor"]["accuracy"]
    tp_acc = meta["metrics"]["tx_power_dbm"]["accuracy"]
    joint = meta["metrics"]["joint"]["accuracy"]
    if joint > min(sf_acc, tp_acc) + 1e-12:
        print(f"  -> FAIL: joint accuracy {joint} exceeds min of "
              f"{sf_acc}/{tp_acc}, which is impossible")
        ok = False

    # Per-context scoring must count contexts, not rows.
    pc = meta["metrics"]["per_context"]
    if pc["n_contexts"] != meta["split"]["test_contexts"]:
        print(f"  -> FAIL: per-context metric counted {pc['n_contexts']} "
              f"contexts, expected {meta['split']['test_contexts']}")
        ok = False

    # Baseline maths, checked directly on a known case.
    b = majority_class_baseline(np.array([1, 1, 1, 2]), np.array([1, 1, 2, 2]))
    if b["predicted_class"] != 1 or abs(b["accuracy"] - 0.5) > 1e-12:
        print(f"  -> FAIL: majority baseline miscomputed: {b}")
        ok = False

    # A deliberately wrong predictor must score badly — proves the metric
    # is measuring something rather than always returning 1.0.
    truth = np.array([7, 7, 9, 9, 12, 12])
    wrong = np.array([12, 12, 7, 7, 9, 9])
    m = classification_metrics(truth, wrong, "test")
    if m["accuracy"] != 0.0:
        print(f"  -> FAIL: an all-wrong predictor scored {m['accuracy']}")
        ok = False

    j = joint_exact_match(truth, truth, truth, wrong)
    if j["accuracy"] != 0.0:
        print("  -> FAIL: joint match ignored the wrong second target")
        ok = False

    pc2 = per_context_agreement(
        np.array(["a", "a", "b", "b"]), np.array([7, 7, 9, 9]),
        np.array([7, 7, 9, 9]), np.array([2, 2, 2, 2]), np.array([2, 2, 2, 2]))
    if pc2["n_contexts"] != 2 or pc2["joint_accuracy"] != 1.0:
        print(f"  -> FAIL: per-context aggregation wrong: {pc2}")
        ok = False

    if ok:
        print("  -> OK (baselines present; joint <= min; all-wrong scores 0.0)")
    return ok


def check_evaluation_script():
    print("[CHECK] the evaluation script runs standalone and writes a report")
    from ml.evaluation.evaluate import evaluate, render_markdown_report
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _prepare()
    ok = True

    try:
        result = evaluate(str(p["model_path"]), str(p["labeled"]))
    except Exception as e:
        print(f"  -> FAIL: evaluate raised ({type(e).__name__}: {e})")
        return False

    if result["banner"] != SYNTHETIC_BANNER:
        print("  -> FAIL: evaluation result is not banner-stamped")
        ok = False

    # Holdout and all-rows scopes must both work and be labelled differently.
    result_all = evaluate(str(p["model_path"]), str(p["labeled"]),
                          evaluate_on="all")
    if result_all["metrics"]["spreading_factor"]["n_samples"] <= \
            result["metrics"]["spreading_factor"]["n_samples"]:
        print("  -> FAIL: evaluate_on='all' did not score more rows")
        ok = False
    if "optimistic" not in result_all["evaluation_scope"]:
        print("  -> FAIL: the all-rows scope is not flagged as optimistic")
        ok = False

    try:
        evaluate(str(p["model_path"]), str(p["labeled"]), evaluate_on="nonsense")
        print("  -> FAIL: an unknown evaluation scope was accepted")
        ok = False
    except ValueError:
        pass

    report = render_markdown_report(result, p.get("metadata"))
    report_path = p["tmp"] / "report.md"
    report_path.write_text(report, encoding="utf-8")
    p["report"] = report_path

    if not report_path.exists() or report_path.stat().st_size == 0:
        print("  -> FAIL: report was not written")
        ok = False

    if ok:
        print("  -> OK (holdout + all-rows scopes, report written)")
    return ok


def check_report_carries_banner_and_non_claims():
    print("[CHECK] the report carries the banner and the explicit non-claims")
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _prepare()
    if "report" not in p:
        print("  -> FAIL: no report from the previous check")
        return False

    text = p["report"].read_text(encoding="utf-8")
    ok = True

    if text.count(SYNTHETIC_BANNER) < 3:
        print(f"  -> FAIL: banner appears only {text.count(SYNTHETIC_BANNER)} "
              f"time(s); it must head the report, the metrics section and the "
              f"footer")
        ok = False

    for phrase in ("packet delivery ratio", "latency", "energy consumption",
                   "adaptation", "real LoRa communication",
                   "Evidence of project success"):
        if phrase.lower() not in text.lower():
            print(f"  -> FAIL: report does not explicitly disclaim {phrase!r}")
            ok = False

    if "Effective sample size" not in text:
        print("  -> FAIL: report does not state the effective sample size")
        ok = False
    if "trivially separable" not in text:
        print("  -> FAIL: report does not warn that the fixture is separable "
              "by construction")
        ok = False

    if ok:
        print(f"  -> OK (banner x{text.count(SYNTHETIC_BANNER)}, all "
              f"non-claims present)")
    return ok


def check_reproducibility():
    print("[CHECK] a fixed random_state gives a reproducible run")
    from ml.training.train_decision_tree import train

    p = _prepare()
    ok = True

    a = train(str(p["labeled"]), str(p["tmp"] / "rep_a"), random_state=7)
    b = train(str(p["labeled"]), str(p["tmp"] / "rep_b"), random_state=7)

    for path in (("split", "train_contexts"), ("sf_tree", "n_nodes"),
                 ("tp_tree", "n_nodes")):
        if a[path[0]][path[1]] != b[path[0]][path[1]]:
            print(f"  -> FAIL: {'.'.join(path)} differed between identical runs")
            ok = False
    if a["metrics"]["joint"]["accuracy"] != b["metrics"]["joint"]["accuracy"]:
        print("  -> FAIL: joint accuracy differed between identical runs")
        ok = False

    # A different seed should generally give a different split.
    c = train(str(p["labeled"]), str(p["tmp"] / "rep_c"), random_state=99,
              save_model=False)
    if c["split"] == a["split"] and c["split"]["train_rows"] == a["split"]["train_rows"]:
        # Not fatal — seeds can coincide — but worth surfacing.
        print("  -> NOTE: seeds 7 and 99 produced the same split sizes")

    if ok:
        print("  -> OK (identical seed reproduces split, structure and metrics)")
    return ok


def check_bundle_has_no_banned_features():
    print("[CHECK] the saved bundle contains no banned feature")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.dataset import BANNED_FEATURE_COLUMNS

    p = _prepare()
    bundle = load_bundle(str(p["model_path"]))
    ok = True

    for col in bundle["feature_columns"]:
        if col in BANNED_FEATURE_COLUMNS:
            print(f"  -> FAIL: saved model uses banned feature {col!r} — "
                  f"{BANNED_FEATURE_COLUMNS[col]}")
            ok = False

    n_features = bundle["sf_model"].n_features_in_
    if n_features != len(bundle["feature_columns"]):
        print(f"  -> FAIL: model expects {n_features} features but the bundle "
              f"lists {len(bundle['feature_columns'])}")
        ok = False

    if ok:
        print(f"  -> OK ({len(bundle['feature_columns'])} features, none banned)")
    return ok


def check_no_pollution_of_real_data_dirs():
    print("[CHECK] real data/ directories remain untouched by this test run")
    ok = True
    for sub in ["raw", "processed", "sample"]:
        d = PROJECT_ROOT / "data" / sub
        contents = [x.name for x in d.iterdir()] if d.exists() else []
        unexpected = [c for c in contents if c not in (".gitkeep", "README.md")]
        if unexpected:
            print(f"  -> FAIL: data/{sub}/ contains unexpected files: {unexpected}")
            ok = False
    # Training must not have written a model into the repo either.
    stray = [x.name for x in (PROJECT_ROOT / "ml" / "models").iterdir()
             if x.name not in (".gitkeep", "README.md")]
    if stray:
        print(f"  -> FAIL: ml/models/ contains stray artifacts: {stray}")
        ok = False
    if ok:
        print("  -> OK (data/ and ml/models/ clean; test output went to a temp dir)")
    return ok


def main():
    print("=" * 70)
    print("LoRa Edge-AI — Checkpoint 4 Training/Evaluation Pipeline Verification")
    print("SOFTWARE VALIDATION ONLY — synthetic data, no research results")
    print("=" * 70)

    checks = [
        check_imports,
        check_fixture,
        check_chain_runs,
        check_feature_leakage_guard,
        check_default_feature_set,
        check_dataset_assembly,
        check_context_aware_split,
        check_split_refuses_too_few_contexts,
        check_training_records_structure,
        check_model_saves_and_reloads,
        check_metadata_completeness,
        check_baseline_and_joint_metrics,
        check_evaluation_script,
        check_report_carries_banner_and_non_claims,
        check_reproducibility,
        check_bundle_has_no_banned_features,
        check_no_pollution_of_real_data_dirs,
    ]

    try:
        results = [check() for check in checks]
    finally:
        _cleanup()

    print("=" * 70)
    if all(results):
        print("ALL CHECKS PASSED")
        print("The training/evaluation pipeline executes end to end.")
        print("This is SOFTWARE VALIDATION ONLY — no real data, no research result.")
        print("=" * 70)
        sys.exit(0)
    else:
        print(f"{results.count(False)} CHECK(S) FAILED")
        print("=" * 70)
        sys.exit(1)


if __name__ == "__main__":
    main()
