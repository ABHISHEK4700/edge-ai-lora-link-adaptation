"""
test_environment.py

Checkpoint 1 — Environment verification script.

Purpose
-------
This script does NOT test any part of the LoRa Edge-AI project itself
(there is no model, data, or pipeline yet). It only verifies that the
Python environment described in `requirements.txt` is correctly set up,
so that later checkpoints can build on a known-good foundation.

IMPORTANT: The numbers used inside `check_sklearn_basic_fit()` below are
synthetic placeholder numbers used ONLY to confirm that scikit-learn can
fit and predict with a model in this environment. They are NOT LoRa
research data, NOT RSSI/SNR measurements, and must never be reported or
interpreted as project results.

Run with:
    python tests/test_environment.py

Exit code 0  -> all checks passed
Exit code 1  -> at least one check failed
"""

import sys


def check_python_version():
    """Confirm Python interpreter version is 3.9+."""
    major, minor = sys.version_info[0], sys.version_info[1]
    print(f"[CHECK] Python version: {sys.version.split()[0]}")
    if (major, minor) < (3, 9):
        print("  -> FAIL: Python 3.9 or newer is required.")
        return False
    print("  -> OK")
    return True


def check_numpy_basic():
    """Confirm numpy imports and basic array math works."""
    print("[CHECK] numpy import + basic array operation")
    try:
        import numpy as np
    except ImportError as e:
        print(f"  -> FAIL: could not import numpy ({e})")
        return False

    try:
        arr = np.array([1, 2, 3, 4, 5], dtype=float)
        mean_val = arr.mean()
        expected = 3.0
        if abs(mean_val - expected) > 1e-9:
            print(f"  -> FAIL: unexpected mean {mean_val}, expected {expected}")
            return False
    except Exception as e:
        print(f"  -> FAIL: numpy operation raised an exception ({e})")
        return False

    print(f"  -> OK (numpy version {np.__version__})")
    return True


def check_pandas_basic():
    """Confirm pandas imports and basic DataFrame operations work."""
    print("[CHECK] pandas import + basic DataFrame operation")
    try:
        import pandas as pd
    except ImportError as e:
        print(f"  -> FAIL: could not import pandas ({e})")
        return False

    try:
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        col_sum = df["a"].sum()
        if col_sum != 6:
            print(f"  -> FAIL: unexpected sum {col_sum}, expected 6")
            return False
    except Exception as e:
        print(f"  -> FAIL: pandas operation raised an exception ({e})")
        return False

    print(f"  -> OK (pandas version {pd.__version__})")
    return True


def check_sklearn_basic_fit():
    """
    Confirm scikit-learn imports and can fit/predict on a trivial,
    clearly-synthetic sanity-check dataset.

    NOTE: This is a LIBRARY SANITY CHECK ONLY. The data below (y = 2x) is
    an arbitrary, obviously-synthetic relationship used purely to confirm
    that model fitting works in this environment. It has no connection to
    LoRa, RSSI, SNR, or any real project data, and must never be cited as
    a project result.
    """
    print("[CHECK] scikit-learn import + trivial model fit (sanity check only)")
    try:
        import sklearn
        from sklearn.linear_model import LinearRegression
        import numpy as np
    except ImportError as e:
        print(f"  -> FAIL: could not import scikit-learn ({e})")
        return False

    try:
        # Purely synthetic sanity-check data: y = 2 * x. Not project data.
        x_sanity_check = np.array([[1], [2], [3], [4]], dtype=float)
        y_sanity_check = np.array([2, 4, 6, 8], dtype=float)

        model = LinearRegression()
        model.fit(x_sanity_check, y_sanity_check)
        prediction = model.predict([[5]])[0]

        if abs(prediction - 10.0) > 1e-6:
            print(f"  -> FAIL: unexpected prediction {prediction}, expected ~10.0")
            return False
    except Exception as e:
        print(f"  -> FAIL: scikit-learn operation raised an exception ({e})")
        return False

    print(f"  -> OK (scikit-learn version {sklearn.__version__})")
    return True


def main():
    print("=" * 60)
    print("LoRa Edge-AI Project — Checkpoint 1 Environment Verification")
    print("=" * 60)

    checks = [
        check_python_version,
        check_numpy_basic,
        check_pandas_basic,
        check_sklearn_basic_fit,
    ]

    results = [check() for check in checks]

    print("=" * 60)
    if all(results):
        print("ALL CHECKS PASSED")
        print("Your environment is ready for Checkpoint 1.")
        print("=" * 60)
        sys.exit(0)
    else:
        failed_count = results.count(False)
        print(f"{failed_count} CHECK(S) FAILED")
        print("Please install/repair dependencies per requirements.txt")
        print("and re-run this script.")
        print("=" * 60)
        sys.exit(1)


if __name__ == "__main__":
    main()
