"""
make_synthetic_labeling_fixture.py

Generates tests/fixtures/synthetic_labeling_fixture_raw.csv.

*** THIS PRODUCES FABRICATED DATA. IT IS NOT A SIMULATOR AND IT IS NOT A ***
*** SOURCE OF RESEARCH RESULTS. Its only purpose is to give             ***
*** tests/test_labeling.py an input whose correct labels are known by    ***
*** construction, so the labeling CODE can be verified before any real   ***
*** hardware data exists.                                                ***

Nothing here models LoRa propagation. Success/failure outcomes are written
down by hand as fixed counts chosen to exercise specific code paths. No
random number generator is used, so the file is byte-for-byte reproducible
and every expected label can be derived on paper.

The fixture contains three deliberately different contexts:

  A — sess_lab_fixture_A  "a proper sweep"
      Four configurations x 30 packets. Three clear the reliability
      threshold, one does not. Exercises the normal path: cheapest
      configuration among those that met the threshold wins.

  B — sess_lab_fixture_B  "nothing works here"
      Two configurations x 30 packets, both far below any sensible
      reliability threshold. Exercises no-valid-configuration handling.

  C — sess_lab_fixture_C  "no sweep happened"
      One configuration x 30 packets, perfectly reliable. Exercises the
      evidence-coverage guard: with nothing to compare against, "best
      configuration" is vacuous and must NOT produce a confident label.

Packet counts are 30 per configuration on purpose. At a 100% observed
delivery ratio the Wilson lower bound equals n / (n + z^2); with the default
z = 1.645 that is 30 / 32.706 = 0.917, which clears a 0.90 threshold. Twelve
packets would give 0.816 and fail — the framework is supposed to reject thin
evidence, so the fixture has to be thick enough to pass on purpose rather
than by accident.

Regenerate with:
    python tests/fixtures/make_synthetic_labeling_fixture.py
"""

from __future__ import annotations

import csv
from pathlib import Path

OUTPUT = Path(__file__).resolve().parent / "synthetic_labeling_fixture_raw.csv"

HEADER = [
    "timestamp_utc", "session_id", "device_id", "packet_seq",
    "sf", "tp_dbm", "rssi_dbm", "snr_db", "retry_count", "packet_success",
    "payload_bytes", "channel_freq_hz", "notes",
]

DEVICE = "dev_lab_fixture"
PAYLOAD_BYTES = 20
# Kept at 433 MHz for consistency with the project's planned SX1278 hardware,
# exactly as in synthetic_test_fixture_raw.csv. Still a fabricated value.
FREQ_HZ = 433000000
PACKETS_PER_CONFIG = 30

# RSSI / SNR values are cycled from these short lists so that, under the
# default context strategy (session x 5 dB RSSI bins x 2.5 dB SNR bins),
# every row of a session lands in exactly ONE context. They are not
# measurements and carry no physical meaning.
BAND_VALUES = {
    "A": {"rssi": [-89.0, -88.0, -87.0, -86.0], "snr": [8.0, 8.5, 9.0, 9.5]},
    "B": {"rssi": [-114.0, -113.0, -112.0, -111.0], "snr": [-12.0, -11.5, -11.0, -10.5]},
    "C": {"rssi": [-99.0, -98.0, -97.0, -96.0], "snr": [0.5, 1.0, 1.5, 2.0]},
}

# (session_letter, sf, tp_dbm, successes_out_of_30, note)
CONFIGURATIONS = [
    # --- Context A: a proper sweep -----------------------------------------
    ("A", 7, 2.0, 15, "fabricated: below threshold"),
    ("A", 7, 14.0, 30, "fabricated: clears threshold"),
    ("A", 9, 2.0, 30, "fabricated: clears threshold"),
    ("A", 9, 14.0, 30, "fabricated: clears threshold"),
    # --- Context B: nothing clears the threshold ---------------------------
    ("B", 7, 14.0, 6, "fabricated: far below threshold"),
    ("B", 12, 14.0, 18, "fabricated: below threshold, but best of a bad set"),
    # --- Context C: only one configuration was ever measured ---------------
    ("C", 8, 14.0, 30, "fabricated: reliable but never compared against anything"),
]


def build_rows():
    rows = []
    seq_by_session = {"A": 0, "B": 0, "C": 0}
    minute = 0

    for letter, sf, tp, successes, note in CONFIGURATIONS:
        session_id = f"sess_lab_fixture_{letter}"
        band = BAND_VALUES[letter]

        for i in range(PACKETS_PER_CONFIG):
            # Successes are placed deterministically: the first `successes`
            # packets of each configuration succeed. No randomness anywhere.
            success = 1 if i < successes else 0
            retry = 0 if success else 3

            seq = seq_by_session[letter]
            seq_by_session[letter] = seq + 1

            timestamp = f"2026-02-01T{minute // 60:02d}:{minute % 60:02d}:{i * 2 % 60:02d}Z"

            rows.append([
                timestamp,
                session_id,
                DEVICE,
                seq,
                sf,
                f"{tp:g}",
                f"{band['rssi'][i % len(band['rssi'])]:g}",
                f"{band['snr'][i % len(band['snr'])]:g}",
                retry,
                success,
                PAYLOAD_BYTES,
                FREQ_HZ,
                f"SYNTHETIC test fixture - {note}",
            ])
        minute += 1

    return rows


def main():
    rows = build_rows()
    with open(OUTPUT, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(HEADER)
        writer.writerows(rows)
    print(f"Wrote {len(rows)} fabricated rows to {OUTPUT}")
    print("Reminder: this is test-only data, never a research result.")


if __name__ == "__main__":
    main()
