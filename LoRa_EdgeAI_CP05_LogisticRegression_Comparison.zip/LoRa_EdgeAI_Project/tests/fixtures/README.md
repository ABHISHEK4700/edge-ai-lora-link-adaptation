# tests/fixtures/ — Synthetic Test Fixtures

**Everything in this folder is fabricated data used ONLY to test that the
preprocessing code behaves correctly.** None of it is real LoRa hardware
data, none of it is a research result, and none of it should ever be cited,
plotted, or reported as a project finding.

This mirrors the same approach used in `tests/test_environment.py` from
Checkpoint 1, where a trivial `y = 2x` relationship was used purely to
confirm scikit-learn could fit a model — not as project data.

## Files

- `synthetic_test_fixture_raw.csv` — a small (12-row), hand-constructed CSV
  matching `ml/preprocessing/schema.RAW_SCHEMA`, used by
  `tests/test_preprocessing.py` to verify:
  - valid rows are kept
  - invalid rows (out-of-range values, missing required fields) are
    correctly detected and dropped
  - rolling/history feature engineering produces the expected columns and
    values, including correctly excluding the current packet's own outcome
    from its own history features

  Its `channel_freq_hz` value (433000000 / 433 MHz) is set to match the
  band of the project's planned hardware (SX1278, 433 MHz) purely so this
  fabricated file doesn't imply a different, incorrect radio band if
  someone skims it later. The value is still entirely synthetic — it was
  not measured from any real device — only the frequency *number* was
  chosen to stay consistent with the real hardware plan and avoid
  confusion.

- `synthetic_labeling_fixture_raw.csv` (added Checkpoint 3) — a 210-row
  fabricated CSV used by `tests/test_labeling.py` to verify the labeling
  framework in `ml/labeling/`. It contains three deliberately different
  sessions:

  | Session | Contents | Code path it exercises |
  |---|---|---|
  | `sess_lab_fixture_A` | 4 configurations x 30 packets; three clear the reliability threshold, one does not | the normal path — cheapest configuration that met the threshold wins |
  | `sess_lab_fixture_B` | 2 configurations x 30 packets, both far below any sensible threshold | no-valid-configuration handling (all four policies) |
  | `sess_lab_fixture_C` | 1 configuration x 30 packets, perfectly reliable | the evidence-coverage guard — with nothing to compare against, "best" is vacuous and must not produce a confident label |

  **This is not a LoRa simulator and its numbers model nothing.** Success and
  failure outcomes are fixed counts written down by hand to trigger specific
  branches. No propagation model, no random number generator, no physical
  reasoning. The expected label for each context is derivable on paper, which
  is the entire point — it lets the test assert an exact answer rather than
  whatever the code happens to output.

  30 packets per configuration is deliberate, not arbitrary: at a 100%
  observed delivery ratio the default Wilson lower bound equals
  `n / (n + z²)`, so 30 packets gives 0.917 and clears the 0.90 threshold
  while 12 would give 0.816 and fail. The framework is supposed to reject
  thin evidence, so the fixture has to be thick enough to pass deliberately.

  Like the Checkpoint 2 fixture, its `channel_freq_hz` is 433 MHz for
  consistency with the planned SX1278 hardware. Still fabricated.

- `make_synthetic_labeling_fixture.py` (added Checkpoint 3) — the generator
  for the above. Fully deterministic (no RNG, no seed), so the CSV is
  byte-for-byte reproducible. Committed alongside the CSV so the fabricated
  data is auditable rather than mysterious. Regenerate with:

  ```bash
  python tests/fixtures/make_synthetic_labeling_fixture.py
  ```

If you need more/different synthetic test cases in a future checkpoint,
add them here with a clear filename and update the relevant test file
accordingly — do not add synthetic data to `data/raw/`, `data/processed/`,
or `data/sample/`.
