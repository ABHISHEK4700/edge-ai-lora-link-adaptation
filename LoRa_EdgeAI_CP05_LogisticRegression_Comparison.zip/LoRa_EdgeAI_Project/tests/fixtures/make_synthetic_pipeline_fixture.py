"""
make_synthetic_pipeline_fixture.py

Generates tests/fixtures/synthetic_pipeline_fixture_raw.csv.

*** THIS PRODUCES FABRICATED DATA. IT IS NOT A LoRa SIMULATOR.            ***
*** Nothing it outputs is a measurement, a research result, or evidence   ***
*** about real LoRa behaviour. Its only purpose is to give Checkpoint 4's ***
*** training/evaluation pipeline enough labelled contexts to RUN, so the  ***
*** software can be verified before any real hardware data exists.        ***

WHY THIS FIXTURE EXISTS
-----------------------
Checkpoint 3's fixture (synthetic_labeling_fixture_raw.csv) produces exactly
ONE labelled context carrying ONE (SF, TP) pair. That is correct for testing
the labeling framework, but a classifier cannot be trained on a single class,
and a train/test split needs more than one group. Checkpoint 4 therefore
needs a larger fixture with several labelled contexts spanning several
label classes.

HOW IT IS BUILT
---------------
Fully deterministic — no random number generator, no seed. Success counts are
written down by hand in LINK_TIERS below, chosen so that different tiers
produce different winning configurations once Checkpoint 3's labeling rule is
applied. Every expected label is derivable on paper.

Structure:
  * 6 "link tiers", each a hand-written table of successes-out-of-30 for each
    of the 6 configurations in the sweep grid
  * 6 sessions per tier = 36 sessions
  * each session round-robins the full (SF, TP) grid, 30 packets per
    configuration = 180 rows per session
  * 6480 rows total

The grid is SF {7, 9, 12} x TX power {2, 14} dBm. These particular values are
a *test grid for the software*, not a hardware decision — Checkpoint 3
deliberately leaves the real candidate sets unset until the SX1278 board and
the regional configuration are confirmed.

30 packets per configuration is required, not arbitrary: at a 100% delivery
ratio Checkpoint 3's default Wilson lower bound equals n / (n + z^2), so 30
gives 0.917 and clears the 0.90 threshold while 12 would give 0.816 and fail.

Tier 6 is deliberately unlabellable (nothing clears the threshold), so the
training pipeline gets exercised on data where some contexts must be
excluded.

A CRITICAL CAVEAT FOR ANYONE READING RESULTS FROM THIS FILE
-----------------------------------------------------------
This fixture is trivially separable by construction: each tier has a distinct
RSSI/SNR band and a single correct answer, so any working classifier should
score near-perfectly on it. A high accuracy here measures only that the
pipeline is wired up correctly. It is NOT evidence that the approach works,
that the model generalises, or that anything has been validated for real LoRa
communication.

Regenerate with:
    python tests/fixtures/make_synthetic_pipeline_fixture.py
"""

from __future__ import annotations

import csv
from pathlib import Path

OUTPUT = Path(__file__).resolve().parent / "synthetic_pipeline_fixture_raw.csv"

HEADER = [
    "timestamp_utc", "session_id", "device_id", "packet_seq",
    "sf", "tp_dbm", "rssi_dbm", "snr_db", "retry_count", "packet_success",
    "payload_bytes", "channel_freq_hz", "notes",
]

DEVICE = "dev_pipe_fixture"
PAYLOAD_BYTES = 20
FREQ_HZ = 433000000            # 433 MHz, consistent with the planned SX1278
PACKETS_PER_CONFIG = 30
SESSIONS_PER_TIER = 6

#: The sweep grid used by this fixture. A software test grid, NOT a hardware
#: or regulatory decision — see module docstring.
GRID = [
    (7, 2.0), (7, 14.0),
    (9, 2.0), (9, 14.0),
    (12, 2.0), (12, 14.0),
]

# Each tier: fabricated successes-out-of-30 per configuration, plus the
# RSSI/SNR band its sessions sit in. `expected` records the label the
# Checkpoint 3 rule should produce, so the test can assert it.
#
# Bands are chosen so that, under the default context strategy (5 dB RSSI
# bins, 2.5 dB SNR bins), every row of a session falls in exactly one bin.
LINK_TIERS = [
    {
        "name": "t1_excellent",
        "rssi_base": -89.0, "snr_base": 8.0,
        "successes": {(7, 2.0): 30, (7, 14.0): 30, (9, 2.0): 30,
                      (9, 14.0): 30, (12, 2.0): 30, (12, 14.0): 30},
        "expected": (7, 2.0),     # everything works -> cheapest wins
    },
    {
        "name": "t2_good",
        "rssi_base": -94.0, "snr_base": 5.5,
        "successes": {(7, 2.0): 15, (7, 14.0): 30, (9, 2.0): 30,
                      (9, 14.0): 30, (12, 2.0): 30, (12, 14.0): 30},
        "expected": (9, 2.0),     # SF7@2 fails; SF9@2 beats SF7@14 on energy
    },
    {
        "name": "t3_lowpower_marginal",
        "rssi_base": -99.0, "snr_base": 3.0,
        "successes": {(7, 2.0): 12, (7, 14.0): 30, (9, 2.0): 18,
                      (9, 14.0): 30, (12, 2.0): 30, (12, 14.0): 30},
        "expected": (7, 14.0),    # both low-power options fail
    },
    {
        "name": "t4_moderate",
        "rssi_base": -104.0, "snr_base": 0.5,
        "successes": {(7, 2.0): 6, (7, 14.0): 14, (9, 2.0): 20,
                      (9, 14.0): 30, (12, 2.0): 30, (12, 14.0): 30},
        "expected": (12, 2.0),    # SF12@2 is cheaper than SF9@14
    },
    {
        "name": "t5_poor",
        "rssi_base": -109.0, "snr_base": -2.0,
        "successes": {(7, 2.0): 0, (7, 14.0): 4, (9, 2.0): 6,
                      (9, 14.0): 16, (12, 2.0): 20, (12, 14.0): 30},
        "expected": (12, 14.0),   # only the most robust option survives
    },
    {
        "name": "t6_unusable",
        "rssi_base": -119.0, "snr_base": -14.4,
        "successes": {(7, 2.0): 0, (7, 14.0): 0, (9, 2.0): 1,
                      (9, 14.0): 3, (12, 2.0): 4, (12, 14.0): 9},
        "expected": None,         # nothing clears the threshold -> no label
    },
]


def build_rows():
    rows = []
    for tier in LINK_TIERS:
        for s in range(SESSIONS_PER_TIER):
            session_id = f"sess_pipe_{tier['name']}_{s + 1:02d}"
            # Small per-session offset so sessions of one tier are not
            # byte-identical, while staying inside the same RSSI/SNR bin.
            rssi_offset = s * 0.4
            snr_offset = s * 0.2
            seq = 0

            # Round-robin the grid, one packet per configuration per cycle.
            # This mirrors the interleaved sweep that DATA_COLLECTION_PLAN.md
            # section 4a requires of real collection.
            for i in range(PACKETS_PER_CONFIG):
                for (sf, tp) in GRID:
                    success = 1 if i < tier["successes"][(sf, tp)] else 0
                    retry = 0 if success else 3
                    rssi = tier["rssi_base"] + rssi_offset + (seq % 3) * 0.3
                    snr = tier["snr_base"] + snr_offset + (seq % 4) * 0.15
                    ts_s = seq % 60
                    ts_m = (seq // 60) % 60
                    rows.append([
                        f"2026-03-01T{s:02d}:{ts_m:02d}:{ts_s:02d}Z",
                        session_id, DEVICE, seq, sf, f"{tp:g}",
                        f"{rssi:.2f}", f"{snr:.2f}", retry, success,
                        PAYLOAD_BYTES, FREQ_HZ, "SYNTHETIC",
                    ])
                    seq += 1
    return rows


def main():
    rows = build_rows()
    with open(OUTPUT, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(HEADER)
        writer.writerows(rows)
    labellable = sum(1 for t in LINK_TIERS if t["expected"] is not None)
    print(f"Wrote {len(rows)} fabricated rows to {OUTPUT}")
    print(f"  {len(LINK_TIERS)} link tiers x {SESSIONS_PER_TIER} sessions "
          f"= {len(LINK_TIERS) * SESSIONS_PER_TIER} contexts")
    print(f"  {labellable} tiers are labellable; "
          f"{len(LINK_TIERS) - labellable} is deliberately not")
    print("Reminder: test-only data. Never a research result.")


if __name__ == "__main__":
    main()
