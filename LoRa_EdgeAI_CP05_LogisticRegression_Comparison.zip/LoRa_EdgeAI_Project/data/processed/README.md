# data/processed/ — Preprocessed / Feature-Engineered LoRa Data

**Status as of Checkpoint 2: EMPTY.** No real or fabricated data has been
placed here. This folder holds only a `.gitkeep` placeholder and this
README until real raw data exists (see `data/raw/README.md`) and is run
through the preprocessing pipeline.

## What will appear here

Files produced by `ml/preprocessing/pipeline.py` from a corresponding raw
CSV in `data/raw/`:

```
data/processed/<session_id>_processed.csv
```

## Format

Every column from `data/raw/` (see its schema), PLUS the following
engineered "history" feature columns, computed per `(device_id,
session_id)` group ordered by `packet_seq`, for each configured window
size `w` (default windows: 5 and 10 prior packets):

| Column pattern | Description |
|---|---|
| `rolling_success_rate_w{w}` | Fraction of successful packets among the previous `w` packets |
| `rolling_retry_avg_w{w}` | Mean retry count over the previous `w` packets |
| `rolling_rssi_avg_w{w}` | Mean RSSI over the previous `w` packets |
| `rolling_snr_avg_w{w}` | Mean SNR over the previous `w` packets |

These features exist **only using packets strictly before the current
one** (no leakage of the current packet's own outcome into its own history
features). Rows with no prior packets in their group will have `NaN` in
these columns — how to handle that (drop vs. impute) is a decision for the
training checkpoint, not preprocessing.

See `ml/preprocessing/schema.py` (`processed_feature_columns`) for the
machine-readable definition, and
`ml/preprocessing/feature_engineering.py` for the implementation.

## How this data is produced

```bash
python -m ml.preprocessing.pipeline \
    --input data/raw/<session_id>.csv \
    --output data/processed/<session_id>_processed.csv
```
