# data/sample/ — Small Illustrative Data Samples

**Status as of Checkpoint 2: EMPTY.** No real or fabricated data has been
placed here.

## Purpose (future)

Once real data has been collected (`data/raw/`) and processed
(`data/processed/`), this folder is intended to hold a small, clearly
real (not synthetic) excerpt of processed data — e.g. a few hundred rows
from one session — for quick demos, documentation examples, and fast
local testing without needing the full dataset.

## Important distinction from test fixtures

Anything placed here in the future must be genuine data collected from
real hardware (a small excerpt), not synthetic/fabricated data. Synthetic
data used purely to test that the preprocessing code works correctly lives
in `tests/fixtures/` and is clearly labeled there as a test fixture — it
must never be copied into this folder or treated as a project result.
