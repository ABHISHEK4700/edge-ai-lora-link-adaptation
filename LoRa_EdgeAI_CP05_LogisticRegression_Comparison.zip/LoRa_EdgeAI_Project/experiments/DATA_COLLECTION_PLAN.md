# Data Collection Plan

**Status: PLANNING DOCUMENT ONLY.** No data has been collected yet. This
document defines the intended methodology for when real ESP32 + LoRa
hardware data collection begins (a future checkpoint, per
`PROJECT_STATUS.md`). Nothing in this file is a result or a promise of a
specific outcome — it is a plan to be refined once hardware collection
actually starts.

---

## 1. Goal of data collection

Collect real per-transmission LoRa link-quality logs (RSSI, SNR, packet
success/failure, retry count, plus the SF/TP that were actually used) from
a physical ESP32 + LoRa end device across a range of channel conditions,
so that a supervised model can eventually be trained to predict good
(SF, TP) choices from recent link history.

## 2. Planned hardware setup (to be confirmed/updated once assembled)

- ESP32 development board
- LoRa radio module: **SX1278 (433 MHz band)** — confirmed as the planned
  hardware. All example frequencies elsewhere in this project (e.g. the
  synthetic test fixture's `channel_freq_hz`) are kept consistent with this
  433 MHz band so they don't imply a different, incorrect radio band.
- At least one LoRa gateway or a second end device acting as a fixed
  receiver, to generate acknowledgements/RSSI+SNR reports
- A logging path from the ESP32 to a CSV file matching
  `data/raw/README.md` — candidates: serial output captured by a laptop
  script, or on-device SD card logging. Choice TBD in the checkpoint where
  hardware integration begins.

## 3. Planned session structure

Each data collection run is a **session**, identified by a `session_id`
following the convention:

```
sess_<YYYY_MM_DD>_<environment>_<condition>_<run_number>
```

e.g. `sess_2026_10_03_outdoor_lineofsight_01`,
`sess_2026_10_05_indoor_mobile_02`

Within a session, the device transmits packets at a defined cadence (TBD,
e.g. every 5–10 seconds) while sweeping or holding SF/TP according to the
session's test plan, logging one row per transmission attempt per
`data/raw/README.md`.

## 4. Planned channel condition scenarios

To capture the "dynamic channel conditions" the project targets, sessions
are planned across a matrix of conditions such as:

- **Distance:** near / medium / far from the receiver, at fixed points
- **Line-of-sight:** clear line-of-sight vs. obstructed (walls, foliage)
- **Mobility:** static device vs. device moved during the session (e.g.
  carried at walking pace)
- **Interference:** quiet RF environment vs. a known interference source
  present (if safely and legally reproducible)
- **Indoor vs. outdoor**

The exact scenario list, number of sessions per scenario, and session
duration are TBD and should be finalized (and recorded here, replacing
this bullet list) once hardware is available and initial pilot sessions
have been run.

## 4a. Requirements imposed by the labeling strategy (added Checkpoint 3)

Checkpoint 3 designed how SF/TP training labels will be derived (see
`experiments/LABELING_STRATEGY.md`). That design **constrains how data must
be collected**, so these requirements are recorded here rather than only in
the labeling document. They are requirements, not suggestions — data
collected without them cannot be labelled.

**1. Sweep configurations within each channel condition.** The labeler
compares (SF, TP) configurations measured under similar conditions and picks
the best by evidence. If a session holds one configuration throughout, there
is nothing to compare, "best" is vacuous, and the labeler will refuse to
label it (`min_configs_per_context`). Each session must cycle through the
candidate (SF, TP) grid.

**2. Interleave the sweep, do not block it.** Transmit round-robin — one
packet per configuration, repeated — rather than 30 packets at SF7 then 30 at
SF8. If conditions drift during a blocked sweep, the last configuration in
the cycle is measured on a different link than the first, and the sweep order
silently becomes the result.

**3. Collect enough packets per configuration.** The default reliability
estimator is a Wilson lower bound, which discounts thin evidence. At a 100%
observed delivery ratio it equals `n / (n + z²)`, so with the default
`z = 1.645` a configuration needs **at least 25 packets** to clear a 0.90
threshold even if it never dropped one. Budget
*(configurations) × (≥25 packets) × (conditions)* per scenario, and check
that against duty-cycle limits and realistic session durations.

**4. Consider recording an explicit condition identifier per row.** If the
protocol controls conditions directly (fixed measurement points, say),
logging a per-row condition id and using
`context_strategy="explicit_column"` is more reliable than having the labeler
infer contexts from RSSI/SNR bins — RSSI and SNR are partly a consequence of
the configuration in use, which makes bin-based grouping imperfect.

**5. Keep payload size constant within a session.** The labeler holds payload
constant per context so that energy differences reflect SF and TX power
rather than payload. Varying payload mid-session weakens that.

These points interact with the open questions in section 6 — particularly
cadence, session duration and total data volume — which is why those remain
open rather than being answered with invented numbers.

## 5. Labeling reality vs. simulation

Any data ever placed in `data/raw/` must be **real hardware data**. If, in
a future checkpoint, synthetic or simulated data is ever produced for any
reason (e.g. to unblock early model prototyping before enough real data
exists), it must:

- live in a clearly separate location (never `data/raw/` or
  `data/sample/`)
- be labeled unambiguously as synthetic/simulated in its filename, an
  accompanying README, and any code that generates it
- never be described as, or mixed silently with, real research results

This mirrors the same discipline already used for the library sanity-check
numbers in `tests/test_environment.py` (Checkpoint 1) and the test fixture
in `tests/fixtures/` (Checkpoint 2).

## 6. Open questions / decisions for a future checkpoint

- Exact LoRa **breakout board / module vendor** part number (radio chip
  itself now confirmed: SX1278, 433 MHz — see section 2)
- Logging transport (serial capture vs. SD card vs. other)
- Transmission cadence and session duration
- Final list and count of channel-condition scenarios
- How many total sessions / rows constitute "enough" data before training
  is attempted (depends on chosen model complexity, decided later)
- Ethical/legal considerations for any RF interference testing (must
  comply with local spectrum regulations)

Added Checkpoint 3, arising from the labeling strategy:

- The exact **(SF, TP) grid to sweep**. Depends on the final SX1278 breakout
  board's supported power levels AND on the spectrum rules that apply at the
  deployment site. Deliberately not guessed — `candidate_sf_values` and
  `candidate_tp_dbm_values` in the labeling config default to "derive from
  the data" precisely so this stays open.
- The **regional configuration** (band plan, maximum permitted power, duty
  cycle). Recorded in the labeling config's `regulatory_profile` field, which
  is `UNSET` and read by no calculation. No regulatory limit is asserted
  anywhere in this project.
- **Module supply current vs. TX power**, from the datasheet or bench
  measurement. Needed for the physically correct energy model
  (`measured_current_table`). The table ships empty and the method raises
  rather than substituting invented figures.
- The **radio's actual airtime parameters** as set by the ESP32 firmware:
  bandwidth, coding rate, preamble length, explicit/implicit header, CRC,
  low-data-rate optimization. The labeling config carries defaults for these,
  but if they disagree with the firmware every energy comparison is biased.
  Verify once the firmware exists.

**None of these open questions are answered by fabricating plausible-sounding
values.** They remain open until addressed with real planning/hardware in
a later checkpoint.
