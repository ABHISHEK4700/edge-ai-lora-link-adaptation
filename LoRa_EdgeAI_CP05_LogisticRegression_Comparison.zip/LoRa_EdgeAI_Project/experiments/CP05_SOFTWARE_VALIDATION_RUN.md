# Checkpoint 5 — Decision Tree vs. Logistic Regression Software Comparison Report

*This file is a committed record of one Checkpoint 5 pipeline run against
fabricated test-fixture data. It is a lab-notebook entry proving the software
executes for a second model family, not a results section. Reproduce it
with:*

```bash
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv --output <tmp>/proc.csv
python -m ml.labeling.labeler --input <tmp>/proc.csv --output <tmp>/lab.csv
python -m ml.training.train_decision_tree --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.training.train_logistic_regression --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.evaluation.compare_models \
    --dt-model <tmp>/models/decision_tree_sf_tp.joblib \
    --dt-metadata <tmp>/models/decision_tree_sf_tp_metadata.json \
    --lr-model <tmp>/models/logistic_regression_sf_tp.joblib \
    --lr-metadata <tmp>/models/logistic_regression_sf_tp_metadata.json \
    --input <tmp>/lab.csv --report <tmp>/comparison_report.md
```

*The Decision Tree's accuracy figures below are 1.0000, exactly as in the
Checkpoint 4 record. **That is the expected outcome on this fixture and is
not a finding.** The fixture assigns each link tier a distinct RSSI/SNR band
with one correct answer, so it is separable by construction. Logistic
Regression, a linear-in-its-inputs model, does NOT reach 1.0000 on this same
fixture — this is expected too: several of the fixture's link tiers are not
linearly separable in the 8 rolling-history features used here, and a linear
decision boundary cannot carve them apart the way an unconstrained tree can.
**Neither number is evidence about which model is better for real LoRa
channel adaptation.** Read section 4 before quoting anything here.*

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

> Every number below was produced from fabricated test-fixture data, not
> from any LoRa hardware. It demonstrates only that the training and
> evaluation pipeline executes end to end, for a second model family. It is
> NOT evidence that either model works, generalises, or improves packet
> delivery ratio, latency, energy consumption or adaptation speed. No claim
> about real LoRa communication is supported by any of it.

> **This comparison does NOT show that either model is better than the
> other for real LoRa channel adaptation.** Both were scored on the same
> fabricated, trivially-separable-for-a-tree fixture used to validate the
> software pipeline. Any difference between them here reflects how each
> model family fits that particular fixture, not real-world merit.

---

## 1. What was compared

- **Model A:** `DecisionTreeClassifier` (scikit-learn) — Checkpoint 4
- **Model B:** `LogisticRegression` (scikit-learn, multinomial) with
  `StandardScaler`, one per target — Checkpoint 5
- **Input:** `<temp>/lab.csv` (derived from
  `tests/fixtures/synthetic_pipeline_fixture_raw.csv`)
- **Features (identical for both):** `rolling_success_rate_w5`,
  `rolling_success_rate_w10`, `rolling_retry_avg_w5`,
  `rolling_retry_avg_w10`, `rolling_rssi_avg_w5`, `rolling_rssi_avg_w10`,
  `rolling_snr_avg_w5`, `rolling_snr_avg_w10` — the same 8 causal rolling
  features used since Checkpoint 4, carrying RSSI, SNR, packet
  success/failure history and retry count in lagged form. No GPS, distance
  or other experimental metadata.
- **Split:** identical held-out contexts for both models (same
  `test_size=0.3`, `random_state=0`, `context_id`-based split) — 21 train /
  9 test contexts, 0 context overlap.

## 2. Predictive performance on the synthetic fixture

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

| Metric | Decision Tree | Logistic Regression |
|---|---|---|
| SF accuracy | 1.0000 | 0.7778 |
| SF macro F1 | 1.0000 | 0.5833 |
| TX power accuracy | 1.0000 | 0.7778 |
| TX power macro F1 | 1.0000 | 0.7750 |
| Joint exact match | 1.0000 | 0.5556 |
| Per-context joint accuracy | 1.0000 | 0.5556 |
| Test rows scored | 1611 | 1611 |

Neither column being higher than the other is evidence of which model is
better for LoRa. The Decision Tree's perfect score is the expected
consequence of the fixture being separable by construction for a model that
can partition feature space into axis-aligned regions of arbitrary shape.
Logistic Regression's lower score on the same fixture reflects that a
single linear decision boundary per class cannot represent that partition —
this is a property of the fixture and the two model families, not a
statement about which is more suitable for the real, not-yet-collected LoRa
data this project is ultimately about.

## 3. Software-level cost

| Metric | Decision Tree | Logistic Regression |
|---|---|---|
| Training time (s) | 0.004234 | 0.011430 |
| Model file size (KB) | 3.21 | 2.94 |
| Inference time (µs/row) | 0.05 | 0.11 |
| Hyperparameters tuned | False | False |

Training and inference times are desktop, scikit-learn measurements — not
ESP32 figures. Model file size is the desktop joblib serialisation
(including, for Logistic Regression, the fitted `StandardScaler`), not an
embedded footprint. Both models are small enough on the build machine that
neither number should be read as a meaningful cost difference at this
sample size; they are recorded so the *comparison methodology* exists, to
be re-run once real data and a real edge-deployment target exist.

## 4. What this does NOT show

- This comparison does NOT show that either model is better than the other
  for real LoRa channel adaptation.
- This does NOT demonstrate improved packet delivery ratio for either
  model.
- This does NOT demonstrate improved latency for either model.
- This does NOT demonstrate improved energy consumption for either model.
- This does NOT demonstrate faster adaptation than standard ADR for either
  model.
- Neither model is validated for real LoRa communication.
- These metrics are NOT evidence of project success for either candidate.
- The fixture is trivially separable by construction (for a tree), so a
  near-perfect Decision Tree score and a modest Logistic Regression score
  are both expected outcomes here and indicate only that both pipelines ran
  correctly — not that the Decision Tree "won."

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**
