# Checkpoint 4 — Decision Tree Software Validation Report

*This file is a committed record of one Checkpoint 4 pipeline run against
fabricated test-fixture data. It is a lab-notebook entry proving the software
executes, not a results section. Reproduce it with:*

```bash
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv --output <tmp>/proc.csv
python -m ml.labeling.labeler --input <tmp>/proc.csv --output <tmp>/lab.csv
python -m ml.training.train_decision_tree --input <tmp>/lab.csv --outdir ml/models
python -m ml.evaluation.evaluate \
    --model ml/models/decision_tree_sf_tp.joblib --input <tmp>/lab.csv \
    --metadata ml/models/decision_tree_sf_tp_metadata.json --report <tmp>/run.md
```

*The accuracy figures below are 1.0000. **That is the expected outcome and it
is not a finding.** The fixture assigns each link tier a distinct RSSI/SNR
band with one correct answer, so it is separable by construction — any
working classifier scores perfectly. What the run actually demonstrates is
that the eight stages of the pipeline connect, that the context split holds,
and that the model saves and reloads. Read section 6 before quoting anything
here.*

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

> Every number below was produced from fabricated test-fixture data, not from any LoRa hardware. It demonstrates only that the training and evaluation pipeline executes end to end. It is NOT evidence that the model works, generalises, or improves packet delivery ratio, latency, energy consumption or adaptation speed. No claim about real LoRa communication is supported by any of it. The fixture is trivially separable by construction, so a high score here is expected and means nothing beyond 'the code ran'.
>

---

## 1. What was evaluated

- **Model:** `ml/models/decision_tree_sf_tp.joblib (regenerated; not committed)`
- **Input:** `<temp>/synthetic_pipeline_labeled.csv (derived from tests/fixtures/synthetic_pipeline_fixture_raw.csv)`
- **Trained from:** `<temp>/synthetic_pipeline_labeled.csv (derived from tests/fixtures/synthetic_pipeline_fixture_raw.csv)`
- **Scope:** held-out contexts only (split reproduced with the same test_size/random_state used at training time)

## 2. Dataset

| Property | Value |
|---|---|
| Rows in file | 5400 |
| Rows with an evidence-backed label | 5400 |
| Usable rows (history features present) | 5370 |
| Contexts | 30 |
| Features | 8 |
| SF classes | [7.0, 9.0, 12.0] |
| TX power classes | [2.0, 14.0] |

> **Effective sample size is 30, not 5370.** One label covers every row of a context, so rows are not independent samples.

## 3. Split

Split by `context_id`, so no context appears on both sides (verified: 0 overlapping contexts).

| | Contexts | Rows |
|---|---|---|
| Train | 21 | 3759 |
| Test | 9 | 1611 |

## 4. Metrics

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

### 4.1 Spreading Factor

- Accuracy: **1.0000**
- Majority-class baseline: **0.3333** (always predict `7.0`)
- Beats baseline: **True**
- Macro F1: 1.0000 | Weighted F1: 1.0000

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| 7.0 | 1.0000 | 1.0000 | 1.0000 | 537 |
| 9.0 | 1.0000 | 1.0000 | 1.0000 | 358 |
| 12.0 | 1.0000 | 1.0000 | 1.0000 | 716 |

### 4.2 Transmission Power

- Accuracy: **1.0000**
- Majority-class baseline: **0.3333** (always predict `2.0`)
- Beats baseline: **True**
- Macro F1: 1.0000 | Weighted F1: 1.0000

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| 2.0 | 1.0000 | 1.0000 | 1.0000 | 537 |
| 14.0 | 1.0000 | 1.0000 | 1.0000 | 1074 |

### 4.3 Joint and per-context

- Joint exact match (both SF and TX power correct): **1.0000** (1611/1611 rows)
- Per-context majority vote over 9 contexts: SF 1.0000, TX power 1.0000, joint 1.0000

> Per-context figures count each context once rather than once per row, which is closer to the true sample size.

## 5. Model structure

| | SF tree | TX power tree |
|---|---|---|
| Depth | 3 | 3 |
| Nodes | 7 | 7 |
| Leaves | 4 | 4 |
| Features used | 2 | 2 |
| Classes | 3 | 2 |
| Training time (s) | 0.002166 | 0.001981 |

- Model file: **3.22 KB** (3298 bytes, joblib (scikit-learn objects))
- This is the desktop serialisation size, not an ESP32 footprint. Converting the decision logic to something an ESP32 can run is a later checkpoint.
- Inference: **0.06 µs/row** over 1611 rows
- Measured with scikit-learn on the build machine, not on an ESP32. Not an edge-latency figure.

- Tuned: **False** — No hyperparameter search was performed. max_depth and min_samples_leaf were set to small fixed values to keep the trees inspectable and edge-deployable, not because they were found to be optimal.

## 6. What this does NOT show

- Improved packet delivery ratio.
- Improved latency.
- Improved energy consumption.
- Faster adaptation than standard ADR.
- Validation for real LoRa communication.
- Evidence of project success.
- Any property of real hardware, in any respect.

The fixture this was run against is trivially separable by construction: each link tier has a distinct RSSI/SNR band and one correct answer. A near-perfect score is the expected outcome and confirms only that the pipeline is wired together correctly.

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**
