# Target-Label Strategy

**Status: DESIGN DOCUMENT (Checkpoint 3).** No labels have been produced,
because no real data exists yet. Nothing in this file is a result. Every
threshold and default mentioned here is a starting value chosen so the code
is testable, not a validated choice — the validated choices can only be made
once real sessions exist.

---

## 1. The problem in one paragraph

The model's inputs are RSSI, SNR, packet success/failure history and retry
count. Its outputs are Spreading Factor and Transmission Power. That makes
this supervised learning, and supervised learning needs `(features, label)`
pairs. But the raw logs do not contain a label. They contain `sf` and
`tp_dbm` — **the settings the device was told to use**, which is a different
thing from the settings it *should* have used. Somebody has to decide what
"should" means, and that decision has to be grounded in measured evidence
rather than assumption. That decision is what this document specifies.

---

## 2. Why the logged SF/TP columns cannot be the labels

The obvious shortcut is to train on `(features → logged sf, logged tp_dbm)`.
It fails in a way that is easy to miss, because the resulting model still
trains fine and still reports an accuracy figure.

Training on the logged configuration teaches the model to **reproduce
whatever policy generated the logs**:

- If collection ran a **manual sweep** across SF/TP, the logged configuration
  is essentially uncorrelated with channel quality. The model learns to
  predict the sweep schedule — noise — and its accuracy measures how
  predictable the sweep was, not how good its radio decisions are.
- If collection ran **standard ADR**, the model learns to imitate ADR. The
  best achievable outcome is to match ADR's decisions, including its
  mistakes. Since the project's entire premise is that ADR adapts too slowly,
  a model that clones ADR cannot demonstrate the thing the project set out to
  demonstrate.
- If collection used a **fixed configuration**, the label is constant and the
  model learns to output that constant, scoring near 100% accuracy while
  having learned nothing.

In all three cases the model is doing *behavioural cloning of an arbitrary
policy*. None of them produce evidence that the predicted configuration is
good. So the label has to be **derived from measured outcomes**, not copied
from a settings column.

---

## 3. The strategy: retrospective best-configuration labeling

The core idea is to use hindsight. During collection we cannot know the best
configuration in advance — but afterwards, for a set of packets that
experienced similar channel conditions, we can look at what each
configuration *actually achieved* and pick the winner from measurement.

Concretely, the label for a set of similar conditions is:

> Among the configurations that were **actually measured** under these
> conditions, the one with the **lowest energy cost** among those whose
> **measured reliability** cleared a configured threshold.

This gives the model a target that is defensible in the project report: the
ground truth is measured, not assumed. The model is then a compact,
ESP32-deployable approximation of a measured oracle — it learns to predict,
from link history alone, the configuration that hindsight showed was best.

The choice encodes the engineering objective directly: **be reliable enough,
then be as cheap as possible.** Reliability is a constraint to satisfy;
energy is the thing to minimise subject to it. That ordering is a design
decision, and `cost_basis` lets it be softened — `per_success_pdr` folds
reliability back into the cost so that energy spent on undelivered packets
counts against a configuration.

### 3.1 The five steps

1. **Group packets into contexts.** A context is a set of packets believed to
   have experienced roughly the same channel conditions. (`context.py`)
2. **Aggregate measured evidence per configuration.** For each
   (context, SF, TP): how many packets, how many delivered, mean retries.
   (`oracle.py` → the oracle table)
3. **Estimate reliability with its uncertainty.** Finite samples, so a
   confidence-aware estimator by default. (`reliability.py`)
4. **Compute energy cost.** Analytic time-on-air × a power model, normalised
   by the configured cost basis. (`airtime.py`, `energy.py`)
5. **Select and flag.** Cheapest configuration clearing the threshold, with
   configured tie-breaking; or a configured fallback, recorded in
   `label_status`. (`oracle.py`)

---

## 4. What this demands of data collection

This is the part that matters most, because it constrains work that has not
happened yet. **The labeling strategy is only valid if the data collection
protocol makes it valid.**

### 4.1 Sweep configurations within each channel condition

If a context contains only one measured configuration, then "the best
configuration in this context" is vacuously that configuration. It is not
evidence of optimality, and a label derived from it would be a fabrication
dressed up as a measurement.

So each session must **cycle through the candidate (SF, TP) grid** while the
channel conditions are held approximately constant, rather than holding one
configuration for the whole session. `min_configs_per_context` (default 2,
and it should be raised well above that) enforces this: contexts that fail it
are flagged `insufficient_config_coverage` and are not silently labelled.

### 4.2 Sweep fast relative to how fast conditions change

A sweep only compares configurations fairly if conditions did not change
underneath it. If the device is walking away from the gateway while the sweep
runs, the last configuration in the cycle is measured on a worse link than
the first, and the comparison is confounded — the sweep order becomes the
result.

Practical implication: interleave configurations (round-robin, one packet
each, repeated) rather than blocking (30 packets at SF7, then 30 at SF8).
Round-robin spreads any drift evenly across all configurations instead of
concentrating it in whichever came last. The exact cadence has to be worked
out against the real device's transmission rate.

### 4.3 Enough packets per configuration

Reliability is estimated from a finite sample. The default Wilson lower bound
makes this explicit: at a 100% observed delivery ratio the estimate is
`n / (n + z²)`, so with `z = 1.645` a configuration needs **at least 25
packets** to clear a 0.90 threshold even if it never dropped a single packet.
A configuration measured 5 times cannot earn a label.

With a full grid this multiplies quickly: *(configurations) × (packets each) ×
(conditions)*. Sizing that budget against the duty-cycle limits and session
durations is an open item for the data collection checkpoint — deliberately
not guessed here.

### 4.4 Record enough to reconstruct the context

The Checkpoint 2 raw schema already carries what the default context strategy
needs (`device_id`, `session_id`, `rssi_dbm`, `snr_db`). If the collection
protocol ends up controlling conditions explicitly (fixed measurement points,
say), recording a per-row condition identifier and using
`context_strategy="explicit_column"` is cleaner than inferring contexts from
RSSI/SNR bins.

---

## 5. The context definition is the biggest judgement call

Everything above rests on "packets that experienced similar conditions". Get
that wrong and the labels are wrong in a way that no amount of model tuning
will fix:

- **Too coarse** — configurations measured under genuinely different
  conditions get compared. The winner reflects *when* each configuration
  happened to be measured, not which is better.
- **Too fine** — each context holds too few configurations, everything fails
  the coverage guard, and almost nothing gets labelled.

There is no way to choose correctly without real data, so the strategy is
configurable (`session`, `rssi_snr_bin`, `session_rssi_snr_bin`,
`explicit_column`) and the active choice is recorded in the run summary.

**A known circularity worth stating plainly:** RSSI and SNR are partly a
*consequence* of the configuration in use, not purely a description of the
channel. Higher TX power raises RSSI; higher SF improves demodulation below
the noise floor. So binning by RSSI/SNR does not carve the world into
perfectly configuration-neutral slices. The default
`session_rssi_snr_bin` is a compromise — it never pools across sessions,
which limits the damage — but this is a real limitation, not a solved
problem, and it should be re-examined against real data.

---

## 6. Handling "nothing worked"

Some contexts will have no configuration that clears the threshold — that is
what a genuinely bad link looks like. Four policies are available
(`no_valid_config_policy`), and the choice is a real trade-off:

- **`drop`** (default) emits nothing. Never invents an unsupported target.
  The cost: the model sees no examples of bad conditions, and at deployment
  it will meet them anyway.
- **`most_reliable`** labels with the best measured configuration despite it
  being below threshold, flagged `below_threshold_fallback`. Keeps the hard
  cases, at the price of a label that means "least bad" rather than "good".
- **`max_robustness`** falls back to highest SF then highest TP, flagged
  `max_robustness_fallback`. This mirrors what a conventional stack does when
  a link degrades, but it is a **heuristic, not measured evidence** — the
  fixture's own context B shows why that distinction matters, since the more
  robust configuration there is also the one burning far more energy for a
  link that still fails most of the time.
- **`error`** stops the run. Useful in CI to catch a collection session that
  failed to sweep properly.

Whatever is chosen, `label_status` records it per row, so a later checkpoint
can filter, down-weight, or report on fallback labels rather than treating
them as equivalent to evidence-backed ones.

---

## 7. Known limitations of this strategy

Stated up front so they end up in the report rather than being discovered
during evaluation.

1. **Self-inclusion in the aggregate.** A packet's label comes from statistics
   over its whole context, including that packet. Strictly this is a mild
   form of leakage. The practical mitigation is to **split train/test by
   `context_id`** (`GroupKFold` / `GroupShuffleSplit`), so no context appears
   on both sides. A leave-one-out variant is possible but was not implemented,
   since removing one packet from a ≥25-packet aggregate changes it slightly
   while re-running selection per row is expensive.
2. **The oracle is only as good as the sweep.** The framework can never select
   a configuration that was not measured. A grid that omits the genuinely
   optimal setting yields labels that are optimal-within-what-was-tried, and
   nothing in the pipeline can detect that.
3. **Energy model fidelity.** The default `airtime_x_linear_power` ignores PA
   efficiency and the module's fixed baseline current, which exaggerates the
   saving from lowering TX power and biases labels toward low power.
   `measured_current_table` fixes this but needs real datasheet or bench
   numbers, which do not exist yet.
4. **Airtime parameters must match firmware.** Bandwidth, coding rate,
   preamble length and header/CRC settings are configured, not measured. If
   they disagree with what the ESP32 actually sets on the radio, every airtime
   figure is scaled wrongly and every energy comparison is biased. Verify
   before trusting any output.
5. **Time-varying conditions inside a context.** Section 4.2's confounding
   risk is mitigated by protocol design (round-robin sweeping), not by
   anything in the code. The code cannot detect that a sweep was blocked
   rather than interleaved.
6. **Class imbalance is likely.** If most contexts are easy links, one
   configuration will dominate the labels and the model can score well by
   always predicting it. Whatever evaluation a later checkpoint uses must
   report per-class performance, not just overall accuracy.
7. **Unvalidated defaults.** `min_reliability=0.90`, the bin widths, the
   coverage guards — all are placeholders chosen to make the code testable,
   in the same spirit as the placeholder rolling-window sizes from
   Checkpoint 2. They are not recommendations.

---

## 8. Alternatives considered and rejected

| Approach | Why not |
|---|---|
| Use the logged `sf` / `tp_dbm` directly | Behavioural cloning of an arbitrary policy — section 2. |
| Hand-write an expert rule table (e.g. SNR thresholds → SF) | The model would then just learn the rule table. Any "performance" would be a property of the table, and the ML contributes nothing. |
| Copy SF/SNR thresholds from a published LoRa paper | Those thresholds belong to that paper's hardware, band and environment. Importing them and presenting the result as this project's finding would be fabricating evidence. |
| Derive labels from a propagation simulator | Labels would describe the simulator's assumptions, not the real channel. Contradicts the project's decision to use real hardware data. |
| Reinforcement learning on the live link | Genuinely appropriate for this problem, but requires online interaction with the radio, not the offline logged dataset this project collects, and is far beyond the ESP32 deployment scope. Worth naming in the report as future work. |

---

## 9. What Checkpoint 3 does NOT do

- **No model is trained.** No architecture chosen, no training code, no
  accuracy figures.
- **No real data is labelled**, because none exists.
- **No SF/TP ranges are locked in.** `candidate_sf_values` and
  `candidate_tp_dbm_values` default to "derive from the data", pending the
  finalized SX1278 board and regional configuration.
- **No hardware energy figures are invented.** The supply-current table ships
  empty and the method that needs it raises rather than guessing.
- **No research results, benchmarks, or performance numbers are produced.**
  The only numbers any of this code has produced are arithmetic over the
  clearly-labelled synthetic fixture in `tests/fixtures/`, used solely to
  prove the code runs correctly.
