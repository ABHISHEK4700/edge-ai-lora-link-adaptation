# CHANGELOG

All notable changes to this project are recorded here, grouped by
checkpoint. This project follows a checkpoint-based workflow rather than
date-based releases, since it is developed incrementally as part of a
3rd-year ECE final year project.

---

## Checkpoint 1 — Project Foundation / Software Scaffolding

**Scope:** Establish the initial project structure and documentation only.
No ML model, no data, no ESP32 code.

### Added
- Full project directory structure:
  - `data/raw/`, `data/processed/`, `data/sample/`
  - `ml/preprocessing/`, `ml/training/`, `ml/evaluation/`, `ml/models/`, `ml/export/`
  - `experiments/`
  - `esp32/`
  - `tests/`
- `.gitkeep` placeholder files in every empty directory to preserve
  structure through zip/git operations
- `README.md` — project overview, structure, setup, and run instructions
- `PROJECT_STATUS.md` — detailed status tracking, design decisions, known
  issues, next checkpoint plan, and explicit continuation instructions for
  a new AI assistant session
- `CHANGELOG.md` — this file
- `requirements.txt` — minimal dependency list (`numpy`, `pandas`,
  `scikit-learn`) needed only to verify the Python ML environment at this
  stage
- `tests/test_environment.py` — minimal script verifying Python version and
  that `numpy`, `pandas`, and `scikit-learn` import and function correctly
  via a trivial, clearly-labeled sanity check (not project research data)

### Explicitly NOT done (by design, per checkpoint scope)
- No LoRa data collected or simulated
- No preprocessing, training, or evaluation code
- No trained model or exported model artifacts
- No ESP32 firmware or inference code
- No performance/research results of any kind

### Verification
- Ran `python3 tests/test_environment.py` in the build environment — all
  checks passed, exit code 0.
- Manually reviewed folder structure against the required layout — matches.

### Deliverable
- `LoRa_EdgeAI_CP01_Project_Setup.zip` — complete, self-contained project
  folder as of the end of Checkpoint 1.

---

## Checkpoint 2 — Data Schema, Preprocessing Pipeline & Data Collection Plan

**Scope:** Define the raw/processed data schema, implement the
preprocessing pipeline, and document the data collection methodology.
Still no real or fabricated LoRa measurement data, no model, no ESP32
code. All Checkpoint 1 deliverables preserved.

### Decision point
Before starting, the user was asked how RSSI/SNR/packet-outcome/retry-count
data would be obtained (real hardware later, a synthetic generator, or an
existing public dataset). The user chose: **real ESP32+LoRa hardware,
collected later — build the pipeline now against a defined schema, with no
data yet.** This shaped the entire checkpoint's scope.

### Added
- `ml/preprocessing/schema.py` — machine-readable `RAW_SCHEMA` (raw CSV
  column contract: `timestamp_utc`, `session_id`, `device_id`,
  `packet_seq`, `sf`, `tp_dbm`, `rssi_dbm`, `snr_db`, `retry_count`,
  `packet_success`, optional `payload_bytes`/`channel_freq_hz`/`notes`)
  and `processed_feature_columns()` for the engineered feature names
- `ml/preprocessing/clean.py` — `load_raw_csv()` and `validate_schema()`,
  which validate required columns, dtypes, valid ranges, and allowed
  values, dropping and reporting invalid rows rather than silently
  keeping them
- `ml/preprocessing/feature_engineering.py` — `add_rolling_features()`,
  computing rolling success-rate/retry/RSSI/SNR history features (windows
  of 5 and 10 packets by default) per `(device_id, session_id)`, with no
  leakage of a packet's own outcome into its own history
- `ml/preprocessing/pipeline.py` — `run_pipeline()` plus a CLI
  (`python -m ml.preprocessing.pipeline --input ... --output ...`) tying
  cleaning and feature engineering together
- `ml/__init__.py`, `ml/preprocessing/__init__.py` — package markers
- `data/raw/README.md` — human-readable raw data schema documentation
- `data/processed/README.md` — human-readable processed data documentation
- `data/sample/README.md` — clarifies this folder is for real data
  excerpts only, never synthetic data
- `experiments/DATA_COLLECTION_PLAN.md` — planned hardware setup, session
  naming convention, planned channel-condition scenarios, and explicit
  open questions (not invented answers)
- `tests/fixtures/synthetic_test_fixture_raw.csv` — a small, clearly
  fabricated CSV (12 rows, 3 deliberately invalid) used only to test the
  pipeline's logic
- `tests/fixtures/README.md` — explains the fixture is synthetic
  test-only data, never a research result
- `tests/test_preprocessing.py` — verifies schema validation, rolling
  feature correctness (including no self-leakage), full-pipeline
  execution (writing to a temp dir only), and that `data/raw/`,
  `data/processed/`, `data/sample/` are left untouched by the test run

### Changed
- `README.md` — added Checkpoint 2 run instructions and updated the
  project structure diagram
- `PROJECT_STATUS.md` — updated to reflect Checkpoint 2 while preserving
  the full Checkpoint 1 record (nothing from Checkpoint 1 was deleted,
  only appended to / reorganized under clear per-checkpoint headings)
- `requirements.txt` — comment updated to note Checkpoint 2 needed no new
  dependencies; package list unchanged (`numpy`, `pandas`, `scikit-learn`)

### Explicitly NOT done (by design, per checkpoint scope)
- No real or synthetic-but-passed-off-as-real LoRa data was collected or
  added to `data/raw/`, `data/processed/`, or `data/sample/`
- No label-construction strategy for training targets (deferred to
  Checkpoint 3 / a modeling decision)
- No model architecture, training code, or evaluation code
- No ESP32 firmware or inference code
- No research results, benchmarks, or performance numbers of any kind

### Verification
- Ran `python3 tests/test_preprocessing.py` — all checks passed, exit
  code 0 (schema validation kept 9/12 fixture rows and dropped exactly the
  3 deliberately-invalid ones with correct reasons; rolling features
  matched hand-computed expected values with no self-leakage; full
  pipeline ran end-to-end to a temp directory; real `data/` folders
  confirmed untouched).
- Ran the pipeline CLI directly against the fixture — output columns and
  drop reasons matched expectations.
- Ran the pipeline CLI against a nonexistent input file — failed cleanly
  with exit code 1, a clear error message, and no output file created.
- Re-ran `python3 tests/test_environment.py` — still passes unmodified,
  confirming Checkpoint 1 was preserved.

### Deliverable
- `LoRa_EdgeAI_CP02_Data_Pipeline.zip` — complete, self-contained project
  folder as of the end of Checkpoint 2 (includes everything from
  Checkpoint 1 plus everything listed above).

---

## Checkpoint 2 — Correction Pass

**Scope:** Three corrections requested by the user after reviewing
Checkpoint 2, applied before Checkpoint 3 began. No preprocessing logic
(`clean.py`, `feature_engineering.py`, `pipeline.py`) was changed — only
documentation, one schema field description, the synthetic fixture's
frequency value, and `requirements.txt`.

### Fixed
1. **`numpy` requirement/verification mismatch.** `requirements.txt`
   pinned `numpy>=1.24,<2.0`, but a prior verification run had numpy 2.3.5
   installed — declared requirement and verified environment didn't
   match. Root cause: an earlier ad hoc `pip install` (no version pins)
   bypassed `requirements.txt` during testing. Fix: widened the pin to
   `numpy>=1.24,<3.0` after confirming — in a clean virtual environment,
   both with `requirements.txt`'s own pinned resolution (numpy 1.26.4)
   and with numpy explicitly upgraded to 2.3.5 — that both
   `tests/test_environment.py` and `tests/test_preprocessing.py` pass
   completely in either case.
2. **Synthetic fixture frequency corrected.**
   `tests/fixtures/synthetic_test_fixture_raw.csv` used
   `channel_freq_hz = 915000000` (915 MHz) in every row, which doesn't
   match the project's planned hardware (SX1278, 433 MHz band) and could
   have misled a reader about the real target band. All 12 rows updated
   to `433000000` (433 MHz). The fixture remains entirely synthetic —
   only the frequency number was aligned to the real hardware plan, not
   the data itself. `tests/fixtures/README.md`,
   `experiments/DATA_COLLECTION_PLAN.md`, `README.md`, `data/raw/README.md`,
   and `ml/preprocessing/schema.py` (the `channel_freq_hz` field
   description) all updated to consistently reference the confirmed
   SX1278 433 MHz hardware instead of a generic/placeholder module.

### Explicitly NOT done (by design, per user instruction)
- **Target-label construction strategy was not decided.** How a
  "correct" SF/TP training label is derived from real logged history
  remains open and deferred to Checkpoint 3, exactly as before this
  correction pass.
- No preprocessing logic changed; no new data added anywhere.

### Verification
- Re-ran `tests/test_environment.py` and `tests/test_preprocessing.py`
  under three separate dependency combinations, all passing with exit
  code 0:
  1. System Python environment (numpy 2.4.4 / pandas 3.0.2 / scikit-learn 1.8.0)
  2. A clean venv installed strictly from `requirements.txt`
     (numpy 1.26.4 / pandas 2.3.3 / scikit-learn 1.9.1)
  3. The same clean venv with numpy explicitly upgraded to 2.3.5
     (matching the version originally reported as mismatched)
- Confirmed schema validation still keeps 9/12 fixture rows and drops the
  same 3 deliberately-invalid rows (the frequency change doesn't affect
  validation or rolling-feature logic, since `channel_freq_hz` isn't used
  in either).
- Grepped the full project for stray `915` / `SX1276` / `SX1262`
  references after the edits — none remain.

### Deliverable
- `LoRa_EdgeAI_CP02_Data_Pipeline_v2.zip` — complete, self-contained
  project folder including all Checkpoint 1 and Checkpoint 2 deliverables
  plus this correction pass.

---

## Checkpoint 3 — Target-Label Strategy & Labeling Framework

**Scope:** Decide and implement how a "correct" (SF, TP) training target is
derived from measured link evidence — the question explicitly deferred
through Checkpoints 1 and 2. Still no real or fabricated LoRa measurement
data, no model trained, no ESP32 code. All Checkpoint 1 and Checkpoint 2
deliverables preserved; no preprocessing logic file was modified.

### The design decision

The raw logs contain `sf` and `tp_dbm` — the settings the device was *told*
to use, which is not the same as the settings it *should* have used.
Training on them would be behavioural cloning of whatever policy generated
the logs: imitating ADR (defeating the project's premise), learning a sweep
schedule (noise), or learning a constant. Labels are therefore **derived from
measured outcomes** instead, via **retrospective best-configuration
labeling**: within each channel context, choose the lowest-energy
configuration whose measured reliability cleared a configured threshold.
Full argument in `experiments/LABELING_STRATEGY.md`.

### Added

- `experiments/LABELING_STRATEGY.md` — the design document: problem
  statement, why logged SF/TP fails as a label, the five-step strategy, the
  requirements it imposes on data collection, the context-definition
  judgement call and its circularity, no-valid-configuration handling, seven
  named limitations, and five alternatives considered and rejected
- `ml/labeling/config.py` — `LabelingConfig`, the single source of truth for
  every knob, with validation and JSON round-tripping
- `ml/labeling/context.py` — four channel-context strategies (`session`,
  `rssi_snr_bin`, `session_rssi_snr_bin`, `explicit_column`)
- `ml/labeling/reliability.py` — point estimate and Wilson score lower bound
- `ml/labeling/airtime.py` — the published LoRa time-on-air formula, with all
  radio parameters configurable rather than assumed
- `ml/labeling/energy.py` — three pluggable energy methods and three cost
  bases
- `ml/labeling/oracle.py` — `build_oracle_table()` and `select_labels()`,
  including the evidence-sufficiency guards, configurable tie-breaking and
  no-valid-configuration handling
- `ml/labeling/labeler.py` — `run_labeling()`, `attach_labels()`, and a CLI
  with `--config`, `--print-config`, `--write-default-config`
- `ml/labeling/__init__.py` — package marker and public API surface
- `ml/labeling/labeling_config.example.json` — generated from the code
  defaults so it cannot drift out of sync
- `ml/labeling/README.md` — documents every configurable knob, including the
  train/test splitting requirement
- `tests/fixtures/make_synthetic_labeling_fixture.py` — deterministic
  generator (no RNG, no seed) for the labeling fixture
- `tests/fixtures/synthetic_labeling_fixture_raw.csv` — 210 fabricated rows
  across three sessions, each exercising a different code path: a proper
  sweep, a context where nothing clears the threshold, and a context with no
  sweep at all
- `tests/test_labeling.py` — 19 checks covering all six required configurable
  items plus the airtime formula, reliability estimators, energy models,
  context assignment, evidence guards, full pipeline, config round-trip, and
  data-directory non-pollution

### Changed

- `experiments/DATA_COLLECTION_PLAN.md` — added section 4a recording the five
  requirements the labeling strategy imposes on collection (sweep
  configurations within each condition; interleave rather than block the
  sweep; ≥25 packets per configuration; consider an explicit condition id;
  keep payload constant per session), plus four new open questions in
  section 6 (the SF/TP grid, the regional configuration, the supply-current
  table, and the firmware's actual airtime parameters)
- `tests/fixtures/README.md` — documents the new fixture and its generator
- `README.md` — Checkpoint 3 status, structure diagram, run instructions, and
  a renumbered roadmap (model training is now Checkpoint 4)
- `PROJECT_STATUS.md` — updated throughout while preserving the full
  Checkpoint 1 and 2 record
- `requirements.txt` — unchanged. No new dependencies were needed; the Wilson
  bound was implemented from its closed form rather than adding scipy

### Explicitly NOT done (by design, per checkpoint scope)

- **No model was trained.** No architecture chosen, no training code,
  `ml/training/` still empty
- **No research results.** No accuracy, latency or energy-saving figure
  appears anywhere as a finding
- **No real hardware data invented.** `data/` untouched; the supply-current
  table ships empty and `measured_current_table` raises rather than guessing,
  and also refuses to extrapolate beyond a supplied table's range
- **No SF/TP ranges locked in.** `candidate_sf_values` and
  `candidate_tp_dbm_values` default to `None` = derive from the data, pending
  the final SX1278 board and regional configuration. A test asserts the
  shipped example config leaves them unset
- **No regulatory limits asserted.** `regulatory_profile` is `UNSET` and read
  by no calculation
- Synthetic data used only to test that the labeling software works, confined
  to `tests/fixtures/`, labelled synthetic in its filename, generator and
  README

### Verification

- Ran `python3 tests/test_labeling.py` — all 19 checks passed, exit code 0.
  Among the things confirmed: the time-on-air formula's symbol time doubles
  per SF step and scales inversely with bandwidth; the Wilson bound equals
  exactly `n / (n + z²)` at a 100% delivery ratio; `measured_current_table`
  refuses an empty table and refuses to extrapolate; in the fixture's context
  A the cheapest configuration overall is the one that *fails* the
  reliability threshold and is correctly rejected in favour of the cheapest
  one that passed; changing the threshold, candidate sets, energy method or
  tie-break rules each changes the output; all four no-valid-configuration
  policies behave distinctly; a single-configuration context is refused a
  label and relaxing `min_configs_per_context` is confirmed to be what
  unblocks it; tie-breaking is order-independent.
- Ran the labeling CLI against the fixture — produced the labeled CSV plus
  the `_oracle.csv` and `_labels.csv` sidecars, with context A labelled,
  context B dropped for failing the threshold, and context C dropped for
  insufficient configuration coverage.
- Ran the labeling CLI against a nonexistent input — failed cleanly with exit
  code 1 and no output file created.
- Re-ran `python3 tests/test_environment.py` and
  `python3 tests/test_preprocessing.py` — both still pass unmodified,
  confirming Checkpoints 1 and 2 were preserved.

### Deliverable

- `LoRa_EdgeAI_CP03_Labeling_Framework.zip` — complete, self-contained
  project folder including all Checkpoint 1 and Checkpoint 2 deliverables
  plus everything listed above.

---

## Checkpoint 4 — Decision Tree Training/Evaluation Pipeline

> ### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> This checkpoint ran against **fabricated test-fixture data only**. It shows
> that the pipeline executes. It does NOT show improved packet delivery
> ratio, latency, energy consumption or adaptation speed, and the model is
> NOT validated for real LoRa communication. The fixture is trivially
> separable by construction, so its near-perfect scores are expected and are
> not evidence of anything.

**Scope:** Build and verify the first end-to-end training and evaluation
pipeline. Still no real LoRa data, no research model, no ESP32 code. All
Checkpoint 1, 2 and 3 deliverables preserved; no earlier logic file was
modified.

```
sample CSV -> preprocessing (CP2) -> label generation (CP3)
           -> context-aware train/test split -> Decision Tree
           -> prediction -> evaluation -> save model -> metadata report
```

### Why a second fixture was needed

Checkpoint 3's fixture produces exactly one labelled context carrying one
(SF, TP) pair — correct for testing the labeling framework, but a classifier
cannot be trained on a single class and a split needs more than one group.
Checkpoint 4 added a larger fixture alongside it; the Checkpoint 3 fixture is
untouched and still used by `tests/test_labeling.py`.

### Added

- `ml/training/dataset.py` — feature assembly, the `BANNED_FEATURE_COLUMNS`
  leakage guard, context-aware splitting via `GroupShuffleSplit`, and a
  summary that reports rows *and* contexts so the effective sample size is
  visible
- `ml/training/train_decision_tree.py` — trains two `DecisionTreeClassifier`s
  (one per target), records tree depth, node count, leaf count, features
  used, training time, model file size and inference time, saves a joblib
  bundle, and writes a metadata JSON
- `ml/evaluation/metrics.py` — `SYNTHETIC_BANNER`, per-class
  precision/recall/F1, confusion matrices, majority-class baselines, joint
  exact-match, and per-context majority-vote scoring
- `ml/evaluation/evaluate.py` — loads a saved bundle, evaluates it
  standalone, and renders a banner-stamped Markdown report
- `ml/training/__init__.py`, `ml/evaluation/__init__.py`
- `ml/training/README.md` — the causality and splitting rules
- `ml/models/README.md` — why no model artifact is committed
- `tests/fixtures/make_synthetic_pipeline_fixture.py` — deterministic
  generator (no RNG, no seed)
- `tests/fixtures/synthetic_pipeline_fixture_raw.csv` — 6,480 fabricated rows,
  6 link tiers x 6 sessions = 36 contexts, configurations interleaved
  round-robin; 30 contexts labellable across 5 joint (SF, TP) classes, the
  sixth tier deliberately unlabellable
- `tests/test_training.py` — 17 checks
- `experiments/CP04_SOFTWARE_VALIDATION_RUN.md` — committed record of one
  pipeline run, whose preamble states that its 1.0000 accuracy is the
  expected outcome and not a finding

### Changed

- `requirements.txt` — added `joblib>=1.2,<2.0`. scikit-learn already depends
  on it, but the training and evaluation scripts now import it directly, so
  it is declared rather than relied on transitively
- `README.md` — Checkpoint 4 status, banner, structure diagram, run
  instructions, renumbered roadmap
- `PROJECT_STATUS.md` — new section 2.1 stating CP01/CP02/CP03/CP04 complete,
  real hardware data not collected, final research model not trained; plus
  the usual per-checkpoint updates throughout

### Design decisions

- **Two trees, not one multi-output tree.** Small independently inspectable
  decision functions suit the eventual ESP32 port and give per-target
  structure metrics. Trade-off: two independent trees can emit a combination
  never seen in training, which joint exact-match exposes.
- **Causality enforced in code.** The current row's `packet_success`,
  `retry_count`, `sf` and `tp_dbm` are banned as features and the guard
  raises at both entry points, because the device must choose before
  transmitting. The current row's `rssi_dbm`/`snr_db` are off by default
  (row *i*'s RSSI is measured *during* transmission *i*).
- **Accuracy never stands alone.** Every accuracy is reported next to a
  majority-class baseline and a per-context score.
- **No model artifact committed.** `ml/models/` ships empty; a stale
  synthetic-trained model in the repo is exactly what later gets mistaken
  for a real one.

### Explicitly NOT done (by design, per checkpoint scope)

- **No Logistic Regression and no Random Forest.** Only
  `DecisionTreeClassifier` appears anywhere in the codebase.
- **No heavy optimization.** No hyperparameter search, no pruning sweep, no
  class weighting. `tuned: False` is a metadata field asserted by a test.
- **No research claims.** No PDR, latency, energy or adaptation claim is
  made; each is disclaimed by name and a test asserts each appears in the
  generated report.
- **No GPS, distance or other contextual ML features.** A test scans the
  feature list for such tokens and fails if any appear.
- **No new labels invented.** Targets come from the Checkpoint 3 framework.
- **No real data collected or fabricated into `data/`.**

### Verification

- Ran `python3 tests/test_training.py` — all 17 checks passed, exit code 0.
  Among the things confirmed: all 14 banned columns refused at both entry
  points; the default feature set represents all four project inputs with no
  contextual variables; the context split leaves zero overlap where a naive
  row split on the same data would have leaked all 30 contexts; splitting
  refuses fewer than two contexts; depth/nodes/leaves/size/training
  time/inference time all recorded; a saved model reloads and predicts
  identically and an invalid bundle is refused; joint accuracy never exceeds
  either individual accuracy and an all-wrong predictor scores 0.0; the
  report carries the banner three times and disclaims each claim by name; a
  fixed `random_state` reproduces split, structure and metrics; `data/` and
  `ml/models/` left clean.
- Ran the full chain (preprocessing → labeling → training → evaluation)
  against the fixture — 36 contexts found, 30 labelled, 6 correctly refused;
  21/9 context split; both trees depth 3, 7 nodes, 4 leaves; 3.22 KB bundle.
- Re-ran `tests/test_environment.py`, `tests/test_preprocessing.py` and
  `tests/test_labeling.py` — all still pass unmodified, confirming
  Checkpoints 1–3 were preserved.

### Deliverable

- `LoRa_EdgeAI_CP04_DecisionTree_SoftwareValidation.zip` — complete,
  self-contained project folder including all Checkpoint 1, 2 and 3
  deliverables plus everything listed above.

---

## Checkpoint 5 — Logistic Regression & Decision Tree Comparison

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.**
> Everything below ran against the same fabricated fixture data as
> Checkpoint 4.

Requested explicitly by the user: add Logistic Regression as a second
lightweight ML candidate, using the identical dataset, preprocessing,
feature set and (SF, TP) target framework as the Checkpoint 4 Decision
Tree, and compare the two on software-level metrics. This redefines what
was previously placeholder Checkpoint 5 ("Real Hardware Data Collection" —
see the prior version of this section and `PROJECT_STATUS.md`); that work
is renumbered to Checkpoint 6 and remains not started.

### Added

- `ml/training/train_logistic_regression.py` — trains two
  `sklearn.Pipeline(StandardScaler, LogisticRegression)` models, one per
  target (SF, TP), on the exact same `build_dataset()` /
  `context_aware_split()` output the Decision Tree trainer uses. Saves a
  joblib bundle (`logistic_regression_sf_tp.joblib`) and a metadata JSON
  (`logistic_regression_sf_tp_metadata.json`) recording solver, iteration
  count, a `converged` flag, per-class coefficients, model file size,
  training time, inference time, and the same evaluation metrics block
  (via the unchanged `ml/evaluation/metrics.py`) as the tree.
- `ml/evaluation/compare_models.py` — loads a Decision Tree bundle+metadata
  pair and a Logistic Regression bundle+metadata pair, evaluates both on an
  **identical** held-out split (same input file, `test_size`,
  `random_state`), and writes a side-by-side Markdown/JSON comparison
  report: predictive metrics, model file size, training time, inference
  time. Refuses to compare bundles trained on different feature sets
  (`ValueError`, not a silent mismatched comparison).
- `experiments/CP05_SOFTWARE_VALIDATION_RUN.md` — a committed record of one
  comparison run, with a preamble explaining why the Decision Tree scores
  1.0000 and Logistic Regression does not on this same fixture, and why
  neither number is a finding.
- `tests/test_logistic_regression.py` — 13 checks covering the Logistic
  Regression trainer, the comparison module, and cross-checks that shared
  Checkpoint 4 code (`dataset.py`, `metrics.py`, `evaluate.py`) needed no
  modification to support a second model family.

### Design decisions worth knowing

35. **Same dataset, same features, same targets — only the model family
    changes.** `train_logistic_regression.py` imports `build_dataset()`,
    `context_aware_split()`, `describe_split()`, `load_labeled_frame()` and
    `resolve_feature_columns()` from the unmodified `ml/training/dataset.py`
    used by the Decision Tree trainer, so there is exactly one leakage
    guard, one feature set, and one splitting discipline for both models to
    drift out of sync with.
36. **Scaling is fit on the training split only.** Logistic Regression's
    gradient-based solver and L2 penalty are scale-sensitive in a way a
    tree's axis-aligned splits are not. Each target's model is a single
    `sklearn.Pipeline` of `(StandardScaler, LogisticRegression)` so a saved
    bundle scales and predicts as one unit, and the scaler's mean/variance
    are computed from training-split rows only — computing them from the
    full dataset before splitting would leak test-split statistics into
    training, which is exactly the class of leakage `context_aware_split()`
    exists to prevent.
37. **Convergence is recorded, not assumed.** `max_iter` is set generously
    (2000) purely so the solver reliably converges on this small fixture; a
    `ConvergenceWarning` is caught and both the warning text and a
    `converged: bool` field land in the metadata rather than being silently
    swallowed or left to print to stderr.
38. **`ml/evaluation/evaluate.py` needed no changes.** Its `evaluate()`
    function only calls `bundle["sf_model"].predict(...)` /
    `bundle["tp_model"].predict(...)` and reads `bundle["feature_columns"]`
    — it never assumes a Decision Tree specifically, so a Logistic
    Regression bundle plugs into it unmodified. `render_markdown_report()`
    is Decision-Tree-specific in its "model structure" section, so
    Checkpoint 5 instead added a separate `compare_models.py` report
    renderer rather than overloading that function with a second, unrelated
    metadata shape.
39. **No superiority claim, structurally enforced.** Every report
    `compare_models.py` generates carries `NO_SUPERIORITY_CLAIM` — the same
    discipline as the `SYNTHETIC_BANNER` in `metrics.py` — and a test
    asserts it, plus every other required disclaimer, is present by name.
40. **A mismatched-feature comparison is refused, not silently run.** If
    someone compares a Decision Tree bundle against a Logistic Regression
    bundle trained with `--include-current-link` (different feature list),
    `compare()` raises `ValueError` rather than producing a comparison where
    the two models were not actually shown the same inputs.
41. **No Random Forest, and no research claims.** Only
    `DecisionTreeClassifier` and `LogisticRegression` appear anywhere in the
    codebase. `tuned: False` is recorded for Logistic Regression exactly as
    it is for the tree; no hyperparameter search was performed. No PDR,
    latency, energy or adaptation claim is made for either model; each is
    disclaimed by name and a test asserts each appears in the generated
    comparison report.

### Preserved unchanged

No file from Checkpoints 1-4 had its logic modified. All of
`ml/preprocessing/`, all of `ml/labeling/`, `ml/training/dataset.py`,
`ml/training/train_decision_tree.py`, `ml/evaluation/metrics.py`,
`ml/evaluation/evaluate.py`, `test_environment.py`, `test_preprocessing.py`,
`test_labeling.py`, `test_training.py`, and all three earlier fixtures are
byte-identical to their Checkpoint 4 state. `ml/training/__init__.py`,
`ml/evaluation/__init__.py`, `ml/training/README.md` and
`ml/models/README.md` had only their docstrings/prose extended to mention
the new modules — no functional code in them changed.

### Verification

- Ran `python3 tests/test_logistic_regression.py` — all 13 checks passed,
  exit code 0. Among the things confirmed: the Logistic Regression trainer
  uses the identical 8-feature set as the Decision Tree; both target models
  are `(StandardScaler, LogisticRegression)` pipelines that converged on the
  fixture; the saved bundle reloads via the unmodified
  `ml/evaluation/evaluate.load_bundle()` and predicts identically;
  `ml/evaluation/evaluate.evaluate()` (unmodified) scores an LR bundle
  correctly; `compare_models.compare()` scores both models on an identical
  1,611-row held-out set and refuses a mismatched-feature comparison; the
  comparison report carries the banner 3 times plus the no-superiority claim
  and every required disclaimer; a fixed `random_state` reproduces the LR
  split, structure and metrics; the saved bundle contains no banned
  feature; `data/` and `ml/models/` left clean.
- Ran the full chain (preprocessing → labeling → training [both models] →
  comparison) against the fixture — Decision Tree: SF/TP accuracy 1.0000,
  joint 1.0000 (unchanged from Checkpoint 4). Logistic Regression: SF
  accuracy 0.7778, TP accuracy 0.7778, joint 0.5556 — lower than the tree on
  this fixture, as expected for a linear model on a fixture separable only
  by axis-aligned regions; neither number is a research result or a
  superiority claim. Decision Tree bundle 3.21 KB / 0.004s train / 0.05
  µs/row inference; Logistic Regression bundle 2.94 KB / 0.011s train / 0.11
  µs/row inference — all desktop, scikit-learn figures, not ESP32 figures.
- Re-ran `tests/test_environment.py`, `tests/test_preprocessing.py`,
  `tests/test_labeling.py` and `tests/test_training.py` — all still pass
  unmodified, confirming Checkpoints 1-4 were preserved.

### Deliverable

- `LoRa_EdgeAI_CP05_LogisticRegression_Comparison.zip` — complete,
  self-contained project folder including all Checkpoint 1-4 deliverables
  plus everything listed above.

---

## Checkpoint 6 — (not started)

Placeholder: **Real Hardware Data Collection**. Everything downstream is
blocked on it — the software path is complete end to end but has never seen
a real link. See `PROJECT_STATUS.md` section 8. Random Forest and any
further model comparisons were explicitly deferred and should not be
started without a request; they are also premature before real data exists.
Do not fill in this section until Checkpoint 6 work is actually performed.
