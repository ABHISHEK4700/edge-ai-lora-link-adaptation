# CHANGELOG

All notable changes to this project are recorded here, grouped by
checkpoint. This project follows a checkpoint-based workflow rather than
date-based releases, since it is developed incrementally as part of a
3rd-year ECE final year project.

---

## Checkpoint 1 — Project Foundation / Software Scaffolding

**Scope:** Establish the initial project structure and documentation only.
No ML model, no data, no ESP32 code.

### Added
- Full project directory structure:
  - `data/raw/`, `data/processed/`, `data/sample/`
  - `ml/preprocessing/`, `ml/training/`, `ml/evaluation/`, `ml/models/`, `ml/export/`
  - `experiments/`
  - `esp32/`
  - `tests/`
- `.gitkeep` placeholder files in every empty directory to preserve
  structure through zip/git operations
- `README.md` — project overview, structure, setup, and run instructions
- `PROJECT_STATUS.md` — detailed status tracking, design decisions, known
  issues, next checkpoint plan, and explicit continuation instructions for
  a new AI assistant session
- `CHANGELOG.md` — this file
- `requirements.txt` — minimal dependency list (`numpy`, `pandas`,
  `scikit-learn`) needed only to verify the Python ML environment at this
  stage
- `tests/test_environment.py` — minimal script verifying Python version and
  that `numpy`, `pandas`, and `scikit-learn` import and function correctly
  via a trivial, clearly-labeled sanity check (not project research data)

### Explicitly NOT done (by design, per checkpoint scope)
- No LoRa data collected or simulated
- No preprocessing, training, or evaluation code
- No trained model or exported model artifacts
- No ESP32 firmware or inference code
- No performance/research results of any kind

### Verification
- Ran `python3 tests/test_environment.py` in the build environment — all
  checks passed, exit code 0.
- Manually reviewed folder structure against the required layout — matches.

### Deliverable
- `LoRa_EdgeAI_CP01_Project_Setup.zip` — complete, self-contained project
  folder as of the end of Checkpoint 1.

---

## Checkpoint 2 — (not started)

Placeholder for the next checkpoint. See `PROJECT_STATUS.md`, section 8
("Next Checkpoint") for proposed scope. Do not fill in this section until
Checkpoint 2 work is actually performed.
