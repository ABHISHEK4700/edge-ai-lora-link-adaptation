# PROJECT STATUS

Last updated: Checkpoint 1
This file is the single source of truth for project state. Read this file
fully before doing any new work, especially if you are a new AI assistant
session with no memory of prior conversations.

---

## 1. Project Objective

Build a **lightweight, edge-deployable machine learning system** that
predicts good **Spreading Factor (SF)** and **Transmission Power (TP)**
settings for a LoRa end device, using:

- RSSI
- SNR
- packet success/failure history
- retry count

as input features, so the device can adapt faster to dynamic channel
conditions (fading, interference, mobility, distance changes) than static
configuration or standard ADR. The trained model is ultimately meant to run
**locally on an ESP32** microcontroller paired with a LoRa radio module.

This is a 3rd-year ECE final year project, developed in checkpoints. Each
checkpoint is reviewed before the next one begins.

---

## 2. Current Checkpoint

**Checkpoint 1 — Project Foundation / Software Scaffolding**

This checkpoint establishes the project's folder structure, documentation,
dependency list, and a minimal environment-verification test. It explicitly
does **not** include any model, data, or ESP32 code.

---

## 3. Completed Work (Checkpoint 1)

- [x] Created the full project directory structure:
  `data/{raw,processed,sample}`, `ml/{preprocessing,training,evaluation,models,export}`,
  `experiments/`, `esp32/`, `tests/`
- [x] Added `.gitkeep` placeholders in every currently-empty directory so the
  structure survives zipping/uploading/cloning
- [x] Wrote `README.md` — project description, structure, setup, and run
  instructions
- [x] Wrote `PROJECT_STATUS.md` (this file)
- [x] Wrote `CHANGELOG.md` recording Checkpoint 1
- [x] Wrote `requirements.txt` with only the dependencies needed to verify
  the environment at this stage (numpy, pandas, scikit-learn)
- [x] Wrote `tests/test_environment.py`, a minimal script that verifies:
  - Python version
  - `numpy` import + basic array operation
  - `pandas` import + basic DataFrame operation
  - `scikit-learn` import + fitting a trivial model on synthetic
    placeholder numbers (explicitly labeled as a library sanity check, NOT
    project research data)
- [x] Verified the test script runs successfully in the build environment
  (see "Verification performed" below)

### Verification performed during this checkpoint
The following was run in the build sandbox to confirm the deliverables are
internally consistent (this is a software/environment check, not a research
result):
```
python3 tests/test_environment.py
```
Result: all checks passed, exit code 0. (You should re-run this yourself
after downloading, since your local Python/library versions may differ.)

---

## 4. Incomplete Work (intentionally NOT done yet)

These are out of scope for Checkpoint 1 and must NOT be started until the
corresponding future checkpoint is explicitly requested:

- [ ] No data has been collected. `data/raw/`, `data/processed/`, and
  `data/sample/` are empty (only `.gitkeep` placeholders).
- [ ] No data collection methodology has been finalized (e.g. what LoRa
  hardware, what environments, how many samples, logging format).
- [ ] No preprocessing / feature engineering code exists in
  `ml/preprocessing/`.
- [ ] No model architecture has been chosen or implemented.
  No training code exists in `ml/training/`.
- [ ] No evaluation metrics/code exist in `ml/evaluation/`.
- [ ] No trained model files exist in `ml/models/`.
- [ ] No export/quantization (e.g. TFLite Micro conversion) code exists in
  `ml/export/`.
- [ ] No ESP32 firmware or on-device inference code exists in `esp32/`.
- [ ] No experiment configs/logs exist in `experiments/`.
- [ ] No research results, benchmarks, or performance numbers exist
  anywhere in the project. **Any numbers describing accuracy, latency,
  energy savings, etc. that appear anywhere in this repo before real data
  is collected and a real model is trained would be fabricated and must
  not be added.**

---

## 5. Current Architecture

At this checkpoint the "architecture" is purely the folder/documentation
scaffolding described in `README.md`, section 3. There is no software
architecture (no data pipeline, no model architecture, no inference
pipeline) yet. This section will be filled in with real architecture
diagrams/descriptions starting at the checkpoint where preprocessing and
model work begins.

---

## 6. Important Design Decisions (Checkpoint 1)

1. **No placeholder/synthetic "research" data was created.** The user
   explicitly required that no fake data be presented as research results.
   The only synthetic numbers in the repo are inside
   `tests/test_environment.py`, and they are clearly scoped as a library
   sanity check (verifying scikit-learn can fit a trivial model), not as
   LoRa research data. This distinction is documented in the script itself.
2. **Dependencies kept minimal for this stage.** `requirements.txt` only
   includes `numpy`, `pandas`, and `scikit-learn` — the minimum needed to
   verify the Python ML environment. Deep learning frameworks (e.g.
   TensorFlow/TFLite, PyTorch) and ESP32-related tooling are intentionally
   **not** included yet, since model design hasn't started and adding heavy
   dependencies now would misrepresent project progress. They should be
   added in the checkpoint where they're actually needed.
3. **Folder structure mirrors the eventual ML lifecycle**
   (preprocessing → training → evaluation → models → export) plus separate
   top-level areas for `data/`, `experiments/`, and `esp32/`, so future
   checkpoints have an obvious place to put new work without restructuring.
4. **`.gitkeep` files** are used to preserve empty directories through
   zip/git operations, since git and some zip tools drop empty folders.
5. **Documentation-first approach.** Because the user may continue this
   project in a different AI assistant session (token limits), this
   checkpoint prioritizes writing thorough, self-contained documentation
   (`README.md`, this file, `CHANGELOG.md`) over any code, so that project
   intent and state are never lost.

---

## 7. Known Issues / Limitations

- No real hardware (ESP32 + LoRa module) has been used or tested yet — all
  hardware integration is future work.
- No dataset exists, so there is no way yet to validate that the chosen
  features (RSSI, SNR, success/failure history, retry count) are sufficient
  or well-scaled for the eventual model.
- The exact ML approach (e.g. decision tree, small neural net, gradient
  boosted trees) has not been chosen and should be decided based on what is
  feasible to run on an ESP32 (memory/compute constraints), not chosen
  arbitrarily.
- `requirements.txt` will need additions later (e.g. `matplotlib` for
  evaluation plots, `tensorflow`/`tflite-runtime` or a micro-ML framework
  for export, `pyserial` for ESP32 communication) — do not add these until
  the checkpoint that needs them, to keep each checkpoint's scope honest.

---

## 8. Next Checkpoint

**Checkpoint 2 (proposed, not started): Data Collection Strategy & Preprocessing Pipeline**

Expected scope (to be confirmed with the project supervisor/user before
starting):
- Define how RSSI, SNR, packet success/failure, and retry count will be
  logged (real hardware logs, testbed, or documented simulation — must be
  clearly labeled as to its real/simulated nature)
- Build a preprocessing pipeline in `ml/preprocessing/` to clean and
  structure that data into `data/processed/`
- Add any newly-needed dependencies to `requirements.txt`
- Update `PROJECT_STATUS.md` and `CHANGELOG.md` accordingly

**Do not start Checkpoint 2 work until explicitly instructed.**

---

## 9. Instructions for a New Claude Account/Session to Continue This Project

If you are a new Claude session picking up this project (e.g. the user
uploaded this project folder because a previous session ran out of tokens),
follow this exact process:

1. **Read this entire file (`PROJECT_STATUS.md`) first**, then skim
   `README.md` and `CHANGELOG.md`.
2. **Do not assume any work exists beyond what section 3 ("Completed Work")
   of this file lists.** Verify by actually inspecting the folder structure
   and file contents rather than trusting summaries alone.
3. **Do not fabricate or backfill research data, results, or benchmarks**
   for any checkpoint, past or future. If the user asks for results that
   don't exist yet, say so plainly instead of inventing plausible-looking
   numbers.
4. **Only work on the checkpoint the user explicitly asks for.** Check
   section 8 ("Next Checkpoint") for what is expected next, but confirm
   with the user before assuming that's what they want right now — they
   may want to revise Checkpoint 1, ask questions, or jump to something
   else.
5. **Preserve this checkpoint discipline going forward:** after finishing
   whatever checkpoint you're asked to do, update `PROJECT_STATUS.md` (all
   relevant sections, especially Completed/Incomplete/Next Checkpoint) and
   append an entry to `CHANGELOG.md`, then stop and wait for explicit
   instruction before continuing to the next checkpoint — mirroring how
   Checkpoint 1 was handled.
6. **Keep the project portable.** At the end of any checkpoint, offer to
   package the complete, current project folder as a downloadable zip
   (naming convention: `LoRa_EdgeAI_CP<NN>_<short-description>.zip`), so the
   user can continue in a fresh session if needed.
7. **When in doubt about scope, ask the user rather than guessing** —
   especially before adding new dependencies, choosing a model architecture,
   or claiming something is "done."
