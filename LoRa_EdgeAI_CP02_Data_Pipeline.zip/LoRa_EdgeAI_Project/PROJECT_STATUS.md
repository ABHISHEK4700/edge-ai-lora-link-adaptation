# PROJECT STATUS

Last updated: Checkpoint 2
This file is the single source of truth for project state. Read this file
fully before doing any new work, especially if you are a new AI assistant
session with no memory of prior conversations.

---

## 1. Project Objective

Build a **lightweight, edge-deployable machine learning system** that
predicts good **Spreading Factor (SF)** and **Transmission Power (TP)**
settings for a LoRa end device, using:

- RSSI
- SNR
- packet success/failure history
- retry count

as input features, so the device can adapt faster to dynamic channel
conditions (fading, interference, mobility, distance changes) than static
configuration or standard ADR. The trained model is ultimately meant to run
**locally on an ESP32** microcontroller paired with a LoRa radio module.

This is a 3rd-year ECE final year project, developed in checkpoints. Each
checkpoint is reviewed before the next one begins.

---

## 2. Current Checkpoint

**Checkpoint 2 — Data Schema, Preprocessing Pipeline & Data Collection Plan**

This checkpoint defines the raw/processed data schema, implements the
preprocessing pipeline (cleaning + rolling history feature engineering),
and documents the data collection methodology. It explicitly does **not**
include any real or fabricated LoRa measurement data, model training code,
trained model, or ESP32 code. Checkpoint 1's deliverables (project
scaffolding, environment test) are preserved unchanged except where noted
below.

---

## 3. Completed Work

### Checkpoint 1 — Project Foundation / Software Scaffolding

- [x] Created the full project directory structure:
  `data/{raw,processed,sample}`, `ml/{preprocessing,training,evaluation,models,export}`,
  `experiments/`, `esp32/`, `tests/`
- [x] Added `.gitkeep` placeholders in every currently-empty directory so the
  structure survives zipping/uploading/cloning
- [x] Wrote `README.md` — project description, structure, setup, and run
  instructions
- [x] Wrote `PROJECT_STATUS.md` (this file)
- [x] Wrote `CHANGELOG.md` recording Checkpoint 1
- [x] Wrote `requirements.txt` with only the dependencies needed to verify
  the environment at this stage (numpy, pandas, scikit-learn)
- [x] Wrote `tests/test_environment.py`, a minimal script that verifies:
  - Python version
  - `numpy` import + basic array operation
  - `pandas` import + basic DataFrame operation
  - `scikit-learn` import + fitting a trivial model on synthetic
    placeholder numbers (explicitly labeled as a library sanity check, NOT
    project research data)
- [x] Verified the test script runs successfully in the build environment
  (see "Verification performed" below)

### Verification performed during Checkpoint 1
```
python3 tests/test_environment.py
```
Result: all checks passed, exit code 0.

### Checkpoint 2 — Data Schema, Preprocessing Pipeline & Data Collection Plan

- [x] **Data source decision confirmed with user**: real ESP32+LoRa
  hardware data will be collected later; this checkpoint builds the
  pipeline against a defined schema with no data yet (user chose this
  explicitly over a synthetic-data-generator or public-dataset approach
  when asked).
- [x] Defined the raw data schema (`ml/preprocessing/schema.py`,
  `RAW_SCHEMA`) — the exact CSV column contract that future ESP32 logging
  must produce: `timestamp_utc`, `session_id`, `device_id`, `packet_seq`,
  `sf`, `tp_dbm`, `rssi_dbm`, `snr_db`, `retry_count`, `packet_success`,
  plus optional `payload_bytes`, `channel_freq_hz`, `notes`. Each field has
  a type and, where applicable, a valid range or allowed-value set.
- [x] Documented the schema in human-readable form in `data/raw/README.md`.
- [x] Defined the processed-data schema addition (rolling history features)
  in `ml/preprocessing/schema.py` (`processed_feature_columns`) and
  `data/processed/README.md`.
- [x] Implemented the preprocessing pipeline in `ml/preprocessing/`:
  - `clean.py` — loads a raw CSV and validates it against `RAW_SCHEMA`,
    dropping and reporting (not silently keeping) rows with missing
    required fields, out-of-range values, or disallowed values.
  - `feature_engineering.py` — computes rolling "history" features
    (success rate, retry avg, RSSI avg, SNR avg) over the preceding N
    packets (N = 5 and 10 by default) per `(device_id, session_id)`,
    strictly excluding each packet's own outcome from its own history
    (no leakage).
  - `pipeline.py` — orchestrates clean → feature-engineer → write, with a
    CLI (`python -m ml.preprocessing.pipeline --input ... --output ...`)
    and a `run_pipeline()` function for reuse.
- [x] Wrote `experiments/DATA_COLLECTION_PLAN.md` — the data collection
  methodology: planned hardware setup, session naming convention, planned
  channel-condition scenarios (distance, line-of-sight, mobility,
  interference, indoor/outdoor), and explicit open questions that are
  **not** answered with invented values.
- [x] Added `tests/fixtures/synthetic_test_fixture_raw.csv` — a small,
  deliberately-labeled **synthetic** CSV (12 rows, 3 deliberately invalid)
  used only to test the pipeline code, plus `tests/fixtures/README.md`
  explaining this distinction clearly.
- [x] Wrote `tests/test_preprocessing.py` — verifies schema validation
  correctness, rolling feature correctness (including no self-leakage),
  and that the full pipeline runs end-to-end, all against the synthetic
  fixture only, writing outputs to a temp directory (never touching
  `data/processed/`). Also asserts `data/raw/`, `data/processed/`,
  `data/sample/` remain untouched by the test run.
- [x] Updated `README.md` with Checkpoint 2 structure and run instructions.
- [x] Reviewed `requirements.txt` — no new dependencies were needed
  (pandas/numpy, already present, are sufficient for the pipeline).

### Verification performed during Checkpoint 2
```
python3 tests/test_preprocessing.py
python -m ml.preprocessing.pipeline --input tests/fixtures/synthetic_test_fixture_raw.csv --output <temp path>
python -m ml.preprocessing.pipeline --input data/raw/does_not_exist.csv --output <temp path>   # error-path check
python3 tests/test_environment.py   # re-run to confirm Checkpoint 1 still passes unmodified
```
Results: all checks passed (exit code 0); the pipeline correctly kept 9/12
rows and dropped 3 deliberately-invalid rows from the fixture with
accurate drop reasons; the missing-file case failed cleanly with exit code
1 and no output file created; Checkpoint 1's environment test still passes
unmodified.

---

## 4. Incomplete Work (intentionally NOT done yet)

Carried over from Checkpoint 1 (still true) unless noted otherwise:

- [ ] No data has been collected. `data/raw/`, `data/processed/`, and
  `data/sample/` remain empty except for the README.md files added this
  checkpoint (and `.gitkeep` placeholders).
- [x] ~~No data collection methodology has been finalized~~ → **Partially
  addressed**: `experiments/DATA_COLLECTION_PLAN.md` now documents the
  intended methodology, but several concrete details (exact hardware part
  numbers, logging transport, cadence, final scenario count) remain open
  questions listed in that document — they are not invented.
- [x] ~~No preprocessing / feature engineering code exists~~ → **Done this
  checkpoint** (`ml/preprocessing/`).
- [ ] No model architecture has been chosen or implemented. No training
  code exists in `ml/training/`.
- [ ] No evaluation metrics/code exist in `ml/evaluation/`.
- [ ] No trained model files exist in `ml/models/`.
- [ ] No export/quantization (e.g. TFLite Micro conversion) code exists in
  `ml/export/`.
- [ ] No ESP32 firmware or on-device inference code exists in `esp32/`.
- [ ] No label-construction strategy has been decided (i.e. how to derive
  a "correct" SF/TP training label from logged history — this is a
  training-checkpoint decision, deliberately out of scope for
  preprocessing).
- [ ] No research results, benchmarks, or performance numbers exist
  anywhere in the project. **Any numbers describing accuracy, latency,
  energy savings, etc. that appear anywhere in this repo before real data
  is collected and a real model is trained would be fabricated and must
  not be added.** (The rolling-window mean values computed by the
  pipeline in tests are arithmetic checks on synthetic fixture data, not
  research results — see `tests/fixtures/README.md`.)

---

## 5. Current Architecture

### Checkpoint 1
Purely folder/documentation scaffolding — no software architecture.

### Checkpoint 2 — Preprocessing pipeline architecture

```
data/raw/<session>.csv                (future: real ESP32 logs; schema in ml/preprocessing/schema.py)
        │
        ▼
ml/preprocessing/clean.py             load_raw_csv() + validate_schema()
        │   - checks required columns present
        │   - coerces dtypes
        │   - drops + reports rows with missing/out-of-range/disallowed values
        ▼
ml/preprocessing/feature_engineering.py   add_rolling_features()
        │   - groups by (device_id, session_id), orders by packet_seq
        │   - computes rolling mean of packet_success / retry_count /
        │     rssi_dbm / snr_db over the preceding W packets (W=5,10)
        │   - shifts by 1 so a packet's own outcome never leaks into its
        │     own history features
        ▼
ml/preprocessing/pipeline.py          run_pipeline() / CLI
        │   - ties the above together
        │   - writes processed CSV to data/processed/
        ▼
data/processed/<session>_processed.csv   (future: once real raw data exists)
```

Tested end-to-end against `tests/fixtures/synthetic_test_fixture_raw.csv`
(synthetic, code-testing only) via `tests/test_preprocessing.py`. No real
data has passed through this pipeline yet, since none exists.

---

## 6. Important Design Decisions

### Checkpoint 1
1. **No placeholder/synthetic "research" data was created.** The only
   synthetic numbers in the repo were inside `tests/test_environment.py`,
   clearly scoped as a library sanity check, not LoRa research data.
2. **Dependencies kept minimal for this stage** (`numpy`, `pandas`,
   `scikit-learn` only).
3. **Folder structure mirrors the eventual ML lifecycle.**
4. **`.gitkeep` files** preserve empty directories through zip/git.
5. **Documentation-first approach** to survive session/token limits.

### Checkpoint 2
6. **Data source decision was asked, not assumed.** Given the significant
   fork between "build against a schema" vs. "build a synthetic generator"
   vs. "ingest a public dataset," the user was asked explicitly rather than
   guessed. Answer: real ESP32 hardware later; build the pipeline + schema
   now. This shaped every decision below.
7. **Schema-first pipeline design.** `ml/preprocessing/schema.py` is the
   single source of truth for both the raw CSV contract and the processed
   output contract, so `clean.py`/`feature_engineering.py`/`pipeline.py`
   and the human-readable READMEs all derive from (or are checked against)
   one place, avoiding drift between documentation and code.
8. **Validation drops and reports, never silently accepts, bad rows.**
   `clean.validate_schema()` returns both the cleaned DataFrame and a
   `ValidationReport` explaining exactly what was dropped and why. This
   was chosen over silently coercing/imputing bad values, since silent
   coercion could hide real hardware/logging bugs once data collection
   begins.
9. **Rolling history features exclude the current packet's own outcome**
   (via `shift(1)` before the rolling window). This was a deliberate
   choice to avoid label/feature leakage: a future model must predict
   SF/TP from *past* history, not from information only available after
   the fact.
10. **Default rolling window sizes (5 and 10) are placeholders**, not a
    validated hyperparameter choice — flagged explicitly in
    `feature_engineering.py` and section 7 below as something to revisit
    once real data and a chosen model architecture exist.
11. **Synthetic test fixture kept strictly separate from `data/`.** Per
    the same discipline as Checkpoint 1's design decision #1, the fixture
    used to test the pipeline lives only in `tests/fixtures/`, is
    explicitly labeled synthetic in its filename and README, and
    `tests/test_preprocessing.py` actively asserts that running it never
    writes anything into `data/raw/`, `data/processed/`, or `data/sample/`.
12. **Label-construction strategy deliberately deferred.** Deciding *how*
    to turn logged history into a "correct SF/TP" training label is a
    modeling decision, not a preprocessing one, and was left out of this
    checkpoint's scope — see section 4.
13. **No new dependencies added.** The pipeline only needed pandas (and
    its numpy dependency), both already present from Checkpoint 1, so
    `requirements.txt` content is unchanged (only its comment was updated).

---

## 7. Known Issues / Limitations

Carried over from Checkpoint 1 (still true):
- No real hardware (ESP32 + LoRa module) has been used or tested yet.
- The exact ML approach has not been chosen.
- `requirements.txt` will need additions later (matplotlib, TensorFlow/TFLite
  or similar, pyserial, etc.) — do not add until actually needed.

New in Checkpoint 2:
- The rolling window sizes (5, 10 packets) are placeholder defaults, not
  validated against real data or a chosen model — may need to change once
  real sessions and a model architecture exist.
- `tp_dbm` and `rssi_dbm` valid ranges in `schema.py` are reasonable
  generic LoRa-module estimates, not yet confirmed against the specific
  hardware that will eventually be used (part numbers not yet chosen —
  see `experiments/DATA_COLLECTION_PLAN.md` open questions). Ranges should
  be revisited once hardware is selected, or a real value could get
  incorrectly rejected/dropped by validation.
- No label-construction strategy exists yet for turning history into a
  training target — required before Checkpoint 3 (training) can begin.
- The preprocessing pipeline has only ever been run against synthetic
  fixture data (12 rows). Its behavior on much larger, messier real data
  (e.g. multi-session files, clock skew, missing sensor readings mid-session)
  is unverified and should be re-checked once real data exists.

---

## 8. Next Checkpoint

**Checkpoint 3 (proposed, not started): Baseline Model Training & Evaluation**

Expected scope (to be confirmed with the user before starting):
- Decide the label-construction strategy (how to derive an SF/TP training
  target from logged history) — flagged as open in section 4/6 above
- Requires real processed data in `data/processed/` to exist first (i.e.
  Checkpoint 3 may itself be blocked on actual data collection happening —
  this should be discussed with the user, not assumed)
- Choose a baseline model approach appropriate for eventual ESP32
  deployment (lightweight — e.g. decision tree / small linear model /
  small neural net — not decided yet)
- Implement training code in `ml/training/` and evaluation code/metrics in
  `ml/evaluation/`
- Add any newly-needed dependencies to `requirements.txt`
- Update `PROJECT_STATUS.md` and `CHANGELOG.md` accordingly

**Do not start Checkpoint 3 work until explicitly instructed.** Given that
Checkpoint 3 likely depends on real data existing, also confirm with the
user whether data collection needs to happen first, or whether Checkpoint
3 should proceed on a placeholder/small pilot dataset the user provides.

---

## 9. Instructions for a New Claude Account/Session to Continue This Project

If you are a new Claude session picking up this project (e.g. the user
uploaded this project folder because a previous session ran out of tokens),
follow this exact process:

1. **Read this entire file (`PROJECT_STATUS.md`) first**, then skim
   `README.md` and `CHANGELOG.md`.
2. **Do not assume any work exists beyond what section 3 ("Completed Work")
   of this file lists.** Verify by actually inspecting the folder structure
   and file contents rather than trusting summaries alone.
3. **Do not fabricate or backfill research data, results, or benchmarks**
   for any checkpoint, past or future. If the user asks for results that
   don't exist yet, say so plainly instead of inventing plausible-looking
   numbers.
4. **Only work on the checkpoint the user explicitly asks for.** Check
   section 8 ("Next Checkpoint") for what is expected next, but confirm
   with the user before assuming that's what they want right now — they
   may want to revise Checkpoint 1, ask questions, or jump to something
   else.
5. **Preserve this checkpoint discipline going forward:** after finishing
   whatever checkpoint you're asked to do, update `PROJECT_STATUS.md` (all
   relevant sections, especially Completed/Incomplete/Next Checkpoint) and
   append an entry to `CHANGELOG.md`, then stop and wait for explicit
   instruction before continuing to the next checkpoint — mirroring how
   Checkpoint 1 was handled.
6. **Keep the project portable.** At the end of any checkpoint, offer to
   package the complete, current project folder as a downloadable zip
   (naming convention: `LoRa_EdgeAI_CP<NN>_<short-description>.zip`), so the
   user can continue in a fresh session if needed. Checkpoint 1 produced
   `LoRa_EdgeAI_CP01_Project_Setup.zip`; Checkpoint 2 produced
   `LoRa_EdgeAI_CP02_Data_Pipeline.zip`.
7. **When in doubt about scope, ask the user rather than guessing** —
   especially before adding new dependencies, choosing a model architecture,
   or claiming something is "done." (Checkpoint 2 did this: it asked the
   user, via a single clarifying question, whether data would come from
   real hardware, a synthetic generator, or a public dataset, before
   building anything — see section 6, decision 6.)
8. **Before starting Checkpoint 3**, note that it likely depends on real
   processed data existing (see section 8). Confirm with the user how they
   want to proceed rather than assuming a data source.
