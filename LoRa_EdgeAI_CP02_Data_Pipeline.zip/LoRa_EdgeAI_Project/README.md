# Lightweight Edge-AI Based Adaptive Spreading Factor and Transmission Power Optimization for LoRa End Devices Under Dynamic Channel Conditions

**Type:** 3rd-Year ECE Final Year Project
**Status:** Checkpoint 1 — Project Foundation (software scaffolding only, no trained model yet)

---

## 1. Project Overview

LoRa (Long Range) end devices must choose two key radio parameters for every
transmission:

- **Spreading Factor (SF)** — trades data rate for range/robustness (SF7–SF12)
- **Transmission Power (TP)** — trades energy consumption for link reliability

Today, most LoRa/LoRaWAN deployments pick these using static configuration or
the standard **ADR (Adaptive Data Rate)** algorithm, which reacts slowly and
does not use short-term contextual information well.

This project explores whether a **lightweight, edge-deployable machine
learning model** can learn to predict a good (SF, TP) pair directly on the
end device, using recent link-quality history, so that the device adapts
faster and more efficiently to changing channel conditions (fading, mobility,
interference, distance changes) than static/ADR approaches.

### Inputs (features) the model will eventually use
- **RSSI** (Received Signal Strength Indicator)
- **SNR** (Signal-to-Noise Ratio)
- **Packet success/failure history** (recent delivery outcomes)
- **Retry count** (how many retransmissions were needed)

### Outputs (targets) the model will eventually predict
- **Spreading Factor (SF)** — classification, one of SF7–SF12
- **Transmission Power (TP)** — classification or regression over the
  device's allowed power levels

### Target deployment
The final trained model is intended to run **locally on an ESP32**
(paired with a LoRa radio module, e.g. SX1276/SX1262) as a lightweight
on-device inference engine (e.g. via TensorFlow Lite Micro or a hand-rolled
decision function), so the device can make SF/TP decisions without relying
on a network server.

---

## 2. Current Scope — Checkpoint 1 ONLY

**This checkpoint does NOT contain:**
- A trained ML model
- Any collected or fabricated experimental/research data
- ESP32 firmware or on-device inference code
- Preprocessing, training, or evaluation logic

**This checkpoint DOES contain:**
- The full project folder/directory scaffolding
- Documentation describing the project, its status, and its plan
- A `requirements.txt` with only the dependencies needed to verify the
  Python environment at this stage
- A minimal test script that checks the Python environment and confirms
  the required ML libraries import and function correctly
- Clear setup/run instructions so the environment can be verified before
  any real work (data collection, preprocessing, model design) begins

See `PROJECT_STATUS.md` for the detailed project status and `CHANGELOG.md`
for a record of what was done in this checkpoint.

---

## 3. Project Structure

```
LoRa_EdgeAI_Project/
├── README.md              # This file
├── PROJECT_STATUS.md       # Detailed status, decisions, and continuation notes
├── CHANGELOG.md            # Checkpoint-by-checkpoint change log
├── requirements.txt         # Python dependencies for the current checkpoint
├── data/
│   ├── raw/                # Raw LoRa link-quality data — schema defined, no real data yet
│   ├── processed/          # Cleaned/feature-engineered data — no real data yet
│   └── sample/             # Small illustrative samples, once real data exists (empty for now)
├── ml/
│   ├── preprocessing/      # Data cleaning & feature engineering pipeline (implemented, Checkpoint 2)
│   │   ├── schema.py             # Raw/processed data schema definitions
│   │   ├── clean.py              # Raw CSV loading + validation
│   │   ├── feature_engineering.py # Rolling "history" feature computation
│   │   └── pipeline.py           # CLI entry point tying it all together
│   ├── training/           # Model training scripts (not started)
│   ├── evaluation/         # Model evaluation/metrics scripts (not started)
│   ├── models/             # Saved trained models (not started)
│   └── export/             # Model export (e.g. TFLite conversion) for ESP32 (not started)
├── experiments/
│   └── DATA_COLLECTION_PLAN.md # Data collection methodology (planning doc, Checkpoint 2)
├── esp32/                  # ESP32 firmware / on-device inference code (not started)
└── tests/
    ├── test_environment.py  # Verifies Python + ML library environment (Checkpoint 1)
    ├── test_preprocessing.py # Verifies preprocessing pipeline against synthetic fixture (Checkpoint 2)
    └── fixtures/              # Synthetic, clearly-labeled test-only data
```

Every currently-empty directory contains a `.gitkeep` placeholder file so the
folder structure survives copying/zipping/uploading to git or a new machine.

---

## 4. Setup Instructions

### 4.1 Prerequisites
- Python 3.9–3.11 (recommended)
- `pip`
- (Optional but recommended) a virtual environment tool such as `venv`

### 4.2 Create and activate a virtual environment

```bash
# From inside the LoRa_EdgeAI_Project/ folder
python3 -m venv venv

# Activate it:
# On Linux / macOS:
source venv/bin/activate
# On Windows (PowerShell):
venv\Scripts\Activate.ps1
```

### 4.3 Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4.4 Verify the environment

Run the environment test script:

```bash
python tests/test_environment.py
```

This will check:
- The Python version in use
- That `numpy`, `pandas`, and `scikit-learn` import correctly
- That basic array/DataFrame operations and a tiny scikit-learn model fit
  correctly (a sanity check, not a real model)

If all checks pass you will see `ALL CHECKS PASSED` printed at the end and
the script will exit with code `0`. If anything fails, the script prints
which check failed and exits with a non-zero code.

---

## 5. How to Run

### Checkpoint 1 — environment verification

```bash
python tests/test_environment.py
```

### Checkpoint 2 — preprocessing pipeline

As of Checkpoint 2, `data/raw/` contains **no real data yet** (see
`experiments/DATA_COLLECTION_PLAN.md`). What exists now is the pipeline
itself, verified against a synthetic test fixture:

```bash
# Verify the pipeline logic against synthetic test-only data
python tests/test_preprocessing.py

# Once real raw data exists in data/raw/ (future work), run it through the
# pipeline like this:
python -m ml.preprocessing.pipeline \
    --input data/raw/<session_id>.csv \
    --output data/processed/<session_id>_processed.csv
```

See `data/raw/README.md` for the required raw CSV schema and
`data/processed/README.md` for what the pipeline adds.

Future checkpoints will add real run instructions for model training,
evaluation, and (eventually) ESP32 deployment.

---

## 6. Roadmap (high level, for context only)

1. **Checkpoint 1 (done):** Project foundation & environment setup
2. **Checkpoint 2 (this checkpoint):** Data schema, preprocessing pipeline, and
   data collection methodology — no real data collected yet
3. **Checkpoint 3 (future):** Baseline model training & evaluation
4. **Checkpoint 4 (future):** Model optimization/quantization for edge deployment
5. **Checkpoint 5 (future):** ESP32 integration & on-device testing
6. **Checkpoint 6 (future):** Field/dynamic-channel evaluation & final report

Exact checkpoint boundaries are defined by the course/project supervisor and
may change; see `PROJECT_STATUS.md` for the authoritative "next checkpoint"
note.

---

## 7. Continuing This Project With a Different AI Assistant Session

If you are picking this project up in a new Claude conversation (e.g. after
running out of tokens), **read `PROJECT_STATUS.md` first**. It is written
specifically to let a new assistant session understand exactly what exists,
what doesn't, and what to do next without needing the original conversation.
