# Data Collection Plan

**Status: PLANNING DOCUMENT ONLY.** No data has been collected yet. This
document defines the intended methodology for when real ESP32 + LoRa
hardware data collection begins (a future checkpoint, per
`PROJECT_STATUS.md`). Nothing in this file is a result or a promise of a
specific outcome — it is a plan to be refined once hardware collection
actually starts.

---

## 1. Goal of data collection

Collect real per-transmission LoRa link-quality logs (RSSI, SNR, packet
success/failure, retry count, plus the SF/TP that were actually used) from
a physical ESP32 + LoRa end device across a range of channel conditions,
so that a supervised model can eventually be trained to predict good
(SF, TP) choices from recent link history.

## 2. Planned hardware setup (to be confirmed/updated once assembled)

- ESP32 development board
- LoRa radio module (e.g. SX1276/SX1262-based, exact part TBD)
- At least one LoRa gateway or a second end device acting as a fixed
  receiver, to generate acknowledgements/RSSI+SNR reports
- A logging path from the ESP32 to a CSV file matching
  `data/raw/README.md` — candidates: serial output captured by a laptop
  script, or on-device SD card logging. Choice TBD in the checkpoint where
  hardware integration begins.

## 3. Planned session structure

Each data collection run is a **session**, identified by a `session_id`
following the convention:

```
sess_<YYYY_MM_DD>_<environment>_<condition>_<run_number>
```

e.g. `sess_2026_10_03_outdoor_lineofsight_01`,
`sess_2026_10_05_indoor_mobile_02`

Within a session, the device transmits packets at a defined cadence (TBD,
e.g. every 5–10 seconds) while sweeping or holding SF/TP according to the
session's test plan, logging one row per transmission attempt per
`data/raw/README.md`.

## 4. Planned channel condition scenarios

To capture the "dynamic channel conditions" the project targets, sessions
are planned across a matrix of conditions such as:

- **Distance:** near / medium / far from the receiver, at fixed points
- **Line-of-sight:** clear line-of-sight vs. obstructed (walls, foliage)
- **Mobility:** static device vs. device moved during the session (e.g.
  carried at walking pace)
- **Interference:** quiet RF environment vs. a known interference source
  present (if safely and legally reproducible)
- **Indoor vs. outdoor**

The exact scenario list, number of sessions per scenario, and session
duration are TBD and should be finalized (and recorded here, replacing
this bullet list) once hardware is available and initial pilot sessions
have been run.

## 5. Labeling reality vs. simulation

Any data ever placed in `data/raw/` must be **real hardware data**. If, in
a future checkpoint, synthetic or simulated data is ever produced for any
reason (e.g. to unblock early model prototyping before enough real data
exists), it must:

- live in a clearly separate location (never `data/raw/` or
  `data/sample/`)
- be labeled unambiguously as synthetic/simulated in its filename, an
  accompanying README, and any code that generates it
- never be described as, or mixed silently with, real research results

This mirrors the same discipline already used for the library sanity-check
numbers in `tests/test_environment.py` (Checkpoint 1) and the test fixture
in `tests/fixtures/` (Checkpoint 2).

## 6. Open questions / decisions for a future checkpoint

- Exact LoRa module/hardware part numbers
- Logging transport (serial capture vs. SD card vs. other)
- Transmission cadence and session duration
- Final list and count of channel-condition scenarios
- How many total sessions / rows constitute "enough" data before training
  is attempted (depends on chosen model complexity, decided later)
- Ethical/legal considerations for any RF interference testing (must
  comply with local spectrum regulations)

**None of these open questions are answered by fabricating plausible-sounding
values.** They remain open until addressed with real planning/hardware in
a later checkpoint.
