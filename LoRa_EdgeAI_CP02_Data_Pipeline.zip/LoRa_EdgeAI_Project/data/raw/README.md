# data/raw/ — Raw LoRa Link-Quality Logs

**Status as of Checkpoint 2: EMPTY.** No real or fabricated data has been
placed here. This folder holds only a `.gitkeep` placeholder and this
README until real hardware logging (see
`experiments/DATA_COLLECTION_PLAN.md`) actually happens in a future
checkpoint.

This document describes the **required CSV format** for any file placed in
this folder. The machine-readable version of this schema (used for
validation by the preprocessing pipeline) lives in
`ml/preprocessing/schema.py` (`RAW_SCHEMA`) — that file is the source of
truth; this README is a human-readable summary of it.

## File naming convention

One CSV file per data collection session:

```
data/raw/<session_id>.csv
```

e.g. `data/raw/sess_2026_10_03_outdoor_lineofsight_01.csv`

`session_id` should match the `session_id` column value used inside the
file (see `experiments/DATA_COLLECTION_PLAN.md` for the naming convention).

## Required columns

Each row = one LoRa transmission attempt (summarizing its retries) logged
by an end device.

| Column | Type | Range / Values | Description |
|---|---|---|---|
| `timestamp_utc` | string | ISO 8601 UTC | Time of the transmission attempt |
| `session_id` | string | — | Data collection session identifier |
| `device_id` | string | — | Identifier of the physical end device |
| `packet_seq` | int | ≥ 0 | Sequence number within the session |
| `sf` | int | 7–12 | Spreading Factor used |
| `tp_dbm` | float | -4 to 22 | Transmission power used, dBm |
| `rssi_dbm` | float | -150 to 0 | RSSI for this transmission, dBm |
| `snr_db` | float | -30 to 20 | SNR for this transmission, dB |
| `retry_count` | int | 0–255 | Retransmissions before success/giving up |
| `packet_success` | int | 0 or 1 | 1 = delivered/acknowledged, 0 = failed |

## Optional columns

| Column | Type | Description |
|---|---|---|
| `payload_bytes` | int | Payload size in bytes |
| `channel_freq_hz` | float | Channel center frequency, Hz |
| `notes` | string | Free-text notes (e.g. environment description) |

## Validation

Any file placed here can be checked against this schema by running the
preprocessing pipeline:

```bash
python -m ml.preprocessing.pipeline --input data/raw/<file>.csv --output data/processed/<file>_processed.csv
```

Rows that violate required-field or range constraints are dropped and
reported (not silently included) — see `ml/preprocessing/clean.py`.

## Why this schema?

The four model input features required by the project
(RSSI, SNR, packet success/failure history, retry count) map directly onto
`rssi_dbm`, `snr_db`, `packet_success`, and `retry_count`. `sf` and `tp_dbm`
are logged too because they are the two labels the model must eventually
learn to predict — recording what was actually used, alongside the
resulting outcome, is what makes supervised learning on this data possible
later. `packet_seq` + `device_id` + `session_id` let the preprocessing
pipeline reconstruct per-device chronological history for rolling/history
features (see `ml/preprocessing/feature_engineering.py`).
