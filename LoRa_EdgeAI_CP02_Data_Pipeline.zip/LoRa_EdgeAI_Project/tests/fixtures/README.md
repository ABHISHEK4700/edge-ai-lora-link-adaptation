# tests/fixtures/ — Synthetic Test Fixtures

**Everything in this folder is fabricated data used ONLY to test that the
preprocessing code behaves correctly.** None of it is real LoRa hardware
data, none of it is a research result, and none of it should ever be cited,
plotted, or reported as a project finding.

This mirrors the same approach used in `tests/test_environment.py` from
Checkpoint 1, where a trivial `y = 2x` relationship was used purely to
confirm scikit-learn could fit a model — not as project data.

## Files

- `synthetic_test_fixture_raw.csv` — a small (12-row), hand-constructed CSV
  matching `ml/preprocessing/schema.RAW_SCHEMA`, used by
  `tests/test_preprocessing.py` to verify:
  - valid rows are kept
  - invalid rows (out-of-range values, missing required fields) are
    correctly detected and dropped
  - rolling/history feature engineering produces the expected columns and
    values, including correctly excluding the current packet's own outcome
    from its own history features

If you need more/different synthetic test cases in a future checkpoint,
add them here with a clear filename and update
`tests/test_preprocessing.py` accordingly — do not add synthetic data to
`data/raw/`, `data/processed/`, or `data/sample/`.
