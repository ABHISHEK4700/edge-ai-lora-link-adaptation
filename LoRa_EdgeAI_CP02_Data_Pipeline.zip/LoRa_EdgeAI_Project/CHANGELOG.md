# CHANGELOG

All notable changes to this project are recorded here, grouped by
checkpoint. This project follows a checkpoint-based workflow rather than
date-based releases, since it is developed incrementally as part of a
3rd-year ECE final year project.

---

## Checkpoint 1 — Project Foundation / Software Scaffolding

**Scope:** Establish the initial project structure and documentation only.
No ML model, no data, no ESP32 code.

### Added
- Full project directory structure:
  - `data/raw/`, `data/processed/`, `data/sample/`
  - `ml/preprocessing/`, `ml/training/`, `ml/evaluation/`, `ml/models/`, `ml/export/`
  - `experiments/`
  - `esp32/`
  - `tests/`
- `.gitkeep` placeholder files in every empty directory to preserve
  structure through zip/git operations
- `README.md` — project overview, structure, setup, and run instructions
- `PROJECT_STATUS.md` — detailed status tracking, design decisions, known
  issues, next checkpoint plan, and explicit continuation instructions for
  a new AI assistant session
- `CHANGELOG.md` — this file
- `requirements.txt` — minimal dependency list (`numpy`, `pandas`,
  `scikit-learn`) needed only to verify the Python ML environment at this
  stage
- `tests/test_environment.py` — minimal script verifying Python version and
  that `numpy`, `pandas`, and `scikit-learn` import and function correctly
  via a trivial, clearly-labeled sanity check (not project research data)

### Explicitly NOT done (by design, per checkpoint scope)
- No LoRa data collected or simulated
- No preprocessing, training, or evaluation code
- No trained model or exported model artifacts
- No ESP32 firmware or inference code
- No performance/research results of any kind

### Verification
- Ran `python3 tests/test_environment.py` in the build environment — all
  checks passed, exit code 0.
- Manually reviewed folder structure against the required layout — matches.

### Deliverable
- `LoRa_EdgeAI_CP01_Project_Setup.zip` — complete, self-contained project
  folder as of the end of Checkpoint 1.

---

## Checkpoint 2 — Data Schema, Preprocessing Pipeline & Data Collection Plan

**Scope:** Define the raw/processed data schema, implement the
preprocessing pipeline, and document the data collection methodology.
Still no real or fabricated LoRa measurement data, no model, no ESP32
code. All Checkpoint 1 deliverables preserved.

### Decision point
Before starting, the user was asked how RSSI/SNR/packet-outcome/retry-count
data would be obtained (real hardware later, a synthetic generator, or an
existing public dataset). The user chose: **real ESP32+LoRa hardware,
collected later — build the pipeline now against a defined schema, with no
data yet.** This shaped the entire checkpoint's scope.

### Added
- `ml/preprocessing/schema.py` — machine-readable `RAW_SCHEMA` (raw CSV
  column contract: `timestamp_utc`, `session_id`, `device_id`,
  `packet_seq`, `sf`, `tp_dbm`, `rssi_dbm`, `snr_db`, `retry_count`,
  `packet_success`, optional `payload_bytes`/`channel_freq_hz`/`notes`)
  and `processed_feature_columns()` for the engineered feature names
- `ml/preprocessing/clean.py` — `load_raw_csv()` and `validate_schema()`,
  which validate required columns, dtypes, valid ranges, and allowed
  values, dropping and reporting invalid rows rather than silently
  keeping them
- `ml/preprocessing/feature_engineering.py` — `add_rolling_features()`,
  computing rolling success-rate/retry/RSSI/SNR history features (windows
  of 5 and 10 packets by default) per `(device_id, session_id)`, with no
  leakage of a packet's own outcome into its own history
- `ml/preprocessing/pipeline.py` — `run_pipeline()` plus a CLI
  (`python -m ml.preprocessing.pipeline --input ... --output ...`) tying
  cleaning and feature engineering together
- `ml/__init__.py`, `ml/preprocessing/__init__.py` — package markers
- `data/raw/README.md` — human-readable raw data schema documentation
- `data/processed/README.md` — human-readable processed data documentation
- `data/sample/README.md` — clarifies this folder is for real data
  excerpts only, never synthetic data
- `experiments/DATA_COLLECTION_PLAN.md` — planned hardware setup, session
  naming convention, planned channel-condition scenarios, and explicit
  open questions (not invented answers)
- `tests/fixtures/synthetic_test_fixture_raw.csv` — a small, clearly
  fabricated CSV (12 rows, 3 deliberately invalid) used only to test the
  pipeline's logic
- `tests/fixtures/README.md` — explains the fixture is synthetic
  test-only data, never a research result
- `tests/test_preprocessing.py` — verifies schema validation, rolling
  feature correctness (including no self-leakage), full-pipeline
  execution (writing to a temp dir only), and that `data/raw/`,
  `data/processed/`, `data/sample/` are left untouched by the test run

### Changed
- `README.md` — added Checkpoint 2 run instructions and updated the
  project structure diagram
- `PROJECT_STATUS.md` — updated to reflect Checkpoint 2 while preserving
  the full Checkpoint 1 record (nothing from Checkpoint 1 was deleted,
  only appended to / reorganized under clear per-checkpoint headings)
- `requirements.txt` — comment updated to note Checkpoint 2 needed no new
  dependencies; package list unchanged (`numpy`, `pandas`, `scikit-learn`)

### Explicitly NOT done (by design, per checkpoint scope)
- No real or synthetic-but-passed-off-as-real LoRa data was collected or
  added to `data/raw/`, `data/processed/`, or `data/sample/`
- No label-construction strategy for training targets (deferred to
  Checkpoint 3 / a modeling decision)
- No model architecture, training code, or evaluation code
- No ESP32 firmware or inference code
- No research results, benchmarks, or performance numbers of any kind

### Verification
- Ran `python3 tests/test_preprocessing.py` — all checks passed, exit
  code 0 (schema validation kept 9/12 fixture rows and dropped exactly the
  3 deliberately-invalid ones with correct reasons; rolling features
  matched hand-computed expected values with no self-leakage; full
  pipeline ran end-to-end to a temp directory; real `data/` folders
  confirmed untouched).
- Ran the pipeline CLI directly against the fixture — output columns and
  drop reasons matched expectations.
- Ran the pipeline CLI against a nonexistent input file — failed cleanly
  with exit code 1, a clear error message, and no output file created.
- Re-ran `python3 tests/test_environment.py` — still passes unmodified,
  confirming Checkpoint 1 was preserved.

### Deliverable
- `LoRa_EdgeAI_CP02_Data_Pipeline.zip` — complete, self-contained project
  folder as of the end of Checkpoint 2 (includes everything from
  Checkpoint 1 plus everything listed above).

---

## Checkpoint 3 — (not started)

Placeholder for the next checkpoint. See `PROJECT_STATUS.md`, section 8
("Next Checkpoint") for proposed scope, including the open question of
whether real data collection needs to happen before Checkpoint 3 can
proceed. Do not fill in this section until Checkpoint 3 work is actually
performed.
