# Checkpoint 6 — Decision Tree vs. Logistic Regression vs. Small Random Forest Software Comparison Report

*This file is a committed record of one Checkpoint 6 pipeline run against
fabricated test-fixture data. It is a lab-notebook entry proving the software
executes for a third model family, not a results section. Reproduce it with:*

```bash
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv --output <tmp>/proc.csv
python -m ml.labeling.labeler --input <tmp>/proc.csv --output <tmp>/lab.csv
python -m ml.training.train_decision_tree       --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.training.train_logistic_regression --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.training.train_random_forest       --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.evaluation.compare_candidates \
    --dt-model <tmp>/models/decision_tree_sf_tp.joblib \
    --dt-metadata <tmp>/models/decision_tree_sf_tp_metadata.json \
    --lr-model <tmp>/models/logistic_regression_sf_tp.joblib \
    --lr-metadata <tmp>/models/logistic_regression_sf_tp_metadata.json \
    --rf-model <tmp>/models/random_forest_sf_tp.joblib \
    --rf-metadata <tmp>/models/random_forest_sf_tp_metadata.json \
    --input <tmp>/lab.csv --report <tmp>/comparison_report.md
```

*How to read the numbers below — please read this before quoting anything.*

*1. **The Decision Tree and Logistic Regression predictive figures (section 2)
and model file sizes (section 3) are identical to the Checkpoint 5 record**
(`experiments/CP05_SOFTWARE_VALIDATION_RUN.md`): same fixture, same split, same
seed, and those two trainers were not touched. (Their timing rows differ from
that record because timings are noisy and are measured differently here — see
point 3.) That is evidence Checkpoint 6 preserved them, and nothing more.*

*2. **The Random Forest scores 1.0000 on this fixture, the same as the single
tree. That is the expected outcome and is not a finding.** The fixture
assigns each link tier a distinct RSSI/SNR band with one correct answer, so
it is separable by construction; any model that can carve axis-aligned
regions will reach 1.0000, whether it is one tree or ten. Equal scores show
that both pipelines are wired correctly. They do **not** show that an
ensemble helps, that it does not help, or that the forest is preferable to
the tree. There are only 9 held-out contexts, and this fixture cannot
distinguish the two.*

*3. **The cost figures are desktop scikit-learn numbers and are noisy; none is
an ESP32 figure.** The forest's joblib file is several times larger than a
single tree's, and its per-call inference time is higher, because it is ten
trees per target plus scikit-learn object overhead. That says nothing about
how large or fast a compact on-device export would be — no such export exists
yet (later checkpoint). Inference time here is measured for BOTH the SF and
TX-power models with one shared harness, so it is not the SF-only figure in
the Checkpoint 4/5 metadata. Timings vary run to run; treat differences
between tiny models as noise.*

*4. The forest was **not tuned**. Its size, depth, leaf size and feature
subsampling are conservative fixed defaults chosen to be small.*

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

> Every number below was produced from fabricated test-fixture data, not from any LoRa hardware. It demonstrates only that the training and evaluation pipeline executes end to end. It is NOT evidence that the model works, generalises, or improves packet delivery ratio, latency, energy consumption or adaptation speed. No claim about real LoRa communication is supported by any of it. The fixture is trivially separable by construction, so a high score here is expected and means nothing beyond 'the code ran'.
>

> **This comparison does NOT show that any one of these models is better than any other for real LoRa channel adaptation. All were scored on the same fabricated, trivially-separable fixture used to validate the software pipeline. Any difference between them here reflects how each model family fits that fixture, not real-world merit.**

---

## 1. What was compared

- **Model A:** Decision Tree — DecisionTreeClassifier (scikit-learn), one per target (recorded by CP04)
- **Model B:** Logistic Regression — LogisticRegression (scikit-learn, multinomial) with StandardScaler, one per target (recorded by CP05)
- **Model C:** Small Random Forest — RandomForestClassifier (scikit-learn, small forest), one per target (recorded by CP06)
- **Input:** `<tmp>/lab.csv`
- **Features (identical for all):** ['rolling_success_rate_w5', 'rolling_success_rate_w10', 'rolling_retry_avg_w5', 'rolling_retry_avg_w10', 'rolling_rssi_avg_w5', 'rolling_rssi_avg_w10', 'rolling_snr_avg_w5', 'rolling_snr_avg_w10']
- **Split:** 21 train / 9 test contexts, 0 context overlap, 1611 held-out rows (`test_size=0.3`, `random_state=0`, split by `context_id`).
- Every model was evaluated on an IDENTICAL held-out split of the same input file (same test_size/random_state), and this module verified that each evaluation reported the same split and the same number of scored rows.

## 2. Predictive performance on the synthetic fixture

> SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT

| Metric | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| SF accuracy | 1.0000 | 0.7778 | 1.0000 |
| SF majority-class baseline | 0.3333 | 0.3333 | 0.3333 |
| SF macro F1 | 1.0000 | 0.5833 | 1.0000 |
| TX power accuracy | 1.0000 | 0.7778 | 1.0000 |
| TX power majority-class baseline | 0.3333 | 0.3333 | 0.3333 |
| TX power macro F1 | 1.0000 | 0.7750 | 1.0000 |
| Joint exact match | 1.0000 | 0.5556 | 1.0000 |
| Per-context joint accuracy | 1.0000 | 0.5556 | 1.0000 |
| Test rows scored | 1611 | 1611 | 1611 |

> No column being higher than another is evidence of which model is better for LoRa. Only 9 held-out contexts exist, and the fixture is separable by construction. See section 5.

## 3. Software-level cost

| Metric | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| Training time, SF+TP (s) | 0.004874 | 0.012191 | 0.021865 |
| Model file size (KB) | 3.21 | 2.94 | 27.6 |
| Inference, batch, SF+TP (µs/row) | 0.08 | 0.20 | 0.69 |
| Inference, one full decision, median (µs) | 76.6 | 221.2 | 853.9 |
| Hyperparameters tuned | False | False | False |

> Training time and model size are taken from each model's own training metadata. Inference time was re-measured for every candidate with one shared harness, over the same held-out rows, for BOTH the SF and TX-power models (a complete decision needs both) — so it is not the SF-only figure recorded in the Checkpoint 4/5 metadata. All figures are desktop scikit-learn measurements — not ESP32 figures. Model file size is the desktop joblib serialisation, dominated by Python object overhead, not an embedded footprint. The single-decision time is dominated by scikit-learn's per-call overhead for models this small and says little about the models themselves. Differences between tiny models here are noise-level and are recorded only so the comparison methodology exists.

## 4. Model structure (what a later export step would budget against)

| Property (SF / TX power) | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| Trees per target | 1 / 1 | n/a (linear model) | 10 / 10 |
| Max tree depth | 3 / 3 | n/a (linear model) | 5 / 5 |
| Total nodes | 7 / 7 | n/a (linear model) | 96 / 118 |

> Structure only. No ESP32 byte or latency figure has been derived from these counts; export and on-device measurement are later checkpoints.

## 5. What this does NOT show

- This comparison does NOT show that any one of these models is better than any other for real LoRa channel adaptation. All were scored on the same fabricated, trivially-separable fixture used to validate the software pipeline. Any difference between them here reflects how each model family fits that fixture, not real-world merit.
- This does NOT demonstrate improved packet delivery ratio for any model.
- This does NOT demonstrate improved latency for any model.
- This does NOT demonstrate improved energy consumption for any model.
- This does NOT demonstrate faster adaptation than ADR for any model.
- No model is validated for real LoRa communication.
- These metrics are NOT evidence of project success for any candidate.
- This does NOT show that an ensemble (the Random Forest) is better or worse than a single tree, and does NOT show that any candidate fits on or runs fast enough on an ESP32 — no ESP32 footprint or latency has been measured.
- The fixture is trivially separable by construction, so high scores are expected and indicate only that the pipelines ran correctly.

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

## 6. Random Forest configuration and structure in this run

> SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT

| Setting | Value |
|---|---|
| `n_estimators` | 10 |
| `max_depth` | 5 |
| `min_samples_leaf` | 5 |
| `max_features` | `sqrt` (resolves to 2 of 8 features per split) |
| `bootstrap` | True |
| `max_leaf_nodes` | None |
| `random_state` | 0 |
| `oob_score` | False (deliberately unused — see `ml/training/README.md`) |
| Small-forest guard | 30 trees / depth 10; override used: False |

| Structure | SF forest | TX-power forest |
|---|---|---|
| Trees | 10 | 10 |
| Per-tree depth | [3, 5, 3, 5, 3, 4, 4, 4, 3, 3] | [3, 5, 3, 5, 3, 5, 5, 4, 3, 3] |
| Max depth reached (cap 5) | 5 | 5 |
| Per-tree node count | [7, 13, 7, 13, 7, 13, 13, 9, 7, 7] | [7, 15, 7, 13, 7, 19, 27, 9, 7, 7] |
| Total nodes | 96 | 118 |
| Total leaves | 53 | 64 |
| Training time (s) | 0.011267 | 0.010598 |

Model file: **27.6 KB** (28266 bytes,
joblib, desktop serialisation — not an ESP32 footprint).

Impurity-based feature importances are recorded in the metadata JSON but are
intentionally not reproduced here: computed on a fixture that is separable by
construction they would be easy to misread as a finding about which channel
measurements matter, and they are not one.

## 7. Integrity stages in this run

| Stage | Result |
|---|---|
| Save, then reload from disk and compare to the in-memory model (feature list, every split feature/threshold, predictions, probabilities, both targets) | passed = True on 1611 rows |
| Retrain from the identical config, seed and training rows and compare | passed = True on 1611 rows |

Environment: Python 3.12.3, scikit-learn
1.8.0, joblib 1.5.3.

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**
