# Checkpoint 7 — Model Comparison and Selection Framework Run Record

*This file is a committed record of one Checkpoint 7 run against fabricated
test-fixture data. It is a lab-notebook entry proving the comparison and
selection framework executes end to end for the three existing candidates, not
a results section. Reproduce it with:*

```bash
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv --output <tmp>/proc.csv
python -m ml.labeling.labeler --input <tmp>/proc.csv --output <tmp>/lab.csv
python -m ml.training.train_decision_tree       --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.training.train_logistic_regression --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.training.train_random_forest       --input <tmp>/lab.csv --outdir <tmp>/models
python -m ml.evaluation.generate_comparison_report \
    --dt-model <tmp>/models/decision_tree_sf_tp.joblib \
    --dt-metadata <tmp>/models/decision_tree_sf_tp_metadata.json \
    --lr-model <tmp>/models/logistic_regression_sf_tp.joblib \
    --lr-metadata <tmp>/models/logistic_regression_sf_tp_metadata.json \
    --rf-model <tmp>/models/random_forest_sf_tp.joblib \
    --rf-metadata <tmp>/models/random_forest_sf_tp_metadata.json \
    --input <tmp>/lab.csv \
    --report <tmp>/comparison_framework_report.md \
    --json <tmp>/comparison_framework_result.json
```

*How to read the numbers below — please read this before quoting anything.*

*1. **Every figure in section A is a synthetic software-validation figure.**
The fixture assigns each link tier a distinct RSSI/SNR band with one correct
answer, so it is separable by construction. The Decision Tree and the Random
Forest reaching 1.0000, and Logistic Regression scoring lower, is what
correctly wired pipelines do on such a fixture. It is not a finding about
which model family suits LoRa link adaptation. The predictive figures and the
model file sizes here are identical to those in
`experiments/CP06_SOFTWARE_VALIDATION_RUN.md` (same fixture, same split, same
seeds, trainers untouched), which shows Checkpoint 7 preserved the earlier
pipelines and nothing more.*

*2. **Timing, size classes and latency classes are desktop figures and are
noisy.** The "compact / moderate / large" and "fast / moderate / slow" labels
are derived from placeholder thresholds against desktop scikit-learn numbers.
They are not ESP32 measurements, and a label can change between runs when a
timing sits near a threshold. The parameter and node counts are facts about
the saved desktop scikit-learn objects, not memory footprints. No on-device
size, memory footprint or latency exists for any candidate (`ml/export/` and
`esp32/` are empty).*

*3. **The section C.3 scores are relative to the three candidates in this run
only.** A score of 1.000 means "highest among these three on this synthetic
run", not any absolute standard. The stability factor uses the worst held-out
context's joint accuracy; with 9 held-out contexts on a separable fixture it
is a coarse number, and it does not measure sensitivity to which contexts were
held out. A single weighted score per candidate is computed and stored in the
JSON output, but is deliberately not printed in the report by default.*

*4. **Section B is empty on purpose.** No ESP32 + SX1278 hardware has been
used, no packet has been transmitted, and no model has been trained or
evaluated on real data. Section B holds a fixed placeholder, not results.*

*5. **Final model selection remains TBD — to be determined using real data and
ESP32 deployment measurements.** The framework has no code path that returns a
selected model; a test asserts this under many weight configurations,
including a hand-built scenario where one candidate leads on every factor.*

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

> Every number below was produced from fabricated test-fixture data, not from any LoRa hardware. It demonstrates only that the training and evaluation pipeline executes end to end. It is NOT evidence that the model works, generalises, or improves packet delivery ratio, latency, energy consumption or adaptation speed. No claim about real LoRa communication is supported by any of it. The fixture is trivially separable by construction, so a high score here is expected and means nothing beyond 'the code ran'.
>

This report is split into three sections: (A) everything this project's software pipeline has ever produced, all of it synthetic; (B) a fixed placeholder for real hardware results, which do not yet exist; and (C) a six-factor decision framework whose final selection status is fixed to TBD regardless of any score below.

---

## A. SYNTHETIC SOFTWARE-VALIDATION RESULTS

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

### A.1 What was compared

- **Decision Tree** — DecisionTreeClassifier (scikit-learn), one per target (recorded by CP04)
- **Logistic Regression** — LogisticRegression (scikit-learn, multinomial) with StandardScaler, one per target (recorded by CP05)
- **Small Random Forest** — RandomForestClassifier (scikit-learn, small forest), one per target (recorded by CP06)
- **Input:** `<tmp>/lab.csv`
- **Features (identical for all):** ['rolling_success_rate_w5', 'rolling_success_rate_w10', 'rolling_retry_avg_w5', 'rolling_retry_avg_w10', 'rolling_rssi_avg_w5', 'rolling_rssi_avg_w10', 'rolling_snr_avg_w5', 'rolling_snr_avg_w10']
- **Split:** 21 train / 9 test contexts, 0 context overlap, 1611 held-out rows (`test_size=0.3`, `random_state=0`, split by `context_id`).

### A.2 Predictive performance (SF and TX-power classification metrics)

> SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT

| Metric | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| SF accuracy | 1.0000 | 0.7778 | 1.0000 |
| SF majority-class baseline | 0.3333 | 0.3333 | 0.3333 |
| SF macro F1 | 1.0000 | 0.5833 | 1.0000 |
| TX power accuracy | 1.0000 | 0.7778 | 1.0000 |
| TX power majority-class baseline | 0.3333 | 0.3333 | 0.3333 |
| TX power macro F1 | 1.0000 | 0.7750 | 1.0000 |
| Joint exact match (both SF and TP correct) | 1.0000 | 0.5556 | 1.0000 |
| Per-context joint accuracy | 1.0000 | 0.5556 | 1.0000 |
| Test rows scored | 1611 | 1611 | 1611 |

> No column being higher than another is evidence of which model is better for LoRa. Only 9 held-out contexts exist, and the fixture is separable by construction.

**Consistency across held-out contexts (joint SF+TP row accuracy per context):**

| Statistic | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| Worst context (used by the stability factor) | 1.0000 | 0.0000 | 1.0000 |
| Mean over contexts | 1.0000 | 0.5556 | 1.0000 |
| Std. deviation over contexts | 0.0000 | 0.4969 | 0.0000 |
| Best context | 1.0000 | 1.0000 | 1.0000 |
| Held-out contexts | 9 | 9 | 9 |

> Consistency across the held-out contexts of ONE split, from rows predicted by an already-trained model. It does not measure sensitivity to which contexts were held out (that needs repeated retraining under different seeds), and with few held-out contexts it is coarse. It is not a confidence interval and says nothing about a real link.

### A.3 Confusion matrices (held-out split)

**Decision Tree — Spreading Factor**

| true \ pred | 7 | 9 | 12 |
|---|---|---|---|
| **7** | 537 | 0 | 0 |
| **9** | 0 | 358 | 0 |
| **12** | 0 | 0 | 716 |

**Decision Tree — TX Power**

| true \ pred | 2 | 14 |
|---|---|---|
| **2** | 537 | 0 |
| **14** | 0 | 1074 |

**Logistic Regression — Spreading Factor**

| true \ pred | 7 | 9 | 12 |
|---|---|---|---|
| **7** | 537 | 0 | 0 |
| **9** | 358 | 0 | 0 |
| **12** | 0 | 0 | 716 |

**Logistic Regression — TX Power**

| true \ pred | 2 | 14 |
|---|---|---|
| **2** | 537 | 0 |
| **14** | 358 | 716 |

**Small Random Forest — Spreading Factor**

| true \ pred | 7 | 9 | 12 |
|---|---|---|---|
| **7** | 537 | 0 | 0 |
| **9** | 0 | 358 | 0 |
| **12** | 0 | 0 | 716 |

**Small Random Forest — TX Power**

| true \ pred | 2 | 14 |
|---|---|---|
| **2** | 537 | 0 |
| **14** | 0 | 1074 |

> Rows are the true label, columns are the predicted label, on the same held-out split as A.2.

### A.4 Computational / resource characteristics

| Metric | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| Training time, SF+TP (s) | 0.005070 | 0.095125 | 0.031921 |
| Model file size (KB) | 3.21 | 2.94 | 27.6 |
| Inference, batch, SF+TP (µs/row) | 0.11 | 0.26 | 1.14 |
| Inference, one full decision, median (µs) | 102.5 | 328.8 | 1454.6 |
| Hyperparameters tuned | False | False | False |

> Timing figures are measured on the machine that generated this report and vary from run to run; size/latency class labels derived from them can change between runs, especially near a threshold.

**Model complexity / structure (SF / TX power):**

| Property | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| Trees per target | 1 / 1 | n/a (linear model) | 10 / 10 |
| Max tree depth | 3 / 3 | n/a (linear model) | 5 / 5 |
| Total nodes | 7 / 7 | n/a (linear model) | 96 / 118 |

**Fitted parameters / structures read from the saved models (SF / TX power):**

| Property | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| Linear parameters (coefficients + intercepts) | n/a | 27 / 9 | n/a |
| Preprocessing parameters (scaler mean + scale) | n/a | 16 / 16 | n/a |
| Tree nodes (all trees) | 7 / 7 | n/a | 96 / 118 |

> Counts of fitted quantities read from the saved model. They are structural facts about the desktop scikit-learn object, not a memory footprint: an ESP32 export would store these values in a different layout and add its own overhead.

**Estimated embedded suitability (desktop-proxy labels — see caveat):**

| Property | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| Model size class | compact (desktop proxy) | compact (desktop proxy) | large (desktop proxy) |
| Latency class | fast (desktop proxy) | moderate (desktop proxy) | slow (desktop proxy) |

> This label is a DESKTOP PROXY derived from joblib file size and desktop scikit-learn latency on a fabricated fixture. It is NOT an ESP32 measurement. No on-device size, RAM/flash footprint or latency has been measured for any candidate in this project.
> Project-chosen placeholder thresholds, NOT measured ESP32 limits — the same kind of placeholder as the small-forest guard in ml/training/train_random_forest.py. They exist only to turn desktop numbers into a readable label; they say nothing about what actually fits on an ESP32.

### A.5 Reproducibility

All three candidates were trained from the SAME labeled CSV, the SAME preprocessing pipeline (`ml/preprocessing/`), the SAME labeling framework (`ml/labeling/`), the SAME 8 causal rolling-history features (RSSI, SNR, packet success/failure history, retry count — no GPS/distance/location), and the SAME context-aware train/test split (`ml/training/dataset.py`, `random_state=0`). Every trainer records `tuned: False` and fixes its own `random_state`. See `ml/training/README.md` for the causality and splitting rules all three trainers share.

### A.6 What this does NOT show

- This comparison does NOT show that any one of these models is better than any other for real LoRa channel adaptation. All were scored on the same fabricated, trivially-separable fixture used to validate the software pipeline. Any difference between them here reflects how each model family fits that fixture, not real-world merit.
- This does NOT demonstrate improved packet delivery ratio for any model.
- This does NOT demonstrate improved latency for any model.
- This does NOT demonstrate improved energy consumption for any model.
- This does NOT demonstrate faster adaptation than ADR for any model.
- No model is validated for real LoRa communication.
- These metrics are NOT evidence of project success for any candidate.
- This does NOT show that an ensemble (the Random Forest) is better or worse than a single tree, and does NOT show that any candidate fits on or runs fast enough on an ESP32 — no ESP32 footprint or latency has been measured.
- The fixture is trivially separable by construction, so high scores are expected and indicate only that the pipelines ran correctly.

---

## B. REAL HARDWARE RESULTS — NOT YET AVAILABLE

**Status:** NOT YET AVAILABLE

No ESP32 + SX1278 hardware has been used in this project. No packet has been transmitted, no RSSI/SNR has been measured from a real radio, and no model has been trained or evaluated on real data. data/raw/, data/processed/ and data/sample/ contain only README.md/.gitkeep.

**Blocking work:** Real ESP32 + SX1278 data collection per experiments/DATA_COLLECTION_PLAN.md, including its section 4a sweep requirements, is required before this section can contain any number. See PROJECT_STATUS.md section 8, 'Next Checkpoint'.

What will go here once real hardware data exists:

- Real predictive performance (accuracy, macro F1, confusion matrices, joint exact match) on held-out real channel contexts.
- Measured ESP32 model size/footprint after export (ml/export/ is currently empty).
- Measured on-device inference latency (esp32/ is currently empty).
- Measured energy consumption per decision, once a supply-current table exists.
- A genuine model selection, made only once the above exist.

---

## C. Decision Framework

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**

### C.1 Final selection status: **TBD — to be determined using real data and ESP32 deployment measurements.**

Two of the six factors this framework scores — predictive performance and embedded feasibility — currently come from a fabricated test fixture and a desktop-proxy label respectively, not from real hardware or a measured ESP32 footprint. No combination of the other four factors, and no choice of weights, can substitute for those two. This framework is built so the SAME factor definitions and weighting mechanism can be re-run once real data and a real ESP32 measurement exist; only then does a selection become meaningful.

### C.2 Factor definitions

| Factor | Definition |
|---|---|
| predictive_performance | Joint (SF+TP) exact-match accuracy on the held-out synthetic split. Higher is better. |
| model_size | Serialized joblib file size (KB). Lower is better. Desktop figure, not an ESP32 footprint. |
| inference_latency | Median desktop time for one full SF+TP decision (µs). Lower is better. Not an ESP32 figure. |
| memory_requirements | Same KB figure as model_size; no separate on-device memory measurement exists yet. |
| embedded_feasibility | Derived from the resource_profile size/latency classes, averaged. A desktop proxy label, not a fit/no-fit verdict. |
| stability_generalization | Worst-context joint (SF+TP) row accuracy across the held-out contexts. Higher is better. Consistency across one split's contexts, not sensitivity to which contexts were held out; coarse with few contexts. |

### C.3 Per-factor normalised scores (0-1, higher = better on THIS run)

| Factor | Decision Tree | Logistic Regression | Small Random Forest |
|---|---|---|---|
| predictive_performance | 1.000 | 0.000 | 1.000 |
| model_size | 0.989 | 1.000 | 0.000 |
| inference_latency | 1.000 | 0.833 | 0.000 |
| memory_requirements | 0.989 | 1.000 | 0.000 |
| embedded_feasibility | 1.000 | 0.750 | 0.000 |
| stability_generalization | 1.000 | 0.000 | 1.000 |

> Each factor is min-max normalised to [0, 1] ACROSS THE CANDIDATES IN THIS RUN ONLY — a score of 1.0 means 'best among these candidates on this synthetic run', not any absolute standard. Every input is a synthetic-fixture or desktop-proxy figure; see the banner.

### C.4 Illustrative weighted scores (opt-in, for transparency only)

Not shown by default. A single weighted number per candidate invites reading it as a ranking, which synthetic data cannot support. The values are still computed and stored in the JSON output; regenerate with `--include-illustrative-scores` to print them here. They never affect the selection status.

### C.5 What this framework does NOT show

- This framework does NOT select a final model. final_selection_status is a fixed value and does not depend on the scores above or on any weight configuration.
- No candidate here is marked 'winner', 'recommended', or 'best'.
- All factor scores were computed from fabricated test-fixture data and/or desktop-proxy figures — see the banner.
- embedded_feasibility is a desktop-proxy label, not a measured ESP32 fit/no-fit verdict.
- The final model will only be selected after real hardware data and embedded measurements are available (see PROJECT_STATUS.md section 8, 'Next Checkpoint').

---

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**
> **Final model selection: TBD — to be determined using real data and ESP32 deployment measurements.**
