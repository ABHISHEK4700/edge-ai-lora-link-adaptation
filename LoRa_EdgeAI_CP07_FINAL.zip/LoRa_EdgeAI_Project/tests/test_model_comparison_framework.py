"""
test_model_comparison_framework.py

Checkpoint 7 — Model Comparison and Selection Framework verification.

Verifies ml/evaluation/resource_profile.py, ml/evaluation/decision_framework.py
and ml/evaluation/generate_comparison_report.py, using ONLY the fabricated
fixture at tests/fixtures/synthetic_pipeline_fixture_raw.csv — the SAME
fixture, preprocessing, labeling, feature set and context-aware split the
Checkpoint 4/5/6 tests use.

*** NOTHING HERE IS A RESEARCH RESULT. ***
No check asserts that any model is better or worse than another, and no
check treats a high or low synthetic score as meaningful. Several checks
instead assert that the framework REFUSES to pick a winner and that the
required disclaimers, the synthetic/real-hardware separation and the fixed
TBD selection status are literally present.

    SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT

What is checked:
  1.  Modules import.
  2.  REPRODUCIBILITY INPUTS: all three candidates share one dataset, one
      feature list (the 8 causal rolling features, no GPS/distance/location),
      one identical held-out split with no context overlap.
  3.  Every score is derived from the SAME split, and the report re-derives
      confusion matrices that sum to the number of scored rows.
  4.  Resource profile reads the comparison without measuring anything new,
      classifies from an allowed vocabulary, is threshold-configurable and
      rejects invalid thresholds; fitted parameter/structure counts agree
      with the trainers' own metadata.
  5.  Factor weights are validated.
  6.  Factor scoring directions are right (checked on hand-built numbers).
  7.  select_candidate() ALWAYS reports the fixed TBD status — under many
      weight configurations AND under a hand-built scenario where one
      candidate dominates every factor — and never emits a winner-type key.
  8.  The rendered report separates SYNTHETIC results (A) from REAL HARDWARE
      results — NOT YET AVAILABLE (B) and the decision framework (C), in
      that order, with the banner, and contains no winner language.
  9.  The real-hardware placeholder contains no numbers at all.
  10. Illustrative weighted scores are opt-in in the report.
  11. JSON output is serialisable and carries the fixed status.
  12. The command line works and reports errors with exit code 1.
  13. DETERMINISM: repeated runs agree on every non-timing field.
  14. Earlier-checkpoint source modules are byte-identical to their CP06
      state, and the CP05/CP06 comparison still works.
  15. Documentation was updated for portability.
  16. data/ and ml/models/ remain clean.

Run with:
    python tests/test_model_comparison_framework.py

Exit code 0 -> all checks passed
Exit code 1 -> at least one check failed
"""

import contextlib
import copy
import hashlib
import io
import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

FIXTURE = PROJECT_ROOT / "tests" / "fixtures" / "synthetic_pipeline_fixture_raw.csv"

BANNER = "SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT"
SEC_A = "## A. SYNTHETIC SOFTWARE-VALIDATION RESULTS"
SEC_B = "## B. REAL HARDWARE RESULTS — NOT YET AVAILABLE"
SEC_C = "## C. Decision Framework"
TBD = ("TBD — to be determined using real data and ESP32 deployment "
       "measurements.")

#: SHA-256 of the Checkpoint 4/5/6 evaluation and training modules exactly as
#: delivered at the end of Checkpoint 6. Checkpoint 7 must not modify them. A
#: LATER checkpoint that deliberately changes one of these files must update
#: its entry here in the same change, so the edit is visible and intentional.
FROZEN_CP06_HASHES = {
    "ml/evaluation/compare_candidates.py":
        "0cbe79117813117e025da1a1a3289d4fcac3c806e6b38fedda6fd12044566825",
    "ml/evaluation/compare_models.py":
        "b0574adcd44a76ee08f4f820abefdea3a83b34dcc63e276eb0dfd1a668162245",
    "ml/evaluation/evaluate.py":
        "0364265fc21c456ddbcfbc7f74536655a6ae2cff509e1e435396fe3a7adc8842",
    "ml/evaluation/metrics.py":
        "186bb15eded637ac5fb1a783609fda486ccda34e9dde8000b973fb8293ab9129",
    "ml/evaluation/timing.py":
        "dfe5769a277d0676026a0299864966f9d7e10d971814faeb68499f62ec91025a",
    "ml/training/dataset.py":
        "ae84059a39c49e138374d3c28d6e4b63a4fb4c2804150eb16728e8e149735c60",
    "ml/training/train_decision_tree.py":
        "af9c99225356f59b6ad0e7693a3adfa7ea9fdf0e99960880dddd477ce6b5def0",
    "ml/training/train_logistic_regression.py":
        "90ae3cc90c0c4c40f665f2590d8609ede6062116f4161893c6cf5e9f96ba65d8",
    "ml/training/train_random_forest.py":
        "1f5863d0514619de349188207fc724307f9673249e1eb571c331db57b714923b",
}

_PREPARED = {}


def _prepare():
    """Preprocess + label + train all three models ONCE into a temp dir."""
    if _PREPARED:
        return _PREPARED

    from ml.labeling.labeler import run_labeling
    from ml.preprocessing.pipeline import run_pipeline
    from ml.training.train_decision_tree import train as train_dt
    from ml.training.train_logistic_regression import train as train_lr
    from ml.training.train_random_forest import train as train_rf

    tmp = Path(tempfile.mkdtemp(prefix="lora_cp07_test_"))
    proc, lab = tmp / "proc.csv", tmp / "lab.csv"
    run_pipeline(str(FIXTURE), str(proc))
    run_labeling(str(proc), str(lab))

    train_dt(str(lab), str(tmp / "dt"))
    train_lr(str(lab), str(tmp / "lr"))
    train_rf(str(lab), str(tmp / "rf"))

    _PREPARED.update({
        "tmp": tmp, "labeled": lab,
        "dt_model": tmp / "dt" / "decision_tree_sf_tp.joblib",
        "dt_meta": tmp / "dt" / "decision_tree_sf_tp_metadata.json",
        "lr_model": tmp / "lr" / "logistic_regression_sf_tp.joblib",
        "lr_meta": tmp / "lr" / "logistic_regression_sf_tp_metadata.json",
        "rf_model": tmp / "rf" / "random_forest_sf_tp.joblib",
        "rf_meta": tmp / "rf" / "random_forest_sf_tp_metadata.json",
    })
    return _PREPARED


def _cleanup():
    if _PREPARED.get("tmp"):
        shutil.rmtree(_PREPARED["tmp"], ignore_errors=True)


def _full(**kwargs):
    from ml.evaluation.generate_comparison_report import build_full_comparison
    p = _prepare()
    return build_full_comparison(
        str(p["dt_model"]), str(p["dt_meta"]),
        str(p["lr_model"]), str(p["lr_meta"]),
        str(p["rf_model"]), str(p["rf_meta"]),
        str(p["labeled"]), **kwargs)


def _cached_full():
    p = _prepare()
    if "full" not in p:
        p["full"] = _full()
    return p["full"]


def _walk_keys(obj):
    """Yield every dict key anywhere inside a nested structure."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield str(k)
            yield from _walk_keys(v)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            yield from _walk_keys(v)


def _walk_numbers(obj):
    """Yield every int/float (not bool) anywhere inside a nested structure."""
    if isinstance(obj, bool):
        return
    if isinstance(obj, (int, float)):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from _walk_numbers(v)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            yield from _walk_numbers(v)


# ---------------------------------------------------------------------------

def check_imports():
    print("[CHECK] Checkpoint 7 modules import correctly")
    try:
        from ml.evaluation import resource_profile  # noqa: F401
        from ml.evaluation import decision_framework  # noqa: F401
        from ml.evaluation import generate_comparison_report  # noqa: F401
    except ImportError as e:
        print(f"  -> FAIL: could not import ({e})")
        return False
    print("  -> OK")
    return True


def check_shared_dataset_features_and_split():
    print("[CHECK] all three candidates share one dataset, one feature list "
          "and one identical held-out split")
    from ml.training.dataset import resolve_feature_columns

    full = _cached_full()
    comp = full["comparison"]
    ok = True

    keys = [c["key"] for c in comp["candidates"]]
    if keys != ["dt", "lr", "rf"]:
        print(f"  -> FAIL: expected candidates dt, lr, rf; got {keys}")
        ok = False

    expected = resolve_feature_columns()
    if list(comp["feature_columns"]) != list(expected):
        print("  -> FAIL: comparison features differ from resolve_feature_columns()")
        ok = False
    if len(expected) != 8:
        print(f"  -> FAIL: expected the 8 causal features, got {len(expected)}")
        ok = False

    banned = ("gps", "distance", "location", "lat", "lon", "latitude", "longitude")
    for col in comp["feature_columns"]:
        if any(tok in col.lower() for tok in banned):
            print(f"  -> FAIL: feature {col!r} looks like GPS/distance/location")
            ok = False
    allowed_stems = ("rolling_success_rate", "rolling_retry_avg",
                     "rolling_rssi_avg", "rolling_snr_avg")
    for col in comp["feature_columns"]:
        if not col.startswith(allowed_stems):
            print(f"  -> FAIL: feature {col!r} is not one of RSSI/SNR/"
                  f"success-history/retry features")
            ok = False

    if comp["split"]["context_overlap"] != 0:
        print("  -> FAIL: train and test contexts overlap")
        ok = False
    rows = {c["predictive"]["n_test_rows"] for c in comp["candidates"]}
    if len(rows) != 1 or rows != {comp["split"]["n_test_rows"]}:
        print(f"  -> FAIL: candidates scored differing row counts: {rows}")
        ok = False

    if ok:
        print("  -> OK (dt/lr/rf, 8 RSSI/SNR/success/retry features, one "
              "split, 0 context overlap, equal scored rows)")
    return ok


def check_confusion_matrices():
    print("[CHECK] confusion matrices are present and sum to the number of "
          "scored rows")
    full = _cached_full()
    n = full["comparison"]["split"]["n_test_rows"]
    ok = True
    for key in ("dt", "lr", "rf"):
        for target in ("spreading_factor", "tx_power_dbm"):
            cm = full["confusion_matrices"][key][target]
            rows = cm["rows_are_true_cols_are_predicted"]
            k = len(cm["labels"])
            if len(rows) != k or any(len(r) != k for r in rows):
                print(f"  -> FAIL: {key}/{target} matrix is not {k}x{k}")
                ok = False
            total = sum(sum(r) for r in rows)
            if total != n:
                print(f"  -> FAIL: {key}/{target} matrix sums to {total}, "
                      f"expected {n}")
                ok = False
    if ok:
        print(f"  -> OK (6 matrices, each sums to {n})")
    return ok


def check_resource_profile_reads_without_remeasuring():
    print("[CHECK] resource profile only re-presents the comparison's "
          "figures and uses an allowed vocabulary")
    from ml.evaluation.resource_profile import SUITABILITY_CAVEAT

    full = _cached_full()
    comp = full["comparison"]
    rp = full["resource_profile"]
    ok = True

    size_ok = ("compact (desktop proxy)", "moderate (desktop proxy)",
               "large (desktop proxy)")
    lat_ok = ("fast (desktop proxy)", "moderate (desktop proxy)",
              "slow (desktop proxy)")
    by_key = {c["key"]: c for c in comp["candidates"]}
    for key, prof in rp["candidates"].items():
        sw = by_key[key]["software"]
        if prof["training_seconds"] != sw["training_seconds"]:
            print(f"  -> FAIL: {key} training_seconds differs from the comparison")
            ok = False
        if prof["model_file_kilobytes"] != sw["model_file_kilobytes"]:
            print(f"  -> FAIL: {key} model size differs from the comparison")
            ok = False
        if prof["inference_single_decision_median_microseconds"] != \
                sw["inference_single_decision_median_microseconds"]:
            print(f"  -> FAIL: {key} latency differs from the comparison")
            ok = False
        if prof["size_class"] not in size_ok:
            print(f"  -> FAIL: {key} size_class {prof['size_class']!r} unexpected")
            ok = False
        if prof["latency_class"] not in lat_ok:
            print(f"  -> FAIL: {key} latency_class {prof['latency_class']!r} unexpected")
            ok = False
        if "NOT an ESP32 measurement" not in prof["caveat"]:
            print(f"  -> FAIL: {key} profile lacks the desktop-proxy caveat")
            ok = False
        leaked = [k for k in prof if "accuracy" in k or "f1" in k]
        if leaked:
            print(f"  -> FAIL: {key} resource profile carries predictive "
                  f"fields: {leaked}")
            ok = False

    if "NOT an ESP32 measurement" not in SUITABILITY_CAVEAT:
        print("  -> FAIL: SUITABILITY_CAVEAT is missing its core disclaimer")
        ok = False

    dt_kb = by_key["dt"]["software"]["model_file_kilobytes"]
    rf_kb = by_key["rf"]["software"]["model_file_kilobytes"]
    if not (dt_kb and rf_kb and dt_kb > 0 and rf_kb > 0):
        print("  -> FAIL: model file sizes were not recorded")
        ok = False

    if ok:
        print("  -> OK (figures identical to the comparison's; labels from the "
              "allowed vocabulary; every profile carries the caveat)")
    return ok


def check_parameter_counts():
    print("[CHECK] fitted parameter / structure counts agree with the "
          "trainers' own metadata")
    import json as _json
    from ml.evaluation.resource_profile import count_model_parameters

    p = _prepare()
    full = _cached_full()
    ok = True

    # --- Logistic Regression: expected counts derived from METADATA, not
    # hard-coded. Multinomial LR stores one coefficient row per class; a
    # binary problem stores a single row. Each row has n_features coefficients
    # and one intercept. The scaler stores a mean and a scale per feature.
    meta = _json.loads(p["lr_meta"].read_text(encoding="utf-8"))
    lr = count_model_parameters(str(p["lr_model"]))
    for target, mkey in (("spreading_factor", "sf_logreg"),
                         ("tx_power_dbm", "tp_logreg")):
        k, nf = meta[mkey]["n_classes"], meta[mkey]["n_features_in"]
        rows = k if k > 2 else 1
        want_linear, want_pre = rows * nf + rows, 2 * nf
        got = lr[target]
        if got["linear_parameters"] != want_linear:
            print(f"  -> FAIL: LR {target} linear parameters "
                  f"{got['linear_parameters']} != {want_linear}")
            ok = False
        if got["preprocessing_parameters"] != want_pre:
            print(f"  -> FAIL: LR {target} scaler parameters "
                  f"{got['preprocessing_parameters']} != {want_pre}")
            ok = False
        if got["tree_nodes"] is not None or got["n_trees"] is not None:
            print(f"  -> FAIL: LR {target} reports tree structure")
            ok = False

    # --- Trees and forest: node/tree counts must equal what the trainers
    # recorded, and they must report no linear parameters.
    by_key = {c["key"]: c for c in full["comparison"]["candidates"]}
    for key, path in (("dt", p["dt_model"]), ("rf", p["rf_model"])):
        got = count_model_parameters(str(path))
        want = by_key[key]["structure"]
        for i, target in enumerate(("spreading_factor", "tx_power_dbm")):
            if got[target]["tree_nodes"] != want["total_nodes"][i]:
                print(f"  -> FAIL: {key} {target} nodes "
                      f"{got[target]['tree_nodes']} != metadata "
                      f"{want['total_nodes'][i]}")
                ok = False
            if got[target]["n_trees"] != want["n_trees"][i]:
                print(f"  -> FAIL: {key} {target} trees differ from metadata")
                ok = False
            if got[target]["linear_parameters"] is not None or \
                    got[target]["preprocessing_parameters"] is not None:
                print(f"  -> FAIL: {key} {target} reports linear parameters")
                ok = False

    # --- The report data and text carry them.
    stored = full["resource_profile"]["candidates"]
    if any(stored[k]["parameter_counts"] is None for k in ("dt", "lr", "rf")):
        print("  -> FAIL: resource profile lacks parameter_counts")
        ok = False
    from ml.evaluation.generate_comparison_report import render_markdown_report
    report = render_markdown_report(full)
    for needle in ("Linear parameters (coefficients + intercepts)",
                   "Preprocessing parameters (scaler mean + scale)",
                   "Tree nodes (all trees)", "not a memory footprint"):
        if needle not in report:
            print(f"  -> FAIL: report is missing {needle!r}")
            ok = False

    try:
        count_model_parameters(str(p["tmp"] / "nope.joblib"))
        print("  -> FAIL: a missing model file did not raise")
        ok = False
    except FileNotFoundError:
        pass

    if ok:
        print("  -> OK (LR coefficients+intercepts and scaler values match the "
              "metadata-derived expectation; tree/forest node and tree counts "
              "equal the trainers' records; non-applicable fields are None)")
    return ok


def check_resource_thresholds_configurable_and_validated():
    print("[CHECK] suitability thresholds are configurable, take effect, and "
          "invalid ones are rejected")
    from ml.evaluation.resource_profile import (
        SuitabilityThresholds, build_resource_profile, classify_latency,
        classify_size)

    ok = True
    t = SuitabilityThresholds()
    for kb, want in ((1.0, "compact"), (5.0, "compact"), (5.01, "moderate"),
                     (20.0, "moderate"), (20.01, "large")):
        got = classify_size(kb, t)
        if not got.startswith(want):
            print(f"  -> FAIL: classify_size({kb}) = {got!r}, wanted {want}")
            ok = False
    for us, want in ((10.0, "fast"), (150.0, "fast"), (150.1, "moderate"),
                     (500.0, "moderate"), (500.1, "slow")):
        got = classify_latency(us, t)
        if not got.startswith(want):
            print(f"  -> FAIL: classify_latency({us}) = {got!r}, wanted {want}")
            ok = False
    if not classify_size(None, t).startswith("unknown"):
        print("  -> FAIL: a missing size must classify as unknown")
        ok = False
    if not classify_latency(None, t).startswith("unknown"):
        print("  -> FAIL: a missing latency must classify as unknown")
        ok = False

    comp = _cached_full()["comparison"]
    generous = SuitabilityThresholds(
        compact_kilobytes=1000.0, moderate_kilobytes=2000.0,
        fast_single_decision_microseconds=10 ** 7,
        moderate_single_decision_microseconds=2 * 10 ** 7)
    rp = build_resource_profile(comp, thresholds=generous)
    for key, prof in rp["candidates"].items():
        if not prof["size_class"].startswith("compact") or \
                not prof["latency_class"].startswith("fast"):
            print(f"  -> FAIL: generous thresholds did not take effect for {key}")
            ok = False
    strict = SuitabilityThresholds(
        compact_kilobytes=0.001, moderate_kilobytes=0.002,
        fast_single_decision_microseconds=0.001,
        moderate_single_decision_microseconds=0.002)
    rp = build_resource_profile(comp, thresholds=strict)
    for key, prof in rp["candidates"].items():
        if not prof["size_class"].startswith("large") or \
                not prof["latency_class"].startswith("slow"):
            print(f"  -> FAIL: strict thresholds did not take effect for {key}")
            ok = False

    bad = [
        SuitabilityThresholds(compact_kilobytes=0),
        SuitabilityThresholds(compact_kilobytes=30, moderate_kilobytes=20),
        SuitabilityThresholds(compact_kilobytes=20, moderate_kilobytes=20),
        SuitabilityThresholds(fast_single_decision_microseconds=0),
        SuitabilityThresholds(fast_single_decision_microseconds=600,
                              moderate_single_decision_microseconds=500),
    ]
    for i, b in enumerate(bad):
        try:
            b.validate()
            print(f"  -> FAIL: invalid thresholds #{i} were accepted")
            ok = False
        except ValueError:
            pass

    if ok:
        print("  -> OK (boundaries correct, unknowns handled, both extremes "
              "take effect, 5 invalid configurations rejected)")
    return ok


def check_context_stability():
    print("[CHECK] per-context stability is consistent with the CP4 evaluation "
          "and feeds the stability factor")
    full = _cached_full()
    comp = full["comparison"]
    cs = full["context_stability"]
    n_contexts = comp["split"]["test_contexts"]
    n_rows = comp["split"]["n_test_rows"]
    ok = True

    by_key = {c["key"]: c for c in comp["candidates"]}
    for key in ("dt", "lr", "rf"):
        r = cs[key]
        if r["n_contexts"] != n_contexts or len(r["contexts"]) != n_contexts:
            print(f"  -> FAIL: {key} has {r['n_contexts']} contexts, expected "
                  f"{n_contexts}")
            ok = False
        if r["n_rows"] != n_rows:
            print(f"  -> FAIL: {key} per-context rows sum to {r['n_rows']}, "
                  f"expected {n_rows}")
            ok = False
        vals = [c["joint_accuracy"] for c in r["contexts"].values()]
        if any(not (0.0 <= v <= 1.0) for v in vals):
            print(f"  -> FAIL: {key} has a per-context accuracy outside [0, 1]")
            ok = False
        if not (r["worst_context_joint_accuracy"] <= r["mean_context_joint_accuracy"]
                <= r["best_context_joint_accuracy"]):
            print(f"  -> FAIL: {key} worst <= mean <= best does not hold")
            ok = False
        if r["std_context_joint_accuracy"] < 0:
            print(f"  -> FAIL: {key} negative standard deviation")
            ok = False
        if any(c["n_rows"] <= 0 for c in r["contexts"].values()):
            print(f"  -> FAIL: {key} has an empty context")
            ok = False

        # Cross-check against the UNMODIFIED CP4 evaluation: the row-weighted
        # mean of per-context joint accuracy must equal the overall joint
        # exact-match accuracy computed by evaluate() on the same rows.
        weighted = sum(c["n_rows"] * c["joint_accuracy"]
                       for c in r["contexts"].values()) / r["n_rows"]
        overall = by_key[key]["predictive"]["joint_accuracy"]
        if abs(weighted - overall) > 1e-9:
            print(f"  -> FAIL: {key} row-weighted per-context accuracy "
                  f"{weighted} != evaluate() joint accuracy {overall}")
            ok = False

        raw = full["decision_framework"]["factor_scores"]["raw_values"][key]
        if raw["stability_generalization"] != r["worst_context_joint_accuracy"]:
            print(f"  -> FAIL: {key} stability factor is not the worst-context "
                  f"figure")
            ok = False
        if "does not measure sensitivity" not in r["caveat"]:
            print(f"  -> FAIL: {key} stability result lacks its caveat")
            ok = False

    # Same split for every candidate: identical context sets.
    sets = {frozenset(cs[k]["contexts"]) for k in ("dt", "lr", "rf")}
    if len(sets) != 1:
        print("  -> FAIL: candidates were broken down over different contexts")
        ok = False

    # It must not retrain or write anything: ml/models stays clean (checked
    # again at the end) and a missing model raises rather than being skipped.
    from ml.evaluation.context_stability import per_context_stability
    try:
        per_context_stability(str(_prepare()["tmp"] / "nope.joblib"),
                              str(_prepare()["labeled"]))
        print("  -> FAIL: a missing model file did not raise")
        ok = False
    except FileNotFoundError:
        pass

    if ok:
        print(f"  -> OK (3 candidates x {n_contexts} contexts; rows sum to "
              f"{n_rows}; row-weighted mean equals evaluate()'s joint accuracy; "
              f"stability factor == worst-context figure; missing model raises)")
    return ok


def check_factor_weights_validation():
    print("[CHECK] factor weights are validated")
    from ml.evaluation.decision_framework import FACTOR_NAMES, FactorWeights

    ok = True
    if len(FACTOR_NAMES) != 6:
        print(f"  -> FAIL: expected six factors, got {len(FACTOR_NAMES)}")
        ok = False
    FactorWeights().validate()
    FactorWeights(predictive_performance=5, model_size=0).validate()

    bad = [
        dict(model_size=-1.0),
        dict(predictive_performance="high"),
        dict(inference_latency=True),
        dict(predictive_performance=0, model_size=0, inference_latency=0,
             memory_requirements=0, embedded_feasibility=0,
             stability_generalization=0),
    ]
    for kw in bad:
        try:
            FactorWeights(**kw).validate()
            print(f"  -> FAIL: invalid weights accepted: {kw}")
            ok = False
        except ValueError:
            pass
    if ok:
        print("  -> OK (defaults and a zero weight accepted; negative, "
              "non-numeric, bool and all-zero weights rejected)")
    return ok


def _fake_comparison(dominant="dt"):
    """Hand-built comparison/resource/stability where `dominant` beats the
    others on EVERY factor — used to prove the framework still won't pick."""
    def cand(key, joint, kb, us):
        return {
            "key": key, "label": key, "model_family": "x", "checkpoint": "T",
            "predictive": {"joint_accuracy": joint},
            "software": {"model_file_kilobytes": kb,
                         "inference_single_decision_median_microseconds": us},
        }
    others = [k for k in ("dt", "lr", "rf") if k != dominant]
    cands = [cand(dominant, 1.0, 1.0, 1.0)]
    cands += [cand(others[0], 0.5, 50.0, 900.0), cand(others[1], 0.4, 80.0, 1500.0)]
    comp = {"banner": BANNER, "candidates": cands}
    rp = {"candidates": {
        dominant: {"size_class": "compact (desktop proxy)",
                   "latency_class": "fast (desktop proxy)"},
        others[0]: {"size_class": "large (desktop proxy)",
                    "latency_class": "slow (desktop proxy)"},
        others[1]: {"size_class": "large (desktop proxy)",
                    "latency_class": "slow (desktop proxy)"},
    }}
    stab = {dominant: {"worst_context_joint_accuracy": 1.0},
            others[0]: {"worst_context_joint_accuracy": 0.4},
            others[1]: {"worst_context_joint_accuracy": 0.2}}
    return comp, rp, stab


def check_factor_scoring_directions():
    print("[CHECK] factor scores point the right way (checked on hand-built "
          "numbers, not model output)")
    from ml.evaluation.decision_framework import compute_factor_scores

    comp, rp, stab = _fake_comparison("dt")
    fs = compute_factor_scores(comp, rp, stab)
    n = fs["normalized_scores"]
    ok = True

    for factor in fs["factors"]:
        if not (n["dt"][factor] > n["lr"][factor] or
                n["dt"][factor] > n["rf"][factor]):
            print(f"  -> FAIL: dominant candidate not ahead on {factor}")
            ok = False
        for k in ("dt", "lr", "rf"):
            v = n[k][factor]
            if v is not None and not (0.0 <= v <= 1.0):
                print(f"  -> FAIL: {k}/{factor} score {v} outside [0, 1]")
                ok = False

    # Lower-is-better factors: the smallest raw value must score exactly 1.0.
    for factor in ("model_size", "inference_latency", "memory_requirements"):
        if n["dt"][factor] != 1.0:
            print(f"  -> FAIL: smallest {factor} should score 1.0, got "
                  f"{n['dt'][factor]}")
            ok = False
    if n["dt"]["predictive_performance"] != 1.0 or \
            n["rf"]["predictive_performance"] != 0.0:
        print("  -> FAIL: predictive_performance scoring direction is wrong")
        ok = False
    # Stability: higher worst-context accuracy must score higher, and the
    # factor must read exactly the worst-context figure it was handed.
    # Hand-built worst-context accuracies are dt=1.0, lr=0.4, rf=0.2, so the
    # min-max scores must be exactly 1.0, 0.25 and 0.0.
    got = tuple(round(n[k]["stability_generalization"], 6)
                for k in ("dt", "lr", "rf"))
    if got != (1.0, 0.25, 0.0):
        print(f"  -> FAIL: stability scores for worst-context accuracies "
              f"(1.0, 0.4, 0.2) should be (1.0, 0.25, 0.0), got {got}")
        ok = False
    if fs["raw_values"]["dt"]["stability_generalization"] != 1.0:
        print("  -> FAIL: stability factor did not read worst_context_joint_accuracy")
        ok = False

    # A tie must not arbitrarily favour anyone.
    comp2, rp2, stab2 = _fake_comparison("dt")
    for c in comp2["candidates"]:
        c["predictive"]["joint_accuracy"] = 0.7
    n2 = compute_factor_scores(comp2, rp2, stab2)["normalized_scores"]
    tied = {n2[k]["predictive_performance"] for k in ("dt", "lr", "rf")}
    if len(tied) != 1:
        print(f"  -> FAIL: identical accuracies did not tie: {tied}")
        ok = False

    # Missing data passes through as None rather than being invented.
    comp3, rp3, stab3 = _fake_comparison("dt")
    comp3["candidates"][1]["software"]["model_file_kilobytes"] = None
    n3 = compute_factor_scores(comp3, rp3, stab3)["normalized_scores"]
    if n3["lr"]["model_size"] is not None:
        print("  -> FAIL: a missing size was scored instead of left as None")
        ok = False

    if ok:
        print("  -> OK (directions right, scores in [0,1], ties stay tied, "
              "missing data stays None)")
    return ok


def check_selection_is_always_tbd():
    print("[CHECK] select_candidate() ALWAYS returns the fixed TBD status and "
          "never names a winner")
    from ml.evaluation.decision_framework import (
        FACTOR_NAMES, FINAL_SELECTION_STATUS, FactorWeights, select_candidate)

    ok = True
    if FINAL_SELECTION_STATUS != TBD:
        print(f"  -> FAIL: FINAL_SELECTION_STATUS is {FINAL_SELECTION_STATUS!r}")
        ok = False

    forbidden_keys = {"winner", "selected", "selected_model", "recommended",
                      "recommendation", "best", "best_model", "chosen",
                      "final_model", "final_choice", "rank", "ranking"}

    weight_sets = [None, FactorWeights()]
    for f in FACTOR_NAMES:
        weight_sets.append(FactorWeights(**{n: (100.0 if n == f else 0.0)
                                            for n in FACTOR_NAMES}))
    weight_sets.append(FactorWeights(predictive_performance=1000, model_size=0.001))

    real = _cached_full()
    scenarios = [("real-run", real["comparison"], real["resource_profile"],
                  real["context_stability"])]
    for dom in ("dt", "lr", "rf"):
        scenarios.append((f"{dom}-dominates-everything", *_fake_comparison(dom)))

    n_calls = 0
    for label, comp, rp, stab in scenarios:
        for w in weight_sets:
            res = select_candidate(comp, rp, stab, weights=w)
            n_calls += 1
            if res["final_selection_status"] != TBD:
                print(f"  -> FAIL: [{label}] status was "
                      f"{res['final_selection_status']!r}")
                ok = False
            bad = forbidden_keys.intersection(k.lower() for k in _walk_keys(res))
            if bad:
                print(f"  -> FAIL: [{label}] result carries winner-type keys: "
                      f"{sorted(bad)}")
                ok = False
            if sorted(res["candidates_considered"]) != sorted(
                    c["key"] for c in comp["candidates"]):
                print(f"  -> FAIL: [{label}] candidates_considered is wrong")
                ok = False

    # Even the illustrative scores must not change the status when they
    # strongly favour one candidate.
    comp, rp, stab = _fake_comparison("rf")
    res = select_candidate(comp, rp, stab)
    scores = res["illustrative_weighted_scores"]["scores"]
    if not scores["rf"] > scores["dt"]:
        print("  -> FAIL: setup error — the dominant candidate did not score "
              "highest, so this scenario proves nothing")
        ok = False
    if res["final_selection_status"] != TBD:
        print("  -> FAIL: a dominant illustrative score changed the status")
        ok = False

    joined = " ".join(res["explicit_non_claims"])
    for needle in ("does NOT select a final model", "winner", "desktop-proxy"):
        if needle not in joined:
            print(f"  -> FAIL: explicit_non_claims missing {needle!r}")
            ok = False

    if ok:
        print(f"  -> OK ({n_calls} calls across 4 scenarios x "
              f"{len(weight_sets)} weight configs all TBD; no winner-type keys; "
              f"a candidate dominating every factor is still not selected)")
    return ok


def check_report_structure_and_separation():
    print("[CHECK] report separates SYNTHETIC results (A) from REAL HARDWARE "
          "RESULTS — NOT YET AVAILABLE (B) and the decision framework (C)")
    from ml.evaluation.generate_comparison_report import render_markdown_report

    report = render_markdown_report(_cached_full())
    ok = True

    for needle in (SEC_A, SEC_B, SEC_C):
        if report.count(needle) != 1:
            print(f"  -> FAIL: expected exactly one {needle!r}, found "
                  f"{report.count(needle)}")
            ok = False
    if ok and not (report.index(SEC_A) < report.index(SEC_B) < report.index(SEC_C)):
        print("  -> FAIL: sections are not in A, B, C order")
        ok = False

    if report.count(BANNER) < 4:
        print(f"  -> FAIL: banner appears only {report.count(BANNER)} times")
        ok = False
    a_part = report[report.index(SEC_A):report.index(SEC_B)]
    c_part = report[report.index(SEC_C):]
    if BANNER not in a_part or BANNER not in c_part:
        print("  -> FAIL: banner missing from section A or C")
        ok = False

    if TBD not in report:
        print("  -> FAIL: the TBD selection status is missing from the report")
        ok = False
    if not report.rstrip().endswith(TBD + "**"):
        print("  -> FAIL: the report does not END with the TBD status")
        ok = False

    for needle in ("Decision Tree", "Logistic Regression", "Small Random Forest",
                   "Confusion matrices", "Model file size (KB)",
                   "Training time", "Model complexity", "Reproducibility",
                   "Estimated embedded suitability", "macro F1",
                   "Joint exact match", "NOT an ESP32 measurement",
                   "Consistency across held-out contexts",
                   "Worst context"):
        if needle not in report:
            print(f"  -> FAIL: report is missing {needle!r}")
            ok = False

    cm_block = report.split("### A.3")[1].split("### A.4")[0]
    if "7.0" in cm_block or "12.0" in cm_block or "**7**" not in cm_block:
        print("  -> FAIL: confusion-matrix class labels are not printed as "
              "integers")
        ok = False

    if ok:
        print("  -> OK (A, B, C each once and in order; banner throughout; "
              "report ends with the TBD status; all required parts present)")
    return ok


def check_no_winner_language():
    print("[CHECK] the report and JSON contain no winner/superiority language")
    from ml.evaluation.generate_comparison_report import render_markdown_report

    full = _cached_full()
    text = render_markdown_report(full, include_illustrative=True) + \
        json.dumps(full)
    ok = True

    model = r"(decision tree|logistic regression|random forest|\bdt\b|\blr\b|\brf\b)"
    patterns = [
        model + r"[^.\n|]{0,40}\b(is|are|was)\s+(the\s+)?(best|winner|superior|optimal|preferred)",
        r"\bwinner\s+(is|was)\b",
        r"\b(selected|recommended|chosen|best)\s+model\s*[:=]",
        r"\bwe\s+(recommend|select|choose)\b",
        r"\boutperforms?\b",
        r"\bshould\s+be\s+(selected|chosen|deployed)\b",
        r"\bis\s+the\s+(best|winner)\b",
    ]
    for pat in patterns:
        m = re.search(pat, text, flags=re.IGNORECASE)
        if m:
            print(f"  -> FAIL: winner-style language found: "
                  f"{text[max(0, m.start() - 30):m.end() + 30]!r}")
            ok = False
    if ok:
        print(f"  -> OK ({len(patterns)} winner-language patterns scanned "
              f"over the report and JSON; none matched)")
    return ok


def check_real_hardware_section_has_no_numbers():
    print("[CHECK] the REAL HARDWARE section contains no measurements and no "
          "numeric values at all")
    from ml.evaluation.generate_comparison_report import (
        REAL_HARDWARE_PLACEHOLDER, render_markdown_report)

    ok = True
    nums = list(_walk_numbers(REAL_HARDWARE_PLACEHOLDER))
    if nums:
        print(f"  -> FAIL: placeholder carries numeric values: {nums}")
        ok = False
    if REAL_HARDWARE_PLACEHOLDER["status"] != "NOT YET AVAILABLE":
        print("  -> FAIL: placeholder status is not 'NOT YET AVAILABLE'")
        ok = False

    report = render_markdown_report(_cached_full())
    section_b = report[report.index(SEC_B):report.index(SEC_C)]
    unit = re.search(
        r"\b\d+(\.\d+)?\s*(ms|µs|us|ns|kb|kib|mb|mw|ma|uj|mj|j|dbm|db|%|s)\b",
        section_b, flags=re.IGNORECASE)
    if unit:
        print(f"  -> FAIL: section B contains a measurement-like value: "
              f"{unit.group(0)!r}")
        ok = False
    if "table" in section_b.lower() and "|" in section_b:
        print("  -> FAIL: section B contains a results table")
        ok = False
    if "NOT YET AVAILABLE" not in section_b or "No ESP32" not in section_b:
        print("  -> FAIL: section B does not state that no hardware was used")
        ok = False

    if ok:
        print("  -> OK (placeholder has no numeric fields; section B has no "
              "units, no table, and states no hardware exists)")
    return ok


def check_illustrative_scores_are_opt_in():
    print("[CHECK] illustrative weighted scores are hidden by default and "
          "shown only on request")
    from ml.evaluation.generate_comparison_report import render_markdown_report

    full = _cached_full()
    default = render_markdown_report(full)
    shown = render_markdown_report(full, include_illustrative=True)
    ok = True

    if "| Weighted score |" in default:
        print("  -> FAIL: the weighted score row appears by default")
        ok = False
    if "Not shown by default" not in default:
        print("  -> FAIL: default report does not explain the omission")
        ok = False
    if "| Weighted score |" not in shown:
        print("  -> FAIL: the weighted score row is missing when requested")
        ok = False
    if "ILLUSTRATIVE ONLY" not in shown:
        print("  -> FAIL: shown scores lack the ILLUSTRATIVE ONLY caveat")
        ok = False
    if TBD not in shown:
        print("  -> FAIL: TBD missing when scores are shown")
        ok = False
    if "illustrative_weighted_scores" not in full["decision_framework"]:
        print("  -> FAIL: illustrative scores are not kept in the data")
        ok = False

    if ok:
        print("  -> OK (absent by default, present with caveat and TBD when "
              "requested, always retained in the data)")
    return ok


def check_json_output_and_metadata():
    print("[CHECK] full result is JSON-serialisable and carries CP07 metadata")
    full = _cached_full()
    ok = True
    try:
        text = json.dumps(full)
        back = json.loads(text)
    except (TypeError, ValueError) as e:
        print(f"  -> FAIL: not serialisable ({e})")
        return False

    if back["checkpoint"] != "CP07":
        print(f"  -> FAIL: checkpoint field is {back['checkpoint']!r}")
        ok = False
    if back["banner"] != BANNER:
        print("  -> FAIL: banner field is wrong")
        ok = False
    if back["decision_framework"]["final_selection_status"] != TBD:
        print("  -> FAIL: JSON status is not the fixed TBD string")
        ok = False
    if back["real_hardware_results"]["status"] != "NOT YET AVAILABLE":
        print("  -> FAIL: JSON real_hardware_results status is wrong")
        ok = False
    if sorted(back.get("context_stability", {})) != ["dt", "lr", "rf"]:
        print("  -> FAIL: JSON lacks per-candidate context_stability")
        ok = False
    if ok:
        print("  -> OK (round-trips through JSON; checkpoint, banner, TBD "
              "status and hardware placeholder present)")
    return ok


def _run_cli(args):
    from ml.evaluation import generate_comparison_report as g
    out, err = io.StringIO(), io.StringIO()
    code = 0
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            g.main(args)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else 1
    return code, out.getvalue(), err.getvalue()


def check_cli():
    print("[CHECK] command line writes report + JSON and reports errors "
          "with exit code 1")
    p = _prepare()
    rpt, js = p["tmp"] / "cli_report.md", p["tmp"] / "cli_result.json"
    base = ["--dt-model", str(p["dt_model"]), "--dt-metadata", str(p["dt_meta"]),
            "--lr-model", str(p["lr_model"]), "--lr-metadata", str(p["lr_meta"]),
            "--rf-model", str(p["rf_model"]), "--rf-metadata", str(p["rf_meta"]),
            "--input", str(p["labeled"])]
    ok = True

    code, out, err = _run_cli(base + ["--report", str(rpt), "--json", str(js)])
    if code != 0:
        print(f"  -> FAIL: CLI exited {code}: {err}")
        return False
    if not rpt.exists() or SEC_B not in rpt.read_text(encoding="utf-8"):
        print("  -> FAIL: report file missing or lacks section B")
        ok = False
    if not js.exists() or json.loads(js.read_text(encoding="utf-8"))[
            "decision_framework"]["final_selection_status"] != TBD:
        print("  -> FAIL: JSON file missing or lacks the TBD status")
        ok = False

    code, out, err = _run_cli(base)
    if code != 0 or SEC_A not in out:
        print("  -> FAIL: stdout mode did not print the report")
        ok = False

    code, out, err = _run_cli(base + ["--include-illustrative-scores"])
    if code != 0 or "| Weighted score |" not in out:
        print("  -> FAIL: --include-illustrative-scores did not take effect")
        ok = False

    missing = list(base)
    missing[missing.index("--dt-model") + 1] = str(p["tmp"] / "nope.joblib")
    code, out, err = _run_cli(missing)
    if code != 1 or "ERROR" not in err:
        print(f"  -> FAIL: missing model gave exit {code}, stderr {err!r}")
        ok = False

    bad_split = base + ["--test-size", "1.5"]
    code, out, err = _run_cli(bad_split)
    if code != 1:
        print(f"  -> FAIL: invalid --test-size gave exit {code}")
        ok = False

    if ok:
        print("  -> OK (report + JSON written; stdout mode; opt-in flag; "
              "missing file and bad test-size both exit 1)")
    return ok


def check_determinism_of_non_timing_fields():
    print("[CHECK] repeated runs agree on every non-timing field")
    a, b = _cached_full(), _full()
    ok = True

    def stable(full):
        s = copy.deepcopy(full)
        for c in s["comparison"]["candidates"]:
            for k in ("training_seconds", "inference_batch_microseconds_per_row_sf_and_tp",
                      "inference_single_decision_median_microseconds"):
                c["software"].pop(k, None)
        for prof in s["resource_profile"]["candidates"].values():
            for k in ("training_seconds",
                      "inference_batch_microseconds_per_row_sf_and_tp",
                      "inference_single_decision_median_microseconds",
                      "latency_class"):
                prof.pop(k, None)
        df = s["decision_framework"]
        for k in ("inference_latency", "embedded_feasibility"):
            for key in df["factor_scores"]["raw_values"]:
                df["factor_scores"]["raw_values"][key].pop(k, None)
                df["factor_scores"]["normalized_scores"][key].pop(k, None)
        df.pop("illustrative_weighted_scores", None)
        return s

    if json.dumps(stable(a), sort_keys=True) != json.dumps(stable(b), sort_keys=True):
        print("  -> FAIL: two runs differ in a non-timing field")
        ok = False
    for key in ("dt", "lr", "rf"):
        if a["confusion_matrices"][key] != b["confusion_matrices"][key]:
            print(f"  -> FAIL: {key} confusion matrices differ between runs")
            ok = False

    c = _full(random_state=1)
    if c["comparison"]["split"]["random_state"] != 1:
        print("  -> FAIL: --random-state did not reach the split")
        ok = False

    if ok:
        print("  -> OK (predictive, structure, size, confusion and factor "
              "fields identical across runs; timing excluded; random_state "
              "is honoured)")
    return ok


def check_previous_checkpoints_preserved():
    print("[CHECK] Checkpoint 4/5/6 sources are byte-identical to their CP06 "
          "state and the earlier comparison still works")
    ok = True
    for rel, want in FROZEN_CP06_HASHES.items():
        path = PROJECT_ROOT / rel
        if not path.exists():
            print(f"  -> FAIL: {rel} is missing")
            ok = False
            continue
        got = hashlib.sha256(path.read_bytes()).hexdigest()
        if got != want:
            print(f"  -> FAIL: {rel} was modified (sha256 {got[:12]}… != "
                  f"{want[:12]}…)")
            ok = False

    from ml.evaluation.compare_candidates import Candidate, compare_candidates
    from ml.evaluation.compare_models import compare as compare_two_models  # noqa: F401
    p = _prepare()
    two = compare_candidates(
        [Candidate("dt", "Decision Tree", str(p["dt_model"]), str(p["dt_meta"])),
         Candidate("lr", "Logistic Regression", str(p["lr_model"]), str(p["lr_meta"]))],
        str(p["labeled"]))
    if len(two["candidates"]) != 2:
        print("  -> FAIL: the two-model CP05-style comparison no longer works")
        ok = False

    if ok:
        print(f"  -> OK ({len(FROZEN_CP06_HASHES)} earlier modules byte-identical; "
              f"two-model comparison still works)")
    return ok


def check_documentation_updated():
    print("[CHECK] README.md, PROJECT_STATUS.md and CHANGELOG.md were updated "
          "for Checkpoint 7")
    ok = True
    docs = {n: (PROJECT_ROOT / n).read_text(encoding="utf-8")
            for n in ("README.md", "PROJECT_STATUS.md", "CHANGELOG.md")}

    for name, text in docs.items():
        for needle in ("Checkpoint 7", "decision_framework", "resource_profile",
                       "context_stability", "generate_comparison_report",
                       BANNER, TBD):
            if needle not in text:
                print(f"  -> FAIL: {name} does not mention {needle!r}")
                ok = False

    status = docs["PROJECT_STATUS.md"].lower()
    for needle in (
        "LoRa_EdgeAI_CP07_FINAL.zip",
        "LoRa_EdgeAI_CP07_Model_Comparison_Framework.zip",
        "Instructions for a New Claude",
        "Decision Tree", "Logistic Regression", "Random Forest",
        "software validation only",
        "REAL HARDWARE RESULTS — NOT YET AVAILABLE",
        "SYNTHETIC SOFTWARE-VALIDATION RESULTS",
        "Checkpoint 8", "Real Hardware Data Collection",
        "final model selection", "ESP32",
    ):
        if needle.lower() not in status:
            print(f"  -> FAIL: PROJECT_STATUS.md is missing {needle!r}")
            ok = False
    for cp in ("CP01", "CP02", "CP03", "CP04", "CP05", "CP06", "CP07"):
        if cp not in docs["PROJECT_STATUS.md"]:
            print(f"  -> FAIL: PROJECT_STATUS.md does not state {cp} status")
            ok = False
    if "not started" not in status:
        print("  -> FAIL: PROJECT_STATUS.md does not say Checkpoint 8 has not started")
        ok = False

    prog = PROJECT_ROOT / "CHECKPOINT_PROGRESS.md"
    if not prog.exists():
        print("  -> FAIL: CHECKPOINT_PROGRESS.md is missing")
        ok = False
    else:
        ptext = prog.read_text(encoding="utf-8")
        for needle in ("Checkpoint 7", "Stage status", TBD, BANNER):
            if needle not in ptext:
                print(f"  -> FAIL: CHECKPOINT_PROGRESS.md is missing {needle!r}")
                ok = False

    if ok:
        print("  -> OK (all three documents updated; status file covers "
              "CP01-CP07, candidates, TBD selection, real-data requirement "
              "and next checkpoint)")
    return ok


def check_no_pollution_of_real_data_dirs():
    print("[CHECK] real data/ directories and ml/models/ remain untouched by "
          "this test run")
    ok = True
    for sub in ("raw", "processed", "sample"):
        d = PROJECT_ROOT / "data" / sub
        contents = [x.name for x in d.iterdir()] if d.exists() else []
        unexpected = [c for c in contents if c not in (".gitkeep", "README.md")]
        if unexpected:
            print(f"  -> FAIL: data/{sub}/ contains unexpected files: {unexpected}")
            ok = False
    stray = [x.name for x in (PROJECT_ROOT / "ml" / "models").iterdir()
             if x.name not in (".gitkeep", "README.md")]
    if stray:
        print(f"  -> FAIL: ml/models/ contains stray artifacts: {stray}")
        ok = False
    for sub in ("export",):
        d = PROJECT_ROOT / "ml" / sub
        if d.exists() and [x.name for x in d.iterdir()
                           if x.name not in (".gitkeep", "README.md")]:
            print(f"  -> FAIL: ml/{sub}/ is no longer empty")
            ok = False
    if ok:
        print("  -> OK (data/, ml/models/ and ml/export/ clean; test output "
              "went to a temp dir)")
    return ok


def main():
    print("=" * 70)
    print("LoRa Edge-AI — Checkpoint 7 Model Comparison Framework Verification")
    print("SOFTWARE VALIDATION ONLY — synthetic data, no research results")
    print(BANNER)
    print("=" * 70)

    checks = [
        check_imports,
        check_shared_dataset_features_and_split,
        check_confusion_matrices,
        check_context_stability,
        check_resource_profile_reads_without_remeasuring,
        check_parameter_counts,
        check_resource_thresholds_configurable_and_validated,
        check_factor_weights_validation,
        check_factor_scoring_directions,
        check_selection_is_always_tbd,
        check_report_structure_and_separation,
        check_no_winner_language,
        check_real_hardware_section_has_no_numbers,
        check_illustrative_scores_are_opt_in,
        check_json_output_and_metadata,
        check_cli,
        check_determinism_of_non_timing_fields,
        check_previous_checkpoints_preserved,
        check_documentation_updated,
        check_no_pollution_of_real_data_dirs,
    ]

    try:
        results = [check() for check in checks]
    finally:
        _cleanup()

    print("=" * 70)
    if all(results):
        print("ALL CHECKS PASSED")
        print("The model comparison and selection framework executes end to end.")
        print("This is SOFTWARE VALIDATION ONLY — no real data, no research result.")
        print("Final model selection remains: " + TBD)
        print("=" * 70)
        sys.exit(0)
    else:
        failed = [c.__name__ for c, r in zip(checks, results) if not r]
        print(f"SOME CHECKS FAILED: {failed}")
        print("=" * 70)
        sys.exit(1)


if __name__ == "__main__":
    main()
