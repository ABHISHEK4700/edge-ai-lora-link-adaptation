"""
test_random_forest.py

Checkpoint 6 — Small Random Forest training/evaluation & three-way comparison
pipeline verification.

Verifies ml/training/train_random_forest.py, ml/evaluation/timing.py and
ml/evaluation/compare_candidates.py, using ONLY the fabricated fixture at
tests/fixtures/synthetic_pipeline_fixture_raw.csv — the SAME fixture, SAME
preprocessing, SAME labeling framework, SAME feature set and SAME
context-aware split that Checkpoint 4's Decision Tree tests and Checkpoint 5's
Logistic Regression tests use.

*** NOTHING HERE IS A RESEARCH RESULT. ***
As with the earlier test files, these checks confirm the SOFTWARE RUNS on a
fixture that is separable by construction. No check asserts "the Random Forest
is better/worse than the Decision Tree or Logistic Regression", and no check
treats a high or low synthetic score as meaningful — several checks instead
assert that the required non-claims and disclaimers are literally present.

    SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT

What is checked:
  1.  Modules import.
  2.  FEATURE CONSISTENCY: the forest uses the identical feature list as the
      Decision Tree and Logistic Regression (all three trained here), the
      list is the 8 causal rolling features, contains no contextual token,
      and each fitted forest expects exactly that many inputs.
  3.  The default configuration is deliberately SMALL.
  4.  TRAINING: two forests train; structure (trees, depth, nodes, leaves),
      training time and model-file size are recorded.
  5.  Every important hyperparameter is configurable and actually takes effect
      (tree count, depth cap, leaf size, leaf-node cap, feature subsampling).
  6.  PREDICTION: shapes, label set, probabilities, single-row prediction, and
      rejection of wrong-width input.
  7.  MODEL SAVE/RELOAD: the bundle reloads through the UNMODIFIED Checkpoint 4
      load_bundle() and predicts identically to the in-memory model.
  8.  The UNMODIFIED Checkpoint 4 evaluate() scores a forest bundle, and
      agrees with the metrics recorded at training time.
  9.  Metadata carries every required field, the banner, tuned=False, and the
      Random-Forest-specific non-claims.
  10. The pipeline's own reload and reproducibility stages are recorded, and
      the comparison they rely on can actually FAIL (tamper tests).
  11. REPRODUCIBILITY: a fixed random_state reproduces structure and metrics.
  12. LEAKAGE PROTECTION (shared guard): banned columns are rejected at both
      entry points, the saved bundle has none, and no context straddles the
      split.
  13. LEAKAGE PROTECTION (behavioural): rewriting the HELD-OUT contexts does not
      change the trained forest, while rewriting TRAINING contexts does
      (negative control, so the test cannot pass vacuously).
  14. Out-of-bag scoring is not used (it would be optimistic under a
      row-bootstrap of context-grouped data).
  15. INVALID CONFIGURATION is rejected clearly, before any file is written.
  16. The command line reports errors with exit code 1.
  17. The three-way comparison scores all models on an IDENTICAL held-out split.
  18. The comparison refuses mismatched features, duplicate keys, and <2 models.
  19. The comparison report carries the banner and every required non-claim.
  20. Checkpoint 4/5 pipelines are untouched in behaviour and files: training
      the forest into the same directory does not alter their saved models,
      and the Checkpoint 5 two-model comparison still works.
  21. Documentation was updated for portability.
  22. data/ and ml/models/ remain clean.

Run with:
    python tests/test_random_forest.py

Exit code 0 -> all checks passed
Exit code 1 -> at least one check failed
"""

import contextlib
import hashlib
import io
import json
import shutil
import sys
import tempfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

FIXTURE = PROJECT_ROOT / "tests" / "fixtures" / "synthetic_pipeline_fixture_raw.csv"

#: Built once by _prepare() and reused, so the chain runs once not N times.
_PREPARED = {}


def _prepare():
    """Run preprocessing + labeling once into a temp dir; cache the paths."""
    if _PREPARED:
        return _PREPARED

    from ml.labeling.labeler import run_labeling
    from ml.preprocessing.pipeline import run_pipeline

    tmp = Path(tempfile.mkdtemp(prefix="lora_cp06_test_"))
    proc = tmp / "proc.csv"
    lab = tmp / "lab.csv"
    run_pipeline(str(FIXTURE), str(proc))
    run_labeling(str(proc), str(lab))

    _PREPARED.update({"tmp": tmp, "processed": proc, "labeled": lab})
    return _PREPARED


def _cleanup():
    if _PREPARED.get("tmp"):
        shutil.rmtree(_PREPARED["tmp"], ignore_errors=True)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _train_rf_default():
    """Train (once) the default small forest into a temp dir and cache it."""
    p = _prepare()
    if "rf_metadata" not in p:
        from ml.training.train_random_forest import train
        outdir = p["tmp"] / "models_rf"
        p["rf_metadata"] = train(str(p["labeled"]), str(outdir))
        p["rf_model_path"] = outdir / "random_forest_sf_tp.joblib"
        p["rf_metadata_path"] = outdir / "random_forest_sf_tp_metadata.json"
    return p


def _train_dt_lr():
    """Train (once) the Decision Tree and Logistic Regression baselines with
    their own, unmodified trainers."""
    p = _prepare()
    if "dt_model_path" not in p:
        from ml.training.train_decision_tree import train as train_dt
        from ml.training.train_logistic_regression import train as train_lr
        dt_out = p["tmp"] / "models_dt"
        lr_out = p["tmp"] / "models_lr"
        p["dt_metadata"] = train_dt(str(p["labeled"]), str(dt_out))
        p["lr_metadata"] = train_lr(str(p["labeled"]), str(lr_out))
        p["dt_model_path"] = dt_out / "decision_tree_sf_tp.joblib"
        p["dt_metadata_path"] = dt_out / "decision_tree_sf_tp_metadata.json"
        p["lr_model_path"] = lr_out / "logistic_regression_sf_tp.joblib"
        p["lr_metadata_path"] = lr_out / "logistic_regression_sf_tp_metadata.json"
    return p


def _dataset(feature_columns=None):
    """(X, y_sf, y_tp, groups, train_idx, test_idx) for the cached labeled CSV."""
    import pandas as pd
    from ml.training.dataset import build_dataset, context_aware_split

    p = _prepare()
    df = pd.read_csv(p["labeled"])
    X, y_sf, y_tp, groups, _ = build_dataset(df, feature_columns=feature_columns)
    tr, te = context_aware_split(groups, test_size=0.3, random_state=0)
    return X, y_sf, y_tp, groups, tr, te


# ---------------------------------------------------------------------------

def check_imports():
    print("[CHECK] Checkpoint 6 modules import correctly")
    try:
        from ml.training import train_random_forest  # noqa: F401
        from ml.evaluation import compare_candidates, timing  # noqa: F401
        from sklearn.ensemble import RandomForestClassifier  # noqa: F401
    except ImportError as e:
        print(f"  -> FAIL: could not import ({e})")
        return False
    print("  -> OK")
    return True


def check_feature_consistency_across_all_three_models():
    print("[CHECK] feature consistency: Random Forest, Decision Tree and "
          "Logistic Regression use the identical feature list")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.dataset import resolve_feature_columns
    from ml.training.train_random_forest import train

    p = _train_rf_default()
    _train_dt_lr()
    ok = True

    rf = load_bundle(str(p["rf_model_path"]))
    dt = load_bundle(str(p["dt_model_path"]))
    lr = load_bundle(str(p["lr_model_path"]))
    expected = resolve_feature_columns()

    for name, b in (("Random Forest", rf), ("Decision Tree", dt),
                    ("Logistic Regression", lr)):
        if list(b["feature_columns"]) != expected:
            print(f"  -> FAIL: {name} bundle's features differ from "
                  f"resolve_feature_columns()")
            ok = False
    if not (list(rf["feature_columns"]) == list(dt["feature_columns"])
            == list(lr["feature_columns"])):
        print("  -> FAIL: the three bundles do not share one feature list "
              "(order included)")
        ok = False

    if len(expected) != 8:
        print(f"  -> FAIL: expected 8 default features, got {len(expected)}")
        ok = False
    for token in ("success_rate", "retry", "rssi", "snr"):
        if not any(token in c for c in expected):
            print(f"  -> FAIL: feature set is missing a {token!r} feature")
            ok = False
    for banned_token in ("gps", "lat", "lon", "distance", "altitude", "location"):
        if any(banned_token in c.lower() for c in rf["feature_columns"]):
            print(f"  -> FAIL: feature set contains a contextual variable "
                  f"matching {banned_token!r}")
            ok = False

    # The fitted forests must actually expect that many inputs.
    for key in ("sf_model", "tp_model"):
        n_in = rf[key].n_features_in_
        if n_in != len(rf["feature_columns"]):
            print(f"  -> FAIL: {key} expects {n_in} inputs but the bundle "
                  f"lists {len(rf['feature_columns'])} features")
            ok = False
        if any(e.n_features_in_ != n_in for e in rf[key].estimators_):
            print(f"  -> FAIL: {key} contains trees with a different width")
            ok = False

    # --include-current-link widens the list identically for the forest.
    wide = p["tmp"] / "models_rf_wide"
    meta = train(str(p["labeled"]), str(wide), include_current_link=True)
    if meta["data"]["feature_columns"] != resolve_feature_columns(True):
        print("  -> FAIL: include_current_link feature list differs from "
              "resolve_feature_columns(True)")
        ok = False
    if len(meta["data"]["feature_columns"]) != 10:
        print("  -> FAIL: include_current_link should give 10 features")
        ok = False

    if ok:
        print(f"  -> OK ({len(expected)} shared causal features, identical order "
              f"across all three models; forests expect {len(expected)} inputs)")
    return ok


def check_default_configuration_is_small():
    print("[CHECK] the default Random Forest configuration is deliberately small")
    from ml.training import train_random_forest as t

    p = _train_rf_default()
    ok = True

    cfg = t.RandomForestConfig()
    if cfg.n_estimators > t.SMALL_FOREST_MAX_TREES or cfg.n_estimators > 20:
        print(f"  -> FAIL: default n_estimators={cfg.n_estimators} is not small")
        ok = False
    if cfg.max_depth is None or cfg.max_depth > 8:
        print(f"  -> FAIL: default max_depth={cfg.max_depth} is not limited")
        ok = False
    if cfg.min_samples_leaf < 2:
        print(f"  -> FAIL: default min_samples_leaf={cfg.min_samples_leaf} does "
              f"not control leaf size")
        ok = False
    if cfg.allow_large_forest:
        print("  -> FAIL: the large-forest override must be off by default")
        ok = False
    try:
        cfg.validate()
    except Exception as e:
        print(f"  -> FAIL: the default configuration fails its own validation ({e})")
        ok = False

    hp = p["rf_metadata"]["hyperparameters"]
    for key in ("n_estimators", "max_depth", "min_samples_leaf", "max_features",
                "bootstrap", "max_leaf_nodes", "random_state", "test_size"):
        if key not in hp:
            print(f"  -> FAIL: metadata hyperparameters is missing {key!r}")
            ok = False
    if p["rf_metadata"]["small_forest_guard"]["override_used"]:
        print("  -> FAIL: default run recorded a large-forest override")
        ok = False

    if ok:
        print(f"  -> OK (n_estimators={cfg.n_estimators}, max_depth="
              f"{cfg.max_depth}, min_samples_leaf={cfg.min_samples_leaf}, "
              f"max_features={cfg.max_features!r}; guard at "
              f"{t.SMALL_FOREST_MAX_TREES} trees / depth {t.SMALL_FOREST_MAX_DEPTH})")
    return ok


def check_training_records_forest_structure():
    print("[CHECK] training fits two forests and records structure, timings "
          "and model size")
    from sklearn.ensemble import RandomForestClassifier
    from ml.evaluation.evaluate import load_bundle

    p = _train_rf_default()
    meta = p["rf_metadata"]
    ok = True

    bundle = load_bundle(str(p["rf_model_path"]))
    for key in ("sf_model", "tp_model"):
        if not isinstance(bundle[key], RandomForestClassifier):
            print(f"  -> FAIL: bundle[{key!r}] is not a RandomForestClassifier")
            ok = False

    n_cfg = meta["hyperparameters"]["n_estimators"]
    depth_cfg = meta["hyperparameters"]["max_depth"]
    for forest_key, model_key in (("sf_forest", "sf_model"), ("tp_forest", "tp_model")):
        f = meta[forest_key]
        for field in ("n_trees", "n_estimators_configured", "max_depth_configured",
                      "actual_max_depth", "actual_mean_depth", "actual_min_depth",
                      "tree_depths", "tree_node_counts", "tree_leaf_counts",
                      "total_nodes", "total_leaves", "mean_nodes_per_tree",
                      "min_samples_leaf", "max_features_configured",
                      "max_features_resolved_per_split", "bootstrap",
                      "n_features_used_by_any_tree", "n_classes", "classes",
                      "training_seconds", "feature_importances"):
            if field not in f:
                print(f"  -> FAIL: {forest_key} is missing '{field}'")
                ok = False
        if ok:
            if f["n_trees"] != n_cfg or f["n_trees"] != len(bundle[model_key].estimators_):
                print(f"  -> FAIL: {forest_key} reports {f['n_trees']} trees, "
                      f"configured {n_cfg}, model has "
                      f"{len(bundle[model_key].estimators_)}")
                ok = False
            if f["actual_max_depth"] > depth_cfg:
                print(f"  -> FAIL: {forest_key} depth {f['actual_max_depth']} "
                      f"exceeds the configured cap {depth_cfg}")
                ok = False
            if len(f["tree_depths"]) != f["n_trees"] or len(f["tree_node_counts"]) != f["n_trees"]:
                print(f"  -> FAIL: {forest_key} per-tree lists do not match n_trees")
                ok = False
            if f["total_nodes"] != sum(f["tree_node_counts"]):
                print(f"  -> FAIL: {forest_key} total_nodes is not the sum of "
                      f"per-tree node counts")
                ok = False
            if f["total_leaves"] != sum(f["tree_leaf_counts"]):
                print(f"  -> FAIL: {forest_key} total_leaves is not the sum of "
                      f"per-tree leaf counts")
                ok = False
            if f["n_classes"] < 2:
                print(f"  -> FAIL: {forest_key} has fewer than 2 classes")
                ok = False
            if f["training_seconds"] <= 0:
                print(f"  -> FAIL: {forest_key} training time not measured")
                ok = False
            if abs(sum(f["feature_importances"].values()) - 1.0) > 1e-6:
                print(f"  -> FAIL: {forest_key} feature importances do not sum to 1")
                ok = False

    if meta["total_training_seconds"] <= 0:
        print("  -> FAIL: total training time not measured")
        ok = False
    mf = meta["model_file"]
    if not mf.get("bytes") or mf["bytes"] <= 0:
        print("  -> FAIL: model file size not recorded")
        ok = False
    elif mf["bytes"] != Path(p["rf_model_path"]).stat().st_size:
        print("  -> FAIL: recorded model size differs from the file on disk")
        ok = False
    it = meta["inference_timing"]
    if not it.get("measured") or it.get("per_row_microseconds") is None:
        print("  -> FAIL: inference time not measured")
        ok = False
    for field in ("batch_per_row_microseconds_all_models",
                  "single_decision_median_microseconds"):
        if it.get(field) is None or it[field] <= 0:
            print(f"  -> FAIL: inference timing is missing/invalid: {field}")
            ok = False
    if set(it.get("models_timed", [])) != {"sf", "tp"}:
        print("  -> FAIL: inference timing did not cover both SF and TP models")
        ok = False

    if ok:
        sf, tp = meta["sf_forest"], meta["tp_forest"]
        print(f"  -> OK (SF: {sf['n_trees']} trees, depth<= {sf['actual_max_depth']}, "
              f"{sf['total_nodes']} nodes; TP: {tp['n_trees']} trees, "
              f"depth<= {tp['actual_max_depth']}, {tp['total_nodes']} nodes; "
              f"{mf['kilobytes']} KB)")
    return ok


def check_hyperparameters_are_configurable_and_take_effect():
    print("[CHECK] every important hyperparameter is configurable and "
          "actually takes effect")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.train_random_forest import train

    p = _prepare()
    ok = True
    outdir = p["tmp"] / "models_rf_custom"
    meta = train(
        str(p["labeled"]), str(outdir),
        n_estimators=4, max_depth=3, min_samples_leaf=20,
        max_features=3, max_leaf_nodes=5, bootstrap=False, random_state=11,
    )
    bundle = load_bundle(str(outdir / "random_forest_sf_tp.joblib"))

    for key in ("sf_model", "tp_model"):
        clf = bundle[key]
        if len(clf.estimators_) != 4:
            print(f"  -> FAIL: {key} has {len(clf.estimators_)} trees, expected 4")
            ok = False
        for i, tree in enumerate(clf.estimators_):
            if tree.get_depth() > 3:
                print(f"  -> FAIL: {key} tree {i} depth {tree.get_depth()} > 3")
                ok = False
            if tree.get_n_leaves() > 5:
                print(f"  -> FAIL: {key} tree {i} has {tree.get_n_leaves()} "
                      f"leaves > max_leaf_nodes=5")
                ok = False
            leaves = tree.tree_.children_left == -1
            if tree.tree_.n_node_samples[leaves].min() < 20:
                print(f"  -> FAIL: {key} tree {i} has a leaf smaller than "
                      f"min_samples_leaf=20")
                ok = False
        if clf.estimators_[0].max_features_ != 3:
            print(f"  -> FAIL: {key} resolved max_features="
                  f"{clf.estimators_[0].max_features_}, expected 3")
            ok = False
        if clf.bootstrap:
            print(f"  -> FAIL: {key} still bootstraps despite bootstrap=False")
            ok = False

    hp = meta["hyperparameters"]
    if (hp["n_estimators"], hp["max_depth"], hp["min_samples_leaf"],
            hp["max_features"], hp["max_leaf_nodes"], hp["bootstrap"],
            hp["random_state"]) != (4, 3, 20, 3, 5, False, 11):
        print(f"  -> FAIL: metadata does not record the configuration used: {hp}")
        ok = False

    if ok:
        print("  -> OK (n_estimators, max_depth, min_samples_leaf, max_features, "
              "max_leaf_nodes, bootstrap, random_state all honoured and recorded)")
    return ok


def check_prediction():
    print("[CHECK] prediction: shapes, label set, probabilities, single-row, "
          "wrong-width rejection")
    import numpy as np
    from ml.evaluation.evaluate import load_bundle

    p = _train_rf_default()
    bundle = load_bundle(str(p["rf_model_path"]))
    X, y_sf, y_tp, groups, tr, te = _dataset(bundle["feature_columns"])
    ok = True

    sf, tp = bundle["sf_model"], bundle["tp_model"]
    sf_pred, tp_pred = sf.predict(X[te]), tp.predict(X[te])

    if sf_pred.shape != (len(te),) or tp_pred.shape != (len(te),):
        print(f"  -> FAIL: prediction shape wrong ({sf_pred.shape}, {tp_pred.shape})")
        ok = False
    if not set(np.unique(sf_pred)) <= set(np.unique(y_sf[tr])):
        print("  -> FAIL: predicted an SF never seen in training")
        ok = False
    if not set(np.unique(tp_pred)) <= set(np.unique(y_tp[tr])):
        print("  -> FAIL: predicted a TX power never seen in training")
        ok = False

    for name, model in (("sf", sf), ("tp", tp)):
        proba = model.predict_proba(X[te])
        if proba.shape != (len(te), len(model.classes_)):
            print(f"  -> FAIL: {name} predict_proba shape {proba.shape}")
            ok = False
        if not np.allclose(proba.sum(axis=1), 1.0):
            print(f"  -> FAIL: {name} probabilities do not sum to 1")
            ok = False
        if not np.array_equal(model.classes_[np.argmax(proba, axis=1)],
                              model.predict(X[te])):
            print(f"  -> FAIL: {name} predict() disagrees with argmax(predict_proba())")
            ok = False

    one = sf.predict(X[te][:1])
    if one.shape != (1,) or one[0] != sf_pred[0]:
        print("  -> FAIL: single-row prediction disagrees with batch prediction")
        ok = False

    for name, model in (("sf", sf), ("tp", tp)):
        try:
            model.predict(np.zeros((2, len(bundle["feature_columns"]) - 1)))
            print(f"  -> FAIL: {name} accepted input with the wrong number of features")
            ok = False
        except ValueError:
            pass

    if ok:
        print(f"  -> OK ({len(te)} held-out rows predicted; label sets, "
              f"probabilities and input-width guard all behave)")
    return ok


def check_model_saves_and_reloads():
    print("[CHECK] the saved bundle reloads via the UNMODIFIED Checkpoint 4 "
          "load_bundle() and predicts identically")
    import joblib
    import numpy as np
    from ml.evaluation.evaluate import load_bundle
    from ml.training.train_random_forest import compare_forests

    p = _train_rf_default()
    ok = True
    if not p["rf_model_path"].exists():
        print("  -> FAIL: model file was not written")
        return False
    if not p["rf_metadata_path"].exists():
        print("  -> FAIL: metadata JSON was not written")
        return False

    bundle = load_bundle(str(p["rf_model_path"]))
    for key in ("sf_model", "tp_model", "feature_columns", "sf_target",
                "tp_target", "model_family", "provenance", "trained_from",
                "forest_config"):
        if key not in bundle:
            print(f"  -> FAIL: bundle is missing '{key}'")
            ok = False

    # Independent loads agree with each other AND with a fresh in-process fit.
    X, y_sf, y_tp, groups, tr, te = _dataset(bundle["feature_columns"])
    again = load_bundle(str(p["rf_model_path"]))
    for key in ("sf_model", "tp_model"):
        res = compare_forests(bundle[key], again[key], X[te])
        if not res["passed"]:
            print(f"  -> FAIL: two loads of {key} differ: {res['problems']}")
            ok = False
        if not np.array_equal(bundle[key].predict_proba(X),
                              again[key].predict_proba(X)):
            print(f"  -> FAIL: {key} probabilities differ across loads (all rows)")
            ok = False

    # A model rebuilt from the recorded config on the training rows matches
    # the one saved to disk — save/reload lost nothing.
    from ml.training.train_random_forest import RandomForestConfig, _make_forest
    cfg = RandomForestConfig(**bundle["forest_config"])
    rebuilt = _make_forest(cfg).fit(X[tr], y_sf[tr])
    res = compare_forests(rebuilt, bundle["sf_model"], X[te])
    if not res["passed"]:
        print(f"  -> FAIL: forest rebuilt from the recorded config differs "
              f"from the saved one: {res['problems']}")
        ok = False

    with open(p["rf_metadata_path"], encoding="utf-8") as fh:
        on_disk = json.load(fh)
    if on_disk["model_file"]["bytes"] != Path(p["rf_model_path"]).stat().st_size:
        print("  -> FAIL: on-disk metadata size does not match the model file")
        ok = False

    if ok:
        print("  -> OK (reload deterministic; load_bundle() from Checkpoint 4 "
              "accepted a forest bundle unmodified; config round-trips)")
    return ok


def check_evaluate_script_accepts_rf_bundle():
    print("[CHECK] ml/evaluation/evaluate.py (Checkpoint 4, unmodified) works "
          "against a forest bundle and agrees with training-time metrics")
    from ml.evaluation.evaluate import evaluate
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _train_rf_default()
    ok = True
    try:
        result = evaluate(str(p["rf_model_path"]), str(p["labeled"]))
    except Exception as e:
        print(f"  -> FAIL: evaluate() raised on a forest bundle "
              f"({type(e).__name__}: {e})")
        return False

    if result["banner"] != SYNTHETIC_BANNER:
        print("  -> FAIL: evaluation result is not banner-stamped")
        ok = False

    # The standalone re-evaluation of the reloaded model must reproduce the
    # metrics computed at training time — the two stages agree.
    tm = p["rf_metadata"]["metrics"]
    em = result["metrics"]
    pairs = [
        ("SF accuracy", tm["spreading_factor"]["accuracy"], em["spreading_factor"]["accuracy"]),
        ("TP accuracy", tm["tx_power_dbm"]["accuracy"], em["tx_power_dbm"]["accuracy"]),
        ("joint accuracy", tm["joint"]["accuracy"], em["joint"]["accuracy"]),
        ("per-context joint", tm["per_context"]["joint_accuracy"], em["per_context"]["joint_accuracy"]),
    ]
    for name, a, b in pairs:
        if abs(a - b) > 1e-12:
            print(f"  -> FAIL: {name} differs between training ({a}) and "
                  f"standalone evaluation ({b})")
            ok = False

    if ok:
        print("  -> OK (evaluate() is model-family-agnostic; training-time and "
              "standalone metrics agree)")
    return ok


def check_metadata_completeness_and_non_claims():
    print("[CHECK] metadata carries every required field, the banner, "
          "tuned=False, and the Random-Forest non-claims")
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _train_rf_default()
    meta = p["rf_metadata"]
    ok = True

    for field in ("banner", "status", "checkpoint", "model_family", "tuned",
                  "tuning_note", "pipeline_stages", "environment", "data",
                  "split", "hyperparameters", "small_forest_guard",
                  "oob_score_used", "oob_score_note", "sf_forest", "tp_forest",
                  "total_training_seconds", "inference_timing", "model_file",
                  "reload_check", "reproducibility_check", "metrics",
                  "explicit_non_claims"):
        if field not in meta:
            print(f"  -> FAIL: metadata is missing '{field}'")
            ok = False

    if meta.get("banner") != SYNTHETIC_BANNER:
        print("  -> FAIL: metadata banner is wrong or missing")
        ok = False
    if SYNTHETIC_BANNER != "SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT":
        print("  -> FAIL: the shared banner text is not the required wording")
        ok = False
    if meta["metrics"].get("banner") != SYNTHETIC_BANNER:
        print("  -> FAIL: the metrics block is not banner-stamped")
        ok = False
    if meta.get("checkpoint") != "CP06":
        print("  -> FAIL: metadata does not record checkpoint CP06")
        ok = False
    if meta.get("tuned") is not False:
        print("  -> FAIL: metadata should record that the model is untuned")
        ok = False
    if "SOFTWARE PIPELINE VALIDATION ONLY" not in meta.get("status", ""):
        print("  -> FAIL: status does not say software validation only")
        ok = False

    text = " ".join(meta.get("explicit_non_claims", [])).lower()
    for phrase in ("packet delivery ratio", "latency", "energy consumption",
                   "adaptation", "real lora communication", "project success",
                   "decision tree", "logistic regression", "esp32", "ensemble"):
        if phrase not in text:
            print(f"  -> FAIL: explicit_non_claims does not mention {phrase!r}")
            ok = False

    for sub in ("spreading_factor", "tx_power_dbm"):
        m = meta["metrics"][sub]
        if "majority_class_baseline" not in m or not m.get("per_class") \
                or "confusion_matrix" not in m:
            print(f"  -> FAIL: {sub} metrics lack a baseline/per-class/confusion block")
            ok = False
    sf_acc = meta["metrics"]["spreading_factor"]["accuracy"]
    tp_acc = meta["metrics"]["tx_power_dbm"]["accuracy"]
    joint = meta["metrics"]["joint"]["accuracy"]
    if joint > min(sf_acc, tp_acc) + 1e-12:
        print("  -> FAIL: joint accuracy exceeds min(SF, TP), which is impossible")
        ok = False
    if meta["metrics"]["per_context"]["n_contexts"] != meta["split"]["test_contexts"]:
        print("  -> FAIL: per-context metric did not count the held-out contexts")
        ok = False

    with open(p["rf_metadata_path"], encoding="utf-8") as fh:
        on_disk = json.load(fh)
    if on_disk.get("banner") != SYNTHETIC_BANNER:
        print("  -> FAIL: on-disk metadata is not banner-stamped")
        ok = False

    if ok:
        print("  -> OK (all fields present, banner stamped, tuned=False, "
              "DT/LR/ESP32/ensemble non-claims present)")
    return ok


def check_reload_and_reproducibility_stages_and_tamper_tests():
    print("[CHECK] the pipeline's reload + reproducibility stages ran, and "
          "the comparison behind them can actually FAIL")
    import joblib
    from ml.training.train_random_forest import (
        RandomForestConfig, _make_forest, compare_forests, verify_reload,
        verify_reproducibility,
    )

    p = _train_rf_default()
    meta = p["rf_metadata"]
    ok = True

    stage_names = [s["stage"] for s in meta["pipeline_stages"]]
    for needed in ("load_labeled_csv_and_build_dataset", "context_aware_split",
                   "train_random_forest_x2", "evaluate_on_held_out_contexts",
                   "save_model", "reload_and_verify", "reproducibility_check"):
        if needed not in stage_names:
            print(f"  -> FAIL: pipeline stage {needed!r} was not recorded")
            ok = False
    if any(s["status"] != "done" for s in meta["pipeline_stages"]):
        print(f"  -> FAIL: not every stage completed: {meta['pipeline_stages']}")
        ok = False
    if stage_names != [
        "load_labeled_csv_and_build_dataset", "context_aware_split",
        "train_random_forest_x2", "evaluate_on_held_out_contexts",
        "save_model", "reload_and_verify", "reproducibility_check",
    ]:
        print("  -> FAIL: stages are not in the documented order "
              "(dataset -> split -> train -> evaluate -> save -> reload -> "
              "reproducibility)")
        ok = False

    for name in ("reload_check", "reproducibility_check"):
        c = meta[name]
        if not (c.get("performed") and c.get("passed") and not c.get("problems")):
            print(f"  -> FAIL: {name} did not pass: {c}")
            ok = False

    # --- Tamper tests: prove the checks are capable of failing -------------
    bundle = joblib.load(p["rf_model_path"])
    X, y_sf, y_tp, groups, tr, te = _dataset(bundle["feature_columns"])

    reordered = dict(bundle)
    reordered["feature_columns"] = list(reversed(bundle["feature_columns"]))
    r = verify_reload(p["rf_model_path"], reordered, X[te])
    if r["passed"] or not any("feature_columns" in x for x in r["problems"]):
        print("  -> FAIL: verify_reload did not detect a changed feature list")
        ok = False

    smaller = _make_forest(RandomForestConfig(n_estimators=3)).fit(X[tr], y_tp[tr])
    swapped = dict(bundle)
    swapped["tp_model"] = smaller
    r = verify_reload(p["rf_model_path"], swapped, X[te])
    if r["passed"] or not any("tree count" in x for x in r["problems"]):
        print("  -> FAIL: verify_reload did not detect a swapped-in smaller forest")
        ok = False

    same = compare_forests(bundle["sf_model"], bundle["sf_model"], X[te])
    if not same["passed"]:
        print("  -> FAIL: compare_forests says a forest differs from itself")
        ok = False

    y_bad = y_sf[tr].copy()
    y_bad[::2] = y_bad[0]  # rewrite half the labels
    different = _make_forest(RandomForestConfig()).fit(X[tr], y_bad)
    r = compare_forests(bundle["sf_model"], different, X[te])
    if r["passed"]:
        print("  -> FAIL: compare_forests did not detect a forest trained on "
              "different labels")
        ok = False

    r = verify_reproducibility(
        RandomForestConfig(random_state=99),  # not the seed the models used
        X[tr], y_sf[tr], y_tp[tr], bundle["sf_model"], bundle["tp_model"], X[te])
    # Same data, different seed: may or may not coincide on a tiny separable
    # fixture, so only require it returns a well-formed result.
    if "passed" not in r or "problems" not in r:
        print("  -> FAIL: verify_reproducibility returned a malformed result")
        ok = False
    cfg_same = RandomForestConfig(**bundle["forest_config"])
    r = verify_reproducibility(
        cfg_same, X[tr], y_sf[tr], y_tp[tr],
        bundle["sf_model"], bundle["tp_model"], X[te])
    if not r["passed"]:
        print(f"  -> FAIL: reproducibility check failed for the true config: "
              f"{r['problems']}")
        ok = False

    if ok:
        print("  -> OK (7 stages in order, both integrity checks passed; "
              "tamper tests confirm they can fail)")
    return ok


def check_no_save_mode():
    print("[CHECK] --no-save trains and reports without writing any file")
    from ml.training.train_random_forest import train

    p = _prepare()
    ok = True
    outdir = p["tmp"] / "no_save_out"
    meta = train(str(p["labeled"]), str(outdir), save_model=False)
    if outdir.exists():
        print("  -> FAIL: no-save run created the output directory")
        ok = False
    if meta["reload_check"].get("performed"):
        print("  -> FAIL: no-save run claims a reload check happened")
        ok = False
    statuses = {s["stage"]: s["status"] for s in meta["pipeline_stages"]}
    if not statuses["save_model"].startswith("skipped") \
            or not statuses["reload_and_verify"].startswith("skipped"):
        print(f"  -> FAIL: save/reload stages not marked skipped: {statuses}")
        ok = False
    if meta["model_file"]["bytes"] is not None:
        print("  -> FAIL: no-save run recorded a model file size")
        ok = False
    if ok:
        print("  -> OK (nothing written; save/reload honestly recorded as skipped)")
    return ok


def check_reproducibility():
    print("[CHECK] a fixed random_state gives a reproducible forest and metrics")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.train_random_forest import compare_forests, train

    p = _prepare()
    ok = True

    a = train(str(p["labeled"]), str(p["tmp"] / "rep_rf_a"), random_state=7)
    b = train(str(p["labeled"]), str(p["tmp"] / "rep_rf_b"), random_state=7)

    for path in (("split", "train_contexts"), ("split", "test_contexts"),
                 ("sf_forest", "tree_node_counts"), ("tp_forest", "tree_node_counts"),
                 ("sf_forest", "tree_depths"), ("tp_forest", "tree_depths"),
                 ("sf_forest", "feature_importances"),
                 ("tp_forest", "feature_importances")):
        if a[path[0]][path[1]] != b[path[0]][path[1]]:
            print(f"  -> FAIL: {'.'.join(path)} differed between identical runs")
            ok = False
    for path in (("joint", "accuracy"),):
        if a["metrics"][path[0]][path[1]] != b["metrics"][path[0]][path[1]]:
            print("  -> FAIL: joint accuracy differed between identical runs")
            ok = False
    for m in ("spreading_factor", "tx_power_dbm"):
        if a["metrics"][m]["confusion_matrix"] != b["metrics"][m]["confusion_matrix"]:
            print(f"  -> FAIL: {m} confusion matrix differed between identical runs")
            ok = False

    ba = load_bundle(str(p["tmp"] / "rep_rf_a" / "random_forest_sf_tp.joblib"))
    bb = load_bundle(str(p["tmp"] / "rep_rf_b" / "random_forest_sf_tp.joblib"))
    X, *_ = _dataset(ba["feature_columns"])
    for key in ("sf_model", "tp_model"):
        res = compare_forests(ba[key], bb[key], X)
        if not res["passed"]:
            print(f"  -> FAIL: {key} from two identical runs is not identical: "
                  f"{res['problems']}")
            ok = False

    if ok:
        print("  -> OK (identical seed reproduces split, structure, importances, "
              "confusion matrices and every prediction)")
    return ok


def check_leakage_protection_shared_guard():
    print("[CHECK] leakage protection: banned columns rejected, bundle clean, "
          "no context straddles the split")
    import pandas as pd
    from ml.evaluation.evaluate import load_bundle
    from ml.training.dataset import (
        BANNED_FEATURE_COLUMNS, FeatureLeakageError, build_dataset,
        resolve_feature_columns,
    )

    p = _train_rf_default()
    ok = True

    # Both entry points of the shared guard reject every banned column.
    df = pd.read_csv(p["labeled"])
    for col in BANNED_FEATURE_COLUMNS:
        try:
            resolve_feature_columns(extra=[col])
            print(f"  -> FAIL: resolve_feature_columns accepted banned {col!r}")
            ok = False
        except FeatureLeakageError:
            pass
        try:
            build_dataset(df, feature_columns=resolve_feature_columns() + [col])
            print(f"  -> FAIL: build_dataset accepted banned {col!r}")
            ok = False
        except FeatureLeakageError:
            pass

    # The saved forest contains none of them, and the features it was fit on
    # are exactly the causal set.
    bundle = load_bundle(str(p["rf_model_path"]))
    for col in bundle["feature_columns"]:
        if col in BANNED_FEATURE_COLUMNS:
            print(f"  -> FAIL: saved forest uses banned feature {col!r} — "
                  f"{BANNED_FEATURE_COLUMNS[col]}")
            ok = False
    for leaky in ("packet_success", "retry_count", "sf", "tp_dbm", "label_sf",
                  "label_tp_dbm", "context_id"):
        if leaky in bundle["feature_columns"]:
            print(f"  -> FAIL: {leaky!r} present in the forest's feature list")
            ok = False

    # The split recorded at training time has no shared context, and the
    # split can be reproduced independently with zero overlap.
    split = p["rf_metadata"]["split"]
    if split["context_overlap"] != 0 or split["split_by"] != "context_id":
        print(f"  -> FAIL: recorded split is not a clean context split: {split}")
        ok = False
    X, y_sf, y_tp, groups, tr, te = _dataset(bundle["feature_columns"])
    overlap = set(groups[tr].tolist()) & set(groups[te].tolist())
    if overlap:
        print(f"  -> FAIL: {len(overlap)} context(s) appear on both sides of the split")
        ok = False
    if (len(set(groups[tr].tolist())), len(set(groups[te].tolist()))) != \
            (split["train_contexts"], split["test_contexts"]):
        print("  -> FAIL: independently reproduced split differs from the recorded one")
        ok = False

    if ok:
        print(f"  -> OK ({len(BANNED_FEATURE_COLUMNS)} banned columns rejected at "
              f"both guard entry points; saved forest clean; "
              f"{split['train_contexts']}/{split['test_contexts']} contexts, "
              f"0 overlap)")
    return ok


def check_test_contexts_have_no_influence_on_the_model():
    print("[CHECK] leakage protection (behavioural): rewriting HELD-OUT contexts "
          "does not change the forest; rewriting TRAINING contexts does")
    import pandas as pd
    from ml.evaluation.evaluate import load_bundle
    from ml.training.dataset import resolve_feature_columns
    from ml.training.train_random_forest import compare_forests, train

    p = _prepare()
    ok = True
    cols = resolve_feature_columns()
    X, y_sf, y_tp, groups, tr, te = _dataset(cols)
    test_ctx = set(groups[te].tolist())
    train_ctx = set(groups[tr].tolist())

    base = train(str(p["labeled"]), str(p["tmp"] / "inv_base"))
    base_b = load_bundle(str(p["tmp"] / "inv_base" / "random_forest_sf_tp.joblib"))

    def rewritten(contexts, tag):
        df = pd.read_csv(p["labeled"])
        mask = df["context_id"].isin(contexts)
        for c in cols:
            df.loc[mask, c] = df.loc[mask, c] * 3.0 + 11.0
        df.loc[mask, "label_sf"] = 99
        df.loc[mask, "label_tp_dbm"] = -77
        path = p["tmp"] / f"inv_{tag}.csv"
        df.to_csv(path, index=False)
        meta = train(str(path), str(p["tmp"] / f"inv_{tag}_models"))
        b = load_bundle(str(p["tmp"] / f"inv_{tag}_models" / "random_forest_sf_tp.joblib"))
        return meta, b

    # (a) Rewrite ONLY the held-out contexts -> forest must be unchanged.
    meta_t, b_t = rewritten(test_ctx, "testctx")
    if meta_t["split"]["train_contexts"] != base["split"]["train_contexts"] \
            or meta_t["split"]["test_contexts"] != base["split"]["test_contexts"]:
        print("  -> FAIL: rewriting rows changed the context split itself")
        ok = False
    for key in ("sf_model", "tp_model"):
        res = compare_forests(base_b[key], b_t[key], X[tr])
        if not res["passed"]:
            print(f"  -> FAIL: {key} changed when only held-out contexts were "
                  f"rewritten — test-split content is influencing training: "
                  f"{res['problems']}")
            ok = False

    # (b) NEGATIVE CONTROL: rewrite the TRAINING contexts -> forest must
    # change, otherwise (a) proves nothing.
    _, b_r = rewritten(train_ctx, "trainctx")
    changed = [not compare_forests(base_b[k], b_r[k], X[tr])["passed"]
               for k in ("sf_model", "tp_model")]
    if not all(changed):
        print("  -> FAIL: negative control failed — rewriting training "
              "contexts did not change the forest, so this test is not "
              "sensitive enough to prove anything")
        ok = False

    if ok:
        print(f"  -> OK (rewriting {len(test_ctx)} held-out contexts left both "
              f"forests bit-identical; rewriting {len(train_ctx)} training "
              f"contexts changed them)")
    return ok


def check_no_oob_score():
    print("[CHECK] out-of-bag scoring is not used (optimistic under a "
          "row-bootstrap of context-grouped data)")
    from ml.evaluation.evaluate import load_bundle
    from ml.training.train_random_forest import (
        RandomForestConfig, _make_forest, train)

    p = _train_rf_default()
    ok = True
    bundle = load_bundle(str(p["rf_model_path"]))
    for key in ("sf_model", "tp_model"):
        if bundle[key].oob_score or hasattr(bundle[key], "oob_score_"):
            print(f"  -> FAIL: {key} was fit with out-of-bag scoring")
            ok = False
    if p["rf_metadata"]["oob_score_used"] is not False \
            or p["rf_metadata"]["hyperparameters"]["oob_score"] is not False:
        print("  -> FAIL: metadata does not record oob_score as unused")
        ok = False
    for key in ("sf_forest", "tp_forest"):
        if p["rf_metadata"][key]["oob_score_used"]:
            print(f"  -> FAIL: {key} stats report OOB scoring")
            ok = False
    if _make_forest(RandomForestConfig()).oob_score:
        print("  -> FAIL: _make_forest builds forests with oob_score enabled")
        ok = False
    if "out-of-bag" not in p["rf_metadata"]["oob_score_note"].lower():
        print("  -> FAIL: the metadata does not explain why OOB is not used")
        ok = False
    if ok:
        print("  -> OK (oob_score off everywhere; reason recorded in metadata)")
    return ok


def check_invalid_configuration_handling():
    print("[CHECK] invalid configurations are rejected clearly, and before any "
          "file is written")
    import numpy as np
    from ml.training import train_random_forest as t
    from ml.training.train_random_forest import (
        InvalidForestConfigError, RandomForestConfig, train)

    p = _prepare()
    ok = True

    bad = [
        ("n_estimators=0", dict(n_estimators=0)),
        ("n_estimators=-3", dict(n_estimators=-3)),
        ("n_estimators=2.5", dict(n_estimators=2.5)),
        ("n_estimators=True", dict(n_estimators=True)),
        ("n_estimators='10'", dict(n_estimators="10")),
        ("n_estimators=None", dict(n_estimators=None)),
        ("max_depth=0", dict(max_depth=0)),
        ("max_depth=-1", dict(max_depth=-1)),
        ("max_depth=2.5", dict(max_depth=2.5)),
        ("max_depth=True", dict(max_depth=True)),
        ("max_depth='5'", dict(max_depth="5")),
        ("max_depth=None (unlimited, no override)", dict(max_depth=None)),
        ("min_samples_leaf=0", dict(min_samples_leaf=0)),
        ("min_samples_leaf=1.5", dict(min_samples_leaf=1.5)),
        ("min_samples_leaf=True", dict(min_samples_leaf=True)),
        ("max_features='banana'", dict(max_features="banana")),
        ("max_features=0", dict(max_features=0)),
        ("max_features=-2", dict(max_features=-2)),
        ("max_features=1.5", dict(max_features=1.5)),
        ("max_features=0.0", dict(max_features=0.0)),
        ("max_features=True", dict(max_features=True)),
        ("max_features=[3]", dict(max_features=[3])),
        ("bootstrap='yes'", dict(bootstrap="yes")),
        ("bootstrap=1", dict(bootstrap=1)),
        ("max_leaf_nodes=1", dict(max_leaf_nodes=1)),
        ("max_leaf_nodes=2.5", dict(max_leaf_nodes=2.5)),
        ("random_state='a'", dict(random_state="a")),
        ("random_state=1.5", dict(random_state=1.5)),
        ("allow_large_forest='yes'", dict(allow_large_forest="yes")),
        ("large forest: n_estimators just over the guard",
         dict(n_estimators=t.SMALL_FOREST_MAX_TREES + 1)),
        ("large forest: n_estimators=500 (scikit-learn-ish default scale)",
         dict(n_estimators=500)),
        ("large forest: max_depth just over the guard",
         dict(max_depth=t.SMALL_FOREST_MAX_DEPTH + 1)),
    ]
    for label, kwargs in bad:
        try:
            RandomForestConfig(**kwargs).validate()
            print(f"  -> FAIL: {label} was accepted")
            ok = False
        except InvalidForestConfigError as e:
            if not str(e):
                print(f"  -> FAIL: {label} raised with an empty message")
                ok = False
        except Exception as e:
            print(f"  -> FAIL: {label} raised {type(e).__name__}, not "
                  f"InvalidForestConfigError")
            ok = False

    # The error type is a ValueError, so existing CLI/except paths handle it.
    if not issubclass(InvalidForestConfigError, ValueError):
        print("  -> FAIL: InvalidForestConfigError should subclass ValueError")
        ok = False

    good = [
        ("large forest with explicit override",
         dict(n_estimators=t.SMALL_FOREST_MAX_TREES + 1, allow_large_forest=True)),
        ("unlimited depth with explicit override",
         dict(max_depth=None, allow_large_forest=True)),
        ("guard boundary: exactly the max trees / depth",
         dict(n_estimators=t.SMALL_FOREST_MAX_TREES, max_depth=t.SMALL_FOREST_MAX_DEPTH)),
        ("max_features float 1.0", dict(max_features=1.0)),
        ("max_features float 0.5", dict(max_features=0.5)),
        ("max_features 'log2'", dict(max_features="log2")),
        ("max_features None (all features)", dict(max_features=None)),
        ("max_features int 3", dict(max_features=3)),
        ("max_leaf_nodes=4", dict(max_leaf_nodes=4)),
        ("numpy integer n_estimators", dict(n_estimators=np.int64(5))),
        ("bootstrap False", dict(bootstrap=False)),
    ]
    for label, kwargs in good:
        try:
            RandomForestConfig(**kwargs).validate()
        except Exception as e:
            print(f"  -> FAIL: valid config rejected ({label}): {e}")
            ok = False

    # Through train(): the same errors surface, and NOTHING is written.
    for label, kwargs in (
        ("n_estimators=0", dict(n_estimators=0)),
        ("max_depth=-4", dict(max_depth=-4)),
        ("max_features='nope'", dict(max_features="nope")),
        ("too-large forest", dict(n_estimators=500)),
        ("max_features=99 (> 8 features)", dict(max_features=99)),
        ("test_size=0", dict(test_size=0)),
        ("test_size=1", dict(test_size=1)),
        ("test_size=1.5", dict(test_size=1.5)),
        ("test_size=-0.2", dict(test_size=-0.2)),
        ("test_size='0.3'", dict(test_size="0.3")),
        ("test_size=True", dict(test_size=True)),
    ):
        outdir = p["tmp"] / "invalid_cfg_out"
        try:
            train(str(p["labeled"]), str(outdir), **kwargs)
            print(f"  -> FAIL: train() accepted an invalid configuration ({label})")
            ok = False
        except ValueError:
            pass
        except Exception as e:
            print(f"  -> FAIL: train() raised {type(e).__name__} for {label}, "
                  f"expected ValueError")
            ok = False
        if outdir.exists():
            print(f"  -> FAIL: train() wrote to {outdir} despite invalid "
                  f"configuration ({label})")
            ok = False

    # Bad DATA also fails loudly, not silently.
    try:
        train(str(p["processed"]), str(p["tmp"] / "bad_data_out"))  # unlabeled CSV
        print("  -> FAIL: an unlabeled CSV was accepted for training")
        ok = False
    except ValueError:
        pass
    try:
        train(str(p["tmp"] / "does_not_exist.csv"), str(p["tmp"] / "x_out"))
        print("  -> FAIL: a missing input file was accepted")
        ok = False
    except FileNotFoundError:
        pass

    if ok:
        print(f"  -> OK ({len(bad)} invalid and {len(good)} valid configurations "
              f"classified correctly; train() rejects early and writes nothing)")
    return ok


def check_cli_error_handling():
    print("[CHECK] the command line reports errors with exit code 1 and works "
          "on a valid run")
    from ml.evaluation.metrics import SYNTHETIC_BANNER
    from ml.training.train_random_forest import main

    p = _prepare()
    ok = True

    def run(argv):
        out, err = io.StringIO(), io.StringIO()
        code = 0
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                main(argv)
            except SystemExit as e:
                code = e.code
        return code, out.getvalue(), err.getvalue()

    lab = str(p["labeled"])
    out = str(p["tmp"] / "cli_out")

    for label, argv, expected in (
        ("n-estimators 0", ["--input", lab, "--outdir", out, "--n-estimators", "0"], 1),
        ("max-depth none w/o override", ["--input", lab, "--outdir", out, "--max-depth", "none"], 1),
        ("500 trees w/o override", ["--input", lab, "--outdir", out, "--n-estimators", "500"], 1),
        ("test-size 2", ["--input", lab, "--outdir", out, "--test-size", "2"], 1),
        ("missing input file", ["--input", str(p["tmp"] / "nope.csv"), "--outdir", out], 1),
        ("unparseable max-features", ["--input", lab, "--outdir", out, "--max-features", "banana"], 2),
    ):
        code, _, err = run(argv)
        if code != expected:
            print(f"  -> FAIL: {label}: exit code {code}, expected {expected}")
            ok = False
        if expected == 1 and "ERROR" not in err:
            print(f"  -> FAIL: {label}: no ERROR message on stderr")
            ok = False
    if Path(out).exists():
        print("  -> FAIL: a rejected command line still created the output directory")
        ok = False

    code, stdout, _ = run(["--input", lab, "--outdir", out, "--n-estimators", "6",
                           "--max-depth", "4", "--max-features", "0.5"])
    if code != 0:
        print(f"  -> FAIL: a valid command line exited with {code}")
        ok = False
    # Same contract as the Checkpoint 4/5 trainers' CLIs: the banner is
    # printed above and below the metadata. (The JSON body escapes the em
    # dash as \u2014, so its own "banner" fields are not literal matches.)
    if stdout.count(SYNTHETIC_BANNER) < 2 or not stdout.lstrip("=\n ").startswith(SYNTHETIC_BANNER):
        print("  -> FAIL: CLI output is not banner-stamped above and below "
              "the metadata")
        ok = False
    if stdout.count('"banner"') < 3:
        print("  -> FAIL: CLI JSON output lacks its banner fields")
        ok = False
    if not (Path(out) / "random_forest_sf_tp.joblib").exists():
        print("  -> FAIL: valid CLI run wrote no model file")
        ok = False

    code, stdout, _ = run(["--input", lab, "--n-estimators", "40",
                           "--allow-large-forest", "--no-save",
                           "--skip-reproducibility-check"])
    if code != 0:
        print(f"  -> FAIL: --allow-large-forest run exited with {code}")
        ok = False
    elif '"override_used": true' not in stdout:
        print("  -> FAIL: the large-forest override was not recorded in the output")
        ok = False

    if ok:
        print("  -> OK (rejections exit 1 with an ERROR; argparse rejection exits "
              "2; valid runs succeed and are banner-stamped; override recorded)")
    return ok


def check_three_way_comparison_identical_split():
    print("[CHECK] compare_candidates evaluates Decision Tree, Logistic "
          "Regression and Random Forest on an IDENTICAL held-out split")
    from ml.evaluation.compare_candidates import compare_three

    p = _train_rf_default()
    _train_dt_lr()
    ok = True

    try:
        result = compare_three(
            str(p["dt_model_path"]), str(p["dt_metadata_path"]),
            str(p["lr_model_path"]), str(p["lr_metadata_path"]),
            str(p["rf_model_path"]), str(p["rf_metadata_path"]),
            str(p["labeled"]),
        )
    except Exception as e:
        print(f"  -> FAIL: compare_three() raised ({type(e).__name__}: {e})")
        return False
    p["comparison"] = result

    keys = [c["key"] for c in result["candidates"]]
    if keys != ["dt", "lr", "rf"]:
        print(f"  -> FAIL: expected candidates dt, lr, rf; got {keys}")
        ok = False
    rows = {c["key"]: c["predictive"]["n_test_rows"] for c in result["candidates"]}
    if len(set(rows.values())) != 1 or min(rows.values()) == 0:
        print(f"  -> FAIL: candidates scored different/zero row counts: {rows}")
        ok = False
    if result["split"]["n_test_rows"] != next(iter(rows.values())):
        print("  -> FAIL: recorded held-out size differs from rows scored")
        ok = False
    if result["split"]["context_overlap"] != 0:
        print("  -> FAIL: comparison split has context overlap")
        ok = False
    if len(result["split"]["heldout_contexts"]) != result["split"]["test_contexts"]:
        print("  -> FAIL: held-out context list does not match test_contexts")
        ok = False

    for c in result["candidates"]:
        for f in ("sf_accuracy", "tp_accuracy", "joint_accuracy",
                  "sf_majority_baseline_accuracy", "tp_majority_baseline_accuracy"):
            if c["predictive"].get(f) is None:
                print(f"  -> FAIL: {c['key']} predictive is missing {f}")
                ok = False
        sw = c["software"]
        for f in ("training_seconds", "model_file_kilobytes",
                  "inference_batch_microseconds_per_row_sf_and_tp",
                  "inference_single_decision_median_microseconds"):
            if sw.get(f) is None or sw[f] <= 0:
                print(f"  -> FAIL: {c['key']} software cost is missing/invalid: {f}")
                ok = False
        if c["model_family"] == "unknown":
            print(f"  -> FAIL: {c['key']} model family resolved to 'unknown'")
            ok = False
        if sw.get("tuned") is not False:
            print(f"  -> FAIL: {c['key']} is not recorded as untuned")
            ok = False

    rf = next(c for c in result["candidates"] if c["key"] == "rf")
    if rf["structure"]["kind"] != "forest" or rf["structure"]["n_trees"] != [10, 10]:
        print(f"  -> FAIL: forest structure not reported correctly: {rf['structure']}")
        ok = False
    dt = next(c for c in result["candidates"] if c["key"] == "dt")
    if dt["structure"]["kind"] != "tree":
        print("  -> FAIL: tree structure not reported for the Decision Tree")
        ok = False
    lr = next(c for c in result["candidates"] if c["key"] == "lr")
    if lr["structure"]["kind"] != "linear":
        print("  -> FAIL: linear structure not reported for Logistic Regression")
        ok = False

    if ok:
        n = next(iter(rows.values()))
        print(f"  -> OK ({n} identical held-out rows scored for all 3 models; "
              f"structure, baselines and software cost reported)")
    return ok


def check_comparison_refusals():
    print("[CHECK] compare_candidates refuses mismatched features, duplicate "
          "keys and fewer than 2 models")
    from ml.evaluation.compare_candidates import Candidate, compare_candidates
    from ml.training.train_random_forest import train

    p = _train_rf_default()
    _train_dt_lr()
    ok = True

    dt = Candidate("dt", "Decision Tree", str(p["dt_model_path"]), str(p["dt_metadata_path"]))
    rf = Candidate("rf", "Small Random Forest", str(p["rf_model_path"]), str(p["rf_metadata_path"]))

    # Forest trained WITH current-link features -> feature list differs.
    wide = p["tmp"] / "models_rf_wide"
    if not (wide / "random_forest_sf_tp.joblib").exists():
        train(str(p["labeled"]), str(wide), include_current_link=True)
    rf_wide = Candidate("rf", "Wide Random Forest",
                        str(wide / "random_forest_sf_tp.joblib"),
                        str(wide / "random_forest_sf_tp_metadata.json"))
    try:
        compare_candidates([dt, rf_wide], str(p["labeled"]))
        print("  -> FAIL: accepted candidates trained on different feature sets")
        ok = False
    except ValueError as e:
        if "different feature sets" not in str(e):
            print(f"  -> FAIL: wrong error for mismatched features: {e}")
            ok = False

    try:
        compare_candidates([rf, Candidate("rf", "again", rf.model_path, rf.metadata_path)],
                           str(p["labeled"]))
        print("  -> FAIL: accepted duplicate candidate keys")
        ok = False
    except ValueError:
        pass

    try:
        compare_candidates([rf], str(p["labeled"]))
        print("  -> FAIL: accepted a single-candidate 'comparison'")
        ok = False
    except ValueError:
        pass
    try:
        compare_candidates([], str(p["labeled"]))
        print("  -> FAIL: accepted an empty comparison")
        ok = False
    except ValueError:
        pass

    if ok:
        print("  -> OK (mismatched features, duplicate keys, <2 candidates all refused)")
    return ok


def check_comparison_report_banner_and_non_claims():
    print("[CHECK] the three-way comparison report carries the banner and "
          "every required non-claim")
    from ml.evaluation.compare_candidates import (
        NO_SUPERIORITY_CLAIM_MULTI, main, render_markdown_report)
    from ml.evaluation.metrics import SYNTHETIC_BANNER

    p = _train_rf_default()
    _train_dt_lr()
    comparison = p.get("comparison")
    if not comparison:
        print("  -> FAIL: no comparison result from the earlier check")
        return False

    report = render_markdown_report(comparison)
    ok = True

    if report.count(SYNTHETIC_BANNER) < 3:
        print(f"  -> FAIL: banner appears only {report.count(SYNTHETIC_BANNER)} "
              f"time(s); expected at least 3")
        ok = False
    if NO_SUPERIORITY_CLAIM_MULTI not in report:
        print("  -> FAIL: the no-superiority claim is missing from the report")
        ok = False
    for phrase in ("better than any other", "packet delivery ratio", "latency",
                   "energy consumption", "adaptation", "real LoRa communication",
                   "project success", "ESP32", "ensemble",
                   "Decision Tree", "Logistic Regression", "Small Random Forest",
                   "trivially separable", "not ESP32 figures"):
        if phrase.lower() not in report.lower():
            print(f"  -> FAIL: report does not contain {phrase!r}")
            ok = False
    for word in ("winner", "best model", "we recommend", "outperforms"):
        if word in report.lower():
            print(f"  -> FAIL: report contains superiority language: {word!r}")
            ok = False

    # The CLI path writes the same content and JSON.
    p2 = p["tmp"]
    md, js = p2 / "cmp3.md", p2 / "cmp3.json"
    out, err = io.StringIO(), io.StringIO()
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            main([
                "--dt-model", str(p["dt_model_path"]), "--dt-metadata", str(p["dt_metadata_path"]),
                "--lr-model", str(p["lr_model_path"]), "--lr-metadata", str(p["lr_metadata_path"]),
                "--rf-model", str(p["rf_model_path"]), "--rf-metadata", str(p["rf_metadata_path"]),
                "--input", str(p["labeled"]), "--report", str(md), "--json", str(js),
            ])
    except SystemExit as e:
        print(f"  -> FAIL: comparison CLI exited {e.code}: {err.getvalue()}")
        return False
    if not md.exists() or not js.exists():
        print("  -> FAIL: comparison CLI did not write the report/JSON")
        ok = False
    else:
        if md.read_text(encoding="utf-8").count(SYNTHETIC_BANNER) < 3:
            print("  -> FAIL: the CLI-written report is not banner-stamped")
            ok = False
        if json.loads(js.read_text(encoding="utf-8")).get("banner") != SYNTHETIC_BANNER:
            print("  -> FAIL: the CLI-written JSON is not banner-stamped")
            ok = False

    # A mismatched-feature comparison exits non-zero from the CLI too.
    err2 = io.StringIO()
    code = 0
    wide = p["tmp"] / "models_rf_wide"
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(err2):
        try:
            main([
                "--dt-model", str(p["dt_model_path"]), "--dt-metadata", str(p["dt_metadata_path"]),
                "--lr-model", str(p["lr_model_path"]), "--lr-metadata", str(p["lr_metadata_path"]),
                "--rf-model", str(wide / "random_forest_sf_tp.joblib"),
                "--rf-metadata", str(wide / "random_forest_sf_tp_metadata.json"),
                "--input", str(p["labeled"]),
            ])
        except SystemExit as e:
            code = e.code
    if code != 1 or "different feature sets" not in err2.getvalue():
        print(f"  -> FAIL: CLI did not refuse a mismatched-feature comparison "
              f"(exit {code})")
        ok = False

    if ok:
        print(f"  -> OK (banner x{report.count(SYNTHETIC_BANNER)}, no-superiority "
              f"claim, all disclaimers, no winner language; CLI works and refuses "
              f"mismatches)")
    return ok


def check_previous_pipelines_preserved():
    print("[CHECK] Checkpoint 4/5 pipelines are preserved: forest training "
          "does not alter their models, and the CP5 two-model comparison "
          "still works")
    from ml.evaluation.compare_models import compare as compare_two
    from ml.training.train_decision_tree import train as train_dt
    from ml.training.train_logistic_regression import train as train_lr
    from ml.training.train_random_forest import train as train_rf

    p = _prepare()
    ok = True

    shared = p["tmp"] / "models_all_three"
    train_dt(str(p["labeled"]), str(shared))
    train_lr(str(p["labeled"]), str(shared))
    before = {n: _sha(shared / n) for n in (
        "decision_tree_sf_tp.joblib", "decision_tree_sf_tp_metadata.json",
        "logistic_regression_sf_tp.joblib", "logistic_regression_sf_tp_metadata.json")}

    train_rf(str(p["labeled"]), str(shared))
    for n, digest in before.items():
        if _sha(shared / n) != digest:
            print(f"  -> FAIL: training the forest modified {n}")
            ok = False
    for n in ("random_forest_sf_tp.joblib", "random_forest_sf_tp_metadata.json"):
        if not (shared / n).exists():
            print(f"  -> FAIL: {n} was not written next to the other models")
            ok = False
    if len(list(shared.iterdir())) != 6:
        print(f"  -> FAIL: expected exactly 6 files (3 models x bundle+metadata), "
              f"found {sorted(x.name for x in shared.iterdir())}")
        ok = False

    try:
        result = compare_two(
            str(shared / "decision_tree_sf_tp.joblib"),
            str(shared / "decision_tree_sf_tp_metadata.json"),
            str(shared / "logistic_regression_sf_tp.joblib"),
            str(shared / "logistic_regression_sf_tp_metadata.json"),
            str(p["labeled"]))
        if "decision_tree" not in result or "logistic_regression" not in result:
            print("  -> FAIL: the CP5 two-model comparison returned an unexpected shape")
            ok = False
    except Exception as e:
        print(f"  -> FAIL: the CP5 two-model comparison broke "
              f"({type(e).__name__}: {e})")
        ok = False

    # The earlier metadata still describe their own checkpoints.
    if p["dt_metadata"]["checkpoint"] != "CP04" or p["lr_metadata"]["checkpoint"] != "CP05":
        print("  -> FAIL: an earlier model's metadata no longer names its own checkpoint")
        ok = False

    if ok:
        print("  -> OK (DT/LR files byte-identical after forest training; CP5 "
              "two-model compare_models.compare() unchanged and working)")
    return ok


def check_documentation_updated():
    print("[CHECK] README.md, PROJECT_STATUS.md and CHANGELOG.md were updated "
          "for Checkpoint 6")
    ok = True
    docs = {n: (PROJECT_ROOT / n).read_text(encoding="utf-8")
            for n in ("README.md", "PROJECT_STATUS.md", "CHANGELOG.md")}

    for name, text in docs.items():
        for needle in ("Checkpoint 6", "Random Forest", "train_random_forest",
                       "SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT"):
            if needle not in text:
                print(f"  -> FAIL: {name} does not mention {needle!r}")
                ok = False

    status = docs["PROJECT_STATUS.md"]
    for needle in (
        "LoRa_EdgeAI_CP06_RandomForest_Comparison.zip",
        "Checkpoint 7", "Real Hardware Data Collection",
        "Instructions for a New Claude",
        "Files created", "Files modified",
        "Hardware status", "Real-data status",
        "software validation only",
        "Decision Tree", "Logistic Regression", "Random Forest",
    ):
        if needle.lower() not in status.lower():
            print(f"  -> FAIL: PROJECT_STATUS.md is missing {needle!r}")
            ok = False
    for cp in ("CP01", "CP02", "CP03", "CP04", "CP05", "CP06"):
        if cp not in status:
            print(f"  -> FAIL: PROJECT_STATUS.md does not state {cp} status")
            ok = False
    if "not started" not in status.lower():
        print("  -> FAIL: PROJECT_STATUS.md does not say CP07 has not started")
        ok = False

    if ok:
        print("  -> OK (all three documents updated; status file covers CP01-CP06, "
              "candidates, files, hardware/real-data status and next checkpoint)")
    return ok


def check_no_pollution_of_real_data_dirs():
    print("[CHECK] real data/ directories and ml/models/ remain untouched by "
          "this test run")
    ok = True
    for sub in ["raw", "processed", "sample"]:
        d = PROJECT_ROOT / "data" / sub
        contents = [x.name for x in d.iterdir()] if d.exists() else []
        unexpected = [c for c in contents if c not in (".gitkeep", "README.md")]
        if unexpected:
            print(f"  -> FAIL: data/{sub}/ contains unexpected files: {unexpected}")
            ok = False
    stray = [x.name for x in (PROJECT_ROOT / "ml" / "models").iterdir()
             if x.name not in (".gitkeep", "README.md")]
    if stray:
        print(f"  -> FAIL: ml/models/ contains stray artifacts: {stray}")
        ok = False
    if ok:
        print("  -> OK (data/ and ml/models/ clean; test output went to a temp dir)")
    return ok


def main():
    print("=" * 70)
    print("LoRa Edge-AI — Checkpoint 6 Small Random Forest & Comparison Verification")
    print("SOFTWARE VALIDATION ONLY — synthetic data, no research results")
    print("SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT")
    print("=" * 70)

    checks = [
        check_imports,
        check_feature_consistency_across_all_three_models,
        check_default_configuration_is_small,
        check_training_records_forest_structure,
        check_hyperparameters_are_configurable_and_take_effect,
        check_prediction,
        check_model_saves_and_reloads,
        check_evaluate_script_accepts_rf_bundle,
        check_metadata_completeness_and_non_claims,
        check_reload_and_reproducibility_stages_and_tamper_tests,
        check_no_save_mode,
        check_reproducibility,
        check_leakage_protection_shared_guard,
        check_test_contexts_have_no_influence_on_the_model,
        check_no_oob_score,
        check_invalid_configuration_handling,
        check_cli_error_handling,
        check_three_way_comparison_identical_split,
        check_comparison_refusals,
        check_comparison_report_banner_and_non_claims,
        check_previous_pipelines_preserved,
        check_documentation_updated,
        check_no_pollution_of_real_data_dirs,
    ]

    try:
        results = [check() for check in checks]
    finally:
        _cleanup()

    print("=" * 70)
    if all(results):
        print("ALL CHECKS PASSED")
        print("The small Random Forest training/comparison pipeline executes end to end.")
        print("This is SOFTWARE VALIDATION ONLY — no real data, no research result.")
        print("=" * 70)
        sys.exit(0)
    else:
        failed = [c.__name__ for c, r in zip(checks, results) if not r]
        print(f"SOME CHECKS FAILED: {failed}")
        print("=" * 70)
        sys.exit(1)


if __name__ == "__main__":
    main()
