"""
generate_comparison_report.py

Checkpoint 7 — Full Model Comparison and Selection Framework report
generator. Ties together, without modifying any of them:

  * ml.evaluation.compare_candidates  (Checkpoint 6, unmodified) — predictive
    performance, software cost, structure, on an identical held-out split
  * ml.evaluation.evaluate            (Checkpoint 4, unmodified) — re-called
    once per candidate, on the SAME split, purely to surface the confusion
    matrices that compare_candidates()'s distilled view does not carry
    forward
  * ml.evaluation.context_stability   (Checkpoint 7) — per-held-out-context
    joint accuracy on the SAME split, for the stability/generalisation factor
  * ml.evaluation.resource_profile    (Checkpoint 7) — resource-only view +
    qualitative embedded-suitability labels
  * ml.evaluation.decision_framework  (Checkpoint 7) — configurable per-factor
    scoring that NEVER selects a model

*** SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT. ***
Every number anywhere in the generated report comes from the fabricated
pipeline fixture (or whatever labeled CSV is passed in) run through desktop
scikit-learn. The report is split into two clearly separated sections,
required by the checkpoint's scope:

  "A. SYNTHETIC SOFTWARE-VALIDATION RESULTS"     — everything this project
                                                     has ever produced
  "B. REAL HARDWARE RESULTS — NOT YET AVAILABLE" — a fixed placeholder
                                                     section. It contains NO
                                                     numbers, because none
                                                     exist. It exists so the
                                                     report has a place for
                                                     real numbers to go once
                                                     the next checkpoint's
                                                     (CP08) hardware data
                                                     collection happens —
                                                     see PROJECT_STATUS.md
                                                     section 8. Filling it
                                                     in is explicitly NOT
                                                     this checkpoint's job.

A third section, "C. Decision Framework", reports the six-factor
comparison from decision_framework.py and its fixed TBD selection status.

Usage:
    python -m ml.evaluation.generate_comparison_report \\
        --dt-model    ml/models/decision_tree_sf_tp.joblib \\
        --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \\
        --lr-model    ml/models/logistic_regression_sf_tp.joblib \\
        --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \\
        --rf-model    ml/models/random_forest_sf_tp.joblib \\
        --rf-metadata ml/models/random_forest_sf_tp_metadata.json \\
        --input       <labeled.csv> \\
        --report      comparison_framework_report.md
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional

from .compare_candidates import Candidate, compare_candidates
from .context_stability import per_context_stability
from .decision_framework import FactorWeights, select_candidate
from .evaluate import evaluate
from .metrics import SYNTHETIC_BANNER, SYNTHETIC_BANNER_LONG
from .resource_profile import (
    SuitabilityThresholds, build_resource_profile, count_model_parameters,
)

#: Fixed placeholder for Section B. No numeric field anywhere in this dict —
#: that is enforced by tests/test_model_comparison_framework.py.
REAL_HARDWARE_PLACEHOLDER = {
    "status": "NOT YET AVAILABLE",
    "note": (
        "No ESP32 + SX1278 hardware has been used in this project. No "
        "packet has been transmitted, no RSSI/SNR has been measured from a "
        "real radio, and no model has been trained or evaluated on real "
        "data. data/raw/, data/processed/ and data/sample/ contain only "
        "README.md/.gitkeep."
    ),
    "blocking_work": (
        "Real ESP32 + SX1278 data collection per "
        "experiments/DATA_COLLECTION_PLAN.md, including its section 4a "
        "sweep requirements, is required before this section can contain "
        "any number. See PROJECT_STATUS.md section 8, 'Next Checkpoint'."
    ),
    "what_will_go_here_once_available": [
        "Real predictive performance (accuracy, macro F1, confusion "
        "matrices, joint exact match) on held-out real channel contexts.",
        "Measured ESP32 model size/footprint after export (ml/export/ is "
        "currently empty).",
        "Measured on-device inference latency (esp32/ is currently empty).",
        "Measured energy consumption per decision, once a supply-current "
        "table exists.",
        "A genuine model selection, made only once the above exist.",
    ],
}


def build_full_comparison(
    dt_model_path: str, dt_metadata_path: str,
    lr_model_path: str, lr_metadata_path: str,
    rf_model_path: str, rf_metadata_path: str,
    input_path: str,
    test_size: float = 0.3,
    random_state: int = 0,
    weights: Optional[FactorWeights] = None,
    thresholds: Optional[SuitabilityThresholds] = None,
) -> Dict:
    """Assemble the complete Checkpoint 7 comparison-and-selection result."""
    candidates = [
        Candidate("dt", "Decision Tree", dt_model_path, dt_metadata_path),
        Candidate("lr", "Logistic Regression", lr_model_path, lr_metadata_path),
        Candidate("rf", "Small Random Forest", rf_model_path, rf_metadata_path),
    ]

    comparison = compare_candidates(
        candidates, input_path, test_size=test_size, random_state=random_state)

    # Re-call the unmodified evaluate() once per candidate, on the identical
    # split (same test_size/random_state), purely for confusion matrices —
    # which compare_candidates()'s distilled `_predictive()` view does not
    # carry forward — and break each candidate's predictions down by held-out
    # context for the stability factor. Nothing is retrained.
    confusion_matrices: Dict[str, Dict] = {}
    context_stability: Dict[str, Dict] = {}
    for c in candidates:
        r = evaluate(c.model_path, input_path, test_size=test_size,
                     random_state=random_state)
        confusion_matrices[c.key] = {
            "spreading_factor": r["metrics"]["spreading_factor"]["confusion_matrix"],
            "tx_power_dbm": r["metrics"]["tx_power_dbm"]["confusion_matrix"],
        }
        context_stability[c.key] = per_context_stability(
            c.model_path, input_path, test_size=test_size,
            random_state=random_state)

    parameter_counts = {c.key: count_model_parameters(c.model_path)
                        for c in candidates}
    resource = build_resource_profile(
        comparison, thresholds=thresholds, parameter_counts=parameter_counts)
    decision = select_candidate(
        comparison, resource, context_stability, weights=weights)

    return {
        "checkpoint": "CP07",
        "banner": SYNTHETIC_BANNER,
        "comparison": comparison,
        "confusion_matrices": confusion_matrices,
        "context_stability": context_stability,
        "resource_profile": resource,
        "decision_framework": decision,
        "real_hardware_results": REAL_HARDWARE_PLACEHOLDER,
    }


def _fmt(v, spec: str) -> str:
    return "n/a" if v is None else format(v, spec)


def _label(v) -> str:
    """7.0 -> '7' so class labels read naturally; other values unchanged."""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def _render_confusion(cm: Dict) -> List[str]:
    labels = [_label(l) for l in cm["labels"]]
    rows = cm["rows_are_true_cols_are_predicted"]
    lines = []
    lines.append("| true \\ pred | " + " | ".join(labels) + " |")
    lines.append("|---|" + "---|" * len(labels))
    for lab, row in zip(labels, rows):
        lines.append(f"| **{lab}** | " + " | ".join(str(x) for x in row) + " |")
    return lines


def render_markdown_report(full: Dict, include_illustrative: bool = False) -> str:
    lines: List[str] = []
    a = lines.append
    comparison = full["comparison"]
    cands = comparison["candidates"]
    labels = [c["label"] for c in cands]

    def row(name: str, values: List[str]) -> None:
        a("| " + name + " | " + " | ".join(values) + " |")

    def header(first: str) -> None:
        a("| " + first + " | " + " | ".join(labels) + " |")
        a("|---|" + "---|" * len(labels))

    a("# Checkpoint 7 — Model Comparison and Selection Framework")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")
    for para in SYNTHETIC_BANNER_LONG.split("\n\n")[1:]:
        a("> " + para.replace("\n", " "))
        a(">")
    a("")
    a("This report is split into three sections: (A) everything this "
      "project's software pipeline has ever produced, all of it synthetic; "
      "(B) a fixed placeholder for real hardware results, which do not yet "
      "exist; and (C) a six-factor decision framework whose final selection "
      "status is fixed to TBD regardless of any score below.")
    a("")
    a("---")
    a("")

    # ================= Section A =================
    a("## A. SYNTHETIC SOFTWARE-VALIDATION RESULTS")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")
    a("### A.1 What was compared")
    a("")
    for i, c in enumerate(cands):
        a(f"- **{c['label']}** — {c['model_family']} (recorded by {c['checkpoint']})")
    a(f"- **Input:** `{comparison['input_path']}`")
    a(f"- **Features (identical for all):** {comparison['feature_columns']}")
    s = comparison["split"]
    a(f"- **Split:** {s['train_contexts']} train / {s['test_contexts']} test "
      f"contexts, {s['context_overlap']} context overlap, {s['n_test_rows']} "
      f"held-out rows (`test_size={s['test_size']}`, "
      f"`random_state={s['random_state']}`, split by `{s['split_by']}`).")
    a("")

    a("### A.2 Predictive performance (SF and TX-power classification metrics)")
    a("")
    a("> " + SYNTHETIC_BANNER)
    a("")
    header("Metric")
    for name, key in (
        ("SF accuracy", "sf_accuracy"),
        ("SF majority-class baseline", "sf_majority_baseline_accuracy"),
        ("SF macro F1", "sf_macro_f1"),
        ("TX power accuracy", "tp_accuracy"),
        ("TX power majority-class baseline", "tp_majority_baseline_accuracy"),
        ("TX power macro F1", "tp_macro_f1"),
        ("Joint exact match (both SF and TP correct)", "joint_accuracy"),
        ("Per-context joint accuracy", "per_context_joint_accuracy"),
    ):
        row(name, [f"{c['predictive'][key]:.4f}" for c in cands])
    row("Test rows scored", [str(c["predictive"]["n_test_rows"]) for c in cands])
    a("")
    a("> No column being higher than another is evidence of which model is "
      "better for LoRa. Only " + str(s["test_contexts"]) + " held-out "
      "contexts exist, and the fixture is separable by construction.")
    a("")

    a("**Consistency across held-out contexts (joint SF+TP row accuracy per "
      "context):**")
    a("")
    header("Statistic")
    cs = full["context_stability"]
    for name, key in (
        ("Worst context (used by the stability factor)", "worst_context_joint_accuracy"),
        ("Mean over contexts", "mean_context_joint_accuracy"),
        ("Std. deviation over contexts", "std_context_joint_accuracy"),
        ("Best context", "best_context_joint_accuracy"),
    ):
        row(name, [_fmt(cs[c["key"]][key], ".4f") for c in cands])
    row("Held-out contexts", [str(cs[c["key"]]["n_contexts"]) for c in cands])
    a("")
    a("> " + cs[cands[0]["key"]]["caveat"])
    a("")

    a("### A.3 Confusion matrices (held-out split)")
    a("")
    for c in cands:
        cm = full["confusion_matrices"][c["key"]]
        a(f"**{c['label']} — Spreading Factor**")
        a("")
        lines_sf = _render_confusion(cm["spreading_factor"])
        for l in lines_sf:
            a(l)
        a("")
        a(f"**{c['label']} — TX Power**")
        a("")
        lines_tp = _render_confusion(cm["tx_power_dbm"])
        for l in lines_tp:
            a(l)
        a("")
    a("> Rows are the true label, columns are the predicted label, on the "
      "same held-out split as A.2.")
    a("")

    a("### A.4 Computational / resource characteristics")
    a("")
    header("Metric")
    row("Training time, SF+TP (s)",
        [_fmt(c["software"]["training_seconds"], ".6f") for c in cands])
    row("Model file size (KB)",
        [_fmt(c["software"]["model_file_kilobytes"], "") for c in cands])
    row("Inference, batch, SF+TP (µs/row)",
        [_fmt(c["software"]["inference_batch_microseconds_per_row_sf_and_tp"], ".2f")
         for c in cands])
    row("Inference, one full decision, median (µs)",
        [_fmt(c["software"]["inference_single_decision_median_microseconds"], ".1f")
         for c in cands])
    row("Hyperparameters tuned",
        [str(c["software"]["tuned"]) for c in cands])
    a("")

    def _pair(c, k):
        v = c["structure"][k]
        return "n/a (linear model)" if v is None else f"{v[0]} / {v[1]}"
    a("> Timing figures are measured on the machine that generated this "
      "report and vary from run to run; size/latency class labels derived "
      "from them can change between runs, especially near a threshold.")
    a("")
    a("**Model complexity / structure (SF / TX power):**")
    a("")
    header("Property")
    row("Trees per target", [_pair(c, "n_trees") for c in cands])
    row("Max tree depth", [_pair(c, "max_depth") for c in cands])
    row("Total nodes", [_pair(c, "total_nodes") for c in cands])
    a("")

    rp = full["resource_profile"]["candidates"]

    def _count(c, field):
        pc = rp[c["key"]]["parameter_counts"]
        sf = pc["spreading_factor"][field]
        tp = pc["tx_power_dbm"][field]
        return "n/a" if sf is None and tp is None else f"{sf} / {tp}"
    a("**Fitted parameters / structures read from the saved models "
      "(SF / TX power):**")
    a("")
    header("Property")
    row("Linear parameters (coefficients + intercepts)",
        [_count(c, "linear_parameters") for c in cands])
    row("Preprocessing parameters (scaler mean + scale)",
        [_count(c, "preprocessing_parameters") for c in cands])
    row("Tree nodes (all trees)", [_count(c, "tree_nodes") for c in cands])
    a("")
    a("> " + rp[cands[0]["key"]]["parameter_counts"]["note"])
    a("")

    a("**Estimated embedded suitability (desktop-proxy labels — see caveat):**")
    a("")
    header("Property")
    row("Model size class", [rp[c["key"]]["size_class"] for c in cands])
    row("Latency class", [rp[c["key"]]["latency_class"] for c in cands])
    a("")
    a("> " + full["resource_profile"]["caveat"])
    a("> " + full["resource_profile"]["thresholds_note"])
    a("")

    a("### A.5 Reproducibility")
    a("")
    a("All three candidates were trained from the SAME labeled CSV, the SAME "
      "preprocessing pipeline (`ml/preprocessing/`), the SAME labeling "
      "framework (`ml/labeling/`), the SAME 8 causal rolling-history "
      "features (RSSI, SNR, packet success/failure history, retry count — "
      "no GPS/distance/location), and the SAME context-aware train/test "
      "split (`ml/training/dataset.py`, `random_state="
      f"{comparison['split']['random_state']}`). Every trainer records "
      "`tuned: False` and fixes its own `random_state`. See "
      "`ml/training/README.md` for the causality and splitting rules all "
      "three trainers share.")
    a("")

    a("### A.6 What this does NOT show")
    a("")
    for claim in comparison["explicit_non_claims"]:
        a(f"- {claim}")
    a("")
    a("---")
    a("")

    # ================= Section B =================
    hw = full["real_hardware_results"]
    a("## B. REAL HARDWARE RESULTS — NOT YET AVAILABLE")
    a("")
    a(f"**Status:** {hw['status']}")
    a("")
    a(hw["note"])
    a("")
    a(f"**Blocking work:** {hw['blocking_work']}")
    a("")
    a("What will go here once real hardware data exists:")
    a("")
    for item in hw["what_will_go_here_once_available"]:
        a(f"- {item}")
    a("")
    a("---")
    a("")

    # ================= Section C =================
    d = full["decision_framework"]
    a("## C. Decision Framework")
    a("")
    a("> **" + d["banner"] + "**")
    a("")
    a(f"### C.1 Final selection status: **{d['final_selection_status']}**")
    a("")
    a(d["reason"])
    a("")

    a("### C.2 Factor definitions")
    a("")
    a("| Factor | Definition |")
    a("|---|---|")
    for factor in d["factor_scores"]["factors"]:
        a(f"| {factor} | {d['factor_definitions'][factor]} |")
    a("")

    a("### C.3 Per-factor normalised scores (0-1, higher = better on THIS run)")
    a("")
    header("Factor")
    for factor in d["factor_scores"]["factors"]:
        row(factor, [_fmt(d["factor_scores"]["normalized_scores"][c["key"]][factor], ".3f")
                     for c in cands])
    a("")
    a("> " + d["factor_scores"]["normalization_note"])
    a("")

    a("### C.4 Illustrative weighted scores (opt-in, for transparency only)")
    a("")
    iw = d["illustrative_weighted_scores"]
    if include_illustrative:
        a("Weights used: " + ", ".join(f"{k}={v:g}" for k, v in iw["weights"].items()))
        a("")
        header("")
        row("Weighted score", [_fmt(iw["scores"][c["key"]], ".3f") for c in cands])
        a("")
        a("> " + iw["caveat"])
    else:
        a("Not shown by default. A single weighted number per candidate "
          "invites reading it as a ranking, which synthetic data cannot "
          "support. The values are still computed and stored in the JSON "
          "output; regenerate with `--include-illustrative-scores` to "
          "print them here. They never affect the selection status.")
    a("")

    a("### C.5 What this framework does NOT show")
    a("")
    for claim in d["explicit_non_claims"]:
        a(f"- {claim}")
    a("")
    a("---")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a(f"> **Final model selection: {d['final_selection_status']}**")
    a("")

    return "\n".join(lines)


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Generate the full Checkpoint 7 model comparison and selection "
            "framework report (predictive performance, resource profile, "
            "decision framework). SOFTWARE VALIDATION ONLY."
        )
    )
    for short, name in (("dt", "Decision Tree"), ("lr", "Logistic Regression"),
                        ("rf", "Random Forest")):
        p.add_argument(f"--{short}-model", required=True,
                       help=f"{name} .joblib bundle.")
        p.add_argument(f"--{short}-metadata", required=True,
                       help=f"{name} training metadata JSON.")
    p.add_argument("--input", "-i", required=True, help="Labeled CSV to evaluate on.")
    p.add_argument("--report", "-r", default=None,
                   help="Path to write the full Markdown report to.")
    p.add_argument("--json", default=None,
                   help="Path to write the machine-readable JSON result to.")
    p.add_argument("--include-illustrative-scores", action="store_true",
                   help="Also print the illustrative weighted scores (opt-in; "
                        "never affects the selection status).")
    p.add_argument("--test-size", type=float, default=0.3)
    p.add_argument("--random-state", type=int, default=0)
    return p


def main(argv=None):
    args = _build_arg_parser().parse_args(argv)

    try:
        full = build_full_comparison(
            dt_model_path=args.dt_model, dt_metadata_path=args.dt_metadata,
            lr_model_path=args.lr_model, lr_metadata_path=args.lr_metadata,
            rf_model_path=args.rf_model, rf_metadata_path=args.rf_metadata,
            input_path=args.input,
            test_size=args.test_size, random_state=args.random_state,
        )
    except FileNotFoundError as e:
        print(f"ERROR: file not found: {e.filename or e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(full, fh, indent=2)
            fh.write("\n")

    report = render_markdown_report(
        full, include_illustrative=args.include_illustrative_scores)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        with open(args.report, "w", encoding="utf-8") as fh:
            fh.write(report)
        print(f"Wrote report to {args.report}")
    else:
        print(report)


if __name__ == "__main__":
    main()
