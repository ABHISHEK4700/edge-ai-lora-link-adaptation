"""
timing.py

Checkpoint 6 — A single, shared inference-timing harness.

Why this exists
---------------
Checkpoints 4 and 5 each timed inference inside their own trainer, and each
timed the SF model only. That was fine while there were two models, but a
three-way comparison needs ONE definition applied identically to every
candidate, or the numbers are not comparable. This module is that definition.
The Checkpoint 4/5 trainers are unchanged and keep their private copies; the
Random Forest trainer and ml/evaluation/compare_candidates.py use this one.

What is measured
----------------
For a dict of fitted models (normally {"sf": ..., "tp": ...} — one complete
configuration decision needs BOTH):

  * batch:  the time to run every model's predict() over all of X, best of N
            repeats, reported per row. This amortises scikit-learn's fixed
            per-call overhead across many rows.
  * single: the time for one complete decision (every model's predict() on ONE
            row), median and 95th percentile over many calls. This is closer to
            how a device would use a model — one packet at a time — and is
            dominated by scikit-learn's per-call overhead for small models, so
            it says more about scikit-learn than about the model.

*** BOTH ARE DESKTOP scikit-learn TIMINGS. NEITHER IS AN ESP32 FIGURE. ***
They exist to compare candidates like-for-like on the build machine, and to
show the shape of the cost, not to estimate on-device latency. Timing is also
inherently noisy: treat differences of a small factor between tiny models as
noise.
"""

from __future__ import annotations

import time
from typing import Any, Dict

import numpy as np

CAVEAT = (
    "Measured with scikit-learn on the build machine, not on an ESP32. Not an "
    "edge-latency figure. Timings of very small models are dominated by "
    "scikit-learn's per-call overhead and are noisy."
)


def measure_inference(
    models: Dict[str, Any],
    X: np.ndarray,
    repeats: int = 5,
    single_row_calls: int = 200,
) -> Dict:
    """Time a full (all-models) prediction, in batch and one row at a time.

    `per_row_microseconds` (the SF model only) is also reported, under exactly
    that key, so the result stays readable by code written for the Checkpoint
    4/5 metadata convention — see ml/evaluation/compare_models.py.
    """
    if len(X) == 0:
        return {"measured": False, "reason": "no rows to predict"}
    if not models:
        return {"measured": False, "reason": "no models supplied"}

    # --- Batch: all models over all rows, best of `repeats` -----------------
    batch_times = []
    for _ in range(repeats):
        start = time.perf_counter()
        for model in models.values():
            model.predict(X)
        batch_times.append(time.perf_counter() - start)
    batch_best = min(batch_times)

    # --- Batch, per model (so a single model can be attributed) ---------------
    per_model_us = {}
    for name, model in models.items():
        times = []
        for _ in range(repeats):
            start = time.perf_counter()
            model.predict(X)
            times.append(time.perf_counter() - start)
        per_model_us[name] = (min(times) / len(X)) * 1e6

    # --- Single row: one complete decision per call ----------------------------
    n_calls = max(1, int(single_row_calls))
    singles = []
    for i in range(n_calls):
        row = X[i % len(X)].reshape(1, -1)
        start = time.perf_counter()
        for model in models.values():
            model.predict(row)
        singles.append(time.perf_counter() - start)

    out = {
        "measured": True,
        "n_rows": int(len(X)),
        "repeats": repeats,
        "models_timed": list(models.keys()),
        "batch_seconds_best_of_n_all_models": batch_best,
        "batch_per_row_microseconds_all_models": (batch_best / len(X)) * 1e6,
        "batch_per_row_microseconds_by_model": per_model_us,
        "single_decision_calls": n_calls,
        "single_decision_median_microseconds": float(np.median(singles) * 1e6),
        "single_decision_p95_microseconds": float(np.percentile(singles, 95) * 1e6),
        "caveat": CAVEAT,
    }
    # Checkpoint 4/5-compatible key: SF model only, batch, per row.
    if "sf" in per_model_us:
        out["per_row_microseconds"] = per_model_us["sf"]
        out["per_row_microseconds_definition"] = (
            "SF model only, batch, best of N — the same definition the "
            "Checkpoint 4 and 5 trainers record."
        )
    return out
