"""
resource_profile.py

Checkpoint 7 — Resource / computational-characteristics profiling for the
three lightweight candidates (Decision Tree, Logistic Regression, small
Random Forest).

*** SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT. ***
Every timing and size figure this module reads comes from the SAME
software-level measurements ml/evaluation/compare_candidates.py already
produces (training time, inference time, model-file size, structure) on the
SAME fabricated pipeline fixture. build_resource_profile() does not
re-measure anything — it re-presents those figures as a standalone
"resource" view and attaches a DERIVED, qualitative "embedded suitability"
label per candidate.

The one thing this module can add is a PARAMETER COUNT, via
count_model_parameters(): it loads a saved bundle and counts the fitted
quantities directly (linear coefficients + intercepts, scaler mean + scale,
tree nodes). It times nothing, trains nothing and writes nothing; the counts
are structural facts about the saved model, not measurements, and a test
cross-checks them against the metadata the trainers recorded.

WHY THIS IS A SEPARATE MODULE FROM compare_candidates.py
-----------------------------------------------------------
compare_candidates.py's job is a side-by-side predictive + software-cost +
structure comparison. This module exists to (a) give a resource-only view
that can be regenerated once real ESP32 measurements replace the desktop
proxies, without touching the predictive-performance code path, and (b)
compute the qualitative suitability labels, which are opinionated enough
(threshold choices) that they don't belong inside the shared comparison
module every future candidate will reuse.

WHAT "EMBEDDED SUITABILITY" IS, AND IS NOT
---------------------------------------------
It is a threshold-based, human-readable label (e.g. "compact (desktop
proxy)") computed from structural proxies already in the comparison: joblib
file size in KB and the single-decision desktop latency in microseconds.

It is NOT a measurement of anything that runs on an ESP32. No on-device
size, RAM/flash footprint, or latency has ever been measured in this
project (see ml/export/ and esp32/, both empty). The thresholds below are
project-chosen placeholders — exactly the same kind of placeholder as the
small-forest guard in ml/training/train_random_forest.py — not measured
ESP32 limits, and they are recorded alongside every label so nobody has to
guess where the line was drawn.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Dict, Optional

#: Project-chosen placeholder thresholds, NOT measured ESP32 limits.
#: A future checkpoint that actually measures an ESP32 footprint should
#: replace these, not tune them to make a favourite candidate look better.
@dataclass(frozen=True)
class SuitabilityThresholds:
    compact_kilobytes: float = 5.0
    moderate_kilobytes: float = 20.0
    fast_single_decision_microseconds: float = 150.0
    moderate_single_decision_microseconds: float = 500.0

    def validate(self) -> "SuitabilityThresholds":
        if self.compact_kilobytes <= 0 or self.moderate_kilobytes <= 0:
            raise ValueError("Size thresholds must be > 0.")
        if self.compact_kilobytes >= self.moderate_kilobytes:
            raise ValueError(
                "compact_kilobytes must be smaller than moderate_kilobytes "
                f"(got {self.compact_kilobytes} >= {self.moderate_kilobytes})."
            )
        if self.fast_single_decision_microseconds <= 0 or \
                self.moderate_single_decision_microseconds <= 0:
            raise ValueError("Latency thresholds must be > 0.")
        if self.fast_single_decision_microseconds >= self.moderate_single_decision_microseconds:
            raise ValueError(
                "fast_single_decision_microseconds must be smaller than "
                "moderate_single_decision_microseconds (got "
                f"{self.fast_single_decision_microseconds} >= "
                f"{self.moderate_single_decision_microseconds})."
            )
        return self

    def to_dict(self) -> Dict:
        return asdict(self)


#: Stamped onto every label this module produces.
SUITABILITY_CAVEAT = (
    "This label is a DESKTOP PROXY derived from joblib file size and desktop "
    "scikit-learn latency on a fabricated fixture. It is NOT an ESP32 "
    "measurement. No on-device size, RAM/flash footprint or latency has been "
    "measured for any candidate in this project."
)


def classify_size(kilobytes: Optional[float], thresholds: SuitabilityThresholds) -> str:
    if kilobytes is None:
        return "unknown (no model file size recorded)"
    if kilobytes <= thresholds.compact_kilobytes:
        return "compact (desktop proxy)"
    if kilobytes <= thresholds.moderate_kilobytes:
        return "moderate (desktop proxy)"
    return "large (desktop proxy)"


def classify_latency(microseconds: Optional[float], thresholds: SuitabilityThresholds) -> str:
    if microseconds is None:
        return "unknown (no inference timing recorded)"
    if microseconds <= thresholds.fast_single_decision_microseconds:
        return "fast (desktop proxy)"
    if microseconds <= thresholds.moderate_single_decision_microseconds:
        return "moderate (desktop proxy)"
    return "slow (desktop proxy)"


def _count_one_model(model) -> Dict:
    """Count the fitted quantities of one scikit-learn estimator or Pipeline."""
    import numpy as np

    steps = list(model.named_steps.values()) if hasattr(model, "named_steps") else [model]
    linear = preprocessing = nodes = trees = 0
    for step in steps:
        if hasattr(step, "coef_") and hasattr(step, "intercept_"):
            linear += int(np.size(step.coef_) + np.size(step.intercept_))
        elif hasattr(step, "mean_") and hasattr(step, "scale_"):
            preprocessing += int(np.size(step.mean_) + np.size(step.scale_))
        elif hasattr(step, "estimators_"):
            trees += len(step.estimators_)
            nodes += int(sum(e.tree_.node_count for e in step.estimators_))
        elif hasattr(step, "tree_"):
            trees += 1
            nodes += int(step.tree_.node_count)
    return {
        "linear_parameters": linear or None,
        "preprocessing_parameters": preprocessing or None,
        "n_trees": trees or None,
        "tree_nodes": nodes or None,
    }


def count_model_parameters(model_path: str) -> Dict:
    """Count fitted parameters/structures of a saved model bundle, per target.

    `linear_parameters` = coefficients + intercepts of a linear model;
    `preprocessing_parameters` = scaler mean + scale values; `tree_nodes` =
    total tree nodes. A field is None when it does not apply to the model
    family (a tree has no linear parameters; a linear model has no nodes).
    Loads the bundle only — no timing, no training, no writing.
    """
    from .evaluate import load_bundle

    bundle = load_bundle(model_path)
    return {
        "spreading_factor": _count_one_model(bundle["sf_model"]),
        "tx_power_dbm": _count_one_model(bundle["tp_model"]),
        "note": (
            "Counts of fitted quantities read from the saved model. They are "
            "structural facts about the desktop scikit-learn object, not a "
            "memory footprint: an ESP32 export would store these values in a "
            "different layout and add its own overhead."
        ),
    }


def build_resource_profile(
    comparison: Dict,
    thresholds: Optional[SuitabilityThresholds] = None,
    parameter_counts: Optional[Dict[str, Dict]] = None,
) -> Dict:
    """Build a resource-only view from a compare_candidates() result.

    `comparison` must be the dict returned by
    ml.evaluation.compare_candidates.compare_candidates() (or compare_three()).
    Timing and size are read from it, not re-measured. `parameter_counts`, if
    given, is {candidate_key: count_model_parameters() result} computed by
    the caller and is attached unchanged.
    """
    thresholds = (thresholds or SuitabilityThresholds()).validate()

    profiles = {}
    for c in comparison["candidates"]:
        sw = c["software"]
        st = c["structure"]
        size_class = classify_size(sw["model_file_kilobytes"], thresholds)
        latency_class = classify_latency(
            sw["inference_single_decision_median_microseconds"], thresholds)
        profiles[c["key"]] = {
            "label": c["label"],
            "model_family": c["model_family"],
            "training_seconds": sw["training_seconds"],
            "model_file_kilobytes": sw["model_file_kilobytes"],
            "size_class": size_class,
            "inference_batch_microseconds_per_row_sf_and_tp":
                sw["inference_batch_microseconds_per_row_sf_and_tp"],
            "inference_single_decision_median_microseconds":
                sw["inference_single_decision_median_microseconds"],
            "latency_class": latency_class,
            "structure_kind": st["kind"],
            "structure_n_trees": st["n_trees"],
            "structure_max_depth": st["max_depth"],
            "structure_total_nodes": st["total_nodes"],
            "parameter_counts": (parameter_counts or {}).get(c["key"]),
            "memory_requirement_proxy": (
                "Same joblib KB figure as model size — no separate on-device "
                "memory measurement exists."
            ),
            "caveat": SUITABILITY_CAVEAT,
        }

    return {
        "banner": comparison["banner"],
        "thresholds": thresholds.to_dict(),
        "thresholds_note": (
            "Project-chosen placeholder thresholds, NOT measured ESP32 "
            "limits — the same kind of placeholder as the small-forest "
            "guard in ml/training/train_random_forest.py. They exist only "
            "to turn desktop numbers into a readable label; they say "
            "nothing about what actually fits on an ESP32."
        ),
        "caveat": SUITABILITY_CAVEAT,
        "candidates": profiles,
    }
