"""
decision_framework.py

Checkpoint 7 — Configurable, multi-factor candidate-selection framework for
the project's three lightweight ML candidates (Decision Tree, Logistic
Regression, small Random Forest).

*** THIS MODULE DOES NOT, AND STRUCTURALLY CANNOT, SELECT A MODEL. ***
`select_candidate()` always returns the fixed status string
`FINAL_SELECTION_STATUS` ("TBD — to be determined using real data and ESP32
deployment measurements."), regardless of the input candidates, the
configured factor weights, or the computed scores. There is no code path in
this module that returns a "winner", "recommended candidate", or "best
model" value. `tests/test_model_comparison_framework.py` asserts this by
calling `select_candidate()` under many different weight configurations and
checking every one comes back with the identical fixed status and no
candidate is marked as selected.

WHY A SCORING FRAMEWORK EXISTS AT ALL, THEN
---------------------------------------------
The user asked for a framework that can REPORT model characteristics across
six factors without forcing a winner, so that when real hardware data
exists, the same factor definitions and weighting mechanism can be reused
for an honest decision — only the inputs (real predictive metrics, a real
measured ESP32 footprint) will have changed. What's built now is the
scoring mechanics and reporting shape; what's deliberately NOT built is
anything that turns those scores into a pick, because the two factors that
matter most for an embedded deployment — real predictive performance and
real embedded feasibility — do not exist yet (see PROJECT_STATUS.md section
8). Reporting an "illustrative weighted score" on synthetic data would
invite exactly the premature-winner reading the user explicitly ruled out,
so `select_candidate()` computes and returns per-factor scores for
transparency but attaches the fixed TBD status to the whole result, not a
per-candidate pick.

THE SIX FACTORS
----------------
  1. predictive_performance    — joint (SF+TP) exact-match accuracy on the
                                  held-out synthetic split (higher better)
  2. model_size                — joblib file size in KB (lower better)
  3. inference_latency         — single-decision median desktop latency in
                                  µs (lower better)
  4. memory_requirements       — same KB figure as model_size; there is no
                                  separate on-device memory measurement, so
                                  this factor is recorded as a proxy of
                                  model_size rather than invented separately
                                  (lower better)
  5. embedded_feasibility      — derived from ml.evaluation.resource_profile's
                                  size_class/latency_class labels, averaged
                                  into a single 0-1 score (higher better)
  6. stability_generalization  — worst-context joint (SF+TP) row accuracy
                                  across the held-out contexts, from
                                  ml.evaluation.context_stability (higher
                                  better). Consistency across the contexts of
                                  ONE split, not sensitivity to which contexts
                                  were held out — see that module's caveat

Every factor's number comes from the fabricated-fixture pipeline. The module
docstring and every rendered report repeat that so a factor score is never
mistaken for a real-world property.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from typing import Dict, List, Optional

FACTOR_NAMES = (
    "predictive_performance",
    "model_size",
    "inference_latency",
    "memory_requirements",
    "embedded_feasibility",
    "stability_generalization",
)

#: The ONLY status value select_candidate() ever returns. Not a template —
#: a constant. Do not parameterise this to depend on the scores.
FINAL_SELECTION_STATUS = (
    "TBD — to be determined using real data and ESP32 deployment "
    "measurements."
)

_SIZE_CLASS_SCORE = {
    "compact (desktop proxy)": 1.0,
    "moderate (desktop proxy)": 0.5,
    "large (desktop proxy)": 0.0,
}
_LATENCY_CLASS_SCORE = {
    "fast (desktop proxy)": 1.0,
    "moderate (desktop proxy)": 0.5,
    "slow (desktop proxy)": 0.0,
}


@dataclass(frozen=True)
class FactorWeights:
    """Relative importance of each factor, for the PERSON's own inspection.

    These weights are read by `illustrative_weighted_scores()` to produce a
    per-candidate number for the person to look at — never by
    `select_candidate()`, which ignores weights entirely when deciding what
    status to report (always FINAL_SELECTION_STATUS). Configuring these does
    not, and cannot, produce a selected model from this module.
    """
    predictive_performance: float = 1.0
    model_size: float = 1.0
    inference_latency: float = 1.0
    memory_requirements: float = 1.0
    embedded_feasibility: float = 1.0
    stability_generalization: float = 1.0

    def validate(self) -> "FactorWeights":
        total = 0.0
        for f in fields(self):
            v = getattr(self, f.name)
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                raise ValueError(
                    f"Weight {f.name!r} must be a number (got {v!r}).")
            if v < 0:
                raise ValueError(
                    f"Weight {f.name!r} must be >= 0 (got {v!r}).")
            total += v
        if total <= 0:
            raise ValueError(
                "At least one factor weight must be > 0 (all weights were 0).")
        return self

    def to_dict(self) -> Dict:
        return asdict(self)


def _minmax(values: Dict[str, Optional[float]], higher_is_better: bool) -> Dict[str, Optional[float]]:
    """Min-max normalise to [0, 1] across candidates. None passes through.

    All-equal (including a single candidate) maps to 1.0 for every present
    value — "tied", not "arbitrarily favoured".
    """
    present = {k: v for k, v in values.items() if v is not None}
    if not present:
        return {k: None for k in values}
    lo, hi = min(present.values()), max(present.values())
    out: Dict[str, Optional[float]] = {}
    for k, v in values.items():
        if v is None:
            out[k] = None
            continue
        if hi == lo:
            out[k] = 1.0
            continue
        score = (v - lo) / (hi - lo)
        out[k] = score if higher_is_better else 1.0 - score
    return out


def compute_factor_scores(
    comparison: Dict,
    resource_profile: Dict,
    context_stability: Dict[str, Dict],
) -> Dict:
    """Per-candidate, per-factor scores in [0, 1], plus the raw values behind
    them, from an already-computed compare_candidates() result and
    resource_profile.build_resource_profile() result.

    `context_stability`: {candidate_key: result of
    ml.evaluation.context_stability.per_context_stability()} — computed by
    the caller, so this module never loads models or touches data itself.
    Only the `worst_context_joint_accuracy` field is read.
    """
    keys = [c["key"] for c in comparison["candidates"]]
    by_key = {c["key"]: c for c in comparison["candidates"]}
    rp = resource_profile["candidates"]

    raw: Dict[str, Dict[str, Optional[float]]] = {k: {} for k in keys}
    for k in keys:
        pred = by_key[k]["predictive"]
        sw = by_key[k]["software"]
        prof = rp[k]
        raw[k]["predictive_performance"] = pred["joint_accuracy"]
        raw[k]["model_size"] = sw["model_file_kilobytes"]
        raw[k]["inference_latency"] = sw["inference_single_decision_median_microseconds"]
        raw[k]["memory_requirements"] = sw["model_file_kilobytes"]
        size_s = _SIZE_CLASS_SCORE.get(prof["size_class"])
        lat_s = _LATENCY_CLASS_SCORE.get(prof["latency_class"])
        parts = [s for s in (size_s, lat_s) if s is not None]
        raw[k]["embedded_feasibility"] = (sum(parts) / len(parts)) if parts else None
        raw[k]["stability_generalization"] = (
            context_stability.get(k, {}).get("worst_context_joint_accuracy"))

    higher_is_better = {
        "predictive_performance": True,
        "model_size": False,
        "inference_latency": False,
        "memory_requirements": False,
        "embedded_feasibility": True,  # already 0-1, higher-is-better; normalised for consistency
        "stability_generalization": True,
    }

    normalized: Dict[str, Dict[str, Optional[float]]] = {k: {} for k in keys}
    for factor in FACTOR_NAMES:
        col = {k: raw[k][factor] for k in keys}
        norm = _minmax(col, higher_is_better[factor])
        for k in keys:
            normalized[k][factor] = norm[k]

    return {
        "factors": list(FACTOR_NAMES),
        "raw_values": raw,
        "normalized_scores": normalized,
        "normalization_note": (
            "Each factor is min-max normalised to [0, 1] ACROSS THE "
            "CANDIDATES IN THIS RUN ONLY — a score of 1.0 means 'best among "
            "these candidates on this synthetic run', not any absolute "
            "standard. Every input is a synthetic-fixture or desktop-proxy "
            "figure; see the banner."
        ),
    }


def illustrative_weighted_scores(
    factor_scores: Dict,
    weights: Optional[FactorWeights] = None,
) -> Dict:
    """A single weighted number per candidate, FOR TRANSPARENCY ONLY.

    Explicitly NOT used by select_candidate() to pick anything. Exists so a
    person can see what their own stated priorities would imply on today's
    synthetic numbers, while the module itself refuses to act on it.
    """
    weights = (weights or FactorWeights()).validate()
    w = weights.to_dict()
    total_w = sum(w.values())

    scores = {}
    for key, per_factor in factor_scores["normalized_scores"].items():
        num, denom = 0.0, 0.0
        for factor in FACTOR_NAMES:
            s = per_factor.get(factor)
            if s is None:
                continue
            num += w[factor] * s
            denom += w[factor]
        scores[key] = (num / denom) if denom > 0 else None

    return {
        "weights": w,
        "weights_note": (
            "Weights reflect the PERSON's stated priorities, not this "
            "project's. Changing them changes this number but NEVER changes "
            "final_selection_status (see select_candidate())."
        ),
        "scores": scores,
        "caveat": (
            "ILLUSTRATIVE ONLY — computed entirely from synthetic-fixture "
            "and desktop-proxy figures. A higher score here does NOT mean a "
            "candidate is better for real LoRa deployment. This value is "
            "never read by select_candidate() and never determines the "
            "final selection status."
        ),
    }


def select_candidate(
    comparison: Dict,
    resource_profile: Dict,
    context_stability: Dict[str, Dict],
    weights: Optional[FactorWeights] = None,
) -> Dict:
    """Report factor scores for every candidate. NEVER select one.

    Returns a dict whose `final_selection_status` is ALWAYS
    FINAL_SELECTION_STATUS, and which contains no "winner", "selected",
    "recommended", or "best" key under any input. `weights` only affects the
    illustrative scores included for transparency (see
    illustrative_weighted_scores()) — it has no effect on the status.
    """
    factor_scores = compute_factor_scores(
        comparison, resource_profile, context_stability)
    illustrative = illustrative_weighted_scores(factor_scores, weights)

    candidates_considered = [c["key"] for c in comparison["candidates"]]

    return {
        "banner": comparison["banner"],
        "final_selection_status": FINAL_SELECTION_STATUS,
        "reason": (
            "Two of the six factors this framework scores — predictive "
            "performance and embedded feasibility — currently come from a "
            "fabricated test fixture and a desktop-proxy label respectively, "
            "not from real hardware or a measured ESP32 footprint. No "
            "combination of the other four factors, and no choice of "
            "weights, can substitute for those two. This framework is built "
            "so the SAME factor definitions and weighting mechanism can be "
            "re-run once real data and a real ESP32 measurement exist; only "
            "then does a selection become meaningful."
        ),
        "candidates_considered": candidates_considered,
        "factor_definitions": {
            "predictive_performance": "Joint (SF+TP) exact-match accuracy on the held-out synthetic split. Higher is better.",
            "model_size": "Serialized joblib file size (KB). Lower is better. Desktop figure, not an ESP32 footprint.",
            "inference_latency": "Median desktop time for one full SF+TP decision (µs). Lower is better. Not an ESP32 figure.",
            "memory_requirements": "Same KB figure as model_size; no separate on-device memory measurement exists yet.",
            "embedded_feasibility": "Derived from the resource_profile size/latency classes, averaged. A desktop proxy label, not a fit/no-fit verdict.",
            "stability_generalization": "Worst-context joint (SF+TP) row accuracy across the held-out contexts. Higher is better. Consistency across one split's contexts, not sensitivity to which contexts were held out; coarse with few contexts.",
        },
        "factor_scores": factor_scores,
        "illustrative_weighted_scores": illustrative,
        "explicit_non_claims": [
            "This framework does NOT select a final model. "
            "final_selection_status is a fixed value and does not depend on "
            "the scores above or on any weight configuration.",
            "No candidate here is marked 'winner', 'recommended', or 'best'.",
            "All factor scores were computed from fabricated test-fixture "
            "data and/or desktop-proxy figures — see the banner.",
            "embedded_feasibility is a desktop-proxy label, not a measured "
            "ESP32 fit/no-fit verdict.",
            "The final model will only be selected after real hardware data "
            "and embedded measurements are available (see PROJECT_STATUS.md "
            "section 8, 'Next Checkpoint').",
        ],
    }
