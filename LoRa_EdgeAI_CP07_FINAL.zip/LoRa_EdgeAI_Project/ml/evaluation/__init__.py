"""
ml.evaluation — Checkpoint 4: model evaluation. Checkpoint 5:
Decision-Tree-vs-Logistic-Regression comparison (ml/evaluation/compare_models.py).
Checkpoint 6: a shared inference-timing harness (ml/evaluation/timing.py) and
an N-way comparison of the three candidates — Decision Tree, Logistic
Regression, small Random Forest (ml/evaluation/compare_candidates.py).
Checkpoint 7: a model comparison and selection framework over those three
candidates — resource_profile.py (resource-only view + desktop-proxy
embedded-suitability labels), context_stability.py (per-held-out-context
accuracy for the stability factor), decision_framework.py (six configurable
factors; select_candidate() always reports the fixed TBD status and never
names a winner) and generate_comparison_report.py (the full report, with
"SYNTHETIC SOFTWARE-VALIDATION RESULTS" separated from "REAL HARDWARE
RESULTS — NOT YET AVAILABLE").

Every report produced by this package carries the SYNTHETIC_BANNER from
ml/evaluation/metrics.py, because as of Checkpoint 7 all metrics still come
from fabricated test-fixture data and measure only that the software runs.
compare_models.py and compare_candidates.py additionally carry an explicit
no-superiority-claim in every report they generate, and the Checkpoint 7
framework reports its final model selection as TBD — see those modules'
docstrings.
"""
