"""
compare_candidates.py

Checkpoint 6 — Software-level comparison of the project's three lightweight
ML candidates: Decision Tree (Checkpoint 4), Logistic Regression
(Checkpoint 5) and small Random Forest (Checkpoint 6).

*** SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT. ***
Every number this module produces comes from the fabricated pipeline
fixture. It compares whether pieces of code run and what they measure on that
fixture — it is NOT a comparison of which model is better for real LoRa
channel adaptation, and must never be read or reported as one.

RELATIONSHIP TO ml/evaluation/compare_models.py (Checkpoint 5)
---------------------------------------------------------------
compare_models.py is a two-model (Decision Tree vs Logistic Regression)
comparison and is left completely unmodified, as Checkpoint 6 requires that
previous model pipelines are not changed. This module does not fork its
discipline; it REUSES it:

  * every model is scored by the same unmodified evaluate() from
    ml/evaluation/evaluate.py, which is model-family-agnostic;
  * the comparison is refused (ValueError) unless every bundle was trained on
    the identical feature list — the CP5 rule, generalised to N models;
  * every generated report carries the synthetic banner and an explicit
    no-superiority claim — the CP5 rule, worded for more than two models;
  * all models are scored on an IDENTICAL held-out split, and this module
    additionally asserts that the split really was identical (same held-out
    rows and contexts for every candidate) rather than assuming it.

It generalises to any number (>= 2) of candidates, so a fourth model family
would need no new comparison code — but adding one is not Checkpoint 6's job.

What is timed here
------------------
Training time and model-file size come from each model's own training
metadata. Inference time is NOT taken from metadata: Checkpoint 4/5 timed the
SF model only while a complete decision needs SF AND TP, so this module
re-measures all candidates with ONE shared harness (ml/evaluation/timing.py),
on the same held-out rows, on both targets. All timings are desktop
scikit-learn figures, not ESP32 figures.

Does NOT:
  * run a statistical significance test — 9 test contexts cannot support one;
  * pick a "winner" or recommend a model for deployment;
  * touch, retrain, or modify any model.

Usage:
    python -m ml.evaluation.compare_candidates \\
        --dt-model    ml/models/decision_tree_sf_tp.joblib \\
        --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \\
        --lr-model    ml/models/logistic_regression_sf_tp.joblib \\
        --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \\
        --rf-model    ml/models/random_forest_sf_tp.joblib \\
        --rf-metadata ml/models/random_forest_sf_tp_metadata.json \\
        --input       <labeled.csv> \\
        --report      comparison_report.md
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

from .evaluate import evaluate, load_bundle
from .metrics import SYNTHETIC_BANNER, SYNTHETIC_BANNER_LONG
from .timing import measure_inference

#: The explicit non-claim this whole module exists to enforce — the
#: Checkpoint 5 statement, worded for more than two models.
NO_SUPERIORITY_CLAIM_MULTI = (
    "This comparison does NOT show that any one of these models is better "
    "than any other for real LoRa channel adaptation. All were scored on the "
    "same fabricated, trivially-separable fixture used to validate the "
    "software pipeline. Any difference between them here reflects how each "
    "model family fits that fixture, not real-world merit."
)


@dataclass(frozen=True)
class Candidate:
    """One saved model to include in a comparison."""
    key: str            # short unique id, e.g. "dt"
    label: str          # column heading, e.g. "Decision Tree"
    model_path: str
    metadata_path: str


def compare_candidates(
    candidates: List[Candidate],
    input_path: str,
    test_size: float = 0.3,
    random_state: int = 0,
) -> Dict:
    """Evaluate every candidate on the same held-out split and assemble a
    side-by-side comparison dict."""
    from ml.training.dataset import (
        build_dataset, context_aware_split, describe_split, load_labeled_frame,
    )

    if len(candidates) < 2:
        raise ValueError(
            f"A comparison needs at least 2 candidates (got {len(candidates)}).")
    keys = [c.key for c in candidates]
    if len(set(keys)) != len(keys):
        raise ValueError(f"Candidate keys must be unique (got {keys}).")

    bundles = {c.key: load_bundle(c.model_path) for c in candidates}

    # --- Same-features rule (Checkpoint 5's, generalised) -------------------
    reference_key = candidates[0].key
    reference_features = list(bundles[reference_key]["feature_columns"])
    for c in candidates[1:]:
        feats = list(bundles[c.key]["feature_columns"])
        if feats != reference_features:
            raise ValueError(
                "The candidates were trained on different feature sets "
                f"({reference_key}: {reference_features!r} vs "
                f"{c.key}: {feats!r}). A comparison is only meaningful when "
                "every model sees the same inputs — retrain so they match "
                "before comparing.")

    # --- The held-out rows, computed once, used for timing and recorded -----
    df = load_labeled_frame(input_path)
    X, y_sf, y_tp, groups, _summary = build_dataset(
        df, feature_columns=reference_features)
    train_idx, test_idx = context_aware_split(
        groups, test_size=test_size, random_state=random_state)
    split_info = describe_split(groups, train_idx, test_idx)
    X_te = X[test_idx]
    heldout_contexts = sorted(str(g) for g in set(groups[test_idx].tolist()))

    results: Dict[str, Dict] = {}
    metas: Dict[str, Dict] = {}
    for c in candidates:
        results[c.key] = evaluate(
            c.model_path, input_path, test_size=test_size,
            random_state=random_state)
        with open(c.metadata_path, encoding="utf-8") as fh:
            metas[c.key] = json.load(fh)

    # --- Assert the split really was identical for every candidate ----------
    ref = results[reference_key]
    for c in candidates[1:]:
        r = results[c.key]
        if r["split"] != ref["split"] or (
                r["metrics"]["spreading_factor"]["n_samples"]
                != ref["metrics"]["spreading_factor"]["n_samples"]):
            raise ValueError(
                f"Candidate {c.key!r} was not scored on the same held-out "
                f"split as {reference_key!r}; refusing to compare.")

    def _predictive(result: Dict) -> Dict:
        m = result["metrics"]
        return {
            "sf_accuracy": m["spreading_factor"]["accuracy"],
            "sf_macro_f1": m["spreading_factor"]["macro_f1"],
            "sf_majority_baseline_accuracy":
                m["spreading_factor"]["majority_class_baseline"]["accuracy"],
            "tp_accuracy": m["tx_power_dbm"]["accuracy"],
            "tp_macro_f1": m["tx_power_dbm"]["macro_f1"],
            "tp_majority_baseline_accuracy":
                m["tx_power_dbm"]["majority_class_baseline"]["accuracy"],
            "joint_accuracy": m["joint"]["accuracy"],
            "per_context_joint_accuracy": m["per_context"]["joint_accuracy"],
            "n_test_rows": m["spreading_factor"]["n_samples"],
        }

    def _software(key: str) -> Dict:
        meta = metas[key]
        mf = meta.get("model_file", {})
        timing = measure_inference(
            {"sf": bundles[key]["sf_model"], "tp": bundles[key]["tp_model"]},
            X_te)
        return {
            "training_seconds": meta.get("total_training_seconds"),
            "model_file_kilobytes": mf.get("kilobytes"),
            "model_file_bytes": mf.get("bytes"),
            "inference_batch_microseconds_per_row_sf_and_tp":
                timing.get("batch_per_row_microseconds_all_models"),
            "inference_single_decision_median_microseconds":
                timing.get("single_decision_median_microseconds"),
            "inference_measured_rows": timing.get("n_rows"),
            "tuned": meta.get("tuned"),
        }

    def _structure(key: str) -> Dict:
        """Tree-based models report structure; a linear model has none."""
        meta = metas[key]
        if "sf_forest" in meta:
            sf, tp = meta["sf_forest"], meta["tp_forest"]
            return {
                "kind": "forest",
                "n_trees": [sf["n_trees"], tp["n_trees"]],
                "max_depth": [sf["actual_max_depth"], tp["actual_max_depth"]],
                "total_nodes": [sf["total_nodes"], tp["total_nodes"]],
            }
        if "sf_tree" in meta:
            sf, tp = meta["sf_tree"], meta["tp_tree"]
            return {
                "kind": "tree",
                "n_trees": [1, 1],
                "max_depth": [sf["actual_depth"], tp["actual_depth"]],
                "total_nodes": [sf["n_nodes"], tp["n_nodes"]],
            }
        return {"kind": "linear", "n_trees": None, "max_depth": None,
                "total_nodes": None}

    comparison = {
        "banner": SYNTHETIC_BANNER,
        "no_superiority_claim": NO_SUPERIORITY_CLAIM_MULTI,
        "input_path": str(input_path),
        "split": {
            "test_size": test_size,
            "random_state": random_state,
            **split_info,
            "n_test_rows": int(len(test_idx)),
            "heldout_contexts": heldout_contexts,
            "note": (
                "Every model was evaluated on an IDENTICAL held-out split of "
                "the same input file (same test_size/random_state), and this "
                "module verified that each evaluation reported the same split "
                "and the same number of scored rows."
            ),
        },
        "candidates": [
            {
                "key": c.key,
                "label": c.label,
                # The Checkpoint 4 bundle predates the "model_family" key, so
                # fall back to the training metadata, which has always had it.
                "model_family": (bundles[c.key].get("model_family")
                                 or metas[c.key].get("model_family")
                                 or "unknown"),
                "checkpoint": metas[c.key].get("checkpoint"),
                "hyperparameters": metas[c.key].get("hyperparameters", {}),
                "predictive": _predictive(results[c.key]),
                "software": _software(c.key),
                "structure": _structure(c.key),
            }
            for c in candidates
        ],
        "feature_columns": reference_features,
        "explicit_non_claims": [
            NO_SUPERIORITY_CLAIM_MULTI,
            "This does NOT demonstrate improved packet delivery ratio for "
            "any model.",
            "This does NOT demonstrate improved latency for any model.",
            "This does NOT demonstrate improved energy consumption for any "
            "model.",
            "This does NOT demonstrate faster adaptation than ADR for any "
            "model.",
            "No model is validated for real LoRa communication.",
            "These metrics are NOT evidence of project success for any "
            "candidate.",
            "This does NOT show that an ensemble (the Random Forest) is "
            "better or worse than a single tree, and does NOT show that any "
            "candidate fits on or runs fast enough on an ESP32 — no ESP32 "
            "footprint or latency has been measured.",
            ("The fixture is trivially separable by construction, so high "
             "scores are expected and indicate only that the pipelines ran "
             "correctly."),
        ],
    }
    return comparison


def compare_three(
    dt_model_path: str, dt_metadata_path: str,
    lr_model_path: str, lr_metadata_path: str,
    rf_model_path: str, rf_metadata_path: str,
    input_path: str,
    test_size: float = 0.3,
    random_state: int = 0,
) -> Dict:
    """Convenience wrapper: Decision Tree vs Logistic Regression vs Random Forest."""
    return compare_candidates(
        [
            Candidate("dt", "Decision Tree", dt_model_path, dt_metadata_path),
            Candidate("lr", "Logistic Regression", lr_model_path, lr_metadata_path),
            Candidate("rf", "Small Random Forest", rf_model_path, rf_metadata_path),
        ],
        input_path, test_size=test_size, random_state=random_state,
    )


def _fmt(v, spec: str) -> str:
    return "n/a" if v is None else format(v, spec)


def render_markdown_report(comparison: Dict) -> str:
    """Render the comparison dict as a banner-stamped Markdown report."""
    lines: List[str] = []
    a = lines.append
    cands = comparison["candidates"]
    labels = [c["label"] for c in cands]

    def row(name: str, values: List[str]) -> None:
        a("| " + name + " | " + " | ".join(values) + " |")

    def header(first: str) -> None:
        a("| " + first + " | " + " | ".join(labels) + " |")
        a("|---|" + "---|" * len(labels))

    a("# Checkpoint 6 — " + " vs. ".join(labels) + " (Software Comparison)")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")
    for para in SYNTHETIC_BANNER_LONG.split("\n\n")[1:]:
        a("> " + para.replace("\n", " "))
        a(">")
    a("")
    a("> **" + comparison["no_superiority_claim"] + "**")
    a("")
    a("---")
    a("")

    a("## 1. What was compared")
    a("")
    for i, c in enumerate(cands):
        a(f"- **Model {chr(ord('A') + i)}:** {c['label']} — {c['model_family']} "
          f"(recorded by {c['checkpoint']})")
    a(f"- **Input:** `{comparison['input_path']}`")
    a(f"- **Features (identical for all):** {comparison['feature_columns']}")
    s = comparison["split"]
    a(f"- **Split:** {s['train_contexts']} train / {s['test_contexts']} test "
      f"contexts, {s['context_overlap']} context overlap, {s['n_test_rows']} "
      f"held-out rows (`test_size={s['test_size']}`, "
      f"`random_state={s['random_state']}`, split by `{s['split_by']}`).")
    a(f"- {s['note']}")
    a("")

    a("## 2. Predictive performance on the synthetic fixture")
    a("")
    a("> " + SYNTHETIC_BANNER)
    a("")
    header("Metric")
    for name, key in (
        ("SF accuracy", "sf_accuracy"),
        ("SF majority-class baseline", "sf_majority_baseline_accuracy"),
        ("SF macro F1", "sf_macro_f1"),
        ("TX power accuracy", "tp_accuracy"),
        ("TX power majority-class baseline", "tp_majority_baseline_accuracy"),
        ("TX power macro F1", "tp_macro_f1"),
        ("Joint exact match", "joint_accuracy"),
        ("Per-context joint accuracy", "per_context_joint_accuracy"),
    ):
        row(name, [f"{c['predictive'][key]:.4f}" for c in cands])
    row("Test rows scored", [str(c["predictive"]["n_test_rows"]) for c in cands])
    a("")
    a("> No column being higher than another is evidence of which model is "
      "better for LoRa. Only " + str(s["test_contexts"]) + " held-out "
      "contexts exist, and the fixture is separable by construction. See "
      "section 5.")
    a("")

    a("## 3. Software-level cost")
    a("")
    header("Metric")
    row("Training time, SF+TP (s)",
        [_fmt(c["software"]["training_seconds"], ".6f") for c in cands])
    row("Model file size (KB)",
        [_fmt(c["software"]["model_file_kilobytes"], "") for c in cands])
    row("Inference, batch, SF+TP (µs/row)",
        [_fmt(c["software"]["inference_batch_microseconds_per_row_sf_and_tp"], ".2f")
         for c in cands])
    row("Inference, one full decision, median (µs)",
        [_fmt(c["software"]["inference_single_decision_median_microseconds"], ".1f")
         for c in cands])
    row("Hyperparameters tuned",
        [str(c["software"]["tuned"]) for c in cands])
    a("")
    a("> Training time and model size are taken from each model's own "
      "training metadata. Inference time was re-measured for every candidate "
      "with one shared harness, over the same held-out rows, for BOTH the SF "
      "and TX-power models (a complete decision needs both) — so it is not "
      "the SF-only figure recorded in the Checkpoint 4/5 metadata. All "
      "figures are desktop scikit-learn measurements — not ESP32 figures. "
      "Model file size is the desktop joblib serialisation, dominated by "
      "Python object overhead, not an embedded footprint. The single-decision "
      "time is dominated by scikit-learn's per-call overhead for models this "
      "small and says little about the models themselves. Differences between "
      "tiny models here are noise-level and are recorded only so the "
      "comparison methodology exists.")
    a("")

    a("## 4. Model structure (what a later export step would budget against)")
    a("")
    header("Property (SF / TX power)")
    def _pair(c, k):
        v = c["structure"][k]
        return "n/a (linear model)" if v is None else f"{v[0]} / {v[1]}"
    row("Trees per target", [_pair(c, "n_trees") for c in cands])
    row("Max tree depth", [_pair(c, "max_depth") for c in cands])
    row("Total nodes", [_pair(c, "total_nodes") for c in cands])
    a("")
    a("> Structure only. No ESP32 byte or latency figure has been derived "
      "from these counts; export and on-device measurement are later "
      "checkpoints.")
    a("")

    a("## 5. What this does NOT show")
    a("")
    for claim in comparison["explicit_non_claims"]:
        a(f"- {claim}")
    a("")
    a("---")
    a("")
    a("> **" + SYNTHETIC_BANNER + "**")
    a("")

    return "\n".join(lines)


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Compare Decision Tree, Logistic Regression and small Random "
            "Forest bundles on identical held-out data. SOFTWARE VALIDATION "
            "ONLY — not a research comparison."
        )
    )
    for short, name in (("dt", "Decision Tree"), ("lr", "Logistic Regression"),
                        ("rf", "Random Forest")):
        p.add_argument(f"--{short}-model", required=True,
                       help=f"{name} .joblib bundle.")
        p.add_argument(f"--{short}-metadata", required=True,
                       help=f"{name} training metadata JSON.")
    p.add_argument("--input", "-i", required=True, help="Labeled CSV to evaluate on.")
    p.add_argument("--report", "-r", default=None,
                   help="Path to write a Markdown report to.")
    p.add_argument("--json", default=None,
                   help="Path to write the machine-readable JSON result to.")
    p.add_argument("--test-size", type=float, default=0.3)
    p.add_argument("--random-state", type=int, default=0)
    return p


def main(argv=None):
    args = _build_arg_parser().parse_args(argv)

    try:
        comparison = compare_three(
            dt_model_path=args.dt_model, dt_metadata_path=args.dt_metadata,
            lr_model_path=args.lr_model, lr_metadata_path=args.lr_metadata,
            rf_model_path=args.rf_model, rf_metadata_path=args.rf_metadata,
            input_path=args.input,
            test_size=args.test_size, random_state=args.random_state,
        )
    except FileNotFoundError as e:
        print(f"ERROR: file not found: {e.filename or e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(comparison, fh, indent=2)
            fh.write("\n")

    report = render_markdown_report(comparison)
    if args.report:
        Path(args.report).parent.mkdir(parents=True, exist_ok=True)
        with open(args.report, "w", encoding="utf-8") as fh:
            fh.write(report)
        print(f"Wrote report to {args.report}")
    else:
        print(report)


if __name__ == "__main__":
    main()
