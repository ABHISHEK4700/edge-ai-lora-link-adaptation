"""
context_stability.py

Checkpoint 7 — Per-context consistency on the held-out split, used as the
"stability / generalisation" factor of the decision framework.

*** SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT. ***
Computed on the fabricated pipeline fixture (or whatever labeled CSV is
passed in). Nothing here says anything about a real link.

WHAT IT MEASURES
-----------------
For every HELD-OUT channel context, the fraction of that context's rows on
which a candidate predicted BOTH the spreading factor and the TX power
correctly ("joint" row accuracy), and from those per-context values:

    worst-context joint accuracy   (the figure the decision framework uses)
    mean, standard deviation, best

A candidate that is right on average but collapses on one kind of channel
shows up as a low worst-context figure even when its mean looks fine —
which is the failure mode that matters for a deployed link adapter, and the
reason this is used instead of the aggregate accuracy that factor 1
(predictive performance) already covers.

WHY NO RETRAINING, AND WHAT THAT COSTS
----------------------------------------
This reproduces the SAME prediction path as ml.evaluation.evaluate.evaluate()
(same unmodified ml.training.dataset functions, same split arguments) and
only breaks the result down by context. It never trains anything, so it
cannot leak and cannot silently use a different hyperparameter set from the
saved model. The cost: it describes consistency across the contexts of ONE
split. It does NOT measure sensitivity to WHICH contexts landed in the
test set, which would need repeated retraining under different seeds — a
later, deliberate step once real data exists. With few held-out contexts
(9 on the fixture) the worst-context figure is a coarse number.
"""

from __future__ import annotations

import math
from typing import Dict

import numpy as np

from .evaluate import load_bundle
from .metrics import SYNTHETIC_BANNER

STABILITY_CAVEAT = (
    "Consistency across the held-out contexts of ONE split, from rows "
    "predicted by an already-trained model. It does not measure sensitivity "
    "to which contexts were held out (that needs repeated retraining under "
    "different seeds), and with few held-out contexts it is coarse. It is "
    "not a confidence interval and says nothing about a real link."
)


def per_context_stability(
    model_path: str,
    input_path: str,
    test_size: float = 0.3,
    random_state: int = 0,
) -> Dict:
    """Per-held-out-context joint accuracy for one saved model bundle."""
    from ml.training.dataset import (
        build_dataset, context_aware_split, load_labeled_frame,
    )

    bundle = load_bundle(model_path)
    df = load_labeled_frame(input_path)
    X, y_sf, y_tp, groups, _summary = build_dataset(
        df, feature_columns=bundle["feature_columns"])
    _train_idx, test_idx = context_aware_split(
        groups, test_size=test_size, random_state=random_state)

    sf_pred = bundle["sf_model"].predict(X[test_idx])
    tp_pred = bundle["tp_model"].predict(X[test_idx])
    sf_true, tp_true, g = y_sf[test_idx], y_tp[test_idx], groups[test_idx]

    contexts: Dict[str, Dict] = {}
    for ctx in sorted({str(x) for x in g}):
        mask = np.array([str(x) == ctx for x in g])
        n = int(mask.sum())
        sf_ok = sf_pred[mask] == sf_true[mask]
        tp_ok = tp_pred[mask] == tp_true[mask]
        contexts[ctx] = {
            "n_rows": n,
            "sf_accuracy": float(sf_ok.mean()),
            "tp_accuracy": float(tp_ok.mean()),
            "joint_accuracy": float((sf_ok & tp_ok).mean()),
        }

    joint = [c["joint_accuracy"] for c in contexts.values()]
    mean = sum(joint) / len(joint) if joint else None
    std = (math.sqrt(sum((v - mean) ** 2 for v in joint) / len(joint))
           if joint else None)

    return {
        "banner": SYNTHETIC_BANNER,
        "n_contexts": len(contexts),
        "n_rows": int(sum(c["n_rows"] for c in contexts.values())),
        "worst_context_joint_accuracy": min(joint) if joint else None,
        "mean_context_joint_accuracy": mean,
        "std_context_joint_accuracy": std,
        "best_context_joint_accuracy": max(joint) if joint else None,
        "contexts": contexts,
        "caveat": STABILITY_CAVEAT,
    }
