# `ml/training/` — Model Training (Checkpoint 4, extended in Checkpoints 5 and 6)

> **SOFTWARE PIPELINE VALIDATION ONLY.** The project has no real LoRa data
> yet. Everything this package produces demonstrates that the pipeline
> executes — nothing more.

## Pipeline position

```
data/raw/<session>.csv
   -> ml/preprocessing/pipeline.py    (CP2)  clean + rolling history features
   -> ml/labeling/labeler.py          (CP3)  derive (SF, TP) targets
   -> ml/training/train_decision_tree.py       (CP4)  train tree, save, report
   -> ml/training/train_logistic_regression.py (CP5)  train LR,   save, report
   -> ml/training/train_random_forest.py       (CP6)  train small forest, save,
                                                      RELOAD+verify, REPRODUCE+verify, report
   -> ml/evaluation/evaluate.py       (CP4)  reload any bundle, score, report
   -> ml/evaluation/compare_models.py (CP5)  compare DT vs LR side by side (unchanged)
   -> ml/evaluation/compare_candidates.py (CP6)  compare DT vs LR vs RF side by side
```

## Modules

| File | Responsibility |
|---|---|
| `dataset.py` | Feature assembly, the leakage guard, and context-aware splitting — shared unchanged by both trainers |
| `train_decision_tree.py` | Trains the two trees, saves the bundle, writes metadata (Checkpoint 4) |
| `train_logistic_regression.py` | Trains two (StandardScaler + LogisticRegression) pipelines, saves the bundle, writes metadata (Checkpoint 5) |
| `train_random_forest.py` | Trains two SMALL `RandomForestClassifier`s, validates the configuration, saves the bundle, reloads and reproduces it to verify, writes metadata (Checkpoint 6) |

## Two rules this package enforces

**1. Causality.** The device picks SF and TX power *before* transmitting, so
any feature only knowable afterwards is unusable. `BANNED_FEATURE_COLUMNS`
rejects the current row's own `packet_success` and `retry_count` (outcomes of
the transmission being decided) and its own `sf` / `tp_dbm` (the decision
itself). The guard raises rather than warns, at both entry points.

The default feature set is Checkpoint 2's rolling history features, which are
already shifted by one packet. They carry all four project inputs — RSSI,
SNR, success/failure history, retry count — in lagged form.

The current row's `rssi_dbm` / `snr_db` are off by default: in a real log,
row *i*'s RSSI is measured *during* transmission *i*, so using it to choose
that transmission's configuration peeks one step ahead. `--include-current-link`
turns them on for comparison.

**2. Context-aware splitting.** One label covers every row of a context, so a
random row split would put the same context on both sides and let the model
score by recognition. All splitting is by `context_id`.

This also means **the effective sample size is the number of contexts, not
the number of rows.** 5,400 rows across 30 contexts is a 30-sample problem.
Every report states both.

## Model choice

**Checkpoint 4 — Decision Tree.** Two separate `DecisionTreeClassifier`s,
one per target, rather than one multi-output tree — small independently
inspectable decision functions suit the eventual ESP32 port, and
depth/nodes/size are reportable per target. The trade-off is that two
independent trees can emit a combination never seen in training; the joint
exact-match metric exists to expose that.

Not tuned. No hyperparameter search, no pruning sweep, no class weighting.
`max_depth=6` and `min_samples_leaf=5` keep the trees inspectable, not
optimal. Tuning belongs after real data exists.

**Checkpoint 5 — Logistic Regression.** A second lightweight candidate, on
the identical dataset, features and targets. Also two separate models — one
`LogisticRegression` per target — for the same inspectability reasoning as
the tree. Unlike a tree, Logistic Regression is scale-sensitive, so each
model is an `sklearn.Pipeline` of `(StandardScaler, LogisticRegression)`,
with the scaler fit on the training split only (fitting it on the full
dataset before splitting would itself leak test-split statistics into
training). Multinomial (softmax) classification is used natively — no
one-vs-rest wrapper — so 3+ class targets (e.g. spreading factor) are
handled directly.

Not tuned, same discipline as the tree. `C=1.0` is scikit-learn's default
regularisation strength; `max_iter` is set generously purely so the solver
reliably converges on this fixture, and convergence is recorded in the
metadata (`converged: bool`) rather than assumed.

**Neither model is presented as better than the other.**
`ml/evaluation/compare_models.py` evaluates both on an identical held-out
split and reports predictive metrics, model size, training time and
inference time side by side, with an explicit statement in every generated
report that none of it licenses a superiority claim on synthetic data.

**Checkpoint 6 — small Random Forest.** A third lightweight candidate on the
identical dataset, features and targets. Two separate forests, one per
target, as with the other two models. The trainer imports the same
unmodified `dataset.py` functions and does **not** accept a caller-supplied
feature list, so the feature set cannot drift from the other two.

*"Small" is a design constraint, not a default.* scikit-learn's default
forest (100 trees, unlimited depth) is the wrong starting point for an
eventual ESP32. Every size lever is configurable, the defaults are
deliberately conservative, and a **small-forest guard** rejects a forest that
is no longer small unless `--allow-large-forest` is passed:

| Parameter | Default | Guard limit (without override) |
|---|---|---|
| `--n-estimators` | 10 | 30 trees |
| `--max-depth` | 5 | 10; `none` (unlimited) rejected |
| `--min-samples-leaf` | 5 | must be an integer >= 1 |
| `--max-features` | `sqrt` | `sqrt`, `log2`, `none`, int, or float in (0, 1] |
| `--max-leaf-nodes` | none | optional cap, >= 2 |
| `--no-bootstrap` | bootstrap on | — |

The guard limits are project-chosen placeholders, **not measured ESP32
limits** — no ESP32 memory or latency figure exists yet. Not tuned: these
values were chosen to be small, not found to be optimal.

The trainer runs the pipeline `dataset -> split -> train -> evaluate -> save
-> reload -> reproducibility check`. The **reload** stage reads the file back
from disk and confirms it matches the in-memory forest (feature list, every
split feature/threshold, predictions and probabilities). The
**reproducibility** stage retrains from the same configuration and seed and
confirms the result is identical. Either failing raises
`ModelIntegrityError` and removes the model file.

*`oob_score` is deliberately not used.* Bootstrap resamples **rows**, and one
label covers ~180 rows of a context, so an out-of-bag row nearly always has
same-context siblings in the bag — an OOB score would be optimistic in the
same way a random row split is. Only the context-held-out metrics are
reported. Relatedly, with ~21 training contexts, row-bootstrapping adds
little diversity across contexts; most tree-to-tree variation comes from
`max_features` subsampling.

`ml/evaluation/compare_candidates.py` compares all three on an identical
held-out split (see its docstring). `compare_models.py` (the CP5 two-model
comparison) is unchanged.

## Usage

```bash
# Train the Decision Tree (writes model + metadata)
python -m ml.training.train_decision_tree \
    --input <labeled.csv> --outdir ml/models

# Train Logistic Regression (writes model + metadata)
python -m ml.training.train_logistic_regression \
    --input <labeled.csv> --outdir ml/models

# Train the small Random Forest (writes model + metadata)
python -m ml.training.train_random_forest \
    --input <labeled.csv> --outdir ml/models

# ...with a different (still small) configuration
python -m ml.training.train_random_forest --input <labeled.csv> \
    --n-estimators 6 --max-depth 4 --min-samples-leaf 10 --max-features 0.5

# Train without saving anything (any trainer)
python -m ml.training.train_decision_tree --input <labeled.csv> --no-save
python -m ml.training.train_logistic_regression --input <labeled.csv> --no-save
python -m ml.training.train_random_forest --input <labeled.csv> --no-save

# Compare the two, once both are trained
python -m ml.evaluation.compare_models \
    --dt-model ml/models/decision_tree_sf_tp.joblib \
    --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \
    --lr-model ml/models/logistic_regression_sf_tp.joblib \
    --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \
    --input <labeled.csv> --report <report.md>

# Compare all three, once all are trained (Checkpoint 6)
python -m ml.evaluation.compare_candidates \
    --dt-model ml/models/decision_tree_sf_tp.joblib \
    --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \
    --lr-model ml/models/logistic_regression_sf_tp.joblib \
    --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \
    --rf-model ml/models/random_forest_sf_tp.joblib \
    --rf-metadata ml/models/random_forest_sf_tp_metadata.json \
    --input <labeled.csv> --report <report.md>

# Verify the whole pipeline against synthetic test-only data
python tests/test_training.py               # Decision Tree (CP4)
python tests/test_logistic_regression.py    # Logistic Regression + comparison (CP5)
python tests/test_random_forest.py          # Small Random Forest + 3-way comparison (CP6)
```
