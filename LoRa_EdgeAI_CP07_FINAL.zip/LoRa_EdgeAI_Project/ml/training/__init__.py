"""
ml.training — Checkpoint 4: Decision Tree training. Checkpoint 5: Logistic
Regression training. Checkpoint 6: small Random Forest training
(ml/training/train_random_forest.py). Three lightweight candidates, all on the
same dataset/features/targets.

SOFTWARE PIPELINE VALIDATION ONLY. As of Checkpoint 6 the only data in this
project is fabricated test-fixture data, so nothing produced here is a
research result or a claim about real LoRa behaviour, and nothing here is
evidence that any one model family is better than another.

    SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT

Read ml/training/README.md before using any of this.
"""
