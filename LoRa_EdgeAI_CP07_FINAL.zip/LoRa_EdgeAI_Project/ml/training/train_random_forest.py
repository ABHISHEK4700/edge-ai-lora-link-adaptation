"""
train_random_forest.py

Checkpoint 6 — SMALL Random Forest training, model saving, reload and
reproducibility verification, and metadata reporting. The third lightweight
ML candidate, trained and evaluated exactly like Checkpoint 4's Decision Tree
and Checkpoint 5's Logistic Regression, for a software-level comparison.

*** SOFTWARE PIPELINE VALIDATION ONLY. ***
As of Checkpoint 6 the only data in this project is fabricated test-fixture
data. Anything this script produces demonstrates that the pipeline executes
for a third model family. It is not a research result, it says nothing about
real LoRa behaviour, and it is not evidence that a forest is better or worse
than the Decision Tree or Logistic Regression — see
ml/evaluation/compare_candidates.py for the explicit non-claims that govern
any comparison.

    SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT

WHY A *SMALL* FOREST, AND HOW "SMALL" IS ENFORCED
--------------------------------------------------
The eventual target is an ESP32. scikit-learn's default RandomForestClassifier
(100 trees, unlimited depth) is exactly the wrong starting point for that:
memory grows with n_estimators x nodes-per-tree, and unlimited depth lets each
tree memorise its bootstrap sample. This trainer therefore starts from a
deliberately conservative configuration and makes every size lever
configurable:

  n_estimators      10   — number of trees
  max_depth          5   — hard depth cap per tree
  min_samples_leaf   5   — controlled leaf size (same value as the CP4 tree)
  max_features    sqrt   — feature subsampling per split (this is what makes
                           the trees differ; see "Bootstrap caveat" below)
  bootstrap       True
  max_leaf_nodes  None   — optional extra cap on tree size

These are NOT tuned. They were chosen to be small, not found to be optimal.
`tuned: False` is recorded in the metadata exactly as for the other two
models.

A "small-forest guard" (SMALL_FOREST_MAX_TREES / SMALL_FOREST_MAX_DEPTH)
rejects configurations that are no longer small — more than 30 trees, deeper
than 10, or unlimited depth — unless the caller passes
`allow_large_forest=True` / `--allow-large-forest`. The guard exists so a
scikit-learn-default forest cannot be trained by accident. Its thresholds are
project-chosen placeholders, NOT measured ESP32 limits; no ESP32 memory or
latency figure exists yet.

SAME PIPELINE AS THE OTHER TWO MODELS
--------------------------------------
Nothing about the data path changes; only the model family does. This module
imports build_dataset(), context_aware_split(), describe_split(),
load_labeled_frame() and resolve_feature_columns() from the unmodified
ml/training/dataset.py, so there is exactly one leakage guard, one feature
set, and one splitting discipline shared by all three trainers.

It deliberately does NOT accept a caller-supplied feature list: the feature
set is whatever resolve_feature_columns() returns (the 8 causal rolling
features, or 10 with --include-current-link), identical to the other trainers.

Two separate forests are trained, one per target (SF, TP), mirroring the
"two models, not one multi-output model" decision from Checkpoints 4 and 5.

PIPELINE STAGES (all recorded in the metadata)
-----------------------------------------------
  labeled CSV -> build_dataset -> context-aware split -> train -> evaluate
  -> save -> RELOAD and verify -> REPRODUCIBILITY check (retrain, compare)

The reload stage proves the file on disk predicts identically to the model in
memory. The reproducibility stage retrains from the same configuration and
seed and proves the forest is structurally and numerically identical. Either
failing raises ModelIntegrityError — a model that cannot be reloaded or
reproduced is not a deliverable.

BOOTSTRAP CAVEAT, AND WHY oob_score IS NOT USED
------------------------------------------------
Bootstrap sampling here resamples ROWS. One label covers ~180 rows of a
context, so an out-of-bag row very likely has same-context siblings that WERE
in the bag. An out-of-bag score would therefore be optimistic in exactly the
way a random row split is (Checkpoint 3's "self-inclusion" leakage). oob_score
is hard-disabled and recorded as `oob_score_used: False`; the only
generalisation figure reported is the context-held-out one. Relatedly, with
~21 training contexts, row bootstrapping adds little diversity across
contexts — most tree-to-tree variation comes from max_features subsampling.

Usage:
    python -m ml.training.train_random_forest \\
        --input  <labeled.csv> \\
        --outdir ml/models/
"""

from __future__ import annotations

import argparse
import json
import numbers
import platform
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import numpy as np

from .dataset import (
    build_dataset,
    context_aware_split,
    describe_split,
    load_labeled_frame,
    resolve_feature_columns,
)

# --- Conservative defaults. NOT tuned — see module docstring. -------------
DEFAULT_N_ESTIMATORS = 10
DEFAULT_MAX_DEPTH = 5
DEFAULT_MIN_SAMPLES_LEAF = 5
DEFAULT_MAX_FEATURES = "sqrt"
DEFAULT_BOOTSTRAP = True
DEFAULT_MAX_LEAF_NODES = None
DEFAULT_TEST_SIZE = 0.3
DEFAULT_RANDOM_STATE = 0

# --- Small-forest guard. Project-chosen placeholders, NOT ESP32 limits. ---
SMALL_FOREST_MAX_TREES = 30
SMALL_FOREST_MAX_DEPTH = 10

MODEL_FILENAME = "random_forest_sf_tp.joblib"
METADATA_FILENAME = "random_forest_sf_tp_metadata.json"

_VALID_MAX_FEATURE_STRINGS = ("sqrt", "log2")

MaxFeatures = Union[str, int, float, None]


class InvalidForestConfigError(ValueError):
    """Raised for a Random Forest configuration that is invalid or is not
    'small' (and was not explicitly allowed to be large)."""


class ModelIntegrityError(RuntimeError):
    """Raised when a saved model fails its reload check, or a retrain from the
    same configuration/seed fails its reproducibility check."""


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def _is_int(v: Any) -> bool:
    """True for real integers, False for bool (True is an int in Python and
    `n_estimators=True` is a bug, not a configuration)."""
    return isinstance(v, numbers.Integral) and not isinstance(v, bool)


@dataclass(frozen=True)
class RandomForestConfig:
    """Every important Random Forest hyperparameter, validated on demand.

    Call .validate() (train() does) — construction alone does not raise, so
    a caller can build a config and inspect it before validating.
    """
    n_estimators: int = DEFAULT_N_ESTIMATORS
    max_depth: Optional[int] = DEFAULT_MAX_DEPTH
    min_samples_leaf: int = DEFAULT_MIN_SAMPLES_LEAF
    max_features: MaxFeatures = DEFAULT_MAX_FEATURES
    bootstrap: bool = DEFAULT_BOOTSTRAP
    max_leaf_nodes: Optional[int] = DEFAULT_MAX_LEAF_NODES
    random_state: int = DEFAULT_RANDOM_STATE
    allow_large_forest: bool = False

    def validate(self) -> "RandomForestConfig":
        """Raise InvalidForestConfigError if anything is wrong; else return self."""
        # n_estimators
        if not _is_int(self.n_estimators):
            raise InvalidForestConfigError(
                f"n_estimators must be an integer (got "
                f"{self.n_estimators!r} of type {type(self.n_estimators).__name__}).")
        if self.n_estimators < 1:
            raise InvalidForestConfigError(
                f"n_estimators must be >= 1 (got {self.n_estimators}).")

        # max_depth
        if self.max_depth is not None:
            if not _is_int(self.max_depth):
                raise InvalidForestConfigError(
                    f"max_depth must be an integer or None (got "
                    f"{self.max_depth!r} of type {type(self.max_depth).__name__}).")
            if self.max_depth < 1:
                raise InvalidForestConfigError(
                    f"max_depth must be >= 1 (got {self.max_depth}).")

        # min_samples_leaf — integer only: a leaf SIZE, so it stays predictable
        if not _is_int(self.min_samples_leaf):
            raise InvalidForestConfigError(
                f"min_samples_leaf must be an integer (got "
                f"{self.min_samples_leaf!r} of type "
                f"{type(self.min_samples_leaf).__name__}).")
        if self.min_samples_leaf < 1:
            raise InvalidForestConfigError(
                f"min_samples_leaf must be >= 1 (got {self.min_samples_leaf}).")

        # max_features
        mf = self.max_features
        if mf is None:
            pass
        elif isinstance(mf, str):
            if mf not in _VALID_MAX_FEATURE_STRINGS:
                raise InvalidForestConfigError(
                    f"max_features string must be one of "
                    f"{_VALID_MAX_FEATURE_STRINGS} (got {mf!r}).")
        elif isinstance(mf, bool):
            raise InvalidForestConfigError(
                f"max_features must be 'sqrt', 'log2', None, a positive int "
                f"or a float in (0, 1] (got bool {mf!r}).")
        elif _is_int(mf):
            if mf < 1:
                raise InvalidForestConfigError(
                    f"max_features as an int must be >= 1 (got {mf}).")
        elif isinstance(mf, numbers.Real):
            if not (0.0 < float(mf) <= 1.0):
                raise InvalidForestConfigError(
                    f"max_features as a float must be in (0, 1] (got {mf}).")
        else:
            raise InvalidForestConfigError(
                f"max_features must be 'sqrt', 'log2', None, a positive int "
                f"or a float in (0, 1] (got {mf!r}).")

        # bootstrap
        if not isinstance(self.bootstrap, bool):
            raise InvalidForestConfigError(
                f"bootstrap must be a bool (got {self.bootstrap!r}).")

        # max_leaf_nodes
        if self.max_leaf_nodes is not None:
            if not _is_int(self.max_leaf_nodes):
                raise InvalidForestConfigError(
                    f"max_leaf_nodes must be an integer or None (got "
                    f"{self.max_leaf_nodes!r}).")
            if self.max_leaf_nodes < 2:
                raise InvalidForestConfigError(
                    f"max_leaf_nodes must be >= 2 (got {self.max_leaf_nodes}).")

        # random_state
        if not _is_int(self.random_state):
            raise InvalidForestConfigError(
                f"random_state must be an integer (got {self.random_state!r}).")

        if not isinstance(self.allow_large_forest, bool):
            raise InvalidForestConfigError(
                f"allow_large_forest must be a bool (got "
                f"{self.allow_large_forest!r}).")

        # --- Small-forest guard -----------------------------------------
        if not self.allow_large_forest:
            if self.n_estimators > SMALL_FOREST_MAX_TREES:
                raise InvalidForestConfigError(
                    f"n_estimators={self.n_estimators} exceeds the small-forest "
                    f"limit of {SMALL_FOREST_MAX_TREES}. This project targets a "
                    f"forest small enough to consider for an ESP32. Pass "
                    f"allow_large_forest=True (--allow-large-forest) if a larger "
                    f"forest is intended.")
            if self.max_depth is None:
                raise InvalidForestConfigError(
                    "max_depth=None (unlimited depth) is not a small forest. "
                    "Give an explicit depth, or pass allow_large_forest=True "
                    "(--allow-large-forest) if unlimited depth is intended.")
            if self.max_depth > SMALL_FOREST_MAX_DEPTH:
                raise InvalidForestConfigError(
                    f"max_depth={self.max_depth} exceeds the small-forest limit "
                    f"of {SMALL_FOREST_MAX_DEPTH}. Pass allow_large_forest=True "
                    f"(--allow-large-forest) if a deeper forest is intended.")
        return self

    def check_against_n_features(self, n_features: int) -> None:
        """max_features as an int cannot exceed the number of features."""
        if _is_int(self.max_features) and self.max_features > n_features:
            raise InvalidForestConfigError(
                f"max_features={self.max_features} exceeds the number of "
                f"features available ({n_features}).")

    def to_dict(self) -> Dict:
        return asdict(self)


def validate_test_size(test_size: Any) -> None:
    """test_size is the fraction of CONTEXTS held out; must be in (0, 1)."""
    if isinstance(test_size, bool) or not isinstance(test_size, numbers.Real):
        raise InvalidForestConfigError(
            f"test_size must be a number in (0, 1) (got {test_size!r}).")
    if not (0.0 < float(test_size) < 1.0):
        raise InvalidForestConfigError(
            f"test_size must be strictly between 0 and 1 (got {test_size}).")


def _make_forest(cfg: RandomForestConfig):
    """Build one (unfitted) RandomForestClassifier from a validated config.

    n_jobs=1 on purpose: results are deterministic regardless of thread
    scheduling, and tiny-model timings are not distorted by thread-pool
    start-up. oob_score=False on purpose — see the module docstring.
    """
    from sklearn.ensemble import RandomForestClassifier
    return RandomForestClassifier(
        n_estimators=cfg.n_estimators,
        max_depth=cfg.max_depth,
        min_samples_leaf=cfg.min_samples_leaf,
        max_features=cfg.max_features,
        bootstrap=cfg.bootstrap,
        max_leaf_nodes=cfg.max_leaf_nodes,
        oob_score=False,
        n_jobs=1,
        random_state=cfg.random_state,
    )


# ---------------------------------------------------------------------------
# Structure, timing, integrity checks
# ---------------------------------------------------------------------------

def forest_stats(clf, feature_columns: List[str]) -> Dict:
    """Structural statistics of a fitted RandomForestClassifier.

    These (trees, depth, node/leaf counts) are the quantities a later export
    checkpoint would budget an ESP32 footprint against. They are reported as
    structure only — no ESP32 byte or latency figure is derived from them.
    """
    depths = [int(e.get_depth()) for e in clf.estimators_]
    nodes = [int(e.tree_.node_count) for e in clf.estimators_]
    leaves = [int(e.get_n_leaves()) for e in clf.estimators_]
    importances = {
        name: float(score)
        for name, score in zip(feature_columns, clf.feature_importances_)
    }
    return {
        "n_trees": int(len(clf.estimators_)),
        "n_estimators_configured": int(clf.n_estimators),
        "max_depth_configured": clf.max_depth,
        "actual_max_depth": int(max(depths)),
        "actual_mean_depth": float(np.mean(depths)),
        "actual_min_depth": int(min(depths)),
        "tree_depths": depths,
        "tree_node_counts": nodes,
        "tree_leaf_counts": leaves,
        "total_nodes": int(sum(nodes)),
        "total_leaves": int(sum(leaves)),
        "mean_nodes_per_tree": float(np.mean(nodes)),
        "min_samples_leaf": int(clf.min_samples_leaf),
        "max_features_configured": clf.max_features,
        "max_features_resolved_per_split": int(clf.estimators_[0].max_features_),
        "bootstrap": bool(clf.bootstrap),
        "n_features_used_by_any_tree": int(np.sum(clf.feature_importances_ > 0)),
        "n_classes": int(len(clf.classes_)),
        "classes": [_py(c) for c in clf.classes_],
        "oob_score_used": hasattr(clf, "oob_score_"),
        "feature_importances": importances,
        "feature_importances_note": (
            "Impurity-based (mean decrease in impurity) and computed from "
            "synthetic data. Structural information only, not a statement "
            "about which channel features matter in reality."
        ),
    }


def compare_forests(a, b, X: np.ndarray) -> Dict:
    """Are two fitted forests structurally and numerically identical on X?

    Compares tree count, per-tree node counts, every split feature and
    threshold, class list, and both hard and probabilistic predictions.
    Pure function — used by the reload check and the reproducibility check,
    and directly by the tests (including with deliberately different forests
    to prove the comparison can actually fail).
    """
    problems: List[str] = []

    if len(a.estimators_) != len(b.estimators_):
        problems.append(
            f"tree count differs ({len(a.estimators_)} vs {len(b.estimators_)})")
    else:
        for i, (ta, tb) in enumerate(zip(a.estimators_, b.estimators_)):
            if ta.tree_.node_count != tb.tree_.node_count:
                problems.append(f"tree {i}: node count differs")
                continue
            if not np.array_equal(ta.tree_.feature, tb.tree_.feature):
                problems.append(f"tree {i}: split features differ")
            if not np.array_equal(ta.tree_.threshold, tb.tree_.threshold):
                problems.append(f"tree {i}: split thresholds differ")

    if not np.array_equal(a.classes_, b.classes_):
        problems.append("class lists differ")
    if a.n_features_in_ != b.n_features_in_:
        problems.append(
            f"n_features_in_ differs ({a.n_features_in_} vs {b.n_features_in_})")

    if not problems:
        # Only meaningful once the structure agrees (and X's width fits).
        if not np.array_equal(a.predict(X), b.predict(X)):
            problems.append("hard predictions differ")
        if not np.array_equal(a.predict_proba(X), b.predict_proba(X)):
            problems.append("predicted probabilities differ")

    return {"passed": not problems, "problems": problems}


def verify_reload(model_path: Path, bundle: Dict, X_check: np.ndarray) -> Dict:
    """Reload the saved bundle from disk and confirm it matches the in-memory
    one: same feature list, same forests (structure + predictions)."""
    import joblib

    reloaded = joblib.load(model_path)
    problems: List[str] = []

    for key in ("sf_model", "tp_model", "feature_columns"):
        if key not in reloaded:
            problems.append(f"reloaded bundle is missing {key!r}")
    if not problems:
        if list(reloaded["feature_columns"]) != list(bundle["feature_columns"]):
            problems.append("feature_columns differ after reload")
        for key in ("sf_model", "tp_model"):
            res = compare_forests(bundle[key], reloaded[key], X_check)
            problems.extend(f"{key}: {p}" for p in res["problems"])

    return {
        "performed": True,
        "passed": not problems,
        "problems": problems,
        "rows_checked": int(len(X_check)),
        "what_was_compared": (
            "feature list, tree count, every split feature and threshold, "
            "class lists, hard predictions and predicted probabilities, for "
            "both the SF and TX-power forests"
        ),
    }


def verify_reproducibility(
    cfg: RandomForestConfig,
    X_tr: np.ndarray, sf_tr: np.ndarray, tp_tr: np.ndarray,
    sf_model, tp_model, X_check: np.ndarray,
) -> Dict:
    """Retrain both forests from the same config, seed and data, and confirm
    they are identical to the ones just trained."""
    sf_again = _make_forest(cfg).fit(X_tr, sf_tr)
    tp_again = _make_forest(cfg).fit(X_tr, tp_tr)

    problems: List[str] = []
    for name, first, second in (("sf_model", sf_model, sf_again),
                                ("tp_model", tp_model, tp_again)):
        res = compare_forests(first, second, X_check)
        problems.extend(f"{name}: {p}" for p in res["problems"])

    return {
        "performed": True,
        "passed": not problems,
        "problems": problems,
        "random_state": cfg.random_state,
        "rows_checked": int(len(X_check)),
        "what_was_compared": (
            "a second fit from the identical config, seed and training rows "
            "versus the first fit: tree structure, split features/thresholds, "
            "hard predictions and predicted probabilities, both targets"
        ),
    }


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

def train(
    input_path: str,
    outdir: str,
    n_estimators: int = DEFAULT_N_ESTIMATORS,
    max_depth: Optional[int] = DEFAULT_MAX_DEPTH,
    min_samples_leaf: int = DEFAULT_MIN_SAMPLES_LEAF,
    max_features: MaxFeatures = DEFAULT_MAX_FEATURES,
    bootstrap: bool = DEFAULT_BOOTSTRAP,
    max_leaf_nodes: Optional[int] = DEFAULT_MAX_LEAF_NODES,
    test_size: float = DEFAULT_TEST_SIZE,
    random_state: int = DEFAULT_RANDOM_STATE,
    include_current_link: bool = False,
    allow_large_forest: bool = False,
    save_model: bool = True,
    verify_reproducibility_check: bool = True,
) -> Dict:
    """Train SF and TX-power small Random Forests and save the model bundle.

    Returns a metadata dict (also written to disk as JSON). Mirrors
    ml.training.train_decision_tree.train() and
    ml.training.train_logistic_regression.train() in shape and in every scope
    constraint (same dataset, same features, same targets, same split, same
    synthetic-data banner and non-claims), so all three are directly
    comparable.

    Configuration is validated BEFORE anything is read or written, so an
    invalid configuration leaves no files behind.
    """
    import joblib

    from ml.evaluation.metrics import (
        SYNTHETIC_BANNER,
        classification_metrics,
        joint_exact_match,
        per_context_agreement,
    )
    from ml.evaluation.timing import measure_inference

    cfg = RandomForestConfig(
        n_estimators=n_estimators, max_depth=max_depth,
        min_samples_leaf=min_samples_leaf, max_features=max_features,
        bootstrap=bootstrap, max_leaf_nodes=max_leaf_nodes,
        random_state=random_state, allow_large_forest=allow_large_forest,
    ).validate()
    validate_test_size(test_size)

    # --- Data: identical path to the Decision Tree / Logistic Regression ---
    feature_columns = resolve_feature_columns(include_current_link)
    cfg.check_against_n_features(len(feature_columns))

    df = load_labeled_frame(input_path)
    X, y_sf, y_tp, groups, summary = build_dataset(
        df, feature_columns=feature_columns
    )

    train_idx, test_idx = context_aware_split(
        groups, test_size=test_size, random_state=random_state
    )
    split_info = describe_split(groups, train_idx, test_idx)

    X_tr, X_te = X[train_idx], X[test_idx]
    sf_tr, sf_te = y_sf[train_idx], y_sf[test_idx]
    tp_tr, tp_te = y_tp[train_idx], y_tp[test_idx]
    groups_te = groups[test_idx]

    stages: List[Dict] = [
        {"stage": "load_labeled_csv_and_build_dataset", "status": "done"},
        {"stage": "context_aware_split", "status": "done"},
    ]

    # --- Train ---------------------------------------------------------------
    sf_clf = _make_forest(cfg)
    start = time.perf_counter()
    sf_clf.fit(X_tr, sf_tr)
    sf_train_seconds = time.perf_counter() - start

    tp_clf = _make_forest(cfg)
    start = time.perf_counter()
    tp_clf.fit(X_tr, tp_tr)
    tp_train_seconds = time.perf_counter() - start
    stages.append({"stage": "train_random_forest_x2", "status": "done"})

    # --- Predict and evaluate ------------------------------------------------
    sf_pred = sf_clf.predict(X_te)
    tp_pred = tp_clf.predict(X_te)

    sf_metrics = classification_metrics(sf_te, sf_pred, "spreading_factor", sf_tr)
    tp_metrics = classification_metrics(tp_te, tp_pred, "tx_power_dbm", tp_tr)
    joint = joint_exact_match(sf_te, sf_pred, tp_te, tp_pred)
    by_context = per_context_agreement(groups_te, sf_te, sf_pred, tp_te, tp_pred)
    stages.append({"stage": "evaluate_on_held_out_contexts", "status": "done"})

    # --- Save -----------------------------------------------------------------
    out = Path(outdir)
    model_path = out / MODEL_FILENAME
    model_bytes = None

    bundle = {
        "sf_model": sf_clf,
        "tp_model": tp_clf,
        "feature_columns": feature_columns,
        "sf_target": "label_sf",
        "tp_target": "label_tp_dbm",
        "model_family": "RandomForestClassifier (scikit-learn, small forest), "
                        "one per target",
        "forest_config": cfg.to_dict(),
        "provenance": SYNTHETIC_BANNER,
        "trained_from": str(input_path),
    }

    reload_check: Dict = {"performed": False, "reason": "model was not saved (--no-save)"}
    if save_model:
        out.mkdir(parents=True, exist_ok=True)
        joblib.dump(bundle, model_path)
        model_bytes = model_path.stat().st_size
        stages.append({"stage": "save_model", "status": "done"})

        # --- Reload and verify ----------------------------------------------
        reload_check = verify_reload(model_path, bundle, X_te)
        if not reload_check["passed"]:
            _discard(model_path)
            raise ModelIntegrityError(
                "The saved model did not match the in-memory model after "
                f"reload: {reload_check['problems']}. The model file was "
                "removed.")
        stages.append({"stage": "reload_and_verify", "status": "done"})
    else:
        stages.append({"stage": "save_model", "status": "skipped (--no-save)"})
        stages.append({"stage": "reload_and_verify", "status": "skipped (--no-save)"})

    # --- Reproducibility -------------------------------------------------------
    if verify_reproducibility_check:
        repro_check = verify_reproducibility(
            cfg, X_tr, sf_tr, tp_tr, sf_clf, tp_clf, X_te)
        if not repro_check["passed"]:
            if save_model:
                _discard(model_path)
            raise ModelIntegrityError(
                "Retraining from the identical configuration and seed did not "
                f"reproduce the model: {repro_check['problems']}."
                + (" The model file was removed." if save_model else ""))
        stages.append({"stage": "reproducibility_check", "status": "done"})
    else:
        repro_check = {"performed": False, "reason": "disabled by caller"}
        stages.append({"stage": "reproducibility_check", "status": "skipped"})

    inference = measure_inference({"sf": sf_clf, "tp": tp_clf}, X_te)

    # --- Metadata ------------------------------------------------------------
    metadata = {
        "banner": SYNTHETIC_BANNER,
        "status": "SOFTWARE PIPELINE VALIDATION ONLY — no real hardware data",
        "checkpoint": "CP06",
        "model_family": "RandomForestClassifier (scikit-learn, small forest), "
                        "one per target",
        "tuned": False,
        "tuning_note": (
            "No hyperparameter search was performed. The forest size, depth, "
            "leaf size and feature-subsampling values are conservative fixed "
            "defaults chosen to be SMALL (for eventual ESP32 consideration), "
            "not because they were found to be optimal."
        ),
        "pipeline_stages": stages,
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "scikit_learn": _sklearn_version(),
            "joblib": _joblib_version(),
        },
        "data": summary.as_dict(),
        "split": split_info,
        "hyperparameters": {
            **cfg.to_dict(),
            "test_size": test_size,
            "include_current_link_features": include_current_link,
            "n_jobs": 1,
            "oob_score": False,
        },
        "small_forest_guard": {
            "max_trees_without_override": SMALL_FOREST_MAX_TREES,
            "max_depth_without_override": SMALL_FOREST_MAX_DEPTH,
            "override_used": bool(cfg.allow_large_forest),
            "note": (
                "Project-chosen placeholder thresholds that stop a "
                "scikit-learn-default (100 trees, unlimited depth) forest "
                "being trained by accident. They are NOT measured ESP32 "
                "limits — no ESP32 memory or latency measurement exists yet."
            ),
        },
        "oob_score_used": False,
        "oob_score_note": (
            "Out-of-bag scoring is deliberately not used: bootstrap "
            "resamples rows, and rows from the same context appear both "
            "in-bag and out-of-bag, so an OOB score would be optimistic in "
            "the same way a random row split is. Only the context-held-out "
            "metrics below are reported."
        ),
        "sf_forest": {
            **forest_stats(sf_clf, feature_columns),
            "training_seconds": sf_train_seconds,
        },
        "tp_forest": {
            **forest_stats(tp_clf, feature_columns),
            "training_seconds": tp_train_seconds,
        },
        "total_training_seconds": sf_train_seconds + tp_train_seconds,
        "inference_timing": inference,
        "model_file": {
            "path": str(model_path) if save_model else None,
            "bytes": model_bytes,
            "kilobytes": round(model_bytes / 1024, 2) if model_bytes else None,
            "format": "joblib (scikit-learn objects)",
            "note": (
                "This is the desktop serialisation size of two scikit-learn "
                "forests including Python object overhead, not an ESP32 "
                "footprint. Converting the forest to something an ESP32 can "
                "run — and measuring its real size — is a later checkpoint."
            ),
        },
        "reload_check": reload_check,
        "reproducibility_check": repro_check,
        "metrics": {
            "banner": SYNTHETIC_BANNER,
            "spreading_factor": sf_metrics,
            "tx_power_dbm": tp_metrics,
            "joint": joint,
            "per_context": by_context,
        },
        "explicit_non_claims": [
            "This does NOT demonstrate improved packet delivery ratio.",
            "This does NOT demonstrate improved latency.",
            "This does NOT demonstrate improved energy consumption.",
            "This does NOT demonstrate faster adaptation than ADR.",
            "This model is NOT validated for real LoRa communication.",
            "These metrics are NOT evidence of project success.",
            "This does NOT show the Random Forest is better or worse than "
            "the Decision Tree or Logistic Regression — see "
            "ml/evaluation/compare_candidates.py for a direct, "
            "equally-caveated comparison.",
            "This does NOT show that an ensemble helps, or that this forest "
            "fits on or runs fast enough on an ESP32 — no ESP32 footprint or "
            "latency has been measured.",
            ("The fixture is trivially separable by construction, so a high "
             "score is expected and indicates only that the code ran."),
        ],
    }

    if save_model:
        with open(out / METADATA_FILENAME, "w", encoding="utf-8") as fh:
            json.dump(metadata, fh, indent=2)
            fh.write("\n")

    return metadata


def _discard(path: Path) -> None:
    """Remove a model file that failed an integrity check (best effort)."""
    try:
        Path(path).unlink()
    except OSError:
        pass


def _sklearn_version() -> str:
    import sklearn
    return sklearn.__version__


def _joblib_version() -> str:
    import joblib
    return joblib.__version__


def _py(v):
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return float(v)
    return v


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_max_features(text: str) -> MaxFeatures:
    t = text.strip().lower()
    if t in _VALID_MAX_FEATURE_STRINGS:
        return t
    if t in ("none", "all"):
        return None
    try:
        return int(t)
    except ValueError:
        pass
    try:
        return float(t)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"max-features must be sqrt, log2, none, an integer or a float "
            f"(got {text!r}).")


def _parse_optional_int(text: str) -> Optional[int]:
    if text.strip().lower() == "none":
        return None
    try:
        return int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"expected an integer or 'none' (got {text!r}).")


def _build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Train SMALL Random Forest SF/TX-power predictors from a labeled "
            "CSV. SOFTWARE PIPELINE VALIDATION ONLY — not a research run."
        )
    )
    p.add_argument("--input", "-i", required=True,
                   help="Labeled CSV from ml.labeling.labeler.")
    p.add_argument("--outdir", "-o", default="ml/models",
                   help="Directory to write the model and metadata to.")
    p.add_argument("--n-estimators", type=int, default=DEFAULT_N_ESTIMATORS,
                   help=f"Number of trees (default {DEFAULT_N_ESTIMATORS}; "
                        f"more than {SMALL_FOREST_MAX_TREES} needs "
                        f"--allow-large-forest).")
    p.add_argument("--max-depth", type=_parse_optional_int, default=DEFAULT_MAX_DEPTH,
                   help=f"Max depth per tree (default {DEFAULT_MAX_DEPTH}; "
                        f"'none' or more than {SMALL_FOREST_MAX_DEPTH} needs "
                        f"--allow-large-forest).")
    p.add_argument("--min-samples-leaf", type=int, default=DEFAULT_MIN_SAMPLES_LEAF,
                   help=f"Minimum samples per leaf (default {DEFAULT_MIN_SAMPLES_LEAF}).")
    p.add_argument("--max-features", type=_parse_max_features,
                   default=DEFAULT_MAX_FEATURES,
                   help="Features considered per split: sqrt, log2, none, an "
                        f"int, or a float fraction (default {DEFAULT_MAX_FEATURES}).")
    p.add_argument("--no-bootstrap", action="store_true",
                   help="Train each tree on the full training set instead of "
                        "a bootstrap sample.")
    p.add_argument("--max-leaf-nodes", type=_parse_optional_int,
                   default=DEFAULT_MAX_LEAF_NODES,
                   help="Optional cap on leaves per tree (default none).")
    p.add_argument("--test-size", type=float, default=DEFAULT_TEST_SIZE,
                   help=f"Fraction of CONTEXTS held out (default {DEFAULT_TEST_SIZE}).")
    p.add_argument("--random-state", type=int, default=DEFAULT_RANDOM_STATE)
    p.add_argument("--include-current-link", action="store_true",
                   help="Also use the current row's rssi_dbm/snr_db as features. "
                        "Off by default — see ml/training/dataset.py on causality.")
    p.add_argument("--allow-large-forest", action="store_true",
                   help="Permit more trees / deeper trees than the small-forest "
                        "guard allows. Not what this project targets.")
    p.add_argument("--skip-reproducibility-check", action="store_true",
                   help="Skip the retrain-and-compare reproducibility stage.")
    p.add_argument("--no-save", action="store_true",
                   help="Train and report without writing any model file.")
    return p


def main(argv=None):
    args = _build_arg_parser().parse_args(argv)

    try:
        metadata = train(
            input_path=args.input,
            outdir=args.outdir,
            n_estimators=args.n_estimators,
            max_depth=args.max_depth,
            min_samples_leaf=args.min_samples_leaf,
            max_features=args.max_features,
            bootstrap=not args.no_bootstrap,
            max_leaf_nodes=args.max_leaf_nodes,
            test_size=args.test_size,
            random_state=args.random_state,
            include_current_link=args.include_current_link,
            allow_large_forest=args.allow_large_forest,
            save_model=not args.no_save,
            verify_reproducibility_check=not args.skip_reproducibility_check,
        )
    except FileNotFoundError:
        print(f"ERROR: input file not found: {args.input}", file=sys.stderr)
        print("Produce one with: python -m ml.labeling.labeler --input "
              "<processed.csv> --output <labeled.csv>", file=sys.stderr)
        sys.exit(1)
    except (ValueError, ModelIntegrityError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    from ml.evaluation.metrics import SYNTHETIC_BANNER
    print("=" * 70)
    print(SYNTHETIC_BANNER)
    print("=" * 70)
    print(json.dumps(metadata, indent=2))
    print("=" * 70)
    print(SYNTHETIC_BANNER)
    print("=" * 70)


if __name__ == "__main__":
    main()
