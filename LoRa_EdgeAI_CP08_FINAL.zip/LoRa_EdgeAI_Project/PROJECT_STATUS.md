# PROJECT STATUS

Last updated: Checkpoint 8 — Real Hardware Data Collection Readiness (CP08 COMPLETE; no real data exists)
This file is the single source of truth for project state. Read this file
fully before doing any new work, especially if you are a new AI assistant
session with no memory of prior conversations.

---

## 0. Portability Snapshot — read this first

Everything a new session needs in one place. The numbered sections below
(1-9) are the detailed record; this section is the summary and points to them.

> #### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Every metric this project has ever produced came from **fabricated
> test-fixture data**, which is separable by construction. It shows that the
> **software runs** — **software validation only**. It shows nothing about
> real LoRa behaviour, packet delivery ratio, latency, energy consumption,
> adaptation speed, or which model is better. No claim of that kind exists
> anywhere in this project and none may be added until real hardware data
> exists.

> #### FINAL MODEL SELECTION: TBD — to be determined using real data and ESP32 deployment measurements.
>
> No candidate (Decision Tree, Logistic Regression, small Random Forest) is
> selected, recommended or preferred, and none may be called "best", until
> real ESP32 + LoRa data has been collected, all three models retrained and
> re-compared on it, and an exported model measured on an ESP32. Checkpoint 7
> built the **framework** that will make that comparison. It did not make it,
> and `select_candidate()` is written so that it cannot.

> #### NO REAL HARDWARE DATA EXISTS — CHECKPOINT 8 BUILT READINESS, NOT DATA
>
> Checkpoint 8 (CP08) built `ml/collection/` and its documents so that real
> ESP32 + LoRa measurements can be validated, converted and fed to the
> unchanged CP02-CP07 pipeline. It did **not** collect, generate or imply any
> measurement. Every CP08 test row is clearly-marked **synthetic software-test
> data** (`data_origin = synthetic_test`) held in memory or a temporary
> directory. **Future real hardware measurements** have not been taken: no
> device has been powered, no firmware exists, and `data/` is empty. No real
> PDR, latency, energy or RSSI/SNR improvement and no model superiority is
> claimed anywhere. External/public LoRa datasets are not used and must stay
> excluded.

### 0.1 Checkpoint status, CP01–CP08

| Checkpoint | Scope | Status |
|---|---|---|
| **CP01** | Project foundation / scaffolding | **COMPLETE** |
| **CP02** | Data schema, preprocessing pipeline, data-collection plan | **COMPLETE** |
| **CP03** | Target-label strategy & labeling framework | **COMPLETE** |
| **CP04** | Decision Tree training/evaluation (software validation) | **COMPLETE** |
| **CP05** | Logistic Regression + DT-vs-LR comparison (software validation) | **COMPLETE** |
| **CP06** | Small Random Forest + three-model comparison (software validation) | **COMPLETE** |
| **CP07** | Model comparison & selection framework (software validation) | **COMPLETE** |
| **CP08** | Real-data collection **readiness** (schema, manifest, configs, validator, adapter, logger, procedure, readiness report) — synthetic software-test data only; **no real data collected** | **COMPLETE** |
| **CP09** | Not defined by the user yet | **NOT STARTED** |

### 0.2 All current model candidates

All three are lightweight scikit-learn classifiers on the **same** dataset,
preprocessing, labeling, 8 causal features, context-aware split and leakage
guards. Each is two separate models (one for SF, one for TP). **None is tuned,
none is trained on real data, none is selected or recommended — final model
selection is TBD — to be determined using real data and ESP32 deployment measurements.**

| Candidate | Checkpoint | Trainer | Saved files (not committed) | Configuration |
|---|---|---|---|---|
| Decision Tree | CP04 | `ml/training/train_decision_tree.py` | `decision_tree_sf_tp.joblib` + `_metadata.json` | `max_depth=6`, `min_samples_leaf=5` |
| Logistic Regression | CP05 | `ml/training/train_logistic_regression.py` | `logistic_regression_sf_tp.joblib` + `_metadata.json` | `StandardScaler` + multinomial LR, `C=1.0`, `max_iter=2000` |
| Small Random Forest | CP06 | `ml/training/train_random_forest.py` | `random_forest_sf_tp.joblib` + `_metadata.json` | `n_estimators=10`, `max_depth=5`, `min_samples_leaf=5`, `max_features="sqrt"`, bootstrap; guard at 30 trees / depth 10 |

Features (identical for all three): the 8 causal rolling-history features
built from RSSI, SNR, packet success/failure history and retry count — **no
GPS, distance, location or other experimental metadata**. Targets: Spreading
Factor (SF) and Transmission Power (TP).

Comparison tools: `ml/evaluation/compare_models.py` (CP05, DT vs LR,
unchanged), `ml/evaluation/compare_candidates.py` (CP06, all three,
unchanged) and, new in CP07, `ml/evaluation/generate_comparison_report.py`
with `resource_profile.py`, `context_stability.py` and `decision_framework.py`.

### 0.3 Current software capabilities

- Validate and preprocess raw LoRa link logs into causal rolling-history
  features (CP02).
- Derive evidence-backed (SF, TP) labels from a configuration sweep, with
  honesty guards that refuse to guess (CP03).
- Assemble a leak-guarded dataset and split it by channel context (CP04).
- Train, save, reload and evaluate a Decision Tree, a Logistic Regression and
  a small Random Forest, each with metadata (structure, size, training time,
  inference time, metrics, explicit non-claims) (CP04-CP06).
- Validate Random Forest hyperparameters, refuse a forest that is no longer
  small unless explicitly overridden, and verify a saved forest by reloading
  it and by reproducing its training (CP06).
- Compare all three models on an identical held-out split with one shared
  inference-timing harness, refusing mismatched feature sets (CP06).
- **Comparison capabilities added in CP07**, all via
  `python -m ml.evaluation.generate_comparison_report`:
  - *Predictive performance:* SF and TX-power accuracy, macro F1,
    majority-class baselines, joint exact match, per-context accuracy,
    **confusion matrices**, and consistency across held-out contexts
    (worst / mean / std / best).
  - *Computational / resource:* training time, batch and single-decision
    inference time, serialized model size, trees / depth / total nodes, fitted parameter
    counts (linear coefficients + intercepts, scaler values), and
    desktop-proxy "embedded suitability" labels from configurable thresholds.
  - *Reproducibility:* same dataset, preprocessing, labeling, feature set and
    split, a `--random-state` control, and a determinism test.
  - *Decision framework:* six configurable factors (predictive performance,
    model size, inference latency, memory requirements, embedded feasibility,
    stability/generalisation), per-factor normalised scores, optional
    illustrative weighted scores (hidden by default), and a selection status
    fixed to TBD.
  - *Report:* Markdown + JSON, with **"SYNTHETIC SOFTWARE-VALIDATION
    RESULTS"** (section A) separated from **"REAL HARDWARE RESULTS — NOT YET
    AVAILABLE"** (section B, a placeholder with no numbers) and the decision
    framework (section C).
- **Capabilities added in CP08** (`ml/collection/`; software only, verified on
  synthetic software-test data):
  - Define the real-data CSV schema (31 columns, a strict superset of the 13
    CP02 raw columns) and generate `experiments/REAL_DATA_SCHEMA.md` from it.
  - Describe a session in a manifest and refuse to start collection while any
    hardware/region value is `UNSET`.
  - Hold `sweep`, `baseline` and `edge_ai` experiment configurations, check
    baseline/Edge-AI parity and training/evaluation separation, and carry a
    fixed claims policy and a pre-declared analysis plan.
  - Validate a real log CSV (fields, consistency, sequence, provenance gate,
    manifest cross-checks, sweep coverage).
  - Convert a validated log into the CP02 raw CSV under an explicit purpose and
    an explicit missing-link policy (the survivorship-bias guard).
  - Parse checksummed serial lines and write an append-safe session log.
  - Report whether the software is ready (yes) and whether a real run may start
    (no).
- Eight test suites (`tests/`), all passing — see section 3, "Verification
  performed during Checkpoint 8".

Not capable of: reading real data (none exists), running on an ESP32,
exporting/quantizing a model, selecting a model, or producing any research
result.

### 0.4a Files created / modified in Checkpoint 8

**Files created**

| File | Purpose |
|---|---|
| `ml/collection/__init__.py`, `_util.py` | package docstring; `UNSET` marker and `find_unset()` |
| `ml/collection/real_schema.py` | 31-column real-data schema; CP02-superset proof; metadata-is-not-a-feature guard |
| `ml/collection/manifest.py` | per-session manifest (hardware, radio config, conditions); every region/radio value `UNSET` by default |
| `ml/collection/experiment_config.py` | `sweep` / `baseline` / `edge_ai` configs, `AnalysisPlan`, `CLAIMS_POLICY`, parity and overlap checks |
| `ml/collection/validator.py` | real-log validation, provenance gate, sweep coverage |
| `ml/collection/adapter.py` | `to_cp02_raw()` — real log to CP02 raw CSV with explicit purpose and missing-link policy |
| `ml/collection/planner.py` | collection-budget arithmetic (planning, not measurement) |
| `ml/collection/logger.py` | `LORALOG1` / `LORACTX1` checksummed line protocol and `SessionLogger` |
| `ml/collection/readiness.py` | software-ready vs collection-ready report |
| `ml/collection/README.md` | module map, quick start, guards, tests, current state |
| `experiments/REAL_DATA_SCHEMA.md` | schema document generated from code (a test fails on drift) |
| `experiments/EXPERIMENT_PROCEDURE.md` | session kinds, arm interleaving, frozen model, analysis plan, data hygiene |
| `experiments/FIRMWARE_LOGGING_SPEC.md` | contract for future firmware (no firmware exists) |
| `experiments/configs/*.json` (4) | `sweep`, `baseline`, `edge_ai` and session-manifest templates, all `UNSET` |
| `tests/test_real_data_collection.py` | 27 CP08 checks |
| `tests/fixtures/make_cp08_synthetic_log.py` | deterministic, clearly-marked synthetic test-row generator |

**Files modified:** `data/raw/README.md` (section on real hardware logs added),
`experiments/DATA_COLLECTION_PLAN.md` (section 9 appended, earlier sections
unchanged), `README.md`, `PROJECT_STATUS.md`, `CHANGELOG.md`,
`CHECKPOINT_PROGRESS.md`. In the documentation-synchronisation session no
functional code changed.

**Preserved byte-identical:** 64 CP01-CP07 files, pinned by SHA-256 in
`tests/test_real_data_collection.py` (all earlier sources, tests, fixtures,
`tests/fixtures/README.md`, `requirements.txt`, earlier run records).

### 0.4 Files created / modified in Checkpoint 7

**Files created**

| File | Purpose |
|---|---|
| `ml/evaluation/resource_profile.py` | Resource-only view of the comparison + fitted parameter/node counts read from the saved models + configurable desktop-proxy embedded-suitability labels (`SuitabilityThresholds`) |
| `ml/evaluation/context_stability.py` | Per-held-out-context joint accuracy (worst / mean / std / best), no retraining — the stability factor's input |
| `ml/evaluation/decision_framework.py` | Six-factor scoring, `FactorWeights`, illustrative weighted score, `select_candidate()` (always the fixed TBD status) |
| `ml/evaluation/generate_comparison_report.py` | Full report + JSON generator and command line: A synthetic / B real hardware (placeholder) / C decision framework |
| `tests/test_model_comparison_framework.py` | 20 CP07 checks |
| `experiments/CP07_MODEL_COMPARISON_FRAMEWORK_RUN.md` | Committed record of one report run, generated from real run output |
| `CHECKPOINT_PROGRESS.md` | Working log of the CP07 build stages and backup snapshots |

**Files modified** (prose/docstring only — no functional code changed)

`README.md`, `PROJECT_STATUS.md`, `CHANGELOG.md`, `ml/evaluation/__init__.py`
(docstring).

**Preserved byte-identical to CP06** (verified by SHA-256 against the
uploaded CP06 archive): all of `ml/preprocessing/`, all of `ml/labeling/`,
all of `ml/training/` (`dataset.py`, the three trainers, the README),
`ml/evaluation/metrics.py`, `evaluate.py`, `compare_models.py`,
`compare_candidates.py`, `timing.py`, all six earlier test files, all
fixtures, `experiments/DATA_COLLECTION_PLAN.md`,
`experiments/LABELING_STRATEGY.md`, all three earlier run records,
`requirements.txt` and `ml/models/README.md`.

### 0.5 Remaining work

- **Actually collecting real hardware data** — CP08 made it *possible to do
  safely*, not done. Everything else is blocked on it. Needs ESP32 firmware
  meeting `experiments/FIRMWARE_LOGGING_SPEC.md`, a filled-in manifest/config
  with no `UNSET` left, and a real session run per
  `experiments/EXPERIMENT_PROCEDURE.md`. See section 8.
- Resolve the open hardware/regulatory questions in
  `experiments/DATA_COLLECTION_PLAN.md` section 6 (SF/TP grid, regional
  configuration, supply-current table, firmware airtime parameters).
- Revisit the placeholder labeling defaults against real data.
- Retrain **all three** models on real data, re-run
  `generate_comparison_report.py`, fill in section B with real results, and
  only then consider removing the synthetic banner and no-superiority
  language.
- Model export/quantization and a **measured** ESP32 footprint, latency and
  energy (`ml/export/` and `esp32/` are empty). Until these exist, the model
  size / latency / memory / embedded-feasibility factors are desktop proxies.
- Decide the factor weights and suitability thresholds **before** looking at
  real results, so they are not tuned toward a favourite.
- Consider a repeated-split (multi-seed) stability analysis on real data; the
  current stability factor only measures consistency across the contexts of
  one split.
- ESP32 firmware and on-device inference; field/dynamic-channel evaluation
  and final report.

### 0.6 Hardware status

**No hardware has been used.** Planned: ESP32 + SX1278 (433 MHz). No unit has
been powered, no firmware exists (`esp32/` holds only `.gitkeep`; CP08 only wrote the
logging contract the firmware must meet), no radio parameter has been measured, and no on-device model size or latency exists.
Every size/time figure in this repo is a desktop scikit-learn figure, and
every "embedded suitability" label is a desktop proxy.

### 0.7 Real-data status

**No real data exists, and no real measurement has been collected.** `data/raw/`,
`data/processed/` and `data/sample/` contain only README.md/.gitkeep. The only
data is fabricated test fixtures in `tests/fixtures/`, plus the synthetic
software-test rows CP08 generates in temporary directories (never committed).
CP08's tooling is ready to receive **future real hardware measurements**; until
they exist there is no real PDR, latency, energy or RSSI/SNR figure. External
or public LoRa datasets are not used and must stay excluded. No model has been trained on real data; no research model
exists; `ml/models/` ships empty on purpose. **Real ESP32 + LoRa data is
still required** before any model comparison can mean anything.

### 0.8 Synthetic results are software validation only

See the banner at the top of this section. In one line: the fixture is
separable by construction, so the Decision Tree and the Random Forest both
reaching 1.0000 and Logistic Regression scoring lower is what a correctly
wired pipeline does on it — not evidence about any model, and not a
finding. `SYNTHETIC_BANNER`, `NO_SUPERIORITY_CLAIM` (CP05),
`NO_SUPERIORITY_CLAIM_MULTI` (CP06) and `FINAL_SELECTION_STATUS` (CP07) are
emitted structurally and tests assert them. The same applies to the CP07
factor scores: they are relative to the three candidates in a run, built from
synthetic and desktop-proxy figures, and are not a ranking.

### 0.9 Exact next checkpoint

**Checkpoint 9 — NOT STARTED, and its scope has not been defined by the user.**
Checkpoint 8 is complete (readiness software only). The roadmap in `README.md`
section 6 lists model optimization/quantization as the next item, but that is
premature without real data, and the user has redefined checkpoint scope
several times. **Ask the user what CP09 should be** and do not start it
unprompted. Real hardware data collection itself is hardware work outside what
an AI session can do; see section 8.

### 0.10 Instructions for a New Claude account (short form)

1. Read this file fully, then skim `README.md`, `CHANGELOG.md` and
   `CHECKPOINT_PROGRESS.md`.
2. Verify against the folder — do not trust summaries alone.
3. Run all eight test suites (below). All must pass before you change anything.
4. Never fabricate results; never present fixture numbers as findings; never
   weaken the banner / no-superiority / honesty guards, and never make
   `select_candidate()` return anything but the TBD status on synthetic data.
5. Do only the checkpoint the user asks for; then update this file and the
   changelog, package a zip, and stop.
6. If a session is interrupted, `CHECKPOINT_PROGRESS.md` says which stage was
   reached and which partial ZIP is newest.
7. Full instructions: **section 9**.

```
python tests/test_environment.py
python tests/test_preprocessing.py
python tests/test_labeling.py
python tests/test_training.py
python tests/test_logistic_regression.py
python tests/test_random_forest.py
python tests/test_model_comparison_framework.py
python tests/test_real_data_collection.py      # CP08; also re-runs the seven above
```

---

## 1. Project Objective

Build a **lightweight, edge-deployable machine learning system** that
predicts good **Spreading Factor (SF)** and **Transmission Power (TP)**
settings for a LoRa end device, using:

- RSSI
- SNR
- packet success/failure history
- retry count

as input features, so the device can adapt faster to dynamic channel
conditions (fading, interference, mobility, distance changes) than static
configuration or standard ADR. The trained model is ultimately meant to run
**locally on an ESP32** microcontroller paired with a LoRa radio module.

This is a 3rd-year ECE final year project, developed in checkpoints. Each
checkpoint is reviewed before the next one begins.

---

## 2. Current Checkpoint

**Checkpoint 8 — Real Hardware Data Collection Readiness
(SYNTHETIC SOFTWARE-TEST DATA ONLY; NO REAL DATA COLLECTED)**

### 2.1 Checkpoint state at a glance

| Checkpoint | State |
|---|---|
| **CP01 — Project foundation / scaffolding** | **COMPLETE** |
| **CP02 — Data schema & preprocessing pipeline** | **COMPLETE** |
| **CP03 — Target-label strategy & labeling framework** | **COMPLETE** |
| **CP04 — Decision Tree software validation** | **COMPLETE** |
| **CP05 — Logistic Regression + DT-vs-LR comparison (software validation)** | **COMPLETE** |
| **CP06 — Small Random Forest + three-model comparison (software validation)** | **COMPLETE** |
| **CP07 — Model comparison & selection framework (software validation)** | **COMPLETE** |
| **CP08 — Real-data collection readiness (software-test data only)** | **COMPLETE** |
| **CP09** | **NOT STARTED — scope not defined** |
| **Actual real hardware data collection** | **NOT DONE — no measurement exists; `data/` is empty** |
| **Final research model** | **NOT YET TRAINED** |
| **Final model selection** | **TBD — to be determined using real data and ESP32 deployment measurements.** |

> **Note on renumbering:** earlier drafts of this file (through Checkpoint
> 4) listed "Checkpoint 5" as a placeholder for real hardware data
> collection. The user explicitly redefined Checkpoint 5 to be the
> Logistic Regression comparison documented below; real hardware data
> collection is renumbered to **Checkpoint 6** and remains not started —
> see section 8.
>
> **Second renumbering (Checkpoint 6):** the user then redefined Checkpoint 6
> to be the small Random Forest documented below, so real hardware data
> collection is now **Checkpoint 7** (and every later checkpoint moved down by
> one — see `README.md` section 6). Where this file's *historical* CP4/CP5
> text says hardware collection is "Checkpoint 6", that was correct when
> written; the number was 7 until Checkpoint 7 was redefined (below).
>
> **Third renumbering (Checkpoint 7):** the user then redefined Checkpoint 7
> to be the model comparison and selection framework documented in section
> 2.6, so real hardware data collection is now **Checkpoint 8** (and every
> later checkpoint moved down by one again). Where this file's *historical*
> text says hardware collection is "Checkpoint 7", that was correct when
> written; the current number is 8.
>
> **Meaning of CP08 as built:** the user's Checkpoint 8 delivered collection
> *readiness* — the software and documents needed to receive real data
> correctly — not the data itself. Collecting real measurements remains future
> hardware work.

### 2.2 What Checkpoint 4 is, and is not

> #### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Checkpoint 4 built the first end-to-end training and evaluation pipeline
> and ran it against **fabricated test-fixture data only**. It demonstrates
> that eight pipeline stages connect, that the context split holds, and that
> a model saves and reloads. It demonstrates **nothing else**.
>
> Specifically it does NOT show improved packet delivery ratio, improved
> latency, improved energy consumption, or faster adaptation than ADR; and
> the model is NOT validated for real LoRa communication. The fixture is
> trivially separable by construction, so its near-perfect scores are the
> expected outcome of a correctly wired pipeline and are not evidence of
> anything about LoRa or about this project's hypothesis.

The pipeline built this checkpoint:

```
sample CSV -> preprocessing (CP2) -> label generation (CP3)
           -> context-aware train/test split -> Decision Tree
           -> prediction -> evaluation -> save model -> metadata report
```

**Scope constraints the user set, and how each was met:**

| Constraint | How it was honoured |
|---|---|
| Software pipeline validation only | Every generated report, the metadata JSON, `README.md`, and this file carry the banner; `explicit_non_claims` is a required metadata field asserted by a test |
| No synthetic performance as research results | `experiments/CP04_SOFTWARE_VALIDATION_RUN.md` states in its preamble that 1.0000 accuracy is expected and is not a finding |
| No claim of validation for real LoRa | Stated in the banner, in `ml/models/README.md`, and in report section 6 |
| No PDR / latency / energy / adaptation claims | Each is disclaimed by name; a test asserts every one appears in the report |
| No synthetic accuracy as evidence of success | Disclaimed by name; majority-class baselines and per-context scoring are reported alongside every accuracy so a number can never stand alone |
| Use the project's intended feature set | RSSI, SNR, success/failure history, retry count — in causal (lagged) form |
| No GPS/distance/contextual features | A test scans the feature list for such tokens and fails if any appear |
| Use the CP3 labeling framework for targets | Targets come from `ml.labeling`; no new labels were invented |
| Record depth, nodes, size, timings, metrics | All present in the metadata; a test asserts each field |
| Do not optimize the model heavily | `tuned: False` in metadata, asserted by a test; no hyperparameter search |
| Do not start Logistic Regression / Random Forest | Only `DecisionTreeClassifier` appears anywhere in the codebase |

### 2.3 One thing that had to change

Checkpoint 3's fixture produces exactly **one** labelled context carrying
**one** (SF, TP) pair. That is correct for testing the labeling framework,
but a classifier cannot be trained on a single class and a train/test split
needs more than one group. Checkpoint 4 therefore added a second, larger
fixture (`tests/fixtures/synthetic_pipeline_fixture_raw.csv`): 36 contexts
across 6 hand-written link tiers, 30 of which are labellable across 5 joint
(SF, TP) classes, with the sixth deliberately unlabellable so the pipeline is
exercised on data where contexts must be excluded. The Checkpoint 3 fixture
is unchanged and still used by `tests/test_labeling.py`.

### 2.4 What Checkpoint 5 is, and is not

> #### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Checkpoint 5 added a second lightweight ML candidate, Logistic Regression,
> trained on the identical dataset, features and (SF, TP) targets as the
> Checkpoint 4 Decision Tree, plus a software-level comparison between the
> two. Both ran against **fabricated test-fixture data only**. It
> demonstrates that a second model family plugs into the existing
> preprocessing/labeling/dataset/evaluation pipeline without modification,
> and that a same-split comparison can be run and reported. It demonstrates
> **nothing else**.
>
> Specifically it does NOT show improved packet delivery ratio, improved
> latency, improved energy consumption, or faster adaptation than ADR for
> either model; neither model is validated for real LoRa communication; and
> — the constraint specific to this checkpoint — **it does NOT show that
> Logistic Regression is better or worse than the Decision Tree.** The
> Decision Tree's near-perfect score and Logistic Regression's more modest
> score on the same fixture reflect how each model family fits a fixture
> that is separable by axis-aligned regions, not real-world merit.

The pipeline extended this checkpoint:

```
sample CSV -> preprocessing (CP2) -> label generation (CP3)
           -> context-aware train/test split (CP4, unchanged)
           -> Decision Tree (CP4)      -> metrics -> save -> metadata
           -> Logistic Regression (CP5) -> metrics -> save -> metadata
           -> compare_models.py (CP5): re-evaluate both on the SAME split
              -> side-by-side predictive + software-cost comparison report
```

**Scope constraints the user set, and how each was met:**

| Constraint | How it was honoured |
|---|---|
| Preserve all CP1-4 files and functionality | No file from Checkpoints 1-4 had its logic modified; `tests/test_environment.py`, `tests/test_preprocessing.py`, `tests/test_labeling.py`, `tests/test_training.py` all re-run and still pass |
| Same dataset/preprocessing/labeling as the Decision Tree | `train_logistic_regression.py` imports `build_dataset()`, `context_aware_split()`, `resolve_feature_columns()` etc. from the unmodified `ml/training/dataset.py` — no parallel/duplicated data logic |
| Same feature set (RSSI, SNR, packet success/failure history, retry count) | Identical `resolve_feature_columns()` call, asserted equal to the Decision Tree's by a test |
| No GPS/distance/other experimental metadata as features | Same `BANNED_FEATURE_COLUMNS` guard (unchanged) applies; a test scans for contextual tokens |
| Predict the same outputs (SF, TP) | Same `label_sf` / `label_tp_dbm` targets, same two-separate-models shape as the tree |
| Use the existing synthetic/sample dataset for software-pipeline validation only | Same fixture (`tests/fixtures/synthetic_pipeline_fixture_raw.csv`) as Checkpoint 4; no new fabricated data introduced |
| Label synthetic metrics clearly | `SYNTHETIC_BANNER` (unchanged, from `ml/evaluation/metrics.py`) stamped on every LR metadata field, every comparison report, and this file |
| Do not claim LR is better than DT based on synthetic data | `NO_SUPERIORITY_CLAIM` stamped on every `compare_models.py` report; a test asserts it and every other required disclaimer is present |
| Compare on software-level metrics (predictive performance, model size, training time, inference time) | All four reported side by side by `compare_models.py`, on an identical held-out split |
| Preserve context/group-based split and leakage protections | Same `context_aware_split()` / `BANNED_FEATURE_COLUMNS` used verbatim; no new leakage path introduced |
| No fabricated real-world LoRa measurements | No new data files added; only the existing synthetic fixture is used |
| Do not begin Checkpoint 6 (real hardware data collection) | Not started; `data/raw/`, `data/processed/`, `data/sample/` still contain only README.md/.gitkeep |
| Do not add Random Forest yet | Only `DecisionTreeClassifier` and `LogisticRegression` appear anywhere in the codebase |


### 2.5 What Checkpoint 6 is, and is not

> #### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Checkpoint 6 added a third lightweight ML candidate, a deliberately small
> Random Forest, trained on the identical dataset, features and (SF, TP)
> targets as the Decision Tree and Logistic Regression, plus a three-way
> software-level comparison. Everything ran against **fabricated test-fixture
> data only**. It demonstrates that a third model family plugs into the
> existing preprocessing/labeling/dataset/evaluation pipeline without
> modifying it, that the forest can be kept small and configured safely, that
> a saved forest reloads and its training reproduces, and that a same-split
> three-way comparison can be run and reported. It demonstrates **nothing
> else**.
>
> Specifically it does NOT show improved packet delivery ratio, improved
> latency, improved energy consumption, or faster adaptation than ADR for any
> model; no model is validated for real LoRa communication; it does NOT show
> the Random Forest is better or worse than the Decision Tree or Logistic
> Regression (the forest and the tree both scoring 1.0000 on a fixture that is
> separable by construction shows that both pipelines are wired correctly, and
> nothing about ensembles); and it does NOT show the forest fits on, or runs
> fast enough on, an ESP32 — no ESP32 footprint or latency has been measured.

The pipeline extended this checkpoint:

```
sample CSV -> preprocessing (CP2) -> label generation (CP3)
           -> context-aware train/test split (CP4, unchanged)
           -> Decision Tree (CP4)        -> metrics -> save -> metadata
           -> Logistic Regression (CP5)  -> metrics -> save -> metadata
           -> small Random Forest (CP6)  -> metrics -> save
                                         -> RELOAD from disk and verify
                                         -> REPRODUCE from seed and verify
                                         -> metadata
           -> compare_candidates.py (CP6): re-evaluate all three on the SAME
              split + one shared timing harness -> side-by-side report
```

**Scope constraints the user set, and how each was met:**

| Constraint | How it was honoured |
|---|---|
| Preserve ALL work from CP01-CP05 | Verified by SHA-256 against the uploaded CP05 archive: every functional file from CP1-5 is byte-identical; only README/PROJECT_STATUS/CHANGELOG/two READMEs/two `__init__` docstrings/a `requirements.txt` comment changed. All five earlier suites re-run and pass |
| Do not present synthetic results as research results | `SYNTHETIC_BANNER` stamped on the RF metadata, its metrics block, the comparison report (3x), the run record, and this file; tests assert it |
| Do not invent real LoRa measurements | No data files added; only the existing synthetic fixture is used |
| Do not claim improved PDR, latency, energy or adaptation time | Each is disclaimed by name in the RF metadata and the comparison report; tests assert every one appears |
| Do not start CP07 | Not started; `data/` and `ml/models/` still contain only README.md/.gitkeep |
| Do not modify or remove previous model pipelines | `train_decision_tree.py`, `train_logistic_regression.py`, `compare_models.py`, `dataset.py`, `metrics.py`, `evaluate.py` byte-identical; a test asserts forest training does not alter the DT/LR model files and that the CP5 two-model `compare()` still works |
| Small Random Forest as the third candidate | `train_random_forest.py`: 10 trees, depth 5, leaf 5, `sqrt` features by default; small-forest guard |
| Same preprocessing / labeling / features / split / leakage protections | Imports the unmodified `dataset.py`; no feature-list override parameter exists; identical-features test across all three models |
| Features: RSSI, SNR, success/failure history, retry count only; no GPS/distance/location | Same 8 causal rolling features; tests scan for contextual tokens; the schema has no such columns |
| Targets: SF and TP | Same `label_sf` / `label_tp_dbm`, two separate forests |
| Deliberately small forest, important hyperparameters configurable | `RandomForestConfig` + CLI flags for trees, depth, leaf size, max features, bootstrap, max leaf nodes, seed; a test proves each takes effect |
| Report training time, inference time, model size, number of trees, tree depth, predictive metrics | All in the metadata and the comparison report; tests assert each field |
| Label all synthetic metrics with the required banner | `SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT` |
| Pipeline: dataset -> preprocessing -> labeling -> same split -> RF training -> evaluation -> save -> reload -> reproducibility check | All stages implemented and recorded in `pipeline_stages`; the last two raise on failure |
| Tests: training, prediction, save/reload, feature consistency, leakage protection, invalid configuration | `tests/test_random_forest.py`, 23 checks, each category covered (see section 3) |
| Run all previous tests, then the CP06 tests; all must pass | Done; see "Verification performed during Checkpoint 6" |
| Update README, PROJECT_STATUS, CHANGELOG; complete ZIP | Done; `LoRa_EdgeAI_CP06_RandomForest_Comparison.zip` |

### 2.6 What Checkpoint 7 is, and is not

> #### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Checkpoint 7 built a **model comparison and selection framework** over the
> three existing candidates and generated one report from it. Everything ran
> against **fabricated test-fixture data only**. It demonstrates that the
> three models can be compared on predictive performance, resource
> characteristics and reproducibility inputs through one automated report,
> that six decision factors can be scored with configurable weights, and that
> the framework refuses to declare a winner. It demonstrates **nothing
> else**.
>
> Specifically it does NOT select a model — final model selection is
> **TBD — to be determined using real data and ESP32 deployment measurements.** It does NOT show any model is better or worse than another
> for LoRa; it does NOT contain any real hardware result (section B of the
> report is a placeholder with no numbers); and it does NOT show any
> candidate fits on, or runs fast enough on, an ESP32 — every size, latency
> and "embedded suitability" figure is a desktop scikit-learn proxy.

The pipeline extended this checkpoint:

```
sample CSV -> preprocessing (CP2) -> label generation (CP3)
           -> context-aware train/test split (CP4, unchanged)
           -> Decision Tree (CP4) / Logistic Regression (CP5) / small Random
              Forest (CP6) — all unchanged
           -> compare_candidates.py (CP6, unchanged): identical-split
              predictive metrics + software cost + structure
           -> evaluate() (CP4, unchanged), re-called per candidate: confusion
              matrices
           -> context_stability.py (CP7): per-held-out-context accuracy
           -> resource_profile.py (CP7): resource view + desktop-proxy labels
           -> decision_framework.py (CP7): six factors; select_candidate()
              ALWAYS returns the fixed TBD status
           -> generate_comparison_report.py (CP7): Markdown + JSON report
              A. SYNTHETIC SOFTWARE-VALIDATION RESULTS
              B. REAL HARDWARE RESULTS — NOT YET AVAILABLE (placeholder)
              C. Decision Framework
```

**Scope constraints the user set, and how each was met:**

| Constraint | How it was honoured |
|---|---|
| Preserve ALL existing work from CP01-CP06 | Every functional file from CP1-6 is byte-identical to the uploaded CP06 archive (SHA-256); the CP07 test pins the hashes of nine CP04-CP06 modules; all six earlier suites re-run and pass |
| Do NOT start Checkpoint 8 | Not started; `data/`, `ml/models/`, `ml/export/` and `esp32/` untouched |
| Do NOT invent real hardware results | Section B is a fixed placeholder with no numeric fields (a test walks it); every size/latency figure is labelled a desktop proxy |
| Do NOT claim a final winner from synthetic data | `select_candidate()` returns a constant TBD status; tested 36 times across four scenarios and nine weightings, including one where a candidate leads on every factor |
| Predictive performance: SF and TP metrics, classification metrics, confusion matrices | Report sections A.2 and A.3; per-context consistency table |
| Resource characteristics: training time, inference time, serialized size, complexity, parameters/structures, embedded suitability | Report section A.4 (`resource_profile.py`); structure = trees / depth / total nodes, plus fitted parameter counts read from the saved models (Logistic Regression: coefficients + intercepts and scaler values; trees and forest: nodes) |
| Reproducibility: same dataset, preprocessing, labeling, split, features, random-state controls | Report section A.5; tests assert one feature list, one split, zero context overlap, equal scored rows, and identical non-timing output across repeated runs; `--random-state` reaches the split |
| Features stay RSSI, SNR, success/failure history, retry count; no GPS/distance/location | Same 8 causal features; a test scans names for contextual tokens |
| Targets SF and TP | Unchanged |
| Configurable scoring/comparison framework that does not force a winner | `FactorWeights`, `SuitabilityThresholds`, optional illustrative scores; none can change the selection status |
| Documented decision framework (performance, size, latency, memory, embedded feasibility, stability) | Six factors, defined in `decision_framework.py` and printed as report section C.2 |
| Final selection status "TBD — to be determined using real data and ESP32 deployment measurements." | A constant; asserted by tests and printed as the last line of every report |
| Files for model comparison, resource comparison, report generation, selection logic, tests | `compare_candidates.py` (reused), `resource_profile.py`, `context_stability.py`, `generate_comparison_report.py`, `decision_framework.py`, `tests/test_model_comparison_framework.py` |
| Automatic comparison table/report; separate synthetic from real-hardware | `generate_comparison_report.py`; a test checks sections A, B, C appear once each, in order |
| Do not train any model on real data | None exists; `ml/models/` holds only README.md |
| Run ALL previous tests plus CP07 tests; all pass | Done; see "Verification performed during Checkpoint 7" |
| Update README, PROJECT_STATUS, CHANGELOG | Done |
| ZIP named `LoRa_EdgeAI_CP07_Model_Comparison_Framework.zip` (a later request asked for `LoRa_EdgeAI_CP07_FINAL.zip`) | Done — one archive, delivered under both names, byte-identical |
| Save progress per stage; `CHECKPOINT_PROGRESS.md`; partial ZIPs of the CURRENT tree | Done; see `CHECKPOINT_PROGRESS.md` for the list of partial snapshots taken during the build |
| Stop after Checkpoint 7 | Stopped |

### 2.7 What Checkpoint 8 is, and is not

> #### NO REAL DATA — SYNTHETIC SOFTWARE-TEST DATA ONLY
>
> Checkpoint 8 built the readiness package `ml/collection/`. It demonstrates
> that a log in the real-data schema can be validated, converted into the CP02
> format, and pushed through the unchanged CP02 -> CP03 -> CP04 pipeline, that
> unsafe conversions are refused, and that an unfilled configuration is
> refused. It demonstrates **nothing about LoRa behaviour**: its test rows are
> synthetic, deterministic and clearly marked. It does NOT contain a real
> measurement, any PDR/latency/energy/RSSI/SNR result, any model-superiority
> claim, any firmware, or any trained research model. Final model selection
> remains **TBD — to be determined using real data and ESP32 deployment measurements.**

```
real log (future, from firmware) --LORALOG1 lines--> logger.py --> real-schema CSV + manifest
   -> validator.py (fields, consistency, sequence, provenance, manifest, sweep coverage)
   -> adapter.py: purpose + missing-link policy -> CP02 raw CSV
   -> unchanged CP02 preprocessing -> CP03 labeling -> CP04-CP07
readiness.py: software ready? collection ready? (currently YES / NO)
```

**Scope constraints the user set, and how each was met:**

| Constraint | How it was honoured |
|---|---|
| Preserve ALL CP01-CP07 work | 64 files pinned by SHA-256 and verified byte-identical; all seven earlier suites re-run inside the CP08 suite and pass |
| Do NOT start CP09 | Not started |
| Do NOT use external/public datasets | No dataset added; the collection package has no network capability (tested); `data/` holds only README/.gitkeep |
| Do NOT fabricate real hardware data | Test rows are `synthetic_test`, deterministic, written only to temporary directories; the provenance gate rejects them as real |
| Assume no region/radio values | All such values `UNSET`; strict validation refuses while any remains (129 across the templates) |
| Do not claim PDR/latency/energy/RSSI/SNR gains or superiority | `CLAIMS_POLICY` fixed in code; docs state no result exists |
| Distinguish synthetic test data from future real measurements | Banners in every CP08 document; `data_origin` column; readiness reports "collection ready: NO" |
| Final documentation/status sync and regression | README, PROJECT_STATUS, CHANGELOG, CHECKPOINT_PROGRESS, `ml/collection/README.md` updated; 129 of 129 checks pass |

---

## 3. Completed Work

### Checkpoint 1 — Project Foundation / Software Scaffolding

- [x] Created the full project directory structure:
  `data/{raw,processed,sample}`, `ml/{preprocessing,training,evaluation,models,export}`,
  `experiments/`, `esp32/`, `tests/`
- [x] Added `.gitkeep` placeholders in every currently-empty directory so the
  structure survives zipping/uploading/cloning
- [x] Wrote `README.md` — project description, structure, setup, and run
  instructions
- [x] Wrote `PROJECT_STATUS.md` (this file)
- [x] Wrote `CHANGELOG.md` recording Checkpoint 1
- [x] Wrote `requirements.txt` with only the dependencies needed to verify
  the environment at this stage (numpy, pandas, scikit-learn)
- [x] Wrote `tests/test_environment.py`, a minimal script that verifies:
  - Python version
  - `numpy` import + basic array operation
  - `pandas` import + basic DataFrame operation
  - `scikit-learn` import + fitting a trivial model on synthetic
    placeholder numbers (explicitly labeled as a library sanity check, NOT
    project research data)
- [x] Verified the test script runs successfully in the build environment
  (see "Verification performed" below)

### Verification performed during Checkpoint 1
```
python3 tests/test_environment.py
```
Result: all checks passed, exit code 0.

### Checkpoint 2 — Data Schema, Preprocessing Pipeline & Data Collection Plan

- [x] **Data source decision confirmed with user**: real ESP32+LoRa
  hardware data will be collected later; this checkpoint builds the
  pipeline against a defined schema with no data yet (user chose this
  explicitly over a synthetic-data-generator or public-dataset approach
  when asked).
- [x] Defined the raw data schema (`ml/preprocessing/schema.py`,
  `RAW_SCHEMA`) — the exact CSV column contract that future ESP32 logging
  must produce: `timestamp_utc`, `session_id`, `device_id`, `packet_seq`,
  `sf`, `tp_dbm`, `rssi_dbm`, `snr_db`, `retry_count`, `packet_success`,
  plus optional `payload_bytes`, `channel_freq_hz`, `notes`. Each field has
  a type and, where applicable, a valid range or allowed-value set.
- [x] Documented the schema in human-readable form in `data/raw/README.md`.
- [x] Defined the processed-data schema addition (rolling history features)
  in `ml/preprocessing/schema.py` (`processed_feature_columns`) and
  `data/processed/README.md`.
- [x] Implemented the preprocessing pipeline in `ml/preprocessing/`:
  - `clean.py` — loads a raw CSV and validates it against `RAW_SCHEMA`,
    dropping and reporting (not silently keeping) rows with missing
    required fields, out-of-range values, or disallowed values.
  - `feature_engineering.py` — computes rolling "history" features
    (success rate, retry avg, RSSI avg, SNR avg) over the preceding N
    packets (N = 5 and 10 by default) per `(device_id, session_id)`,
    strictly excluding each packet's own outcome from its own history
    (no leakage).
  - `pipeline.py` — orchestrates clean → feature-engineer → write, with a
    CLI (`python -m ml.preprocessing.pipeline --input ... --output ...`)
    and a `run_pipeline()` function for reuse.
- [x] Wrote `experiments/DATA_COLLECTION_PLAN.md` — the data collection
  methodology: planned hardware setup, session naming convention, planned
  channel-condition scenarios (distance, line-of-sight, mobility,
  interference, indoor/outdoor), and explicit open questions that are
  **not** answered with invented values.
- [x] Added `tests/fixtures/synthetic_test_fixture_raw.csv` — a small,
  deliberately-labeled **synthetic** CSV (12 rows, 3 deliberately invalid)
  used only to test the pipeline code, plus `tests/fixtures/README.md`
  explaining this distinction clearly.
- [x] Wrote `tests/test_preprocessing.py` — verifies schema validation
  correctness, rolling feature correctness (including no self-leakage),
  and that the full pipeline runs end-to-end, all against the synthetic
  fixture only, writing outputs to a temp directory (never touching
  `data/processed/`). Also asserts `data/raw/`, `data/processed/`,
  `data/sample/` remain untouched by the test run.
- [x] Updated `README.md` with Checkpoint 2 structure and run instructions.
- [x] Reviewed `requirements.txt` — no new dependencies were needed
  (pandas/numpy, already present, are sufficient for the pipeline).

### Verification performed during Checkpoint 2
```
python3 tests/test_preprocessing.py
python -m ml.preprocessing.pipeline --input tests/fixtures/synthetic_test_fixture_raw.csv --output <temp path>
python -m ml.preprocessing.pipeline --input data/raw/does_not_exist.csv --output <temp path>   # error-path check
python3 tests/test_environment.py   # re-run to confirm Checkpoint 1 still passes unmodified
```
Results: all checks passed (exit code 0); the pipeline correctly kept 9/12
rows and dropped 3 deliberately-invalid rows from the fixture with
accurate drop reasons; the missing-file case failed cleanly with exit code
1 and no output file created; Checkpoint 1's environment test still passes
unmodified.

### Checkpoint 2 — Correction Pass

Requested by the user after reviewing Checkpoint 2, before Checkpoint 3
began. Three corrections, in order:

**1. `numpy` requirement/verification mismatch fixed.**
`requirements.txt` previously pinned `numpy>=1.24,<2.0`, but an earlier
verification run had numpy 2.3.5 actually installed — the declared
requirement and the actually-tested environment didn't match. Root cause:
an ad hoc `pip install numpy pandas scikit-learn` (no version pins) had
been run directly in the build sandbox for earlier testing, bypassing
`requirements.txt` entirely, so the versions verified against didn't
necessarily reflect the pinned range.

Fix: rather than just re-verifying against an arbitrarily older numpy,
the pin was **widened to `numpy>=1.24,<3.0`**, since numpy 2.x is fully
compatible with the pinned pandas/scikit-learn versions here. This was
confirmed properly, not assumed:
- A clean virtual environment was created and `pip install -r
  requirements.txt` was run with no pre-existing packages. This correctly
  resolved to `numpy 1.26.4`, `pandas 2.3.3`, `scikit-learn 1.9.1` — i.e.
  the *old* pin was never actually broken by pip's own resolution.
- `numpy` was then explicitly upgraded in that same clean venv to
  `2.3.5` (the version the user reported), while keeping the
  `requirements.txt`-resolved `pandas 2.3.3` / `scikit-learn 1.9.1`.
- Both `tests/test_environment.py` and `tests/test_preprocessing.py` were
  re-run against **both** version combinations (numpy 1.26.4 and numpy
  2.3.5) — all checks passed, exit code 0, in both cases.
- `requirements.txt`'s numpy upper bound was then widened to `<3.0` so the
  file honestly reflects what has actually been verified to work, instead
  of a narrower range that a real install might silently exceed.

**2. Synthetic fixture frequency corrected to match planned hardware.**
`tests/fixtures/synthetic_test_fixture_raw.csv` had `channel_freq_hz =
915000000` (915 MHz, US ISM band) in every row. The project's planned
hardware is an **SX1278 module (433 MHz band)**, so a reader skimming the
fixture could have been misled into thinking 915 MHz was the real target
band. Fix:
- All 12 rows in the fixture now use `channel_freq_hz = 433000000` (433
  MHz), matching the planned hardware's band. The fixture remains 100%
  synthetic/fabricated data — only the frequency *number* was aligned to
  avoid implying the wrong hardware band; no row was reinterpreted as real
  data.
- `tests/fixtures/README.md` now explicitly explains why 433 MHz was
  chosen for the fixture (consistency with planned hardware) while
  reiterating the fixture is still entirely synthetic.
- `experiments/DATA_COLLECTION_PLAN.md` section 2 (planned hardware setup)
  updated: the radio module is now stated as confirmed (SX1278, 433 MHz)
  rather than "TBD" (only the exact breakout-board vendor part number
  remains an open question, listed in section 6).
- `README.md`'s "Target deployment" paragraph updated from a generic
  "e.g. SX1276/SX1262" example to the confirmed SX1278 (433 MHz) hardware.
- `ml/preprocessing/schema.py`'s `channel_freq_hz` field description and
  `data/raw/README.md`'s schema table both now note the expected ~433 MHz
  band for real future data, for consistency.

**3. Label-construction strategy intentionally NOT decided.**
Per explicit user instruction, this correction pass did **not** design or
decide how a "correct" SF/TP training label will be derived from logged
history. This remains open, deferred to Checkpoint 3, exactly as it was
before this correction pass — see sections 4, 6, and 8. No preprocessing
logic files (`clean.py`, `feature_engineering.py`, `pipeline.py`) were
modified in this correction pass; only documentation, one schema field
description (non-functional, string-only), the fixture's frequency value,
and `requirements.txt` changed.

### Verification performed during the Correction Pass
```
# System Python (numpy 2.4.4 / pandas 3.0.2 / scikit-learn 1.8.0)
python3 tests/test_environment.py
python3 tests/test_preprocessing.py

# Clean venv, requirements.txt exactly as pinned (numpy 1.26.4 / pandas 2.3.3 / scikit-learn 1.9.1)
python tests/test_environment.py
python tests/test_preprocessing.py

# Same clean venv, numpy upgraded to 2.3.5 (matching the version originally reported)
python tests/test_environment.py
python tests/test_preprocessing.py
```
Results: **all checks passed, exit code 0, in every one of the three
version combinations above.** This directly confirms the numpy
requirement/verification mismatch is resolved, and that the fixture and
documentation edits did not break the preprocessing pipeline's behavior
(schema validation still keeps 9/12 rows and drops the same 3 deliberately
invalid ones; rolling features still compute identically, since
`channel_freq_hz` is not used in any feature-engineering calculation).

### Checkpoint 3 — Target-Label Strategy & Labeling Framework

**The core design decision.** The raw logs contain `sf` and `tp_dbm` — the
settings the device was *told* to use. Those are not labels. Training on them
teaches the model to imitate whatever policy generated the logs: a manual
sweep (so it learns noise), standard ADR (so it can at best clone ADR,
defeating the project's premise), or a fixed setting (so it learns a
constant). The label therefore has to be **derived from measured outcomes**.

The strategy adopted is **retrospective best-configuration labeling**: group
packets into channel contexts, and for each context choose, from the
configurations actually measured there, the lowest-energy one whose measured
reliability cleared a configured threshold. The model becomes a compact
approximation of a measured oracle. Full argument, alternatives considered
and limitations: `experiments/LABELING_STRATEGY.md`.

- [x] Wrote `experiments/LABELING_STRATEGY.md` — the design document: the
  problem statement, why logged SF/TP fails, the five-step strategy, the
  requirements it imposes on data collection, the context-definition
  judgement call (including the circularity that RSSI/SNR are partly a
  *consequence* of the configuration), how "nothing worked" is handled, seven
  named limitations, and five alternatives considered and rejected.
- [x] Implemented `ml/labeling/config.py` — `LabelingConfig`, the single
  source of truth for every knob, with validation, JSON round-tripping, and
  `resolve_candidate_configs()` which derives the candidate space from the
  data when nothing is pinned.
- [x] Implemented `ml/labeling/context.py` — four context strategies
  (`session`, `rssi_snr_bin`, `session_rssi_snr_bin`, `explicit_column`).
- [x] Implemented `ml/labeling/reliability.py` — point estimate and Wilson
  score lower bound, so thin evidence cannot win a label by luck.
- [x] Implemented `ml/labeling/airtime.py` — the published LoRa time-on-air
  formula, with bandwidth, coding rate, preamble, header, CRC and
  low-data-rate-optimization all configurable rather than assumed.
- [x] Implemented `ml/labeling/energy.py` — three pluggable energy methods
  (`airtime_only`, `airtime_x_linear_power`, `measured_current_table`) and
  three cost bases (`per_attempt`, `per_success_pdr`,
  `per_success_retries`).
- [x] Implemented `ml/labeling/oracle.py` — `build_oracle_table()` (measured
  evidence per context/SF/TP) and `select_labels()` (one target per context,
  with configurable tie-breaking and no-valid-configuration handling).
- [x] Implemented `ml/labeling/labeler.py` — `run_labeling()`, `attach_labels()`
  and a CLI with `--config`, `--print-config`, `--write-default-config`.
- [x] Added `ml/labeling/labeling_config.example.json` (generated from the
  code defaults, so it cannot drift) and `ml/labeling/README.md` documenting
  every knob.
- [x] Added `tests/fixtures/make_synthetic_labeling_fixture.py` and the
  210-row `synthetic_labeling_fixture_raw.csv` it generates — fully
  deterministic (no RNG), three sessions exercising three distinct code
  paths, expected labels derivable on paper.
- [x] Wrote `tests/test_labeling.py` — 19 checks covering all six required
  configurable items plus the formula, estimator, guard and error paths.
- [x] Extended `experiments/DATA_COLLECTION_PLAN.md` with section 4a (the
  five requirements the labeling strategy imposes on collection) and four new
  open questions in section 6.
- [x] Updated `tests/fixtures/README.md`, `README.md`, this file, and
  `CHANGELOG.md`.
- [x] Reviewed `requirements.txt` — no new dependencies needed. The framework
  uses only pandas/numpy, both already present. The Wilson bound is
  implemented directly from its closed form rather than pulling in scipy.

**Preserved unchanged:** no file from Checkpoint 1 or Checkpoint 2 had its
logic modified. `clean.py`, `feature_engineering.py`, `pipeline.py`,
`schema.py`, `test_environment.py`, `test_preprocessing.py` and
`synthetic_test_fixture_raw.csv` are byte-identical to their Checkpoint 2
state. `tests/fixtures/README.md`, `README.md`,
`experiments/DATA_COLLECTION_PLAN.md`, `PROJECT_STATUS.md` and `CHANGELOG.md`
were appended to, not rewritten.

### Verification performed during Checkpoint 3

```
python3 tests/test_environment.py     # Checkpoint 1 — still passes unmodified
python3 tests/test_preprocessing.py   # Checkpoint 2 — still passes unmodified
python3 tests/test_labeling.py        # Checkpoint 3 — new
python3 -m ml.labeling.labeler --print-config
python3 -m ml.labeling.labeler --input tests/fixtures/synthetic_labeling_fixture_raw.csv --output <temp path>
python3 -m ml.labeling.labeler --input <nonexistent> --output <temp path>   # error path
```

Results: all three test scripts passed with exit code 0. The 19 Checkpoint 3
checks confirmed, among other things, that:
- the time-on-air formula's symbol time doubles per SF step and scales
  inversely with bandwidth;
- the Wilson bound equals exactly `n / (n + z²)` at a 100% delivery ratio and
  increases with sample size at a constant ratio;
- `measured_current_table` refuses an empty table and refuses to extrapolate
  beyond a supplied one, rather than inventing figures;
- in the fixture's context A the cheapest configuration overall is the one
  that fails the reliability threshold, and the labeler correctly rejects it
  in favour of the cheapest configuration that passed — i.e. the reliability
  constraint genuinely binds;
- changing the threshold, the candidate sets, the energy method or the
  tie-break rules each changes the output, so none of them is decorative;
- all four no-valid-configuration policies behave distinctly;
- a context containing a single perfectly-reliable configuration is *not*
  labelled, and relaxing `min_configs_per_context` to 1 is confirmed to be
  what unblocks it;
- tie-breaking is independent of input row order;
- the example config ships with no SF/TP ranges pinned and an empty
  supply-current table;
- `data/raw/`, `data/processed/` and `data/sample/` remain untouched.

### Checkpoint 4 — Decision Tree Training/Evaluation Pipeline

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.**
> Everything below ran against fabricated fixture data.

- [x] Added `tests/fixtures/make_synthetic_pipeline_fixture.py` and the
  6,480-row `synthetic_pipeline_fixture_raw.csv` it generates — fully
  deterministic (no RNG), 6 hand-written link tiers x 6 sessions = 36
  contexts, configurations interleaved round-robin as
  `DATA_COLLECTION_PLAN.md` section 4a requires of real collection. Five
  tiers are labellable across 5 joint (SF, TP) classes; the sixth is
  deliberately unlabellable.
- [x] Implemented `ml/training/dataset.py` — feature assembly, the
  `BANNED_FEATURE_COLUMNS` leakage guard, context-aware splitting via
  `GroupShuffleSplit`, and `DatasetSummary` which reports rows *and*
  contexts so the effective sample size is visible.
- [x] Implemented `ml/training/train_decision_tree.py` — trains two
  `DecisionTreeClassifier`s (one per target), records structure and timings,
  saves a joblib bundle, and writes a metadata JSON.
- [x] Implemented `ml/evaluation/metrics.py` — the `SYNTHETIC_BANNER`,
  per-class precision/recall/F1, confusion matrices, majority-class
  baselines, joint exact-match, and per-context majority-vote scoring.
- [x] Implemented `ml/evaluation/evaluate.py` — loads a saved bundle,
  evaluates it standalone, and renders a banner-stamped Markdown report.
- [x] Added `ml/training/__init__.py`, `ml/evaluation/__init__.py`,
  `ml/training/README.md`, `ml/models/README.md`.
- [x] Wrote `tests/test_training.py` — 17 checks.
- [x] Generated `experiments/CP04_SOFTWARE_VALIDATION_RUN.md`, a committed
  record of one pipeline run, with a preamble stating that its 1.0000
  accuracy is the expected outcome and not a finding.
- [x] Updated `requirements.txt` — added `joblib>=1.2,<2.0`, now imported
  directly rather than relied on as a scikit-learn transitive dependency.
- [x] Updated `README.md`, this file, and `CHANGELOG.md`.

**Design decisions worth knowing:**

1. **Two trees, not one multi-output tree.** Small independently inspectable
   decision functions suit the eventual ESP32 port, and depth/nodes/size are
   reportable per target. Trade-off: two independent trees can emit a
   combination never seen in training, which is why joint exact-match is
   reported.
2. **Causality is enforced, not assumed.** The device chooses SF and TX power
   *before* transmitting, so the current row's own `packet_success`,
   `retry_count`, `sf` and `tp_dbm` are banned as features and the guard
   raises at both entry points. The default feature set is Checkpoint 2's
   already-shifted rolling history features. The current row's `rssi_dbm` /
   `snr_db` are off by default, because row *i*'s RSSI is measured *during*
   transmission *i* — using it to pick that transmission's configuration
   peeks one step ahead.
3. **Every accuracy is reported next to a majority-class baseline** and a
   per-context score, so a bare number can never stand alone.
4. **No model file is committed.** `ml/models/` ships empty with a README
   explaining that anything appearing there was trained on fabricated data
   and must never be deployed or cited. Regenerating takes seconds.

**Preserved unchanged:** no file from Checkpoints 1, 2 or 3 had its logic
modified. All of `ml/preprocessing/`, all of `ml/labeling/`,
`test_environment.py`, `test_preprocessing.py`, `test_labeling.py`, and both
earlier fixtures are byte-identical to their Checkpoint 3 state.

### Verification performed during Checkpoint 4

```
python3 tests/test_environment.py     # CP1 — still passes unmodified
python3 tests/test_preprocessing.py   # CP2 — still passes unmodified
python3 tests/test_labeling.py        # CP3 — still passes unmodified
python3 tests/test_training.py        # CP4 — new, 17 checks
python3 -m ml.training.train_decision_tree --input <labeled.csv> --outdir <temp>
python3 -m ml.evaluation.evaluate --model <bundle> --input <labeled.csv> --report <temp>
```

All four suites passed with exit code 0. The Checkpoint 4 checks confirmed,
among other things, that:
- all 14 banned columns are refused as features at both entry points;
- the default feature set represents all four project inputs and contains no
  GPS/distance/contextual variable;
- the split leaves zero contexts on both sides — while a naive row-level
  split on the same data would have leaked all 30, which is why the
  discipline matters;
- splitting refuses to run on fewer than two contexts;
- tree depth, node count, leaf count, model file size, training time and
  inference time are all recorded;
- a saved model reloads and predicts identically, and an invalid bundle is
  refused;
- joint accuracy never exceeds either individual accuracy, and an
  all-wrong predictor scores 0.0 (so the metrics measure something);
- the generated report carries the banner three times and disclaims PDR,
  latency, energy, adaptation, real-LoRa validation and project success by
  name;
- a fixed `random_state` reproduces the split, tree structure and metrics;
- `data/` and `ml/models/` are left clean.

### Checkpoint 5 — Logistic Regression & Decision Tree Comparison

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.**
> Everything below ran against the same fabricated fixture data as
> Checkpoint 4.

- [x] Implemented `ml/training/train_logistic_regression.py` — trains two
  `sklearn.Pipeline(StandardScaler, LogisticRegression)` models, one per
  target, using the SAME `build_dataset()` / `context_aware_split()` /
  `resolve_feature_columns()` calls the Decision Tree trainer uses. Records
  solver, iteration count, a `converged` flag, per-class coefficients,
  model file size, training time, inference time, and the shared
  `metrics.py` evaluation block.
- [x] Implemented `ml/evaluation/compare_models.py` — loads a Decision Tree
  bundle+metadata pair and a Logistic Regression bundle+metadata pair,
  re-evaluates both on an identical held-out split (same input file,
  `test_size`, `random_state`), and renders a side-by-side Markdown/JSON
  comparison report (predictive metrics, model size, training time,
  inference time), refusing to compare bundles trained on different
  feature sets.
- [x] Added `tests/test_logistic_regression.py` — 13 checks covering the
  trainer, the comparison module, and confirmation that unmodified
  Checkpoint 4 code (`dataset.py`, `metrics.py`, `evaluate.py`) needed no
  changes to support a second model family.
- [x] Generated `experiments/CP05_SOFTWARE_VALIDATION_RUN.md`, a committed
  record of one comparison run, with a preamble explaining why the two
  models score differently on this fixture and why neither number is a
  finding.
- [x] Updated `ml/training/__init__.py`, `ml/evaluation/__init__.py`,
  `ml/training/README.md`, `ml/models/README.md`, `requirements.txt`
  (comment only — no new dependency), `README.md`, this file, and
  `CHANGELOG.md`. No functional code in any pre-existing file changed.

**Design decisions worth knowing:**

35. **Same dataset, same features, same targets — only the model family
    changes.** The Logistic Regression trainer imports its dataset-assembly
    and splitting functions from the unmodified `ml/training/dataset.py`,
    so there is exactly one leakage guard, one feature set, and one
    splitting discipline for both models to share — no parallel
    implementation to drift out of sync.
36. **Scaling is fit on the training split only.** Logistic Regression's
    solver and L2 penalty are scale-sensitive in a way a tree's
    axis-aligned splits are not. Each target's model is a single
    `sklearn.Pipeline` of `(StandardScaler, LogisticRegression)`, with the
    scaler fit on training-split rows only — fitting it on the full
    dataset before splitting would leak test-split statistics into
    training.
37. **Convergence is recorded, not assumed.** `max_iter=2000` is generous
    purely so the solver reliably converges on this small fixture; a
    `ConvergenceWarning`, if raised, is caught and both its text and a
    `converged: bool` field land in the metadata.
38. **`ml/evaluation/evaluate.py` needed no changes.** Its `evaluate()`
    function is model-family-agnostic — it only calls
    `bundle["sf_model"].predict(...)` / `bundle["tp_model"].predict(...)`
    and reads `bundle["feature_columns"]`. A Logistic Regression bundle
    plugs into it unmodified; a test asserts this directly.
    `render_markdown_report()`'s "model structure" section is
    Decision-Tree-specific (tree depth/nodes/leaves), so a separate
    `compare_models.py` report renderer was written rather than overloading
    that function with an unrelated metadata shape.
39. **No superiority claim, structurally enforced.** Every report
    `compare_models.py` generates carries `NO_SUPERIORITY_CLAIM` — the same
    discipline as `SYNTHETIC_BANNER` — and a test asserts it, plus every
    other required disclaimer, is present by name.
40. **A mismatched-feature comparison is refused, not silently run.**
    `compare()` raises `ValueError` if the two bundles' `feature_columns`
    differ, rather than producing a comparison where the two models were
    not actually shown the same inputs.
41. **No Random Forest, and no research claims.** Only
    `DecisionTreeClassifier` and `LogisticRegression` appear anywhere in
    the codebase. `tuned: False` is recorded for Logistic Regression
    exactly as for the tree — no hyperparameter search was performed.

**Preserved unchanged:** no file from Checkpoints 1-4 had its logic
modified. All of `ml/preprocessing/`, all of `ml/labeling/`,
`ml/training/dataset.py`, `ml/training/train_decision_tree.py`,
`ml/evaluation/metrics.py`, `ml/evaluation/evaluate.py`,
`test_environment.py`, `test_preprocessing.py`, `test_labeling.py`,
`test_training.py`, and all three earlier fixtures are byte-identical to
their Checkpoint 4 state.

### Verification performed during Checkpoint 5

```
python3 tests/test_environment.py          # CP1 — still passes unmodified
python3 tests/test_preprocessing.py        # CP2 — still passes unmodified
python3 tests/test_labeling.py             # CP3 — still passes unmodified
python3 tests/test_training.py             # CP4 — still passes unmodified
python3 tests/test_logistic_regression.py  # CP5 — new, 13 checks
python3 -m ml.training.train_logistic_regression --input <labeled.csv> --outdir <temp>
python3 -m ml.evaluation.compare_models --dt-model <dt.joblib> --dt-metadata <dt.json> \
    --lr-model <lr.joblib> --lr-metadata <lr.json> --input <labeled.csv> --report <temp>
```

All five suites passed with exit code 0. The Checkpoint 5 checks confirmed,
among other things, that:
- the Logistic Regression trainer uses the byte-identical 8-feature set as
  the Decision Tree (same `resolve_feature_columns()` call);
- both target models are `sklearn.Pipeline(StandardScaler, LogisticRegression)`
  objects, and both converged on the fixture;
- the saved LR bundle reloads via the unmodified
  `ml/evaluation/evaluate.load_bundle()` and predicts identically across two
  loads;
- the unmodified `ml/evaluation/evaluate.evaluate()` correctly scores an LR
  bundle — no code changes were needed for a second model family;
- `compare_models.compare()` scores both models on an identical held-out
  split (1,611 rows in the verification run) and refuses a
  mismatched-feature comparison (e.g. one bundle trained with
  `--include-current-link`, the other without) with a `ValueError`;
- the comparison report carries the banner at least three times, plus the
  no-superiority claim and every required disclaimer (PDR, latency, energy,
  adaptation, real-LoRa validation, project success) by name;
- a fixed `random_state` reproduces the LR split, structure and metrics;
- the saved LR bundle contains no banned feature and its
  `n_features_in_` matches the bundle's feature list;
- `data/` and `ml/models/` are left clean.

One committed run (`experiments/CP05_SOFTWARE_VALIDATION_RUN.md`) recorded:
Decision Tree SF/TP accuracy 1.0000, joint 1.0000 (unchanged from
Checkpoint 4, same fixture, same split). Logistic Regression SF accuracy
0.7778, TP accuracy 0.7778, joint 0.5556 — lower, as expected for a linear
model on a fixture whose classes are separable only by axis-aligned
regions, and explicitly **not** presented as a finding about either model
family's real-world merit. Decision Tree bundle 3.21 KB / 0.0042 s train /
0.05 µs/row inference; Logistic Regression bundle 2.94 KB / 0.0114 s
train / 0.11 µs/row inference — all desktop, scikit-learn figures.

### Checkpoint 6 — Small Random Forest & Three-Model Comparison

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.**
> Everything below ran against the same fabricated fixture data as
> Checkpoints 4 and 5.

- [x] Implemented `ml/training/train_random_forest.py` — trains two small
  `RandomForestClassifier`s, one per target, using the SAME
  `build_dataset()` / `context_aware_split()` / `describe_split()` /
  `load_labeled_frame()` / `resolve_feature_columns()` calls the other two
  trainers use. Adds a validated `RandomForestConfig`, a small-forest guard,
  a reload-and-verify stage, a reproducibility-and-verify stage, and a
  metadata report (trees, per-tree depth and node/leaf counts,
  hyperparameters, model size, training time, inference time, metrics).
- [x] Implemented `ml/evaluation/timing.py` — one shared inference-timing
  harness (batch and single-decision, SF and TP models together).
- [x] Implemented `ml/evaluation/compare_candidates.py` — an N-way comparison
  (used for three) that reuses the unmodified `evaluate()`, refuses
  mismatched feature sets, asserts the split was identical for every
  candidate, and stamps every report with the banner and a no-superiority
  claim.
- [x] Added `tests/test_random_forest.py` — 23 checks: feature consistency
  (all three models), defaults are small, training/structure, configurable
  hyperparameters take effect, prediction, save/reload, unmodified
  `evaluate()` agreement, metadata completeness, reload + reproducibility
  stages **and tamper tests proving they can fail**, `--no-save`,
  reproducibility, shared leakage guard, **behavioural leakage test with a
  negative control**, no out-of-bag scoring, invalid-configuration handling,
  CLI error handling, three-way identical-split comparison, comparison
  refusals, report banner/non-claims, CP4/CP5 preservation, documentation
  updated, data directories clean.
- [x] Generated `experiments/CP06_SOFTWARE_VALIDATION_RUN.md`, a committed
  record of one three-model run, produced from real run output (not
  hand-transcribed), with a preamble explaining why the forest and the tree
  score identically on this fixture and why neither number is a finding.
- [x] Updated `ml/training/__init__.py` and `ml/evaluation/__init__.py`
  (docstrings), `ml/training/README.md`, `ml/models/README.md`,
  `requirements.txt` (comment only — no new dependency), `README.md`, this
  file and `CHANGELOG.md`. No functional code in any pre-existing file
  changed.

**Design decisions worth knowing:**

42. **A forest is small by construction, and "small" is enforced, not just
    defaulted.** scikit-learn's default forest (100 trees, unlimited depth)
    is the wrong starting point for an eventual ESP32. Defaults are 10
    trees, `max_depth=5`, `min_samples_leaf=5`, `max_features="sqrt"`. A
    small-forest guard (`SMALL_FOREST_MAX_TREES=30`,
    `SMALL_FOREST_MAX_DEPTH=10`, unlimited depth rejected) raises
    `InvalidForestConfigError` unless `allow_large_forest=True` /
    `--allow-large-forest` is passed, and the override is recorded in the
    metadata. **The guard thresholds are project-chosen placeholders, not
    measured ESP32 limits.** The values are not tuned — chosen to be small,
    not found to be optimal.
43. **Same data path, and no way to change the feature set.** The trainer
    imports the unmodified `dataset.py` and deliberately has no
    `feature_columns` parameter, so it cannot drift from the other two
    models or accept a contextual column the guard's name list would not
    catch. A test asserts all three saved bundles carry the identical
    feature list in identical order.
44. **Two forests, one per target** — the CP4/CP5 "two models, not one
    multi-output model" decision, for the same reasons (independently
    inspectable; structure reportable per target). Two independent forests
    can still emit an (SF, TP) pair never seen together; joint exact match
    exposes it.
45. **`oob_score` is hard-disabled.** Bootstrap resamples rows, and one
    label covers ~180 rows of a context, so an out-of-bag row nearly always
    has same-context siblings in the bag — an OOB score would be optimistic
    in exactly the way a random row split is (CP3's self-inclusion
    leakage). Only the context-held-out metrics are reported. Recorded as
    `oob_score_used: False` and asserted by a test.
46. **Reload and reproducibility are pipeline stages, not just tests.**
    After saving, the trainer reloads the file and compares it to the
    in-memory forest (feature list, every split feature and threshold,
    class lists, hard predictions, probabilities); then it retrains from
    the same config/seed and compares again. Failure raises
    `ModelIntegrityError` and deletes the model file. The comparison
    (`compare_forests`) is a pure function, and tests feed it deliberately
    different forests to prove it can fail.
47. **Validate before touching disk.** `RandomForestConfig.validate()` and
    `validate_test_size()` run before any file is read or written, so an
    invalid configuration leaves nothing behind.
    `InvalidForestConfigError` subclasses `ValueError`, so existing CLI
    error paths handle it. Booleans are rejected for integer parameters
    (`True` is an `int` in Python; `n_estimators=True` is a bug, not a
    configuration).
48. **`n_jobs=1`.** Deterministic regardless of thread scheduling, and
    tiny-model timings are not distorted by thread-pool start-up.
49. **Previous code was not modified; the three-way comparison is a new
    module.** An earlier session's note (item 11 in section 9, written for
    CP5) said to *extend* `compare_models.py` for a third model. The user's
    Checkpoint 6 instruction not to modify previous model pipelines takes
    precedence, so `compare_models.py` is byte-identical and
    `compare_candidates.py` REUSES its discipline instead — the unmodified
    `evaluate()`, the same-features rule, the same banner and
    no-superiority machinery — rather than forking it. This follows that
    note's intent (do not fork the comparison discipline), not its letter.
    (Decision 41 above, "No Random Forest", described Checkpoint 5 and is
    superseded by this checkpoint.)
50. **One timing harness, applied to every candidate.** CP4/CP5 timed the
    SF model only, but a complete decision needs SF and TP.
    `compare_candidates.py` re-measures all three with `timing.py`, on the
    same held-out rows, for both models, in batch and as one full decision,
    so its figures differ from the SF-only figures in the CP4/CP5 metadata
    by definition. The single-decision time is dominated by scikit-learn's
    per-call overhead. **All timings are desktop figures, not ESP32
    figures.**
51. **Behavioural leakage test with a negative control.** Beyond checking
    the banned-column list, a test rewrites the features AND labels of every
    held-out context and asserts the trained forest is bit-identical; it
    then rewrites the training contexts and asserts the forest changes (so
    the test cannot pass vacuously). It fails if anyone later lets
    test-split content influence training (for example by fitting a
    transform on the full dataset).
52. **Impurity feature importances are recorded but not interpreted.**
    Computed on a fixture that is separable by construction they are easy
    to misread as a finding about which channel measurements matter. They
    are in the metadata JSON but deliberately not reproduced in the run
    record.
53. **No tuning, no claims.** `tuned: False` is recorded exactly as for the
    other two models. No PDR, latency, energy or adaptation claim is made;
    each is disclaimed by name and a test asserts it. No superiority
    language ("winner", "best model", "outperforms", "we recommend") is
    emitted, and a test scans the report for it.

**Preserved unchanged:** no functional file from Checkpoints 1-5 had its
logic modified — verified by SHA-256 against the uploaded CP05 archive. See
section 0.4 for the exact lists of files created, modified and preserved.

### Verification performed during Checkpoint 6

```
python3 tests/test_environment.py          # CP1 — still passes unmodified
python3 tests/test_preprocessing.py        # CP2 — still passes unmodified
python3 tests/test_labeling.py             # CP3 — still passes unmodified
python3 tests/test_training.py             # CP4 — still passes unmodified
python3 tests/test_logistic_regression.py  # CP5 — still passes unmodified
python3 tests/test_random_forest.py        # CP6 — new, 23 checks
python3 -m ml.training.train_random_forest --input <labeled.csv> --outdir <temp>
python3 -m ml.evaluation.compare_candidates --dt-model ... --lr-model ... --rf-model ... \
    --input <labeled.csv> --report <temp>
```

All six suites passed with exit code 0 in three different dependency stacks:

| Environment | numpy | pandas | scikit-learn | joblib |
|---|---|---|---|---|
| System Python 3.12.3 | 2.4.4 | 3.0.2 | 1.8.0 | 1.5.3 |
| Clean venv, `requirements.txt` exactly as pinned (upper end) | 2.5.3 | 2.3.3 | 1.9.1 | 1.6.0 |
| Clean venv, low end of the declared ranges | 1.26.4 | 2.1.4 | 1.3.2 | 1.3.2 |

(The system Python's pandas 3.0.2 is outside `requirements.txt`'s
`pandas<3.0` pin, exactly as noted in the Checkpoint 2 correction pass; it is
retained as an extra data point, not as a supported configuration.)

The Checkpoint 6 checks confirmed, among other things, that:
- the forest, Decision Tree and Logistic Regression bundles carry the
  identical 8-feature list in identical order, and each fitted forest expects
  exactly 8 inputs;
- the default forest is small (10 trees, depth <= 5) and each of
  `n_estimators`, `max_depth`, `min_samples_leaf`, `max_features`,
  `max_leaf_nodes`, `bootstrap` and `random_state` demonstrably takes effect
  (tree count, depth, leaf count, smallest leaf, resolved feature count);
- 32 invalid configurations are rejected with an explanatory
  `InvalidForestConfigError`, 11 valid ones (including guard boundaries and
  explicit overrides) are accepted, and `train()` rejects an invalid
  configuration before creating any output directory;
- the saved forest reloads through the unmodified CP4 `load_bundle()`,
  predicts identically across loads (including probabilities), and the
  unmodified CP4 `evaluate()` reproduces the training-time metrics exactly;
- the reload and reproducibility stages pass, and tamper tests show the
  comparison fails when the feature list is reordered, when a smaller forest
  is swapped in, and when a forest is trained on different labels;
- rewriting all 9 held-out contexts leaves both forests bit-identical, while
  rewriting the 21 training contexts changes them (negative control);
- training the forest into the same directory as the DT and LR models does not
  alter their files, and the CP5 two-model `compare()` still works;
- the three-way comparison scores 1,611 identical held-out rows for all three
  models and refuses mismatched features, duplicate keys and fewer than two
  models; the report carries the banner 3 times, the multi-model
  no-superiority claim and every required disclaimer, and no winner language;
- `data/` and `ml/models/` are left clean.

One committed run (`experiments/CP06_SOFTWARE_VALIDATION_RUN.md`) recorded:
Decision Tree SF/TP accuracy 1.0000, joint 1.0000 (identical to CP4/CP5);
Logistic Regression SF/TP accuracy 0.7778, joint 0.5556 (identical to CP5);
Random Forest SF/TP accuracy 1.0000, joint 1.0000. Majority-class baseline for
both targets 0.3333. **None of these is a finding** — the fixture is separable
by construction. Structure: Random Forest 10 trees per target, max depth 5,
96 (SF) / 118 (TP) total nodes, versus 7 / 7 for the single tree. Desktop
scikit-learn cost figures from that one run (noisy, not ESP32): training
0.0049 s (tree) / 0.0122 s (LR) / 0.0219 s (forest); joblib size 3.21 / 2.94 /
27.6 KB; one full SF+TP decision median ~77 / ~221 / ~854 µs, dominated by
scikit-learn's per-call overhead.

### Checkpoint 7 — Model Comparison & Selection Framework

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.** Everything below ran against the same fabricated
> fixture as Checkpoints 4-6. No model was trained on real data, no hardware
> result exists, and no model is declared best. Final model selection:
> **TBD — to be determined using real data and ESP32 deployment measurements.**

What was built (the user's scope: a framework that can later be rerun on the
real ESP32 + LoRa dataset, comparing the three existing candidates on
predictive performance, resource characteristics and reproducibility, with a
configurable scoring framework that does not force a winner):

- [x] `ml/evaluation/resource_profile.py` — `SuitabilityThresholds`
  (validated, configurable), `classify_size()`, `classify_latency()`,
  `count_model_parameters(model_path)` and
  `build_resource_profile(comparison, thresholds=None, parameter_counts=None)`.
  Re-presents the timing/size/structure figures `compare_candidates()` already
  produced as a resource-only view, attaches desktop-proxy "compact / moderate
  / large" and "fast / moderate / slow" labels, and attaches fitted-parameter
  counts read from the saved models: linear coefficients + intercepts, scaler
  mean + scale values, tree nodes.
- [x] `ml/evaluation/context_stability.py` —
  `per_context_stability(model_path, input_path, test_size, random_state)`:
  joint (SF+TP) row accuracy for each held-out context, with worst / mean /
  standard deviation / best. Uses the unmodified `dataset.py` split and
  prediction path; trains nothing.
- [x] `ml/evaluation/decision_framework.py` — six factors, `FactorWeights`,
  `compute_factor_scores()`, `illustrative_weighted_scores()` and
  `select_candidate()`, whose `final_selection_status` is the constant
  `FINAL_SELECTION_STATUS` under every input.
- [x] `ml/evaluation/generate_comparison_report.py` —
  `build_full_comparison()`, `render_markdown_report()`, a command line, and
  the fixed `REAL_HARDWARE_PLACEHOLDER`. Produces Markdown and JSON.
- [x] `tests/test_model_comparison_framework.py` — 20 checks.
- [x] `experiments/CP07_MODEL_COMPARISON_FRAMEWORK_RUN.md` — committed record
  of one report generated from real run output, with a reading guide.
- [x] `CHECKPOINT_PROGRESS.md` — working log and backup-snapshot register.
- [x] README, PROJECT_STATUS, CHANGELOG and the `ml/evaluation/__init__.py`
  docstring updated.

**The report** (`python -m ml.evaluation.generate_comparison_report`) has
three parts, in this order, each present exactly once:

1. **A. SYNTHETIC SOFTWARE-VALIDATION RESULTS** — A.1 what was compared; A.2
   predictive performance (SF and TX-power accuracy, majority-class baselines,
   macro F1, joint exact match, per-context joint accuracy) plus a
   consistency-across-held-out-contexts table; A.3 confusion matrices; A.4
   resource characteristics (training time, batch and single-decision
   inference time, serialized size, hyperparameters tuned?, trees / depth /
   nodes, fitted-parameter counts, desktop-proxy suitability labels); A.5
   reproducibility; A.6 what this does not show.
2. **B. REAL HARDWARE RESULTS — NOT YET AVAILABLE** — a fixed placeholder
   with no numeric fields: status, why nothing exists, what blocks it, and
   what will go here later.
3. **C. Decision Framework** — C.1 the final selection status; C.2 factor
   definitions; C.3 per-factor normalised scores; C.4 illustrative weighted
   scores (opt-in); C.5 what the framework does not show.

The report starts and ends with the synthetic banner, and its last line is the
TBD selection status.

**The six factors** (all computed from synthetic-fixture or desktop-proxy
figures; each min-max normalised across the candidates in the run only):

| Factor | Input | Direction |
|---|---|---|
| predictive_performance | joint (SF+TP) exact-match accuracy, held-out split | higher better |
| model_size | joblib file size (KB) | lower better |
| inference_latency | median desktop time for one full SF+TP decision (µs) | lower better |
| memory_requirements | same KB figure as model_size (no separate on-device measurement exists) | lower better |
| embedded_feasibility | average of the size-class and latency-class scores from `resource_profile` | higher better |
| stability_generalization | worst-context joint accuracy across the held-out contexts | higher better |

Weights (`FactorWeights`) and thresholds (`SuitabilityThresholds`) are
configurable through the Python API. Neither can change the selection status.

What one run on the fixture shows (a software-validation observation, not a
finding): the pipeline executes end to end for all three models; the
predictive figures and file sizes are identical to the Checkpoint 6 record, so
nothing upstream changed; the Decision Tree has 7 nodes per target, the
Logistic Regression has 27 / 9 coefficients+intercepts (SF / TX power) plus 16
/ 16 scaler values, and the Random Forest has 10 trees with 96 / 118 nodes.
The fixture is separable by construction, so none of this says which model
suits LoRa.

**Design decisions worth knowing:** 54-65 in section 6.

### Verification performed during Checkpoint 7

- Baseline before any change: all six earlier suites passed on the extracted
  Checkpoint 6 archive.
- Ran all seven suites on the final tree: `test_environment.py` (4 checks),
  `test_preprocessing.py` (6), `test_labeling.py` (19), `test_training.py`
  (17), `test_logistic_regression.py` (13), `test_random_forest.py` (23) and
  `test_model_comparison_framework.py` (20) — all pass.
- Byte-identity of CP01-CP06 sources against the uploaded Checkpoint 6
  archive checked by SHA-256 (section 0.4 lists what is preserved); the CP07
  test additionally pins the hashes of nine CP04-CP06 modules.
- `select_candidate()` returned the fixed TBD status in 36 calls across four
  scenarios (the real run and three hand-built ones in which a different
  candidate leads on every factor) and nine weight configurations, with no
  winner-type key anywhere in any result.
- The per-context breakdown is cross-checked against the unmodified CP04
  `evaluate()`: the row-weighted mean of per-context accuracies equals the
  overall joint accuracy, for all three candidates.
- Parameter counts are cross-checked against the trainers' own metadata:
  the Logistic Regression expectation is derived from recorded class and
  feature counts, and tree/forest node and tree counts must equal the
  recorded structure.
- Determinism: repeated full runs agree on every non-timing field.
- Environment: Python 3.12.3, numpy 2.4.4, pandas 3.0.2, scikit-learn 1.8.0,
  joblib 1.5.3 (the container's system stack). **Not** re-run in clean
  virtual environments at the pinned lower and upper bounds this checkpoint
  (Checkpoint 6 did that); see section 7.
- One development note worth recording: the first draft of the stability
  factor ("beats the majority baseline") scored 1.000 for every candidate and
  was replaced before it was ever reported; and one documentation edit script
  aborted on a mismatched anchor before writing anything and was rerun.

### Checkpoint 8 — Real-Data Collection Readiness

**Status: COMPLETE** (readiness software and documents; **no real data collected**).

Built (details in section 0.4a and `CHANGELOG.md`): the `ml/collection/`
package (schema, manifest, experiment configs, validator, adapter, planner,
logger, readiness), three documents (`REAL_DATA_SCHEMA.md`,
`EXPERIMENT_PROCEDURE.md`, `FIRMWARE_LOGGING_SPEC.md`), four `UNSET`-filled JSON
templates, a synthetic test-row generator and a 27-check test suite.

What it guards against, each asserted by a test:

- **Survivorship bias.** The CP02 cleaner drops rows with no RSSI/SNR; real
  failed packets usually have none. A test shows naive conversion losing every
  failure; the adapter keeps them under an explicit policy and refuses if
  failures vanish.
- **Training on a policy's own decisions.** Only `sweep` sessions may train.
- **Log loss mistaken for failure.** Sequence gaps are reported, never read as
  failed packets; `boot_id` makes reboots visible.
- **Assumed radio/region.** Nothing hard-coded to EU868 or any band.
- **Synthetic data passed off as real**, and **metadata used as a feature**.
- **Premature claims.** Fixed claims policy; energy counts only when measured.

### Verification performed during Checkpoint 8

Run in the final session on the container's system stack (Python 3.12.3):

- At session start, 26 of the 27 CP08 checks passed; the failing one was
  `check_documentation_synchronised`, because the four core documents still
  described Checkpoint 7. (Hand-over notes had said "25/25"; the suite
  actually defines 27 checks.) No functional defect was found; no code
  changed. The documents were then rewritten to describe the implementation as
  it is.
- Final run, all suites exit 0: `test_environment` 4, `test_preprocessing` 6,
  `test_labeling` 19, `test_training` 17, `test_logistic_regression` 13,
  `test_random_forest` 23, `test_model_comparison_framework` 20, and
  `test_real_data_collection` 27 — 129 checks.
- The 64 pinned CP01-CP07 files are byte-identical; `data/raw`, `data/processed`,
  `data/sample` and `ml/models` hold only README/.gitkeep; no `*.csv` exists
  outside `tests/fixtures/`; the collection package imports no network or
  dataset library.
- The end-to-end check (synthetic log -> adapter -> CP02 -> CP03 -> CP04 trainer)
  uses fabricated rows; its figures are software checks, **not results**.
- Not verified: anything on hardware; behaviour on real, messy logs;
  the pinned-bound virtual-environment matrix from Checkpoint 6.

---

## 4. Incomplete Work (intentionally NOT done yet)

Carried over from Checkpoint 1 (still true) unless noted otherwise:

- [ ] No data has been collected. `data/raw/`, `data/processed/`, and
  `data/sample/` remain empty except for the README.md files added this
  checkpoint (and `.gitkeep` placeholders).
- [x] ~~No data collection methodology has been finalized~~ → **Partially
  addressed**: `experiments/DATA_COLLECTION_PLAN.md` now documents the
  intended methodology, but several concrete details (exact hardware part
  numbers, logging transport, cadence, final scenario count) remain open
  questions listed in that document — they are not invented.
- [x] ~~No preprocessing / feature engineering code exists~~ → **Done this
  checkpoint** (`ml/preprocessing/`).
- [x] ~~No model architecture has been chosen or implemented~~ → **Done for
  software-validation purposes**: Decision Tree (Checkpoint 4), Logistic
  Regression (Checkpoint 5) and a small Random Forest (Checkpoint 6), each as
  two classifiers, in `ml/training/`.
  Whether any of them is the right *research* choice is still open and cannot
  be decided without real data — the Checkpoint 5 and 6 comparisons are
  explicitly software-level only and make no claim either way (see sections
  2.4 and 2.5).
- [x] ~~No evaluation metrics/code exist~~ → **Done this checkpoint**
  (`ml/evaluation/`).
- [x] ~~Logistic Regression comparison not started~~ → **Done in Checkpoint
  5** (`ml/training/train_logistic_regression.py`,
  `ml/evaluation/compare_models.py`). (Random Forest was deferred at that
  point and added later, in Checkpoint 6.)
- [x] ~~Random Forest has not been added~~ → **Done in Checkpoint 6**
  (`ml/training/train_random_forest.py`, `ml/evaluation/compare_candidates.py`),
  as a deliberately small forest, software validation only.
- [ ] **No model trained on real data exists.** `ml/models/` ships empty on
  purpose. Anything generated there so far — Decision Tree, Logistic
  Regression or Random Forest — was trained on fabricated fixture data and is
  not a research artifact — see `ml/models/README.md`.
- [ ] **No honest evaluation exists.** Every metric the project has produced
  came from a fixture that is separable by construction. Nothing is known
  about how this approach performs on a real link.
- [ ] No export/quantization (e.g. TFLite Micro conversion, or a compact
  C-array/node-table export of a tree or forest) code exists in `ml/export/`.
  Consequently **no on-device model size exists**: the Random Forest's node
  counts and joblib size are structure and desktop figures, not an ESP32
  footprint.
- [ ] No ESP32 firmware or on-device inference code exists in `esp32/`.
- [x] ~~No label-construction strategy has been decided~~ → **Done this
  checkpoint.** The strategy is documented in
  `experiments/LABELING_STRATEGY.md` and implemented in `ml/labeling/`.
  Note what is still open: the framework has never been run on real data,
  because none exists, and its defaults (reliability threshold, context bin
  widths, evidence guards) are placeholders chosen so the code is testable,
  not validated choices.
- [ ] No (SF, TP) candidate grid has been fixed. This is blocked on the final
  SX1278 breakout board and the regional spectrum configuration — see
  `experiments/DATA_COLLECTION_PLAN.md` section 6. The labeling config
  deliberately defaults to deriving candidates from the data.
- [ ] No module supply-current-vs-TX-power table exists, so the physically
  correct energy model (`measured_current_table`) cannot yet be used. The
  table ships empty on purpose.
- [ ] No labels have actually been produced, since there is no real data to
  label.
- [ ] No research results, benchmarks, or performance numbers exist
  anywhere in the project. **Any numbers describing accuracy, latency,
  energy savings, etc. that appear anywhere in this repo before real data
  is collected and a real model is trained would be fabricated and must
  not be added.** (The rolling-window mean values computed by the
  pipeline in tests are arithmetic checks on synthetic fixture data, not
  research results — see `tests/fixtures/README.md`. The same applies to
  the Checkpoint 5 Decision-Tree-vs-Logistic-Regression comparison numbers
  in `experiments/CP05_SOFTWARE_VALIDATION_RUN.md`, and the Checkpoint 6
  three-model numbers in `experiments/CP06_SOFTWARE_VALIDATION_RUN.md` —
  they are software comparisons on a fabricated fixture, not research
  findings about which model is better.)
- [ ] **No fourth model family** (gradient boosting, small neural networks,
  etc.) exists, and none should be added without an explicit request.
- [ ] **Hardware (ESP32 + SX1278) has not been used at all**, and no
  on-device inference exists.

### Status update from Checkpoint 7

Newly done: a model comparison and selection **framework** (section 3). Still
not done, and not to be done without being asked:

- [ ] **Real hardware data collection — now Checkpoint 8, NOT STARTED *as of Checkpoint 7* (superseded: CP08 readiness is complete, but no real data has been collected — see "Status update from Checkpoint 8" below).** (Lines
  above that call it "Checkpoint 7" or "Checkpoint 6" predate the
  renumberings; see sections 2.1 and 8.)
- [ ] **A selected model.** Final model selection remains
  **TBD — to be determined using real data and ESP32 deployment measurements.**
- [ ] Any real-data result, and therefore section B of the comparison report
  (still a placeholder).
- [ ] Any measured ESP32 footprint, latency or energy figure: `ml/export/` and
  `esp32/` are empty, so the size, latency, memory and embedded-feasibility
  factors are desktop proxies.
- [ ] Choosing the factor weights and suitability thresholds for real use.
  These are the person's decisions and should be fixed before real results
  are seen.
- [ ] A repeated-split (multi-seed) stability analysis, which needs retraining
  under several seeds with hyperparameters guaranteed to match the saved
  models. The current stability factor does not measure sensitivity to which
  contexts are held out.
- [ ] An energy-per-decision factor (needs the supply-current table in
  `experiments/DATA_COLLECTION_PLAN.md` section 6 to be filled in).
- [ ] Weight/threshold options on the command line (Python API only today).

### Status update from Checkpoint 8

Newly done: collection **readiness** (section 3). Still not done:

- [ ] **Any real hardware data.** `data/` is empty; nothing was measured.
- [ ] **ESP32 firmware** meeting `experiments/FIRMWARE_LOGGING_SPEC.md`
  (`esp32/` is empty).
- [ ] **Filled-in manifest and experiment configs** — 129 template values are
  `UNSET` until the real hardware, region and experiment exist; strict
  validation refuses them.
- [ ] The (SF, TP) grid, regional configuration/duty cycle, supply-current
  table and firmware airtime parameters (`DATA_COLLECTION_PLAN.md` section 6).
- [ ] Arm-comparison analysis code (baseline vs Edge-AI); the analysis *plan*
  exists, the code does not.
- [ ] A real-data-aware comparison report (see section 7), retraining on real
  data, and any export/ESP32 measurement.
- [ ] A selected model: **TBD — to be determined using real data and ESP32 deployment measurements.**

---

## 5. Current Architecture

### Checkpoint 1
Purely folder/documentation scaffolding — no software architecture.

### Checkpoint 2 — Preprocessing pipeline architecture

```
data/raw/<session>.csv                (future: real ESP32 logs; schema in ml/preprocessing/schema.py)
        │
        ▼
ml/preprocessing/clean.py             load_raw_csv() + validate_schema()
        │   - checks required columns present
        │   - coerces dtypes
        │   - drops + reports rows with missing/out-of-range/disallowed values
        ▼
ml/preprocessing/feature_engineering.py   add_rolling_features()
        │   - groups by (device_id, session_id), orders by packet_seq
        │   - computes rolling mean of packet_success / retry_count /
        │     rssi_dbm / snr_db over the preceding W packets (W=5,10)
        │   - shifts by 1 so a packet's own outcome never leaks into its
        │     own history features
        ▼
ml/preprocessing/pipeline.py          run_pipeline() / CLI
        │   - ties the above together
        │   - writes processed CSV to data/processed/
        ▼
data/processed/<session>_processed.csv   (future: once real raw data exists)
```

Tested end-to-end against `tests/fixtures/synthetic_test_fixture_raw.csv`
(synthetic, code-testing only) via `tests/test_preprocessing.py`. No real
data has passed through this pipeline yet, since none exists.

### Checkpoint 3 — Labeling framework architecture

```
data/processed/<session>_processed.csv     (future: Checkpoint 2 output)
        │
        ▼
ml/labeling/context.py            assign_contexts()
        │   groups packets into comparable channel contexts
        │   (session / RSSI-SNR bins / both / explicit column)
        ▼
ml/labeling/oracle.py             build_oracle_table()
        │   one row per (context, SF, TP):
        │     n_packets, n_success, reliability, mean_retry, energy_cost
        │   uses reliability.py  -> Wilson lower bound or point estimate
        │   uses airtime.py      -> LoRa time-on-air formula
        │   uses energy.py       -> pluggable cost model + cost basis
        ▼
ml/labeling/oracle.py             select_labels()
        │   per context: cheapest configuration clearing min_reliability
        │   guards:   min_packets_per_config
        │             min_configs_per_context   <- requires a real sweep
        │             min_packets_per_context
        │   ties:     configurable ordered rules, ending deterministically
        │   failure:  drop / most_reliable / max_robustness / error
        ▼
ml/labeling/labeler.py            attach_labels() + CLI
        │
        ├──> <output>_oracle.csv    measured evidence (audit trail)
        ├──> <output>_labels.csv    one label per context
        └──> <output>               per-packet rows + label_sf, label_tp_dbm,
                                    label_status, selection_reason, context_id
```

Every knob in that diagram is set from `LabelingConfig` (`config.py`), which
round-trips to JSON so a labeling run is reproducible from a committed config
file.

Tested end-to-end against `tests/fixtures/synthetic_labeling_fixture_raw.csv`
(synthetic, code-testing only) via `tests/test_labeling.py`. No real data has
passed through this framework, since none exists.

### Checkpoint 4 — Decision Tree training/evaluation architecture

```
data/processed/<session>_labeled.csv     (Checkpoint 3 output)
        │
        ▼
ml/training/dataset.py                build_dataset() + context_aware_split()
        │   - assembles X/y_sf/y_tp/groups from the 8 causal rolling features
        │   - BANNED_FEATURE_COLUMNS guard rejects any acausal/leaky column
        │   - splits by context_id (GroupShuffleSplit), never by row
        ▼
ml/training/train_decision_tree.py    train()
        │   - fits one DecisionTreeClassifier per target (SF, TP)
        │   - records depth/nodes/leaves/timings/feature_importances
        │   - saves {sf_model, tp_model, feature_columns, provenance} bundle
        ▼
ml/evaluation/metrics.py + evaluate.py
        │   - classification_metrics(), joint_exact_match(), per_context_agreement()
        │   - evaluate() reloads a bundle and re-scores it standalone
        ▼
ml/models/decision_tree_sf_tp.joblib + _metadata.json   (not committed)
```

### Checkpoint 5 — Logistic Regression training + comparison architecture

```
data/processed/<session>_labeled.csv     (Checkpoint 3 output, unchanged)
        │
        ▼
ml/training/dataset.py                (UNCHANGED — same functions as CP4)
        │
        ├──────────────────────────────┬─────────────────────────────────┐
        ▼                              ▼                                 │
ml/training/train_decision_tree.py   ml/training/train_logistic_regression.py
   (CP4, unchanged)                     (CP5, new)
        │   DecisionTreeClassifier         │   Pipeline(StandardScaler,
        │   x2 (SF, TP)                    │            LogisticRegression) x2
        ▼                                  ▼
ml/models/decision_tree_sf_tp.joblib   ml/models/logistic_regression_sf_tp.joblib
   + _metadata.json                       + _metadata.json
        │                                  │
        └──────────────┬───────────────────┘
                        ▼
        ml/evaluation/compare_models.py   compare()
                │   - loads both bundles, checks feature_columns match
                │   - re-evaluates BOTH on an identical held-out split
                │     (evaluate(), unchanged from CP4, called twice)
                │   - assembles predictive + software-cost comparison
                ▼
        render_markdown_report()   banner-stamped, NO_SUPERIORITY_CLAIM
                │
                ▼
        <comparison_report>.md / .json   (not committed)
```

The key architectural point: `ml/training/dataset.py`, `ml/evaluation/metrics.py`
and `ml/evaluation/evaluate.py` are shared, unmodified infrastructure. Adding a
second model family required exactly one new trainer module and one new
comparison module — nothing about the data pipeline, splitting, or per-model
metrics computation was duplicated or forked.


### Checkpoint 6 — Random Forest training + three-way comparison architecture

```
data/processed/<session>_labeled.csv     (Checkpoint 3 output, unchanged)
        │
        ▼
ml/training/dataset.py                  (UNCHANGED — same functions as CP4/CP5)
        │
        ├────────────────────────┬───────────────────────────┐
        ▼                        ▼                           ▼
train_decision_tree.py   train_logistic_regression.py   train_random_forest.py
  (CP4, unchanged)         (CP5, unchanged)               (CP6, new)
  1 tree x2                Pipeline(Scaler, LR) x2        small forest x2
        │                        │                        validate config
        │                        │                        train / evaluate / save
        │                        │                        RELOAD from disk + verify
        │                        │                        REPRODUCE from seed + verify
        ▼                        ▼                           ▼
decision_tree_sf_tp      logistic_regression_sf_tp    random_forest_sf_tp
.joblib + _metadata      .joblib + _metadata          .joblib + _metadata
        │                        │                           │
        └───────────┬────────────┘                           │
                    ▼                                        │
      compare_models.py (CP5, unchanged)                     │
      Decision Tree vs Logistic Regression                   │
                                                             │
        ┌────────────────────────────────────────────────────┘
        ▼   (all three bundles)
ml/evaluation/compare_candidates.py   (CP6, new)
   - same-features rule (refuses mismatched feature lists)
   - evaluate() x3 — the unmodified CP4 function
   - asserts every candidate saw an IDENTICAL held-out split
   - timing.py: one shared inference harness (SF + TP, batch + single decision)
        ▼
banner-stamped report + NO_SUPERIORITY_CLAIM_MULTI
```

The key architectural point is the same as in Checkpoint 5: `dataset.py`,
`metrics.py` and `evaluate.py` are shared, unmodified infrastructure. Adding a
third model family required one trainer, one timing helper and one comparison
module — nothing about the data pipeline, splitting, or per-model metric
computation was duplicated or forked.

### Checkpoint 7 additions

```
ml/evaluation/
  compare_candidates.py        (CP6, unchanged)  predictive + software cost + structure, identical split
  evaluate.py                  (CP4, unchanged)  re-called per candidate for confusion matrices
  resource_profile.py          (CP7)  resource view, parameter counts, desktop-proxy labels
  context_stability.py         (CP7)  per-held-out-context accuracy
  decision_framework.py        (CP7)  six factors; select_candidate() -> fixed TBD status
  generate_comparison_report.py(CP7)  orchestrates all of the above -> Markdown + JSON
```

Data flow of `build_full_comparison(dt_model, dt_meta, lr_model, lr_meta,
rf_model, rf_meta, input_path, test_size=0.3, random_state=0, weights=None,
thresholds=None)`:

1. `compare_candidates()` (unmodified) loads the three bundles, refuses
   mismatched feature sets, evaluates on one identical split and times
   inference.
2. For each candidate, `evaluate()` (unmodified) is called again on the same
   split to obtain confusion matrices; `per_context_stability()` breaks the
   same predictions down by held-out context; `count_model_parameters()` reads
   fitted-parameter counts. None of these trains or writes anything.
3. `build_resource_profile()` re-presents timing/size/structure and attaches
   labels and parameter counts.
4. `select_candidate()` computes factor scores and illustrative weighted
   scores and returns a result whose `final_selection_status` is the constant
   TBD string.
5. The result dict has the keys `checkpoint` ("CP07"), `banner`,
   `comparison`, `confusion_matrices`, `context_stability`,
   `resource_profile`, `decision_framework` and `real_hardware_results`, and
   is JSON-serialisable. `render_markdown_report(full,
   include_illustrative=False)` turns it into the three-part report.

Invariants the tests enforce: one feature list and one split across all
candidates; the real-hardware placeholder contains no numbers; the TBD status
is the same constant everywhere and ends the report; no winner-type keys or
winner language in results; nothing is written to `data/`, `ml/models/` or
`ml/export/`.

Command line flags: `--dt-model --dt-metadata --lr-model --lr-metadata
--rf-model --rf-metadata --input` (required), `--report`, `--json`,
`--test-size`, `--random-state`, `--include-illustrative-scores`. Exit code 1
with a message on stderr for a missing file or an invalid value.

### Checkpoint 8 additions

```
ml/collection/
  _util.py             UNSET marker, find_unset(), to_plain()
  real_schema.py       REAL_SCHEMA (31 cols) ⊇ CP02 RAW_SCHEMA (13); assert_no_metadata_features()
  manifest.py          RadioConfig / HardwareConfig / ConditionInfo / SessionManifest; to_labeling_radio_params()
  experiment_config.py SweepConfig / BaselineConfig / EdgeAIConfig; problems(strict); check_arm_parity(); scenario_overlap()
  validator.py         validate_real_csv(); sweep_coverage_report(); validate_row()
  adapter.py           to_cp02_raw(real_csv, out_csv, purpose, missing_link_policy, ...)
  planner.py           min_packets_for_reliability(); plan_sweep()   (reuses CP03 airtime + Wilson, unmodified)
  logger.py            checksum / make_log_line / parse_line / SessionLogger / CLI
  readiness.py         software-ready vs collection-ready report / CLI
```

CP02-CP07 modules are not imported-and-changed: the package depends on CP03's
airtime and reliability code read-only, and its output is the plain CP02 raw
CSV, so nothing downstream changed. Command lines: `python -m
ml.collection.readiness [--manifest M --config C]` and `python -m
ml.collection.logger --manifest M --out CSV --input FILE|-`. Exit code 1 with a
reason on refusal.

---

## 6. Important Design Decisions

### Checkpoint 1
1. **No placeholder/synthetic "research" data was created.** The only
   synthetic numbers in the repo were inside `tests/test_environment.py`,
   clearly scoped as a library sanity check, not LoRa research data.
2. **Dependencies kept minimal for this stage** (`numpy`, `pandas`,
   `scikit-learn` only).
3. **Folder structure mirrors the eventual ML lifecycle.**
4. **`.gitkeep` files** preserve empty directories through zip/git.
5. **Documentation-first approach** to survive session/token limits.

### Checkpoint 2
6. **Data source decision was asked, not assumed.** Given the significant
   fork between "build against a schema" vs. "build a synthetic generator"
   vs. "ingest a public dataset," the user was asked explicitly rather than
   guessed. Answer: real ESP32 hardware later; build the pipeline + schema
   now. This shaped every decision below.
7. **Schema-first pipeline design.** `ml/preprocessing/schema.py` is the
   single source of truth for both the raw CSV contract and the processed
   output contract, so `clean.py`/`feature_engineering.py`/`pipeline.py`
   and the human-readable READMEs all derive from (or are checked against)
   one place, avoiding drift between documentation and code.
8. **Validation drops and reports, never silently accepts, bad rows.**
   `clean.validate_schema()` returns both the cleaned DataFrame and a
   `ValidationReport` explaining exactly what was dropped and why. This
   was chosen over silently coercing/imputing bad values, since silent
   coercion could hide real hardware/logging bugs once data collection
   begins.
9. **Rolling history features exclude the current packet's own outcome**
   (via `shift(1)` before the rolling window). This was a deliberate
   choice to avoid label/feature leakage: a future model must predict
   SF/TP from *past* history, not from information only available after
   the fact.
10. **Default rolling window sizes (5 and 10) are placeholders**, not a
    validated hyperparameter choice — flagged explicitly in
    `feature_engineering.py` and section 7 below as something to revisit
    once real data and a chosen model architecture exist.
11. **Synthetic test fixture kept strictly separate from `data/`.** Per
    the same discipline as Checkpoint 1's design decision #1, the fixture
    used to test the pipeline lives only in `tests/fixtures/`, is
    explicitly labeled synthetic in its filename and README, and
    `tests/test_preprocessing.py` actively asserts that running it never
    writes anything into `data/raw/`, `data/processed/`, or `data/sample/`.
12. **Label-construction strategy deliberately deferred.** Deciding *how*
    to turn logged history into a "correct SF/TP" training label is a
    modeling decision, not a preprocessing one, and was left out of this
    checkpoint's scope — see section 4.
13. **No new dependencies added.** The pipeline only needed pandas (and
    its numpy dependency), both already present from Checkpoint 1, so
    `requirements.txt` content is unchanged (only its comment was updated).

### Checkpoint 2 — Correction Pass
14. **Widen, don't arbitrarily pin, when a version mismatch is found.**
    Rather than forcing the environment back to an old numpy version to
    match a narrow pin, the pin itself was widened to `<3.0` after
    confirming (via a clean-venv install plus an explicit numpy 2.3.5
    test) that the actually-used dependency versions all work correctly
    together. The goal was an honest, verified `requirements.txt`, not
    just a cosmetic fix.
15. **Fixture values kept synthetic, but aligned to avoid misleading
    hardware claims.** Once the user confirmed the planned radio hardware
    (SX1278, 433 MHz), the test fixture's `channel_freq_hz` was updated to
    433 MHz purely to prevent a reader from mistaking a fabricated
    900 MHz-band value for the real target band. This is a documentation
    accuracy fix, not a step toward treating the fixture as real data —
    see decision #11 and `tests/fixtures/README.md`.
16. **Label-construction strategy still deliberately deferred**, per
    explicit user instruction — reaffirming decision #12. No
    preprocessing logic was touched in this correction pass.

### Checkpoint 3

17. **Labels are derived from measured evidence, never copied from the
    logged configuration.** The central decision of this checkpoint. Using
    the logged `sf`/`tp_dbm` as targets would be behavioural cloning of
    whatever policy produced the logs — reproducing ADR at best, learning
    noise at worst. See `experiments/LABELING_STRATEGY.md` section 2.
18. **Reliability is a constraint, energy is the objective.** "Be reliable
    enough, then be as cheap as possible" is encoded directly in the
    selection rule, rather than blending the two into a weighted score with
    invented weights. `cost_basis` allows softening this by folding
    reliability back into the cost.
19. **The framework refuses to label a context it has no sweep for.**
    `min_configs_per_context` exists because "the best configuration among
    one configuration" is vacuous, not optimal. This turns a configuration
    sweep from a nice-to-have into a hard data collection requirement, which
    was written back into `DATA_COLLECTION_PLAN.md` section 4a.
20. **Thin evidence is discounted by default.** The Wilson lower bound is the
    default estimator so a configuration measured five times cannot outrank
    one measured five hundred times on a lucky run. Consequence worth
    knowing: at a 100% delivery ratio the bound is `n / (n + z²)`, so ≥25
    packets per configuration are needed to clear a 0.90 threshold.
21. **Hardware-dependent constants are refused, not guessed.** The
    supply-current table ships empty and `measured_current_table` raises a
    descriptive error rather than substituting plausible figures. It also
    refuses to extrapolate beyond a supplied table's range. This mirrors
    Checkpoint 1's decision #1 and Checkpoint 2's decision #11.
22. **SF/TX-power candidate sets default to "derive from the data."**
    Pre-filling them would bake an unverified hardware+regulatory assumption
    into every label the framework ever produces. `regulatory_profile` exists
    as a place to record the constraint once confirmed, and is read by no
    calculation — no regulatory limit is asserted anywhere in this project.
23. **Every label carries its provenance.** `label_status` distinguishes
    evidence-backed labels from fallbacks, and `selection_reason` records the
    human-readable cause. A later checkpoint can filter or down-weight
    fallback labels instead of silently treating them as equivalent.
24. **The energy model's known bias is documented rather than hidden.** The
    default `airtime_x_linear_power` models only radiated power, ignoring PA
    efficiency and the module's fixed baseline current. This *exaggerates*
    the saving from lowering TX power and therefore biases labels toward low
    power. Stated in the code, the package README and the strategy document,
    because it directly affects which configuration wins.
25. **The synthetic fixture is generated by committed, deterministic code.**
    No RNG and no seed, so the CSV is byte-for-byte reproducible and every
    expected label is derivable on paper. The generator is committed next to
    the CSV so the fabricated data is auditable rather than mysterious.
26. **No new dependencies.** The Wilson bound was implemented from its closed
    form rather than adding scipy, keeping `requirements.txt` unchanged for a
    third consecutive checkpoint.

### Checkpoint 4

27. **Two separate trees rather than one multi-output tree.** Small,
    independently inspectable decision functions suit the eventual ESP32
    port, and structure is reportable per target. The trade-off — two
    independent trees can emit an (SF, TP) combination never seen in
    training — is exposed by the joint exact-match metric rather than hidden.
    Predicting the pair as a single joint class remains an option for later.
28. **Causality is enforced in code, not left to discipline.**
    `BANNED_FEATURE_COLUMNS` raises rather than warns, at both entry points.
    A feature that is only knowable after the transmission has happened
    cannot be used, however predictive it looks, because the device must
    choose before transmitting.
29. **The current row's RSSI/SNR are off by default.** In a real log, row
    *i*'s RSSI is measured *during* transmission *i*. Using it to choose
    that transmission's configuration peeks one step ahead.
    `--include-current-link` enables them for comparison and the choice is
    recorded in the metadata.
30. **Accuracy is never reported alone.** Every accuracy is accompanied by a
    majority-class baseline and a per-context score. An 80% accuracy on a
    problem where 80% of contexts want one class is a statement about the
    class distribution, not the model.
31. **Per-context scoring exists because rows are not samples.** One label
    covers ~180 rows, so row-level accuracy over-weights large contexts.
    Aggregating by majority vote per context is much closer to the real
    sample size.
32. **No model artifact is committed.** A stale model trained on fabricated
    data sitting in the repo is exactly the sort of thing that later gets
    mistaken for a real one. `ml/models/` ships empty with a README.
33. **The banner is structural, not decorative.** `SYNTHETIC_BANNER` is
    emitted by the metrics module itself, and a test asserts it appears at
    least three times in any generated report along with each disclaimed
    claim by name. Removing it means failing the suite.
34. **A second fixture was necessary.** Checkpoint 3's fixture yields one
    context and one class, which cannot train a classifier or support a
    split. The new fixture is additive; the old one is untouched.

### Checkpoint 5

35. **Same dataset, same features, same targets — only the model family
    changes.** The Logistic Regression trainer imports its dataset-assembly
    and splitting functions from the unmodified `ml/training/dataset.py`,
    so there is exactly one leakage guard, one feature set, and one
    splitting discipline for both models to share — no parallel
    implementation to drift out of sync.
36. **Scaling is fit on the training split only.** Logistic Regression's
    solver and L2 penalty are scale-sensitive in a way a tree's
    axis-aligned splits are not. Each target's model is a single
    `sklearn.Pipeline` of `(StandardScaler, LogisticRegression)`, with the
    scaler fit on training-split rows only — fitting it on the full
    dataset before splitting would leak test-split statistics into
    training.
37. **Convergence is recorded, not assumed.** `max_iter=2000` is generous
    purely so the solver reliably converges on this small fixture; a
    `ConvergenceWarning`, if raised, is caught and both its text and a
    `converged: bool` field land in the metadata rather than being
    silently swallowed.
38. **`ml/evaluation/evaluate.py` needed no changes.** Its `evaluate()`
    function is model-family-agnostic — it only calls
    `bundle["sf_model"].predict(...)` / `bundle["tp_model"].predict(...)`
    and reads `bundle["feature_columns"]`. A Logistic Regression bundle
    plugs into it unmodified; a test asserts this directly.
    `render_markdown_report()`'s "model structure" section is
    Decision-Tree-specific (tree depth/nodes/leaves), so a separate
    `compare_models.py` report renderer was written rather than overloading
    that function with an unrelated metadata shape.
39. **No superiority claim, structurally enforced.** Every report
    `compare_models.py` generates carries `NO_SUPERIORITY_CLAIM` — the same
    discipline as `SYNTHETIC_BANNER` — and a test asserts it, plus every
    other required disclaimer, is present by name.
40. **A mismatched-feature comparison is refused, not silently run.**
    `compare()` raises `ValueError` if the two bundles' `feature_columns`
    differ, rather than producing a comparison where the two models were
    not actually shown the same inputs.
41. **No Random Forest, and no research claims.** Only
    `DecisionTreeClassifier` and `LogisticRegression` appear anywhere in
    the codebase. `tuned: False` is recorded for Logistic Regression
    exactly as for the tree — no hyperparameter search was performed.

### Checkpoint 6

42. **A forest is small by construction, and "small" is enforced, not just
    defaulted.** scikit-learn's default forest (100 trees, unlimited depth)
    is the wrong starting point for an eventual ESP32. Defaults are 10
    trees, `max_depth=5`, `min_samples_leaf=5`, `max_features="sqrt"`. A
    small-forest guard (`SMALL_FOREST_MAX_TREES=30`,
    `SMALL_FOREST_MAX_DEPTH=10`, unlimited depth rejected) raises
    `InvalidForestConfigError` unless `allow_large_forest=True` /
    `--allow-large-forest` is passed, and the override is recorded in the
    metadata. **The guard thresholds are project-chosen placeholders, not
    measured ESP32 limits.** The values are not tuned — chosen to be small,
    not found to be optimal.
43. **Same data path, and no way to change the feature set.** The trainer
    imports the unmodified `dataset.py` and deliberately has no
    `feature_columns` parameter, so it cannot drift from the other two
    models or accept a contextual column the guard's name list would not
    catch. A test asserts all three saved bundles carry the identical
    feature list in identical order.
44. **Two forests, one per target** — the CP4/CP5 "two models, not one
    multi-output model" decision, for the same reasons (independently
    inspectable; structure reportable per target). Two independent forests
    can still emit an (SF, TP) pair never seen together; joint exact match
    exposes it.
45. **`oob_score` is hard-disabled.** Bootstrap resamples rows, and one
    label covers ~180 rows of a context, so an out-of-bag row nearly always
    has same-context siblings in the bag — an OOB score would be optimistic
    in exactly the way a random row split is (CP3's self-inclusion
    leakage). Only the context-held-out metrics are reported. Recorded as
    `oob_score_used: False` and asserted by a test.
46. **Reload and reproducibility are pipeline stages, not just tests.**
    After saving, the trainer reloads the file and compares it to the
    in-memory forest (feature list, every split feature and threshold,
    class lists, hard predictions, probabilities); then it retrains from
    the same config/seed and compares again. Failure raises
    `ModelIntegrityError` and deletes the model file. The comparison
    (`compare_forests`) is a pure function, and tests feed it deliberately
    different forests to prove it can fail.
47. **Validate before touching disk.** `RandomForestConfig.validate()` and
    `validate_test_size()` run before any file is read or written, so an
    invalid configuration leaves nothing behind.
    `InvalidForestConfigError` subclasses `ValueError`, so existing CLI
    error paths handle it. Booleans are rejected for integer parameters
    (`True` is an `int` in Python; `n_estimators=True` is a bug, not a
    configuration).
48. **`n_jobs=1`.** Deterministic regardless of thread scheduling, and
    tiny-model timings are not distorted by thread-pool start-up.
49. **Previous code was not modified; the three-way comparison is a new
    module.** An earlier session's note (item 11 in section 9, written for
    CP5) said to *extend* `compare_models.py` for a third model. The user's
    Checkpoint 6 instruction not to modify previous model pipelines takes
    precedence, so `compare_models.py` is byte-identical and
    `compare_candidates.py` REUSES its discipline instead — the unmodified
    `evaluate()`, the same-features rule, the same banner and
    no-superiority machinery — rather than forking it. This follows that
    note's intent (do not fork the comparison discipline), not its letter.
    (Decision 41 above, "No Random Forest", described Checkpoint 5 and is
    superseded by this checkpoint.)
50. **One timing harness, applied to every candidate.** CP4/CP5 timed the
    SF model only, but a complete decision needs SF and TP.
    `compare_candidates.py` re-measures all three with `timing.py`, on the
    same held-out rows, for both models, in batch and as one full decision,
    so its figures differ from the SF-only figures in the CP4/CP5 metadata
    by definition. The single-decision time is dominated by scikit-learn's
    per-call overhead. **All timings are desktop figures, not ESP32
    figures.**
51. **Behavioural leakage test with a negative control.** Beyond checking
    the banned-column list, a test rewrites the features AND labels of every
    held-out context and asserts the trained forest is bit-identical; it
    then rewrites the training contexts and asserts the forest changes (so
    the test cannot pass vacuously). It fails if anyone later lets
    test-split content influence training (for example by fitting a
    transform on the full dataset).
52. **Impurity feature importances are recorded but not interpreted.**
    Computed on a fixture that is separable by construction they are easy
    to misread as a finding about which channel measurements matter. They
    are in the metadata JSON but deliberately not reproduced in the run
    record.
53. **No tuning, no claims.** `tuned: False` is recorded exactly as for the
    other two models. No PDR, latency, energy or adaptation claim is made;
    each is disclaimed by name and a test asserts it. No superiority
    language ("winner", "best model", "outperforms", "we recommend") is
    emitted, and a test scans the report for it.

### Checkpoint 7

54. **The framework cannot select a model, by construction.**
    `FINAL_SELECTION_STATUS` is a module constant, not a template.
    `select_candidate()` never reads the scores or the weights when choosing
    it, and no key named winner / selected / recommended / best / rank exists
    in any result. Reason: two of the six factors (real predictive
    performance and embedded feasibility) cannot be known yet, and no
    weighting of the other four can substitute for them. A test calls it 36
    times — the real run plus three hand-built scenarios in which a different
    candidate leads on every factor, each under nine weightings — and
    asserts the same status and no such keys every time. A later checkpoint
    that deliberately adds a selection step must change the constant and the
    test in the same change, with a documented, human-reviewed rationale.
55. **Built on top of Checkpoint 6, not by editing it.**
    `compare_candidates()` is reused unchanged. `evaluate()` is called again
    per candidate on the identical split to obtain confusion matrices, rather
    than extending `compare_candidates()`'s distilled output. Nine CP04-CP06
    modules are pinned by SHA-256 in the CP07 test so an accidental edit is
    caught; a deliberate one must update the pinned hash in the same change.
56. **The stability factor was redesigned during the build.** The first
    draft ("fraction of SF/TP predictions beating the majority-class
    baseline") scored 1.000 for every candidate, so it could never
    differentiate them even on real data. It was replaced by worst-context
    joint accuracy (`context_stability.py`), computed without retraining and
    cross-checked against the unmodified CP04 `evaluate()` (the row-weighted
    mean of per-context accuracies equals the overall joint accuracy). A saved
    model must **not** be scored against a different seed's split — it was
    trained on contexts that may now be in the test set, which is leakage — so
    a multi-seed sensitivity analysis has to retrain, and has to guarantee the
    same hyperparameters as the saved models. That is deferred, not built.
57. **"Memory requirements" is deliberately a proxy.** No on-device memory
    measurement exists, so the factor reuses the joblib size and says so
    rather than inventing a second number. The consequence for the default
    weights is recorded in section 7.
58. **"Embedded feasibility" is a desktop-proxy label, not a verdict.** It
    averages the size-class and latency-class scores from `resource_profile`.
    The class boundaries (5 / 20 KB, 150 / 500 µs) are project-chosen
    placeholders, validated and configurable through `SuitabilityThresholds`;
    every label carries a "(desktop proxy)" suffix and every profile carries
    a "NOT an ESP32 measurement" caveat, which a test checks.
59. **Normalised scores are relative; ties stay tied; missing stays
    missing.** Each factor is min-max normalised across the candidates in the
    run. If all values are equal every candidate gets 1.0 rather than one
    being arbitrarily favoured. A missing value stays `None` and is excluded
    from weighted sums rather than imputed. Adding or removing a candidate
    changes every score.
60. **Illustrative weighted scores are computed but opt-in to print.** They
    are always in the JSON; `--include-illustrative-scores` prints them with an
    "ILLUSTRATIVE ONLY" caveat. A single number per candidate invites being
    read as a ranking, which synthetic data cannot support, and
    `select_candidate()` never reads it.
61. **Section B is a placeholder with no numeric fields, and the report ends
    with the TBD status.** A test walks the placeholder structure for
    numbers, scans the rendered section for units, tables and
    measurement-like values, and checks the last line of the report.
62. **Timing-dependent values are not deterministic, and the tests do not
    pretend they are.** Training time, inference time, the latency class and
    the embedded-feasibility score derive from timing; the determinism test
    excludes them, and the report warns that labels can change between runs
    near a threshold.
63. **Parameter counts are read from the fitted models and cross-checked.**
    `count_model_parameters()` counts coefficients + intercepts, scaler
    mean + scale values and tree nodes. The test derives the Logistic
    Regression expectation from the class and feature counts the trainer
    recorded, and requires tree/forest node and tree counts to equal the
    trainers' records. They are structural facts, explicitly not a memory
    footprint, and are not comparable across families.
64. **The person chooses the weights and thresholds, ideally before seeing
    real results.** Defaults are equal weights (itself a choice — see the
    double-counting note in section 7) and placeholder thresholds; none was
    tuned, and changing either never changes the selection status.
65. **Progress is logged and backed up from the current tree.**
    `CHECKPOINT_PROGRESS.md` records stages and snapshots. Each partial ZIP is
    built from the working directory and checked file by file (SHA-256
    manifest) against it before being reported, and an older checkpoint
    archive is never handed back as a backup. The documentation test now
    requires that file to exist.

### Checkpoint 8

66. **Readiness is not collection.** The readiness report answers "software
    ready?" (yes) and "collection ready?" (no) separately; passing the first
    says nothing about the second.
67. **The real schema is a strict superset of the CP02 raw schema**, proved by
    `cp02_compatibility_problems()` (with a mutation test), so the adapter's
    output always passes the unmodified CP02 cleaner.
68. **RSSI/SNR are nullable with an explicit source.** A packet that never
    arrived has no gateway RSSI/SNR; forcing a value would be fabrication.
69. **The survivorship-bias guard.** The adapter has no default missing-link
    policy, reports what it filled or dropped per outcome, marks filled rows in
    `notes`, limits carry-forward by staleness, and refuses if failures existed
    and none survive. `drop` needs an acknowledgement.
70. **Only `sweep` sessions may train.** `baseline`/`edge_ai` sessions are
    evaluation-only, otherwise a model would learn its own policy.
71. **Missing row != failed packet.** Sequence gaps are log loss; `boot_id`
    splits sessions at reboots because a rebooted device really loses its
    history.
72. **No region, band or radio parameter is assumed.** `UNSET` everywhere,
    refused in strict mode; the SX1278 433 MHz plan is not enforced.
73. **Synthetic can never pass as real.** `data_origin` gate plus signature
    detection; `require_real=True` is the default everywhere.
74. **Metadata is never a feature.** Environment, scenario, context, distance,
    energy, latency and provenance columns are rejected as model inputs.
75. **Claims are fixed before data.** `CLAIMS_POLICY` and a pre-declared analysis
    plan; energy is a metric only when `energy_source` says it was measured and
    estimated energy is never pooled with measured energy.
76. **The logger never invents a value.** Checksummed lines; rejects go to
    `<out>.rejects.log` with the reason; it refuses a non-strict manifest, an
    existing non-empty CSV (without `resume`), and a synthetic manifest unless
    told to.
77. **Documentation is reconciled with code, not the reverse.** `REAL_DATA_SCHEMA.md`
    is generated from code and templates are regenerated and checked for drift;
    in the final session the documents were rewritten to match the
    implementation and no test or code was altered to make a check pass.

---

## 7. Known Issues / Limitations

Carried over from Checkpoint 1 (still true):
- No real hardware (ESP32 + LoRa module) has been used or tested yet —
  the radio chip is now chosen (SX1278, 433 MHz — confirmed during the
  Checkpoint 2 correction pass) but no physical unit has been used.
- The exact ML approach has not been chosen.
- `requirements.txt` will need additions later (matplotlib, TensorFlow/TFLite
  or similar, pyserial, etc.) — do not add until actually needed.

New in Checkpoint 2:
- The rolling window sizes (5, 10 packets) are placeholder defaults, not
  validated against real data or a chosen model — may need to change once
  real sessions and a model architecture exist.
- `tp_dbm` and `rssi_dbm` valid ranges in `schema.py` are reasonable
  generic LoRa-module estimates, not yet confirmed against the specific
  SX1278 hardware that will eventually be used. Ranges should be
  revisited once real hardware measurements are available, or a real
  value could get incorrectly rejected/dropped by validation.
- ~~No label-construction strategy exists yet~~ → **Addressed in Checkpoint
  3** (`experiments/LABELING_STRATEGY.md`, `ml/labeling/`). The limitations
  of that strategy are listed below rather than here.
- The preprocessing pipeline has only ever been run against synthetic
  fixture data (12 rows). Its behavior on much larger, messier real data
  (e.g. multi-session files, clock skew, missing sensor readings mid-session)
  is unverified and should be re-checked once real data exists.

Resolved in the Checkpoint 2 correction pass (no longer open issues):
- ~~`numpy` requirement pin (`<2.0`) didn't match the numpy version
  (2.3.5) actually verified against~~ → fixed; pin widened to `<3.0` and
  re-verified against numpy 1.26.4 AND 2.3.5.
- ~~Synthetic fixture used a 915 MHz frequency inconsistent with the
  planned SX1278 433 MHz hardware~~ → fixed; fixture now uses 433 MHz,
  clearly still labeled synthetic.

New in Checkpoint 3 (all also listed, with fuller explanation, in
`experiments/LABELING_STRATEGY.md` section 7):

- **The labeling framework has never been run on real data**, because none
  exists. Everything verified so far is verified against a 210-row synthetic
  fixture designed to exercise specific branches.
- **All labeling defaults are placeholders.** `min_reliability=0.90`, the
  RSSI/SNR bin widths, and the three evidence guards were chosen so the code
  is testable, not validated against anything. Same status as Checkpoint 2's
  placeholder rolling-window sizes.
- **The context definition is the framework's biggest unvalidated
  assumption.** Too coarse and configurations measured under different
  conditions get compared; too fine and nothing clears the coverage guard.
  There is a real circularity too: RSSI and SNR are partly a *consequence* of
  the configuration in use, so binning by them is not configuration-neutral.
- **Mild self-inclusion leakage.** A packet's label derives from statistics
  over its whole context, including that packet. Mitigation is to split
  train/test by `context_id` (`GroupKFold`/`GroupShuffleSplit`), not by row.
  A leave-one-out variant was considered and not implemented.
- **The oracle can only ever pick a configuration that was measured.** If the
  sweep omits the genuinely optimal setting, labels are
  optimal-within-what-was-tried and nothing in the pipeline can detect it.
- **The default energy model is biased toward low TX power** (see design
  decision #24). Switch to `measured_current_table` before quoting any energy
  figure as a result — which requires datasheet or bench measurements that do
  not exist yet.
- **Airtime parameters are configured, not measured.** If bandwidth, coding
  rate, preamble, header or CRC settings disagree with what the ESP32
  firmware actually sets, every energy comparison is biased. Verify once
  firmware exists.
- **Class imbalance is likely.** If most contexts turn out to be easy links,
  one configuration will dominate the labels and a model could score well by
  always predicting it. Evaluation must report per-class performance.
- **Sweep confounding cannot be detected in code.** Whether a session
  interleaved configurations round-robin or blocked them is a protocol
  property; the labeler cannot tell the difference from the CSV.

New in Checkpoint 4:

- **Every metric the project has ever produced is meaningless as evidence.**
  The fixture assigns each link tier a distinct RSSI/SNR band with one
  correct answer, so it is separable by construction. The pipeline scores
  perfectly on it; that is the expected outcome of correct wiring and says
  nothing about LoRa.
- **Effective sample size is tiny.** 5,370 usable rows across 30 contexts is
  a 30-sample problem, split 21/9. Nine test contexts cannot support any
  confident statement, even on real data. Real collection needs far more
  distinct channel conditions, not just more packets.
- **Two independent trees can emit an unseen (SF, TP) combination.** Joint
  exact-match exposes it; nothing currently prevents it.
- **Decision Tree was chosen for validation, not selected on merit.**
  Checkpoint 5 ran a first software-level comparison against Logistic
  Regression (see below), but that comparison is itself only valid on this
  fabricated fixture. Whether a tree, a linear model, or something else is
  the right family for real LoRa data remains an open question.
- **Hyperparameters are arbitrary.** `max_depth=6`, `min_samples_leaf=5`,
  `test_size=0.3` were set to keep trees inspectable, not tuned.
- **Inference timing is from the build machine, not an ESP32.** The 3 KB
  joblib figure is desktop serialisation, not an embedded footprint. Neither
  number transfers to the target hardware.
- **The current-row RSSI/SNR question is unresolved.** Off by default for
  causality, but which lag a real device can actually act on depends on
  firmware behaviour that does not exist yet.
- **Class balance in the fixture is artificial.** Six contexts per class,
  because it was written that way. Real conditions will not be balanced, and
  the majority-class baseline will matter much more.

New in Checkpoint 5:

- **The Decision-Tree-vs-Logistic-Regression comparison is a software
  comparison, not a model-selection result.** Both models were scored on a
  fixture that is separable by axis-aligned regions — exactly the shape a
  tree exploits and a linear model cannot. Logistic Regression scoring
  lower here says nothing about which family will generalise better on
  real, not-yet-collected channel data; a linear model can easily be the
  better real-world choice if the true decision boundary turns out to be
  closer to linear than this fixture's construction implies.
- **Only two model families exist.** Random Forest, gradient boosting,
  small neural networks, and any other candidate remain unexplored, per
  explicit user instruction to defer them.
- **The comparison methodology, not just the two model files, is the
  actual Checkpoint 5 deliverable.** `compare_models.py` is written to be
  re-run once real data exists and once a third or fourth candidate is
  added — the identical-split, mismatched-feature-refusal, and
  no-superiority-claim discipline should be reused rather than
  re-implemented per new model.
- **Logistic Regression's coefficients are on standardized features.**
  The per-class coefficients recorded in
  `logistic_regression_sf_tp_metadata.json` are in units of standard
  deviations of each rolling-history feature, not raw dBm/ratio/count
  units — reading them as if they were in the original units would
  misstate each feature's real-world effect size.
- **Convergence was verified only on this fixture's scale and size.**
  `max_iter=2000` was sufficient here; a much larger or differently-scaled
  real dataset may need a different `max_iter` or solver, and the
  `converged` metadata field exists precisely so a future run can catch
  this rather than silently accept a non-converged model.

New in Checkpoint 6:

- **The three-model comparison is a software comparison, not a model-selection
  result.** The Random Forest and the Decision Tree both score 1.0000 because
  the fixture is separable by axis-aligned regions — exactly what tree-based
  models exploit. That says nothing about ensembles: a forest matching a
  single tree here is not evidence that an ensemble helps, and it would not be
  evidence that it hurts either. Only 9 held-out contexts exist, and no
  significance test is (or could meaningfully be) run.
- **The forest's diversity comes mostly from feature subsampling, not from
  bootstrapping.** Bootstrap resamples rows, but with ~21 training contexts
  and ~180 rows each, every bootstrap sample still covers every context. The
  trees differ chiefly because `max_features="sqrt"` (2 of 8 features) forces
  different splits. On real data with more contexts this may change; a
  context-aware (grouped) bootstrap was not implemented because it is not
  justified by any evidence yet.
- **The forest's hyperparameters are arbitrary.** 10 trees, depth 5, leaf 5,
  `sqrt` were chosen to be small, not tuned. The small-forest guard limits (30
  trees, depth 10) are placeholders, not measured ESP32 limits.
- **No ESP32 footprint or latency exists.** The forest's joblib file is 27.6 KB
  against 3.21 KB for a single tree, but that is scikit-learn object overhead
  on a desktop. Its total node counts (96 SF / 118 TP across 10 trees each,
  versus 7 / 7 for the single tree) are the structural quantity a compact
  export would be budgeted against; how many bytes that is on the device is
  unknown until an export exists (later checkpoint).
- **Single-decision inference time is mostly scikit-learn overhead.** ~854 µs
  per full SF+TP decision for the forest versus ~77 µs for the tree, in one
  noisy desktop run, largely reflects per-call cost of calling a forest through
  scikit-learn rather than the models' intrinsic cost. It must not be read as
  an estimate of on-device latency.
- **Out-of-bag scoring is unavailable by design** (see decision 45), so there
  is no second, cheaper generalisation estimate — only the context-held-out
  one, on 9 contexts.
- **Feature importances exist but are not interpreted.** They are impurity
  based, computed on a fixture built to be separable, and are in the metadata
  JSON only.
- **Two independent forests can still emit an (SF, TP) pair never seen
  together.** Same limitation as the two other models; joint exact match
  exposes it.
- **`compare_models.py` (CP5) remains a two-model, DT-vs-LR tool.** The
  three-way comparison lives in `compare_candidates.py`; nothing forces the
  two to stay in sync beyond the tests.
- **Environment note.** Verified under three dependency stacks (see section
  3), one of which (pandas 3.0.2) is outside the declared pin. Behaviour was
  identical, but only the pinned/low-end stacks are the supported
  configuration.

New in Checkpoint 7:
- **Every number is synthetic.** The fixture is separable by construction, so
  the factor scores are not a ranking and say nothing about which model suits
  LoRa. The size, latency and "embedded suitability" figures are desktop
  scikit-learn proxies, and the thresholds behind the labels are placeholders.
- **The default weights count model size twice.** `memory_requirements` reuses
  the joblib KB figure, so its normalised score is identical to
  `model_size`'s; with equal weights size carries 2/6 of the weighted score,
  and `embedded_feasibility` (derived from the size and latency classes) adds
  further correlation. The six factors are not independent. Whoever sets the
  weights must account for this.
- **Min-max scores exaggerate small differences and depend on the candidate
  set.** Two sizes of 2.9 and 3.2 KB map to 1.0 and 0.0. Adding a fourth
  candidate changes every score.
- **The stability factor is coarse.** It uses the worst of 9 held-out contexts
  from one split, each with few rows, so it is noisy. It does not measure
  sensitivity to which contexts were held out, has no confidence interval, and
  there is no statistical test anywhere in the framework.
- **Parameter counts are not memory.** A coefficient and a tree node are not
  the same size and are not comparable across families; an ESP32 export would
  use its own layout. There is no energy-per-decision factor (it needs the
  supply-current table in the data-collection plan).
- **The report is hard-wired to call everything synthetic.** Section A's title,
  the banner and the "does not show" lists assume fixture data. When real data
  exists, the generator needs a deliberate, reviewed change (for example an
  explicit data-source parameter) so real-data results are not mislabelled
  synthetic and synthetic ones are never labelled real. This is not built.
- **Weights and thresholds are Python-API only.** The command line exposes
  `--include-illustrative-scores`, `--test-size` and `--random-state` only.
- **Timing figures come from one machine and are noisy**; labels derived from
  them can flip between runs. The committed run record is one sample.
- **Redundant model loading.** One report loads each model several times
  (comparison, `evaluate()`, stability, parameter counts). Harmless at this
  scale.
- **The documentation test is a floor.** It checks that required strings
  exist, not that the documents are correct or complete.
- **Frozen-hash test couples to exact bytes** of nine CP04-CP06 modules by
  design.
- **Environment.** Verified only on the container's system stack (Python
  3.12.3, numpy 2.4.4, pandas 3.0.2, scikit-learn 1.8.0, joblib 1.5.3). The
  pinned lower/upper-bound virtual-environment matrix that Checkpoint 6 ran
  was not repeated; the new code uses only dataclasses, numpy and the
  standard library, so the risk is low but unverified.

Known limitations of Checkpoint 8:

- **Never exercised on real data.** Every check uses deterministic synthetic
  rows with arbitrary test radio values; real logs will be messier.
- **No firmware.** The line protocol and field rules are a contract nothing
  implements yet; mismatches will only show up on hardware.
- **Host-clock timestamps.** `timestamp_source = host_receipt`; absolute time is
  only as good as the capture machine's clock.
- **Carry-forward is a judgement.** Its staleness limit (`max_carry_forward_packets`)
  is the user's decision and changes the training data.
- **The 25-packet minimum is arithmetic**, from CP03's placeholder reliability
  threshold and Wilson bound; it moves if those change.
- **Analysis code is absent.** The pre-declared plan names metrics and rules, but
  nothing computes the baseline-vs-Edge-AI comparison.
- **The CP07 report generator is still hard-wired to call results synthetic**
  (see the CP07 limitations above); it needs a deliberate, reviewed
  data-source-aware change before it can present real results.
- **The documentation test is a floor**, not proof of correctness.
- **`tests/fixtures/README.md` does not mention the CP08 generator**: it is pinned
  byte-for-byte by the frozen-file check, so the generator is documented in
  `ml/collection/README.md` instead.
- **Environment.** Verified only on the container's system stack; the pinned-bound
  virtual-environment matrix was not repeated.

---

## 8. Next Checkpoint

**Checkpoint 9 (NOT started; scope not defined by the user).** Checkpoint 8
(collection readiness) is complete. What follows is the preserved description of
the *real data collection work itself*, which CP08 prepared for but did not do.

> Final model selection is still **TBD — to be determined using real data and ESP32 deployment measurements.** Nothing in
> this section authorises starting work; confirm with the user first.

### 8.0 State after Checkpoint 8

Ready: schema, manifest, configs, validator, adapter, logger, procedure,
firmware contract, readiness report. Missing: real hardware, firmware, filled
configs (129 `UNSET`), real measurements. The first real-data step is to fill a
manifest and config until `python -m ml.collection.readiness --manifest ... --config ...`
reports no `UNSET`, then run a `sweep` session per `experiments/EXPERIMENT_PROCEDURE.md`.

**Checkpoint 8 (earlier text, NOT started at the time): Real Hardware Data Collection**

> Final model selection is still **TBD — to be determined using real data and ESP32 deployment measurements.** Nothing in
> this section authorises starting the work; confirm with the user first.

(Renumbered a third time. This was called "Checkpoint 5" in early drafts,
"Checkpoint 6" through Checkpoint 5, and "Checkpoint 7" through Checkpoint 6.
The user explicitly redefined Checkpoint 5 to be the Logistic Regression
comparison, Checkpoint 6 to be the small Random Forest, and Checkpoint 7 to
be the model comparison and selection framework documented in sections 2.6
and 3. If the user redefines scope again, this section should follow them,
not the other way round.)

### 8.1 Why this is next, and why it is blocked on the user

The software path is now complete end to end — preprocessing, labeling,
training of three model families, evaluation, comparison, and a configurable
selection framework all run — and has been validated only on fabricated data.
What it has never seen is a real link. Real ESP32 + SX1278 data is **still
required** before any comparison of the three candidates means anything, and
before any model can be selected. Collecting it is largely outside what an AI
session can do itself.

### 8.2 What to do once real data exists (do not start this unprompted)

1. Follow `experiments/DATA_COLLECTION_PLAN.md`, including its section 4a
   sweep requirements, and resolve the open items in its section 6.
2. Run the existing preprocessing and labeling on the real data; revisit the
   placeholder labeling defaults and record every change.
3. **Decide the factor weights and the suitability thresholds in writing
   before looking at any real result**, accounting for the double-counting of
   model size (section 7), so they are not tuned toward a favourite.
4. Retrain all three models with identical settings. If tuning is wanted, make
   it a separate, explicit step with the same budget for each model, and keep
   `tuned` truthful in the metadata.
5. Make the report generator's synthetic labelling data-source-aware by a
   deliberate, reviewed change (section 7), then re-run
   `generate_comparison_report` and fill in section B with real results.
6. Export/quantize and measure on an ESP32 (later checkpoints) so that size,
   latency, memory and embedded feasibility stop being desktop proxies.
7. Only then make a model selection, as a documented, human-reviewed decision
   that deliberately updates the framework's selection status and its test.

### 8.3 Earlier description of this work

*Preserved verbatim from before Checkpoint 7, when this work was called
"Checkpoint 7". Read every "Checkpoint 7" below as Checkpoint 8.*

**Checkpoint 7 (NOT started): Real Hardware Data Collection**

(Renumbered — this was called "Checkpoint 5" in early drafts of this file and
"Checkpoint 6" through Checkpoint 5. The user explicitly redefined Checkpoint
5 to be the Logistic Regression comparison, and then Checkpoint 6 to be the
small Random Forest documented in sections 2.5, 3 and 6 above. If the user
redefines scope again, this section should follow them, not the other way
round.)

Everything downstream is blocked on this. The software path is now complete
end to end — preprocessing, labeling, training (three model families),
evaluation, and comparison all run — and has been validated on fabricated
data. What it has never seen is a real link.

Before anything else is worth doing:

- Collect real ESP32 + SX1278 data per `experiments/DATA_COLLECTION_PLAN.md`,
  **including the section 4a sweep requirements** (interleaved round-robin
  configuration sweep within each channel condition, ≥25 packets per
  configuration, enough distinct conditions to give a usable number of
  contexts)
- Resolve the open hardware/regulatory questions in that document's section
  6: the (SF, TP) grid, the regional configuration, the supply-current table,
  and the firmware's actual airtime parameters
- Run the existing pipeline over it and **review the oracle table and the
  `label_status` breakdown before training** — that will reveal whether the
  collection protocol actually produced labellable data
- Revisit the labeling defaults (threshold, context strategy, bin widths,
  evidence guards) against real data; they are placeholders
- Retrain ALL THREE models (Decision Tree, Logistic Regression, small Random
  Forest) on real data, re-run `ml/evaluation/compare_candidates.py` for an
  honest comparison, and only then consider removing the synthetic-data
  banner and the no-superiority-claim language — they come off only once the
  numbers genuinely come from hardware

**Explicitly deferred:** a *fourth* model family (gradient boosting, small
neural networks, etc.) should not be added without an explicit request, and
is better done once real data exists so the comparison methodology in
`ml/evaluation/compare_candidates.py` is exercised on something more than a
fixture that is separable by construction. Likewise, exporting/quantizing any
model and measuring its real ESP32 footprint is a later checkpoint — the
forest's node counts and joblib size are not on-device figures.

**Do not start Checkpoint 7 work until explicitly instructed.** It is largely
outside what an AI session can do itself; confirm with the user how they want
to proceed.

---

## 9. Instructions for a New Claude Account/Session to Continue This Project

If you are a new Claude session picking up this project (e.g. the user
uploaded this project folder because a previous session ran out of tokens),
follow this exact process:

1. **Read this entire file (`PROJECT_STATUS.md`) first**, then skim
   `README.md` and `CHANGELOG.md`.
2. **Do not assume any work exists beyond what section 3 ("Completed Work")
   of this file lists.** Verify by actually inspecting the folder structure
   and file contents rather than trusting summaries alone.
3. **Do not fabricate or backfill research data, results, or benchmarks**
   for any checkpoint, past or future. If the user asks for results that
   don't exist yet, say so plainly instead of inventing plausible-looking
   numbers.
4. **Only work on the checkpoint the user explicitly asks for.** Check
   section 8 ("Next Checkpoint") for what is expected next, but confirm
   with the user before assuming that's what they want right now — they
   may want to revise Checkpoint 1, ask questions, or jump to something
   else.
5. **Preserve this checkpoint discipline going forward:** after finishing
   whatever checkpoint you're asked to do, update `PROJECT_STATUS.md` (all
   relevant sections, especially Completed/Incomplete/Next Checkpoint) and
   append an entry to `CHANGELOG.md`, then stop and wait for explicit
   instruction before continuing to the next checkpoint — mirroring how
   Checkpoint 1 was handled.
6. **Keep the project portable.** At the end of any checkpoint, offer to
   package the complete, current project folder as a downloadable zip
   (naming convention: `LoRa_EdgeAI_CP<NN>_<short-description>.zip`), so the
   user can continue in a fresh session if needed. Checkpoint 1 produced
   `LoRa_EdgeAI_CP01_Project_Setup.zip`; Checkpoint 2 produced
   `LoRa_EdgeAI_CP02_Data_Pipeline.zip`, later corrected and re-delivered as
   `LoRa_EdgeAI_CP02_Data_Pipeline_v2.zip` after a user-requested
   correction pass (numpy pin, fixture frequency — see section 3);
   Checkpoint 3 produced `LoRa_EdgeAI_CP03_Labeling_Framework.zip`;
   Checkpoint 4 produced
   `LoRa_EdgeAI_CP04_DecisionTree_SoftwareValidation.zip`; Checkpoint 5
   produced `LoRa_EdgeAI_CP05_LogisticRegression_Comparison.zip`; Checkpoint 6
   produced `LoRa_EdgeAI_CP06_RandomForest_Comparison.zip`. Checkpoint 7
   produced `LoRa_EdgeAI_CP07_FINAL.zip`, also delivered under the originally
   requested name `LoRa_EdgeAI_CP07_Model_Comparison_Framework.zip` (the two
   are byte-identical); partial backups made during the build are listed in
   `CHECKPOINT_PROGRESS.md`.
7. **When in doubt about scope, ask the user rather than guessing** —
   especially before adding new dependencies, choosing a model architecture,
   or claiming something is "done." (Checkpoint 2 did this: it asked the
   user, via a single clarifying question, whether data would come from
   real hardware, a synthetic generator, or a public dataset, before
   building anything — see section 6, decision 6.)
8. **Checkpoint 8 is complete (readiness only).** Before anything that touches
   real data, note that collecting it is hardware work outside what an AI
   session can do itself (see section 8). Confirm with the user how they want to proceed rather than
   assuming. (Hardware collection has been called "Checkpoint 5", "6", "7" and
   now "8" because the user redefined scope three times — check which
   numbering they mean before acting.)
8a. **Never present a metric from fixture data as a result.** Every number
   this project has produced so far — Decision Tree, Logistic Regression,
   Random Forest, or any comparison of them — came from a fixture that is
   separable by construction. The `SYNTHETIC_BANNER` in
   `ml/evaluation/metrics.py`, the `NO_SUPERIORITY_CLAIM` in
   `ml/evaluation/compare_models.py` and the `NO_SUPERIORITY_CLAIM_MULTI` in
   `ml/evaluation/compare_candidates.py` are emitted structurally and tests
   assert their presence — if a future session finds any inconvenient, that is
   the guard working, not a bug. They come off only when metrics genuinely come
   from hardware.
9. **Do not weaken the labeling framework's honesty guards.** Several things
   in `ml/labeling/` deliberately refuse to produce output rather than
   guessing: the empty supply-current table, the candidate sets defaulting to
   "derive from data", `min_configs_per_context`, and the extrapolation
   refusal in the current-table lookup. If a future session finds one of
   these inconvenient, the correct response is to get the real value from the
   user or the datasheet — not to fill in a plausible default. Tests in
   `tests/test_labeling.py` assert several of these guards, so silently
   removing one will fail the suite.
10. **Numbers the labeling code produces are not results.** Anything computed
   from `tests/fixtures/` is arithmetic over fabricated data used to verify
   the code. It must never appear in a report as a finding.
11. **Do not add a fourth model family without an explicit request.**
   Random Forest was deferred in Checkpoint 5 and added in Checkpoint 6 only
   because the user explicitly asked for it. If asked to add another, reuse
   `ml/training/dataset.py` unmodified (as all three trainers do), give the new
   trainer no way to override the feature set, and add the model as one more
   `Candidate` to `ml/evaluation/compare_candidates.py` — which is generic over
   N candidates — rather than writing a new, separate comparison path.
12. **When comparing model families, always evaluate on an identical split**
   and never claim one is "better" from synthetic/fixture data. This is not
   Checkpoint-5-specific advice — it is the standing discipline
   `ml/evaluation/compare_models.py` was built to enforce, and it applies to
   any future model comparison in this project, including once real data
   exists.
13. **Random-Forest-specific guards — do not remove them to make something
   work.** The small-forest guard in `train_random_forest.py` (30 trees, depth
   10, unlimited depth rejected) stops a scikit-learn-default forest being
   trained by accident; override it deliberately with `--allow-large-forest`,
   do not delete it. `oob_score` stays disabled (decision 45). The reload and
   reproducibility stages raise on failure; a failure means a real defect, not
   a flaky test. The trainer deliberately has no feature-list parameter.
14. **Keep the earlier modules unmodified unless the user explicitly
   asks.** That means the three trainers, `dataset.py`, `evaluate.py`,
   `metrics.py`, `timing.py`, `compare_models.py` and `compare_candidates.py`.
   Checkpoint 7 was verified byte-identical against the Checkpoint 6 archive
   for every functional file from Checkpoints 1-6, and its test pins nine of
   them by SHA-256. If you change one, say so, update the pinned hash in the
   same change, and re-run all seven suites.
15. **Before delivering any checkpoint: run all seven test suites, and after
   any programmatic markdown edit grep for doubled trailing backslashes**
   (`grep -c '\\\\$' file.md`) — line-continuation backslashes in shell code
   blocks were silently doubled twice during Checkpoint 6 and had to be fixed.
   The expected suite command list is in section 0.10.
16. **Never make the comparison framework select a model on synthetic data.**
   `select_candidate()` returns the constant `FINAL_SELECTION_STATUS`
   ("TBD — to be determined using real data and ESP32 deployment measurements.") and a test asserts it under many weightings. Do not add
   a flag, default, weight, "recommended" field or report sentence that
   names a winner. A real selection is a later, human-reviewed step made on
   real data and measured ESP32 figures (section 8.2).
17. **Keep the report's two worlds separate.** "SYNTHETIC SOFTWARE-VALIDATION
   RESULTS" (section A) and "REAL HARDWARE RESULTS — NOT YET AVAILABLE"
   (section B) must stay distinct. Section B stays a placeholder with no
   numbers until real measurements exist, and must then be filled from
   measured files, never from desktop proxies.
18. **Do not read the factor scores as a ranking.** They are relative to the
   candidates in a run, built from synthetic and desktop-proxy figures, and
   the six factors are not independent (section 7). If asked "which model is
   best", say that final selection is TBD and why.
19. **Do not change weights or thresholds after seeing real results.** Fix
   them first, in writing, and record them with the results.
20. **Do not assert on timing.** Training time, inference time and the labels
   derived from them vary run to run; tests must not depend on them.
21. **Keep `CHECKPOINT_PROGRESS.md` current and back up from the current
   tree.** After each major stage update it and, if the session may be cut
   short, build a partial ZIP from the working directory, verify it file by
   file (SHA-256 manifest) against that directory, and name it with the next
   partial stage. Never return an older checkpoint archive as a backup. If
   you are handed a partial ZIP, compare it with any working directory that
   still exists before choosing which is newer.
22. **Stop after the checkpoint you were asked for.** Checkpoint 8 is complete;
   Checkpoint 9 has not been started and must not be unless the user says so.
23. **Never put synthetic data in `data/`, and never add external or public LoRa
   datasets.** CP08 test rows are `synthetic_test`, deterministic, and live only
   in temporary directories. Do not weaken the provenance gate, the
   survivorship-bias guard, the `UNSET` refusals or the claims policy to make
   something run; get the real value from the user or the hardware.
24. **Run all eight suites** (section 0.10) before delivering; the CP08 suite
   already re-runs the other seven and pins 64 CP01-CP07 files by SHA-256.
25. **Deliverable naming:** Checkpoint 8 produced `LoRa_EdgeAI_CP08_FINAL.zip`;
   partial backups are listed in `CHECKPOINT_PROGRESS.md`.
