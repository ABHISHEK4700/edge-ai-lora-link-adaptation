"""
experiment_config.py

Checkpoint 8 — Experiment configurations for the three kinds of session:

    sweep      a configuration sweep that produces LABELLABLE training data
    baseline   the baseline policy arm (evaluation only)
    edge_ai    the Edge-AI policy arm (evaluation only)

*** Nothing here claims any result. *** In particular nothing claims that
Edge-AI improves packet delivery ratio, latency or energy: that is a question
for real measurements, answered by an analysis plan fixed BEFORE the data is
looked at (`AnalysisPlan`), under `CLAIMS_POLICY`.

THE POINT OF A SHARED STRUCTURE
---------------------------------
Baseline and Edge-AI must be compared under the SAME conditions. Both configs
carry identical `radio` and `conditions` blocks; `check_arm_parity()` verifies
that and reports every difference, so only the policy can differ. Block order
is declared (alternating / counterbalanced / seeded-random) because running one
arm entirely before the other confounds the policy with channel drift.

NO REGION IS ASSUMED: every hardware-dependent value is UNSET in the templates
(experiments/configs/*.json). `problems(cfg, strict=True)` refuses to approve a
config for real collection while any UNSET remains.

TRAINING / EVALUATION SEPARATION
----------------------------------
Only `sweep` sessions may feed labeling and training. An Edge-AI config must
list the sessions its model was trained on and the sessions it is evaluated
on, and the two lists must not overlap. Overlap of *scenarios* is allowed but
reported, since it weakens the generalisation claim.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Union

from ml.collection._util import UNSET, build, find_unset, to_plain
from ml.collection.manifest import RadioConfig, radio_problems
from ml.collection.planner import min_packets_for_reliability
from ml.collection.real_schema import assert_no_metadata_features, MetadataFeatureError

CLAIMS_POLICY = (
    "No statement that the Edge-AI policy improves packet delivery ratio, "
    "latency or energy may be made until it is supported by REAL hardware "
    "measurements analysed according to this pre-declared plan. A synthetic "
    "or desktop result is software validation only."
)

BLOCK_ORDERS = ("alternating", "counterbalanced", "seeded_random")
SWEEP_ORDERS = ("round_robin", "seeded_shuffle")        # blocked sweeps are refused
BASELINE_TYPES = ("fixed_config", "adr_algorithm")
MODEL_FAMILIES = ("decision_tree", "logistic_regression", "random_forest")
ALLOWED_METRICS = ("packet_delivery_ratio", "mean_latency_ms", "energy_per_delivered_packet_mj")


@dataclass
class ControlledConditions:
    """Identical across baseline and edge_ai. Everything that could differ
    between arms other than the policy lives here, so it cannot."""
    scenario_ids: Union[List[str], str] = UNSET
    payload_bytes: Union[int, str] = UNSET
    packet_interval_s: Union[float, str] = UNSET
    packets_per_block: Union[int, str] = UNSET
    blocks_per_arm: Union[int, str] = UNSET
    max_retries: Union[int, str] = UNSET
    ack_timeout_ms: Union[int, str] = UNSET
    block_order: str = "alternating"
    block_order_seed: Union[int, str] = UNSET


@dataclass
class AnalysisPlan:
    """Fixed BEFORE looking at real results, so it cannot be tuned toward a
    favoured outcome."""
    primary_metrics: List[str] = field(default_factory=lambda: ["packet_delivery_ratio", "mean_latency_ms"])
    #: Energy is only a metric if it is MEASURED (energy_source measured_*).
    energy_metric_enabled: bool = False
    min_blocks_per_arm: Union[int, str] = UNSET
    comparison_method: str = UNSET
    significance_level: Union[float, str] = UNSET
    plan_frozen_before_data_review: Union[bool, str] = UNSET
    claims_policy: str = CLAIMS_POLICY


@dataclass
class SweepPolicy:
    allowed_sf: Union[List[int], str] = UNSET
    allowed_tp_dbm: Union[List[float], str] = UNSET
    packets_per_config_per_context: Union[int, str] = UNSET
    order: str = "round_robin"


@dataclass
class BaselinePolicy:
    policy_type: str = UNSET
    fixed_sf: Union[int, str] = UNSET
    fixed_tp_dbm: Union[float, str] = UNSET
    algorithm_name: str = UNSET
    algorithm_reference: str = UNSET          # firmware commit / document describing it
    algorithm_parameters: Dict[str, Any] = field(default_factory=dict)


def _default_features() -> List[str]:
    from ml.training.dataset import DEFAULT_FEATURE_COLUMNS
    return list(DEFAULT_FEATURE_COLUMNS)


@dataclass
class EdgeAIPolicy:
    #: Chosen by a human AFTER the CP07 framework is re-run on REAL data. The
    #: CP07 selection status is TBD and nothing here selects a model.
    model_family: str = UNSET
    model_artifact_sha256: str = UNSET
    selection_basis: str = UNSET              # path/hash of the real-data comparison report
    training_session_ids: Union[List[str], str] = UNSET
    evaluation_session_ids: Union[List[str], str] = UNSET
    feature_columns: List[str] = field(default_factory=_default_features)
    export_format: str = UNSET
    decision_rule: str = "per_packet"


@dataclass
class _Common:
    config_name: str = UNSET
    config_version: int = 1
    experiment_mode: str = UNSET
    radio: RadioConfig = field(default_factory=RadioConfig)
    conditions: ControlledConditions = field(default_factory=ControlledConditions)
    analysis: AnalysisPlan = field(default_factory=AnalysisPlan)

    def to_dict(self) -> dict:
        return to_plain(self)

    def unresolved(self) -> List[str]:
        return find_unset(self)

    def to_json_file(self, path) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2)
            fh.write("\n")


@dataclass
class SweepConfig(_Common):
    experiment_mode: str = "sweep"
    policy: SweepPolicy = field(default_factory=SweepPolicy)


@dataclass
class BaselineConfig(_Common):
    experiment_mode: str = "baseline"
    policy: BaselinePolicy = field(default_factory=BaselinePolicy)


@dataclass
class EdgeAIConfig(_Common):
    experiment_mode: str = "edge_ai"
    policy: EdgeAIPolicy = field(default_factory=EdgeAIPolicy)


_BY_MODE = {"sweep": SweepConfig, "baseline": BaselineConfig, "edge_ai": EdgeAIConfig}


def config_from_dict(data: dict):
    mode = data.get("experiment_mode")
    if mode not in _BY_MODE:
        raise ValueError(f"experiment_mode must be one of {list(_BY_MODE)} (got {mode!r})")
    return build(_BY_MODE[mode], data)


def load_config(path):
    with open(path, "r", encoding="utf-8") as fh:
        return config_from_dict(json.load(fh))


def _num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def problems(cfg, strict: bool = False) -> List[str]:
    """Structural problems always; in strict mode every UNSET too."""
    out = radio_problems(cfg.radio)
    c, a, p = cfg.conditions, cfg.analysis, cfg.policy
    if c.block_order not in BLOCK_ORDERS:
        out.append(f"conditions.block_order must be one of {BLOCK_ORDERS}")
    if cfg.experiment_mode != "sweep" and c.block_order == "seeded_random" and c.block_order_seed == UNSET and strict:
        out.append("seeded_random block order needs conditions.block_order_seed")
    for name in ("payload_bytes", "packet_interval_s", "packets_per_block", "blocks_per_arm",
                 "max_retries", "ack_timeout_ms"):
        v = getattr(c, name)
        if v != UNSET and not (_num(v) and v >= 0):
            out.append(f"conditions.{name} must be a non-negative number or UNSET")
    bad = [m for m in a.primary_metrics if m not in ALLOWED_METRICS]
    if bad:
        out.append(f"analysis.primary_metrics {bad} not in {ALLOWED_METRICS}")
    if "energy_per_delivered_packet_mj" in a.primary_metrics and not a.energy_metric_enabled:
        out.append("energy metric listed but analysis.energy_metric_enabled is false: energy "
                   "is only a metric when it is MEASURED (energy_source measured_*)")
    if a.claims_policy != CLAIMS_POLICY:
        out.append("analysis.claims_policy was altered; the no-premature-claims policy is fixed")

    if isinstance(p, SweepPolicy):
        if p.order not in SWEEP_ORDERS:
            out.append(f"sweep order must be one of {SWEEP_ORDERS}: a BLOCKED sweep lets channel "
                       "drift masquerade as a configuration effect (DATA_COLLECTION_PLAN 4a)")
        for attr, radio_attr in (("allowed_sf", "allowed_sf"), ("allowed_tp_dbm", "allowed_tp_dbm")):
            mine, theirs = getattr(p, attr), getattr(cfg.radio, radio_attr)
            if isinstance(mine, list) and isinstance(theirs, list):
                extra = [x for x in mine if x not in theirs]
                if extra:
                    out.append(f"policy.{attr} {extra} not in radio.{radio_attr}")
        n = p.packets_per_config_per_context
        if _num(n) and n < min_packets_for_reliability():
            out.append(f"policy.packets_per_config_per_context={n} < {min_packets_for_reliability()}: "
                       "below this no configuration can clear the labeler's reliability "
                       "threshold, so every context would be refused a label")
    elif isinstance(p, BaselinePolicy):
        if p.policy_type != UNSET and p.policy_type not in BASELINE_TYPES:
            out.append(f"baseline policy_type must be one of {BASELINE_TYPES}")
        if p.policy_type == "fixed_config":
            for attr, ra in (("fixed_sf", "allowed_sf"), ("fixed_tp_dbm", "allowed_tp_dbm")):
                v, allowed = getattr(p, attr), getattr(cfg.radio, ra)
                if v != UNSET and isinstance(allowed, list) and v not in allowed:
                    out.append(f"policy.{attr}={v} not in radio.{ra}")
        if p.policy_type == "adr_algorithm" and strict:
            for attr in ("algorithm_name", "algorithm_reference"):
                if getattr(p, attr) in (UNSET, ""):
                    out.append(f"adr_algorithm baseline needs policy.{attr}")
    elif isinstance(p, EdgeAIPolicy):
        if p.model_family != UNSET and p.model_family not in MODEL_FAMILIES:
            out.append(f"edge_ai model_family must be one of {MODEL_FAMILIES}")
        try:
            assert_no_metadata_features(p.feature_columns)
        except MetadataFeatureError as e:
            out.append(str(e))
        if list(p.feature_columns) != _default_features():
            out.append("policy.feature_columns differs from the features the CP04-CP07 models "
                       "are trained on; the deployed feature set must equal the trained one")
        t, e = p.training_session_ids, p.evaluation_session_ids
        if isinstance(t, list) and isinstance(e, list):
            overlap = sorted(set(t) & set(e))
            if overlap:
                out.append(f"training and evaluation sessions overlap: {overlap}")

    if strict:
        out += [f"UNSET: {path} — fill in from the real hardware/experiment; never guess"
                for path in cfg.unresolved()]
    return out


def check_arm_parity(a, b) -> Dict[str, Any]:
    """baseline vs edge_ai must differ ONLY in policy. Reports every
    difference in radio / conditions / analysis."""
    diffs: List[str] = []
    if {a.experiment_mode, b.experiment_mode} != {"baseline", "edge_ai"}:
        diffs.append("parity is defined between a baseline and an edge_ai config")
    for block in ("radio", "conditions", "analysis"):
        da, db = to_plain(getattr(a, block)), to_plain(getattr(b, block))
        for k in sorted(set(da) | set(db)):
            if da.get(k) != db.get(k):
                diffs.append(f"{block}.{k}: {da.get(k)!r} != {db.get(k)!r}")
    return {"identical_conditions": not diffs, "differences": diffs}


def scenario_overlap(edge: EdgeAIConfig, sweep: SweepConfig) -> List[str]:
    """Scenarios used both for training sweeps and for evaluation (a warning,
    not an error: it weakens the generalisation claim)."""
    s = sweep.conditions.scenario_ids
    e = edge.conditions.scenario_ids
    return sorted(set(s) & set(e)) if isinstance(s, list) and isinstance(e, list) else []
