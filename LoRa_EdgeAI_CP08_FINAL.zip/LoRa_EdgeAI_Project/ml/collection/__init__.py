"""
ml.collection — Checkpoint 8: readiness for REAL ESP32 + LoRa data collection.

*** NO REAL HARDWARE DATA EXISTS YET, AND NOTHING IN THIS PACKAGE IS A
*** MEASUREMENT. *** This package defines what real data must look like,
validates it when it arrives, converts it for the existing (unmodified)
CP02-CP07 pipeline, and holds the experiment configurations for the baseline
and Edge-AI arms. It never generates, simulates or fills in measurements.

Read ml/collection/README.md first. Modules:

    real_schema        the real-data CSV schema (superset of the CP02 raw schema)
    manifest           per-session manifest: hardware, radio configuration, conditions
    experiment_config  sweep / baseline / edge_ai experiment configurations
    validator          validates a real-data CSV (+ provenance gate, sweep coverage)
    adapter            converts validated real data for the CP02 pipeline
    planner            collection-budget arithmetic (planning, not measurement)
    logger             serial log-line parser and append-safe session logger
    readiness          one command that reports what still blocks real collection

No region, frequency or radio parameter is assumed anywhere: every such value
is `UNSET` in the templates and strict mode refuses to proceed while any is.
"""
