"""
planner.py

Checkpoint 8 — Collection-budget arithmetic. PLANNING, NOT MEASUREMENT.

Reuses the CP03 airtime formula (ml/labeling/airtime.py, unmodified) and CP03's
Wilson reliability estimator to answer: how many packets does a sweep need, and
how long does it take under the duty-cycle limit the user declares?

Nothing is assumed about the region: the duty-cycle fraction comes from the
manifest/config the user filled in, and an UNSET value refuses to plan. The
output is arithmetic on the numbers supplied; real airtime must be confirmed on
the hardware.
"""
from __future__ import annotations

import math
from typing import Dict, List, Optional

from ml.collection._util import UNSET
from ml.collection.manifest import RadioConfig, to_labeling_radio_params

PLANNING_DISCLAIMER = (
    "Planning arithmetic from the airtime formula and the radio parameters you "
    "supplied. Not a measurement: confirm real time-on-air on the hardware."
)


def min_packets_for_reliability(min_reliability: Optional[float] = None,
                                wilson_z: Optional[float] = None) -> int:
    """Fewest packets n for which n successes out of n still clear
    `min_reliability` under the Wilson lower bound. At 100% delivery the bound
    is n/(n+z^2), so n >= z^2 * r/(1-r). Defaults come from CP03's
    LabelingConfig so they cannot drift from the labeler."""
    from ml.labeling.config import LabelingConfig
    from ml.labeling.reliability import wilson_lower_bound

    d = LabelingConfig()
    r = d.min_reliability if min_reliability is None else min_reliability
    z = d.wilson_z if wilson_z is None else wilson_z
    if not 0 < r < 1:
        raise ValueError("min_reliability must be strictly between 0 and 1 "
                         "(1.0 can never be reached by a finite sample)")
    n = max(1, math.ceil(z * z * r / (1 - r)))
    while wilson_lower_bound(n, n, z=z) < r:     # guard against float rounding
        n += 1
    return n


def plan_sweep(radio: RadioConfig, allowed_sf: List[int], allowed_tp_dbm: List[float],
               n_contexts: int, packets_per_config: int, payload_bytes: int,
               max_attempts_per_packet: int, interval_s: Optional[float] = None) -> Dict:
    """Budget for a configuration sweep. Refuses if the radio or duty-cycle
    parameters are UNSET — a plan built on guessed values would be worse than none."""
    from ml.labeling.airtime import time_on_air_s

    if radio.duty_cycle_fraction == UNSET:
        raise ValueError("duty_cycle_fraction is UNSET: declare the limit that applies "
                         "(or null with a basis) before planning.")
    if min(n_contexts, packets_per_config, max_attempts_per_packet) < 1:
        raise ValueError("n_contexts, packets_per_config and max_attempts_per_packet must be >= 1")
    rp = to_labeling_radio_params(radio, payload_bytes)
    duty = radio.duty_cycle_fraction            # number, or None meaning no limit

    per_config = []
    total_seconds = 0.0
    slowest_period = 0.0
    for sf in sorted(allowed_sf):
        toa = time_on_air_s(sf, payload_bytes, rp)
        worst_on_air = toa * max_attempts_per_packet
        period = worst_on_air / duty if duty else worst_on_air
        n_pkts = n_contexts * packets_per_config
        per_config.append({"sf": sf, "airtime_ms": toa * 1000.0,
                           "worst_case_on_air_ms": worst_on_air * 1000.0,
                           "min_packet_period_s": period,
                           "packets": n_pkts * len(allowed_tp_dbm)})
        total_seconds += period * n_pkts * len(allowed_tp_dbm)
        slowest_period = max(slowest_period, period)

    return {
        "disclaimer": PLANNING_DISCLAIMER,
        "n_configs": len(allowed_sf) * len(allowed_tp_dbm),
        "n_contexts": n_contexts,
        "packets_per_config_per_context": packets_per_config,
        "total_packets": len(allowed_sf) * len(allowed_tp_dbm) * n_contexts * packets_per_config,
        "min_packets_per_config_for_reliability": min_packets_for_reliability(),
        "packets_per_config_sufficient": packets_per_config >= min_packets_for_reliability(),
        "duty_cycle_fraction": duty,
        "per_sf": per_config,
        "min_total_hours": total_seconds / 3600.0,
        "slowest_min_period_s": slowest_period,
        "interval_ok": None if interval_s is None else interval_s >= slowest_period,
    }
