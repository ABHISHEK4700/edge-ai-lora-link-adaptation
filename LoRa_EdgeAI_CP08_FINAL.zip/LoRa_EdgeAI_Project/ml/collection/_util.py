"""
_util.py — shared helpers for ml.collection (Checkpoint 8).

`UNSET` marks a value that depends on the real hardware, region or experiment
and has deliberately NOT been guessed. `find_unset()` lists every such value
so strict validation can refuse to start a real collection while any remain.
"""
from __future__ import annotations

import dataclasses
import typing
from typing import Any, Dict, List

UNSET = "UNSET"


def to_plain(obj: Any) -> Any:
    """dataclass / dict / list -> plain JSON-able structure."""
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: to_plain(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, dict):
        return {str(k): to_plain(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_plain(v) for v in obj]
    return obj


def find_unset(obj: Any, prefix: str = "") -> List[str]:
    """Dotted paths of every value equal to UNSET anywhere inside `obj`."""
    plain = to_plain(obj)
    out: List[str] = []

    def walk(v: Any, path: str) -> None:
        if isinstance(v, dict):
            for k, x in v.items():
                walk(x, f"{path}.{k}" if path else str(k))
        elif isinstance(v, list):
            for i, x in enumerate(v):
                walk(x, f"{path}[{i}]")
        elif v == UNSET:
            out.append(path)

    walk(plain, prefix)
    return out


def build(cls, data: Dict[str, Any], path: str = ""):
    """Strict dict -> dataclass: unknown keys raise (never silently ignored),
    nested dataclasses and Dict[str, dataclass] fields are rebuilt."""
    if not isinstance(data, dict):
        raise ValueError(f"{path or cls.__name__}: expected an object, got {type(data).__name__}")
    hints = typing.get_type_hints(cls)
    known = {f.name for f in dataclasses.fields(cls)}
    unknown = sorted(set(data) - known)
    if unknown:
        raise ValueError(f"{path or cls.__name__}: unknown key(s) {unknown}; known: {sorted(known)}")
    kwargs = {}
    for name, value in data.items():
        hint = hints[name]
        sub = f"{path}.{name}" if path else name
        if dataclasses.is_dataclass(hint) and isinstance(value, dict):
            kwargs[name] = build(hint, value, sub)
        elif typing.get_origin(hint) is dict and isinstance(value, dict):
            args = typing.get_args(hint)
            if len(args) == 2 and dataclasses.is_dataclass(args[1]):
                kwargs[name] = {k: build(args[1], v, f"{sub}.{k}") for k, v in value.items()}
            else:
                kwargs[name] = dict(value)
        else:
            kwargs[name] = value
    return cls(**kwargs)
