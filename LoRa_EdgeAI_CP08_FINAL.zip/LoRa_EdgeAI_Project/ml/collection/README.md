# `ml/collection/` — Readiness for Real ESP32 + LoRa Data (Checkpoint 8)

> **NO REAL HARDWARE DATA EXISTS YET, AND NOTHING HERE IS A MEASUREMENT.** This package
> defines what real data must look like, validates it when it arrives, converts it for
> the existing CP02–CP07 pipeline, and holds the baseline / Edge-AI experiment
> configurations. It never generates, simulates or fills in measurements. Only data
> measured on this project's own hardware may be used — no external or public datasets.

## Module map

| module | purpose |
|---|---|
| `real_schema.py` | the real-data CSV schema — a strict superset of the CP02 raw schema; metadata-is-not-a-feature guard |
| `manifest.py` | per-session manifest: hardware, radio/regional configuration, channel conditions (all `UNSET` until real) |
| `experiment_config.py` | `sweep` / `baseline` / `edge_ai` configs, strict validation, arm-parity and train/eval-separation checks |
| `validator.py` | validates a real log CSV: fields, consistency, sequence, provenance gate, manifest cross-checks, sweep coverage |
| `adapter.py` | converts a validated log into the CP02 raw CSV, under explicit purpose and missing-link policies |
| `planner.py` | collection-budget arithmetic (planning, not measurement) |
| `logger.py` | checksummed serial-line protocol and append-safe session logger |
| `readiness.py` | one report: is the *software* ready, and is a given config ready for a *real run*? |

Companion documents: `experiments/REAL_DATA_SCHEMA.md` (generated from the code),
`experiments/FIRMWARE_LOGGING_SPEC.md`, `experiments/EXPERIMENT_PROCEDURE.md`,
templates in `experiments/configs/`.

## Quick start

```bash
python -m ml.collection.readiness                       # software ready? what is still UNSET?
python -m ml.collection.readiness --manifest m.json --config sweep.json   # strict check of filled files

python -m ml.collection.logger --manifest m.json --out data/raw/<session>.csv --input capture.txt

python - <<'PY'
from ml.collection.validator import validate_real_csv
from ml.collection.adapter import to_cp02_raw
print(validate_real_csv("data/raw/<session>.csv").summary())
to_cp02_raw("data/raw/<session>.csv", "data/processed/<session>_cp02.csv",
            purpose="training", missing_link_policy="carry_forward",
            max_carry_forward_packets=3)      # 3 is an example: it is YOUR decision
PY
```

Then run the unchanged CP02 → CP03 → CP04–CP07 tools on the converted file.

## Guards (each is asserted by `tests/test_real_data_collection.py`)

1. **No region or radio value is assumed.** Every hardware-dependent value is `UNSET` in the
   templates; strict mode refuses while any remains. Nothing is hard-coded to EU868 or any
   band.
2. **Survivorship-bias guard.** The CP02 cleaner deletes rows with no RSSI/SNR, i.e. most
   failed packets. The adapter requires an explicit missing-link policy (no default),
   reports what it filled/dropped per outcome, and refuses if failures existed and none
   survive.
3. **Training/evaluation separation.** Only `sweep` sessions can be converted for training;
   `baseline`/`edge_ai` sessions are evaluation-only.
4. **Synthetic data is never accepted as real.** `data_origin` gate plus synthetic-signature
   detection; real-data mode is the default everywhere.
5. **Metadata is never a feature.** Environment, scenario, context, distance, energy,
   latency and provenance columns are rejected as model inputs.
6. **No premature claims.** The analysis plan carries a fixed claims policy; energy is a
   metric only when measured.

## Tests and synthetic data

`python tests/test_real_data_collection.py` runs 27 checks (and re-runs all seven earlier
suites). It needs rows to exercise the validator, adapter and logger, and no real rows exist,
so `tests/fixtures/make_cp08_synthetic_log.py` generates **synthetic software-test rows**:
deterministic (no random generator), `data_origin = synthetic_test`, notes starting
"SYNTHETIC test row", written only to a temporary directory. Their radio values (125 kHz,
CR 4/5, 433 MHz, the SF/TP grid) are arbitrary test values, not a region and not a
recommendation. Anything computed from them is a software check, never a result.
(`tests/fixtures/README.md` is pinned byte-for-byte by the CP08 frozen-file check, so this
README is where that generator is documented.)

## Current state

Software ready: **yes**. Collection ready: **no** — 129 template values are `UNSET`
because the real hardware, region and experiment do not exist yet. No real data has been
collected; no PDR, latency, energy or RSSI/SNR improvement and no model superiority is
claimed. External or public datasets are not used and must not be added.

## Not built here

Firmware, hardware measurements, a model trained on real data, the arm-comparison analysis
code, and any result.
