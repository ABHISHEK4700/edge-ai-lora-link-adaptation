"""
real_schema.py

Checkpoint 8 — The REAL-HARDWARE data-collection schema.

*** No real data exists yet. This module is a CONTRACT, not data. ***

One row = one logical packet sent by one end device (its retries summarised in
the same row, exactly as in the CP02 raw schema). SF and TX power are held
constant across all attempts of one packet — a protocol rule, see
experiments/EXPERIMENT_PROCEDURE.md.

RELATIONSHIP TO THE CP02 RAW SCHEMA (ml/preprocessing/schema.py, unmodified)
-------------------------------------------------------------------------------
REAL_SCHEMA is a strict SUPERSET of `RAW_SCHEMA`. Every CP02 column exists here
with the same dtype and the same sanity range / allowed values, so the output
of `ml.collection.adapter` always passes the unmodified CP02 cleaner.
`cp02_compatibility_problems()` proves this and is asserted by a test.

THREE DESIGN POINTS THAT MATTER

1. **RSSI/SNR are nullable, with an explicit source.** A packet that never
   arrived has no gateway RSSI/SNR, and a lost ACK carries none either. The
   CP02 cleaner DROPS rows with a missing RSSI/SNR, which on real data would
   silently delete essentially every failed packet — leaving success-rate
   history permanently ~1.0 and making every configuration look reliable
   (survivorship bias). The schema therefore records *that* a measurement is
   absent (`link_measurement_source = none`) instead of forcing a value, and
   `ml.collection.adapter` makes the conversion policy explicit and reported.

2. **Energy is never inferred silently.** `energy_source` says whether
   `tx_energy_mj` was measured (inline/external instrument), estimated from an
   airtime model, or not measured at all (then `tx_energy_mj` must be empty).
   Estimated and measured energy must never be pooled in an analysis.

3. **Boot identity.** An ESP32 reboot resets `packet_seq` and `device_millis`.
   `boot_id` makes a reboot detectable instead of looking like corrupt data. A
   *missing row* (log loss) is a different thing from a *failed packet* (a row
   with `packet_success = 0`); sequence gaps are therefore reported, never
   interpreted as failures.

ENVIRONMENT / CHANNEL-CONDITION INFORMATION is per-session or per-context, not
per-row: it lives in the session manifest (ml/collection/manifest.py), keyed
by `context_id`. It is METADATA. It is never an ML feature —
`assert_no_metadata_features()` enforces that, because the CP04 dataset module
(frozen) only bans some columns by name.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple, Type

from ml.preprocessing.schema import RAW_SCHEMA

INF = float("inf")

# --- enumerations ----------------------------------------------------------
DATA_ORIGIN_REAL = "real_hardware"
DATA_ORIGIN_SYNTHETIC = "synthetic_test"
DATA_ORIGINS = (DATA_ORIGIN_REAL, DATA_ORIGIN_SYNTHETIC)

MODE_SWEEP, MODE_BASELINE, MODE_EDGE_AI = "sweep", "baseline", "edge_ai"
EXPERIMENT_MODES = (MODE_SWEEP, MODE_BASELINE, MODE_EDGE_AI)
#: Only a configuration sweep can be labelled (CP03 needs several configurations
#: measured under comparable conditions). baseline / edge_ai sessions are
#: EVALUATION-ONLY: training on a policy's own decisions is behavioural cloning.
TRAINING_ELIGIBLE_MODES = (MODE_SWEEP,)
EVALUATION_ONLY_MODES = (MODE_BASELINE, MODE_EDGE_AI)

LINK_SOURCES = ("gateway_uplink", "ack_downlink", "none")
TIMESTAMP_SOURCES = ("device_rtc", "host_receipt", "gateway", "other")
ENERGY_SOURCES = ("not_measured", "measured_inline", "measured_external",
                  "estimated_from_airtime_model")
ENERGY_MEASURED_SOURCES = ("measured_inline", "measured_external")

#: Substrings that mark a file as synthetic whatever its `data_origin` claims.
SYNTHETIC_SIGNATURES = ("synthetic", "fixture", "simulated", "mock", "fabricated")


@dataclass(frozen=True)
class RealField:
    name: str
    dtype: Type
    required: bool            # the COLUMN must exist in the CSV
    nullable: bool            # an individual value may be empty
    group: str
    description: str
    valid_range: Optional[Tuple[float, float]] = None
    allowed_values: Optional[Tuple] = None


def _f(name, dtype, required, nullable, group, description, rng=None, allowed=None):
    return RealField(name, dtype, required, nullable, group, description, rng, allowed)


REAL_SCHEMA: List[RealField] = [
    # ---- provenance -------------------------------------------------------
    _f("data_origin", str, True, False, "provenance",
       "'real_hardware' for rows logged from physical hardware; "
       "'synthetic_test' for software-test rows. Never mixed in one file; "
       "real-data mode rejects 'synthetic_test'.", allowed=DATA_ORIGINS),
    _f("session_id", str, True, False, "provenance",
       "One continuous run. Matches the manifest's session_id."),
    _f("device_id", str, True, False, "provenance",
       "Physical end device that logged the row."),
    _f("experiment_mode", str, True, False, "provenance",
       "'sweep' (configuration sweep for labelling/training), 'baseline' or "
       "'edge_ai' (evaluation arms).", allowed=EXPERIMENT_MODES),
    _f("scenario_id", str, True, False, "provenance",
       "Controlled scenario this row belongs to. Identical across baseline and "
       "edge_ai arms so they are compared under the same conditions."),
    _f("context_id", str, False, True, "provenance",
       "Identifier of a block of constant channel conditions (e.g. a fixed "
       "position). Required (non-empty) in sweep mode. This is the column "
       "`LabelingConfig(context_strategy='explicit_column')` reads. Described "
       "per-context in the manifest."),
    # ---- sequence / timing -------------------------------------------------
    _f("boot_id", int, True, False, "sequence",
       "Increments on every device boot (persist in NVS). A reboot resets "
       "packet_seq and device_millis; boot_id keeps that visible.", rng=(0, INF)),
    _f("packet_seq", int, True, False, "sequence",
       "Strictly increasing within (device_id, session_id, boot_id).", rng=(0, INF)),
    _f("device_millis", int, True, False, "sequence",
       "Device monotonic clock (ms since boot) at the START of the first attempt. "
       "Always available, unlike wall-clock time.", rng=(0, INF)),
    _f("timestamp_utc", str, True, False, "sequence",
       "ISO 8601 UTC, e.g. 2026-09-19T05:30:12.345Z. May be host-stamped."),
    _f("timestamp_source", str, True, False, "sequence",
       "Who produced timestamp_utc. An ESP32 without an RTC/NTP cannot be "
       "trusted for absolute time; say which clock this is.",
       allowed=TIMESTAMP_SOURCES),
    # ---- radio configuration actually used --------------------------------
    _f("sf", int, True, False, "radio",
       "Spreading factor used for this packet (same range as CP02).", rng=(7, 12)),
    _f("tp_dbm", float, True, False, "radio",
       "Transmit power setting in dBm (CP02 sanity range; the ACTUAL allowed "
       "set comes from the manifest, never from this range).", rng=(-4, 22)),
    _f("bandwidth_hz", float, True, False, "radio",
       "Channel bandwidth used. Needed for airtime; never assumed.", rng=(1.0, 1e7)),
    _f("coding_rate_denominator", int, True, False, "radio",
       "5, 6, 7 or 8 for coding rate 4/5 ... 4/8.", allowed=(5, 6, 7, 8)),
    _f("channel_freq_hz", float, True, False, "radio",
       "Carrier frequency used (optional in CP02, required here so a mid-run "
       "frequency change cannot go unnoticed). Compared with the manifest; no "
       "band is assumed.", rng=(0, INF)),
    _f("payload_bytes", int, True, False, "radio",
       "Payload size (optional in CP02, required here: airtime/energy need it).",
       rng=(0, 256)),
    # ---- link measurement --------------------------------------------------
    _f("rssi_dbm", float, True, True, "link",
       "RSSI associated with this packet. EMPTY when none exists (e.g. lost "
       "packet, no ACK) - see link_measurement_source.", rng=(-150, 0)),
    _f("snr_db", float, True, True, "link",
       "SNR associated with this packet. EMPTY when none exists.", rng=(-30, 20)),
    _f("link_measurement_source", str, True, False, "link",
       "Where rssi/snr came from: gateway_uplink (receiver measured the uplink), "
       "ack_downlink (sender measured the ACK), none (both columns empty).",
       allowed=LINK_SOURCES),
    # ---- outcome -------------------------------------------------------------
    _f("retry_count", int, True, False, "outcome",
       "Retransmissions of this packet (CP02 definition).", rng=(0, 255)),
    _f("attempts", int, True, False, "outcome",
       "Total transmissions of this packet. Must equal retry_count + 1 (a "
       "redundancy that catches logging bugs).", rng=(1, 256)),
    _f("packet_success", int, True, False, "outcome",
       "1 if acknowledged at the SENDER (what a deployed device can know), else 0.",
       allowed=(0, 1)),
    _f("rx_confirmed", int, False, True, "outcome",
       "Receiver-side ground truth, when a receiver log exists: 1 received, 0 "
       "not received, empty unknown. Acked-but-not-received (0 with "
       "packet_success=1) is impossible and rejected.", allowed=(0, 1)),
    # ---- latency / airtime --------------------------------------------------
    _f("ack_rx_millis", int, False, True, "latency",
       "device_millis when the ACK arrived. Empty for failed packets.", rng=(0, INF)),
    _f("latency_ms", float, False, True, "latency",
       "ack_rx_millis - device_millis (first attempt start to ACK). Empty unless "
       "the packet was acknowledged.", rng=(0, INF)),
    _f("airtime_ms", float, False, True, "latency",
       "Per-attempt time on air, if the firmware reports it; otherwise empty "
       "(ml.labeling.airtime can compute it from the radio parameters).",
       rng=(0, INF)),
    # ---- energy -------------------------------------------------------------
    _f("tx_energy_mj", float, False, True, "energy",
       "Energy for this packet (all attempts) in millijoules. EMPTY iff "
       "energy_source = not_measured.", rng=(0, INF)),
    _f("energy_source", str, True, False, "energy",
       "not_measured | measured_inline | measured_external | "
       "estimated_from_airtime_model. Estimated values are NOT measurements.",
       allowed=ENERGY_SOURCES),
    _f("energy_window_ms", float, False, True, "energy",
       "Length of the measurement window the energy covers.", rng=(0, INF)),
    # ---- notes --------------------------------------------------------------
    _f("notes", str, False, True, "notes", "Free text."),
]

REAL_REQUIRED_COLUMNS = [f.name for f in REAL_SCHEMA if f.required]
REAL_ALL_COLUMNS = [f.name for f in REAL_SCHEMA]
REAL_FIELD_BY_NAME: Dict[str, RealField] = {f.name: f for f in REAL_SCHEMA}

#: The CP02 raw columns, in CP02 order — what the adapter must emit.
CP02_RAW_COLUMNS = [f.name for f in RAW_SCHEMA]

#: Measurement categories the project needs, mapped to the columns that carry
#: them. A test asserts every category is covered by at least one column.
REQUIRED_MEASUREMENT_CATEGORIES: Dict[str, List[str]] = {
    "RSSI": ["rssi_dbm"],
    "SNR": ["snr_db"],
    "packet success/failure": ["packet_success"],
    "retry count": ["retry_count", "attempts"],
    "spreading factor": ["sf"],
    "transmit power": ["tp_dbm"],
    "timestamp / sequence": ["timestamp_utc", "device_millis", "packet_seq", "boot_id"],
    "energy (where supported)": ["tx_energy_mj", "energy_source"],
    "latency": ["latency_ms", "ack_rx_millis"],
    "radio configuration": ["bandwidth_hz", "coding_rate_denominator",
                            "channel_freq_hz", "payload_bytes"],
    "channel-condition identity": ["scenario_id", "context_id"],
}


def cp02_compatibility_problems() -> List[str]:
    """Empty list iff REAL_SCHEMA is a superset of RAW_SCHEMA with identical
    dtype / sanity range / allowed values for every shared column."""
    problems: List[str] = []
    for old in RAW_SCHEMA:
        new = REAL_FIELD_BY_NAME.get(old.name)
        if new is None:
            problems.append(f"CP02 column {old.name!r} is missing from REAL_SCHEMA")
            continue
        if new.dtype is not old.dtype:
            problems.append(f"{old.name}: dtype {new.dtype.__name__} != CP02 {old.dtype.__name__}")
        if new.valid_range != old.valid_range:
            problems.append(f"{old.name}: range {new.valid_range} != CP02 {old.valid_range}")
        if new.allowed_values != old.allowed_values:
            problems.append(f"{old.name}: allowed {new.allowed_values} != CP02 {old.allowed_values}")
        if old.required and not new.required:
            problems.append(f"{old.name}: required in CP02 but not here")
    return problems


_CAUSAL_FEATURE = re.compile(r"^rolling_(success_rate|retry_avg|rssi_avg|snr_avg)_w\d+$")
#: Raw columns CP04 may expose as "current link" features (off by default).
_ALLOWED_RAW_FEATURES = ("rssi_dbm", "snr_db")


class MetadataFeatureError(ValueError):
    """A non-feature column was requested as a model input."""


def assert_no_metadata_features(feature_columns: Sequence[str]) -> None:
    """Allow only the CP02 causal rolling-history features (and, optionally,
    current rssi/snr). Everything else — scenario/context/condition/distance/
    environment/energy/latency/timing/provenance columns, GPS, location — is
    metadata, not an input. Needed because ml.training.dataset (frozen since
    CP04) bans only some columns by name."""
    bad = [c for c in feature_columns
           if not (_CAUSAL_FEATURE.match(c) or c in _ALLOWED_RAW_FEATURES)]
    if bad:
        raise MetadataFeatureError(
            f"Not allowed as ML features (metadata or non-causal): {bad}. "
            "Features must be the CP02 causal rolling-history columns "
            "(RSSI, SNR, packet success history, retry count)."
        )


def render_schema_markdown() -> str:
    lines = [
        "# Real-Data Schema (Checkpoint 8)",
        "",
        "> **Generated from `ml/collection/real_schema.py` — do not edit by hand.**",
        "> A test fails if this file drifts from the code.",
        "",
        "> **NO REAL DATA EXISTS YET.** This is the contract real ESP32 + LoRa logs "
        "must follow. Nothing here is a measurement.",
        "",
        "One row = one logical packet (retries summarised in the row). "
        "`REAL_SCHEMA` is a strict superset of the CP02 raw schema.",
        "",
    ]
    groups: List[str] = []
    for f in REAL_SCHEMA:
        if f.group not in groups:
            groups.append(f.group)
    for g in groups:
        lines += [f"## {g}", "", "| column | type | required | nullable | constraint | meaning |",
                  "|---|---|---|---|---|---|"]
        for f in REAL_SCHEMA:
            if f.group != g:
                continue
            if f.allowed_values is not None:
                cons = "one of " + ", ".join(str(v) for v in f.allowed_values)
            elif f.valid_range is not None:
                lo, hi = f.valid_range
                cons = f"{lo:g} to {'inf' if hi == INF else format(hi, 'g')}"
            else:
                cons = "-"
            lines.append(f"| `{f.name}` | {f.dtype.__name__} | {'yes' if f.required else 'no'} | "
                         f"{'yes' if f.nullable else 'no'} | {cons} | {f.description} |")
        lines.append("")
    lines += ["## Measurement coverage", "", "| needed measurement | column(s) |", "|---|---|"]
    for cat, cols in REQUIRED_MEASUREMENT_CATEGORIES.items():
        lines.append(f"| {cat} | " + ", ".join(f"`{c}`" for c in cols) + " |")
    lines += ["", "Environmental / channel-condition information (environment type, line of "
              "sight, mobility, approximate distance, temperature, interference notes) is "
              "recorded per `context_id` in the session manifest as **metadata** — never as "
              "an ML feature.", ""]
    return "\n".join(lines)
