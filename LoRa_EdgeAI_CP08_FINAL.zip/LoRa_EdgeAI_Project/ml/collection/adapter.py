"""
adapter.py

Checkpoint 8 — Converts a VALIDATED real-schema log into the CP02 raw-schema CSV
that the existing, unmodified pipeline (preprocessing -> labeling -> training ->
comparison) accepts. This is what makes the pipeline "ready to accept real data":
nothing downstream changes.

It makes three decisions that must never be made silently.

1. PURPOSE separates training from evaluation.
   `purpose="training"` accepts only `sweep` sessions: labeling needs several
   configurations measured under comparable conditions. `purpose="evaluation"`
   accepts only `baseline` / `edge_ai`. A model trained on its own policy's
   decisions would just learn that policy (behavioural cloning), so those
   sessions are structurally kept out of training. Mixed files are refused.

2. MISSING LINK MEASUREMENTS need an EXPLICIT policy (no default).
   The CP02 cleaner drops every row with an empty RSSI/SNR. Real failed packets
   usually have none, so converting naively would delete the failures and leave
   success history ~1.0 (survivorship bias). The caller must choose:
     carry_forward   fill from the last MEASURED value in the same device/session/
                     boot, if at most `max_carry_forward_packets` packets old (what
                     a deployed device would actually know); older/absent -> dropped
     drop            diagnostic only; requires `acknowledge_survivorship_bias=True`
   Everything filled or dropped is counted per outcome in the report, and each
   filled row says so in `notes`.
   Last line of defence: if the input had failed packets and the output has none,
   the conversion is REFUSED.

3. REBOOTS split sessions. `session_id` becomes `<session_id>__b<boot_id>`, because
   a rebooted device really does lose its history, and CP02's rolling features
   must not span the reset.

Provenance rides along: every output row's `notes` starts with
`origin=<data_origin>;mode=<mode>`, so synthetic test data stays identifiable.
By default `require_real=True`: synthetic data is refused.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, Optional

import pandas as pd

from ml.collection.manifest import SessionManifest
from ml.collection.real_schema import (
    CP02_RAW_COLUMNS, EVALUATION_ONLY_MODES, TRAINING_ELIGIBLE_MODES,
)
from ml.collection.validator import validate_real_csv

PURPOSES = ("training", "evaluation")
MISSING_LINK_POLICIES = ("carry_forward", "drop")


class AdapterError(ValueError):
    """The conversion was refused; the message says why."""


def _sha256(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def to_cp02_raw(real_csv, out_csv, purpose: str, missing_link_policy: str,
                max_carry_forward_packets: Optional[int] = None,
                acknowledge_survivorship_bias: bool = False,
                manifest: Optional[SessionManifest] = None,
                require_real: bool = True, strict: bool = False) -> Dict:
    """Validate, then convert. Returns the report (also written beside the
    output as `<out>.adapter_report.json`). Raises AdapterError on any refusal;
    on refusal NO output file is written."""
    if purpose not in PURPOSES:
        raise AdapterError(f"purpose must be one of {PURPOSES}")
    if missing_link_policy not in MISSING_LINK_POLICIES:
        raise AdapterError(f"missing_link_policy must be one of {MISSING_LINK_POLICIES} "
                           "(there is deliberately no default)")
    if missing_link_policy == "carry_forward":
        if not isinstance(max_carry_forward_packets, int) or max_carry_forward_packets < 1:
            raise AdapterError("carry_forward needs max_carry_forward_packets >= 1: how stale "
                               "a link measurement may be is a decision, not a default")
    elif not acknowledge_survivorship_bias:
        raise AdapterError("the 'drop' policy deletes rows without RSSI/SNR, which are mostly the "
                           "failed packets; pass acknowledge_survivorship_bias=True to use it "
                           "(diagnostics only)")

    v = validate_real_csv(real_csv, manifest=manifest, strict=strict, require_real=require_real)
    if not v.ok:
        raise AdapterError("input failed validation:\n  " + "\n  ".join(v.errors[:10]))

    df = pd.read_csv(real_csv, dtype=str, keep_default_na=False)
    modes = sorted(set(df["experiment_mode"]))
    allowed = TRAINING_ELIGIBLE_MODES if purpose == "training" else EVALUATION_ONLY_MODES
    wrong = [m for m in modes if m not in allowed]
    if wrong:
        raise AdapterError(
            f"purpose={purpose!r} accepts only {list(allowed)} sessions but the file contains {wrong}. "
            + ("Policy-driven sessions are never training data: the model would learn the policy's own "
               "decisions." if purpose == "training" else
               "Sweep sessions are training data, not evaluation arms."))

    num = {c: pd.to_numeric(df[c].replace("", pd.NA), errors="coerce")
           for c in ("boot_id", "packet_seq", "rssi_dbm", "snr_db", "packet_success")}
    df["_boot"], df["_seq"] = num["boot_id"], num["packet_seq"]
    df["_rssi"], df["_snr"], df["_ok"] = num["rssi_dbm"], num["snr_db"], num["packet_success"]
    df = df.sort_values(["device_id", "session_id", "_boot", "_seq"], kind="mergesort").reset_index(drop=True)

    in_fail = int((df["_ok"] == 0).sum())
    keep, notes_extra = [], []
    filled = {"success": 0, "failure": 0}
    dropped: Dict[str, Dict[str, int]] = {}
    new_rssi, new_snr = list(df["_rssi"]), list(df["_snr"])

    def drop(reason, outcome):
        dropped.setdefault(reason, {"success": 0, "failure": 0})[outcome] += 1

    for (_, _, _), g in df.groupby(["device_id", "session_id", "_boot"], sort=False):
        last_val, last_pos = None, None
        for pos, i in enumerate(g.index):
            outcome = "success" if df.at[i, "_ok"] == 1 else "failure"
            if pd.notna(df.at[i, "_rssi"]) and pd.notna(df.at[i, "_snr"]):
                last_val, last_pos = (df.at[i, "_rssi"], df.at[i, "_snr"]), pos
                keep.append(i); notes_extra.append("")
                continue
            if missing_link_policy == "drop":
                drop("no_link_measurement", outcome)
            elif last_val is None:
                drop("no_prior_measurement", outcome)
            elif pos - last_pos > max_carry_forward_packets:
                drop("measurement_too_stale", outcome)
            else:
                new_rssi[i], new_snr[i] = last_val
                filled[outcome] += 1
                keep.append(i); notes_extra.append(f";link=carried({pos - last_pos})")

    out = df.loc[keep].copy()
    out["_rssi"] = [new_rssi[i] for i in keep]
    out["_snr"] = [new_snr[i] for i in keep]
    out_fail = int((out["_ok"] == 0).sum())
    if in_fail > 0 and out_fail == 0:
        raise AdapterError("refusing: the input contains failed packets but the converted output "
                           "contains none (survivorship bias). Use carry_forward with a larger "
                           "max_carry_forward_packets, or fix the logging so failures keep a measurement.")

    prov = ("origin=" + out["data_origin"] + ";mode=" + out["experiment_mode"]).tolist()
    notes = [f"{p}{x};{n}" if n else f"{p}{x}"
             for p, x, n in zip(prov, notes_extra, out["notes"].astype(str).str.replace(";", ",").tolist())]
    cp02 = pd.DataFrame({
        "timestamp_utc": out["timestamp_utc"],
        "session_id": out["session_id"] + "__b" + out["_boot"].astype(int).astype(str),
        "device_id": out["device_id"],
        "packet_seq": out["_seq"].astype(int),
        "sf": pd.to_numeric(out["sf"]).astype(int),
        "tp_dbm": pd.to_numeric(out["tp_dbm"]),
        "rssi_dbm": out["_rssi"], "snr_db": out["_snr"],
        "retry_count": pd.to_numeric(out["retry_count"]).astype(int),
        "packet_success": out["_ok"].astype(int),
        "payload_bytes": pd.to_numeric(out["payload_bytes"]).astype(int),
        "channel_freq_hz": pd.to_numeric(out["channel_freq_hz"]),
        "notes": notes,
    })[CP02_RAW_COLUMNS]
    if purpose == "training" and "context_id" in out.columns:
        cp02["context_id"] = out["context_id"].values   # for LabelingConfig(context_strategy="explicit_column")

    Path(out_csv).parent.mkdir(parents=True, exist_ok=True)
    cp02.to_csv(out_csv, index=False)

    n_drop = sum(sum(v.values()) for v in dropped.values())
    dropped_fail = sum(v["failure"] for v in dropped.values())
    report = {
        "source_file": str(real_csv), "source_sha256": _sha256(real_csv),
        "output_file": str(out_csv), "purpose": purpose, "modes": modes,
        "origins": sorted(set(df["data_origin"])), "missing_link_policy": missing_link_policy,
        "max_carry_forward_packets": max_carry_forward_packets,
        "rows_in": int(len(df)), "rows_out": int(len(cp02)), "rows_dropped": n_drop,
        "failed_rows_in": in_fail, "failed_rows_out": out_fail,
        "link_measurement_filled_by_outcome": filled,
        "dropped_by_reason_and_outcome": dropped,
        "sessions_out": sorted(set(cp02["session_id"])),
        "survivorship_warning": (
            f"{dropped_fail} FAILED packet(s) were dropped for lack of an RSSI/SNR value; the converted "
            "data under-represents failures." if dropped_fail else None),
        "note": "Conversion statistics only. Not an evaluation of any policy.",
    }
    with open(str(out_csv) + ".adapter_report.json", "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
        fh.write("\n")
    return report
