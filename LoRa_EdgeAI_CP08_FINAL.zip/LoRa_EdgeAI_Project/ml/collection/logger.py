"""
logger.py

Checkpoint 8 — The host-side DATA-LOGGING pipeline: parses the ESP32's serial log
lines and writes validated rows to a real-schema CSV, beside a copy of the
session manifest. No firmware exists yet (esp32/ is empty); this module and
experiments/FIRMWARE_LOGGING_SPEC.md define the CONTRACT it must meet.

*** The logger never invents a value. *** A row exists only if a well-formed,
checksummed line arrived and passed validation. Anything else is rejected, with
the reason, into `<out>.rejects.log` — never silently dropped, never repaired.

SERIAL LINE PROTOCOL (version 1)
    LORALOG1,<f1>,...,<f22>*<HH>      one record = one logical packet
    LORACTX1,<context_id>*<HH>        switch the current channel-condition block
    anything else                     ignored (firmware debug output is allowed)
`HH` is the two-digit hex XOR of every character before the `*` (NMEA style): a
serial byte error makes a line fail the checksum and be rejected rather than
become a wrong measurement. An empty field means "no value".
The 22 device fields, in order, are `LOG_LINE_FIELDS`. Everything else in the
schema is known to the host: data_origin/session/device/mode/scenario come from the
manifest, context_id from the latest LORACTX1 marker (or `initial_context_id`),
timestamp_utc from the host clock at receipt (`timestamp_source=host_receipt` —
an ESP32 without an RTC cannot be trusted for absolute time).

SAFETY RAILS
  * refuses to start unless the manifest is STRICTLY valid (no UNSET) — you cannot
    collect with an unknown radio configuration;
  * `require_real=True` by default; synthetic_test manifests need an explicit opt-in;
  * refuses to write into an existing non-empty CSV unless `resume=True`, so one
    session can never be silently merged with another;
  * a sweep row with no current context is rejected, not guessed.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Tuple

import pandas as pd

from ml.collection.manifest import SessionManifest
from ml.collection.real_schema import MODE_SWEEP, REAL_ALL_COLUMNS
from ml.collection.validator import check_manifest, validate_row

LOG_PREFIX = "LORALOG1"
CTX_PREFIX = "LORACTX1"
LOG_LINE_FIELDS = [
    "boot_id", "packet_seq", "device_millis", "sf", "tp_dbm", "bandwidth_hz",
    "coding_rate_denominator", "channel_freq_hz", "payload_bytes", "rssi_dbm", "snr_db",
    "link_measurement_source", "retry_count", "attempts", "packet_success", "rx_confirmed",
    "ack_rx_millis", "latency_ms", "airtime_ms", "tx_energy_mj", "energy_source",
    "energy_window_ms",
]


class LogParseError(ValueError):
    """A protocol line was malformed or failed its checksum."""


class LoggerError(RuntimeError):
    """The logger refused to start."""


def checksum(text: str) -> str:
    x = 0
    for ch in text.encode("utf-8"):
        x ^= ch
    return f"{x:02X}"


def make_log_line(record: Dict[str, object]) -> str:
    """Reference encoder (what the firmware must emit). Missing keys -> empty."""
    body = LOG_PREFIX + "," + ",".join("" if record.get(k) is None else str(record.get(k, ""))
                                       for k in LOG_LINE_FIELDS)
    return f"{body}*{checksum(body)}"


def make_context_line(context_id: str) -> str:
    body = f"{CTX_PREFIX},{context_id}"
    return f"{body}*{checksum(body)}"


def parse_line(line: str) -> Optional[Tuple[str, object]]:
    """Return ("record", dict) / ("context", str) / None for an ignorable line.
    Raises LogParseError for a protocol line that is malformed or corrupt."""
    line = line.strip()
    if not (line.startswith(LOG_PREFIX + ",") or line.startswith(CTX_PREFIX + ",")):
        return None
    if "*" not in line:
        raise LogParseError("no checksum")
    body, _, given = line.rpartition("*")
    if checksum(body).upper() != given.strip().upper():
        raise LogParseError(f"checksum mismatch (expected {checksum(body)}, got {given.strip()})")
    parts = body.split(",")
    if parts[0] == CTX_PREFIX:
        if len(parts) != 2 or not parts[1]:
            raise LogParseError("context marker must carry exactly one non-empty context_id")
        return "context", parts[1]
    values = parts[1:]
    if len(values) != len(LOG_LINE_FIELDS):
        raise LogParseError(f"expected {len(LOG_LINE_FIELDS)} fields, got {len(values)}")
    return "record", dict(zip(LOG_LINE_FIELDS, values))


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


class SessionLogger:
    def __init__(self, manifest: SessionManifest, out_csv, clock: Callable[[], str] = _now,
                 require_real: bool = True, resume: bool = False,
                 initial_context_id: Optional[str] = None):
        probs = manifest.problems(strict=True, allow_synthetic_test=not require_real)
        if probs:
            raise LoggerError("manifest is not ready for collection:\n  " + "\n  ".join(probs[:10]))
        self.m, self.clock, self.require_real = manifest, clock, require_real
        self.out = Path(out_csv)
        if self.out.exists() and self.out.stat().st_size > 0 and not resume:
            raise LoggerError(f"{self.out} already exists and is not empty; refusing to mix sessions "
                              "(use resume=True only to continue the SAME session)")
        self.out.parent.mkdir(parents=True, exist_ok=True)
        new_file = not self.out.exists() or self.out.stat().st_size == 0
        self._fh = open(self.out, "a", newline="", encoding="utf-8")
        self._w = csv.DictWriter(self._fh, fieldnames=REAL_ALL_COLUMNS)
        if new_file:
            self._w.writeheader()
        manifest.to_json_file(str(self.out) + ".manifest.json")
        self.context = initial_context_id or ""
        self.counts = {"lines": 0, "rows_written": 0, "context_markers": 0,
                       "ignored_lines": 0, "rejected_lines": 0, "sequence_numbers_missing": 0}
        self.reject_reasons: Dict[str, int] = {}
        self._last: Dict[int, Tuple[int, int]] = {}      # boot_id -> (seq, device_millis)

    def _reject(self, line: str, reason: str) -> str:
        self.counts["rejected_lines"] += 1
        key = reason.split(" (")[0][:80]
        self.reject_reasons[key] = self.reject_reasons.get(key, 0) + 1
        with open(str(self.out) + ".rejects.log", "a", encoding="utf-8") as fh:
            fh.write(f"{reason}\t{line.rstrip()}\n")
        return "rejected"

    def ingest_line(self, line: str) -> str:
        self.counts["lines"] += 1
        try:
            parsed = parse_line(line)
        except LogParseError as e:
            return self._reject(line, f"parse error: {e}")
        if parsed is None:
            self.counts["ignored_lines"] += 1
            return "ignored"
        kind, payload = parsed
        if kind == "context":
            self.context = payload
            self.counts["context_markers"] += 1
            return "context"
        row = {c: "" for c in REAL_ALL_COLUMNS}
        row.update(payload)
        row.update({"data_origin": self.m.data_origin, "session_id": self.m.session_id,
                    "device_id": self.m.device_id, "experiment_mode": self.m.experiment_mode,
                    "scenario_id": self.m.scenario_id, "context_id": self.context,
                    "timestamp_utc": self.clock(), "timestamp_source": "host_receipt", "notes": ""})
        if self.m.experiment_mode == MODE_SWEEP and not self.context:
            return self._reject(line, "sweep row but no context set (send a LORACTX1 marker first)")
        errs = validate_row(row, require_real=self.require_real)
        if not errs:
            frame = pd.DataFrame([{k: str(v) for k, v in row.items()}])
            errs = [e for e in check_manifest(frame, self.m, True, self.require_real)
                    if not e.startswith("manifest:")]
        if errs:
            return self._reject(line, "invalid row: " + "; ".join(errs)[:200])
        boot, seq, ms = int(float(row["boot_id"])), int(float(row["packet_seq"])), int(float(row["device_millis"]))
        if boot in self._last:
            pseq, pms = self._last[boot]
            if seq <= pseq:
                return self._reject(line, f"packet_seq {seq} not greater than previous {pseq} in boot {boot}")
            if ms < pms:
                return self._reject(line, f"device_millis {ms} went backwards from {pms} in boot {boot}")
            if seq > pseq + 1:
                self.counts["sequence_numbers_missing"] += seq - pseq - 1
        self._last[boot] = (seq, ms)
        self._w.writerow(row)
        self._fh.flush()
        self.counts["rows_written"] += 1
        return "row"

    def ingest(self, lines: Iterable[str]) -> Dict:
        for ln in lines:
            self.ingest_line(ln)
        return self.counts

    def close(self) -> Dict:
        self._fh.close()
        summary = {
            "NOTE": "log statistics; not an evaluation of anything",
            "output_csv": str(self.out), "session_id": self.m.session_id,
            "data_origin": self.m.data_origin, "counts": self.counts,
            "reject_reasons": self.reject_reasons,
            "manifest_sha256": hashlib.sha256(
                json.dumps(self.m.to_dict(), sort_keys=True).encode()).hexdigest(),
        }
        with open(str(self.out) + ".session_summary.json", "w", encoding="utf-8") as fh:
            json.dump(summary, fh, indent=2)
            fh.write("\n")
        return summary

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if not self._fh.closed:
            self.close()


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Log ESP32 serial lines (LORALOG1) to a validated real-schema CSV.")
    p.add_argument("--manifest", required=True, help="Filled-in session manifest JSON (strictly valid).")
    p.add_argument("--out", required=True, help="Output CSV, e.g. data/raw/<session_id>.csv")
    p.add_argument("--input", default="-", help="File of captured serial lines, or - for stdin.")
    p.add_argument("--initial-context-id", default=None)
    p.add_argument("--allow-synthetic-test", action="store_true",
                   help="SOFTWARE TESTING ONLY: accept a synthetic_test manifest.")
    a = p.parse_args(argv)
    try:
        m = SessionManifest.from_json_file(a.manifest)
        lg = SessionLogger(m, a.out, require_real=not a.allow_synthetic_test,
                           initial_context_id=a.initial_context_id)
    except (LoggerError, ValueError, OSError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    src = sys.stdin if a.input == "-" else open(a.input, "r", encoding="utf-8", errors="replace")
    try:
        lg.ingest(src)
    finally:
        summary = lg.close()
        if src is not sys.stdin:
            src.close()
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
