"""
manifest.py

Checkpoint 8 — Per-session manifest: the hardware, radio/regional configuration
and channel-condition description that accompanies every real-data CSV.

*** No region, frequency, bandwidth, power limit or duty cycle is assumed. ***
Every such field defaults to UNSET. In STRICT mode (required before a real
collection) any UNSET is a problem. Nothing here encodes EU868 or any other
band plan; the project's planned radio is an SX1278 (433 MHz, per
experiments/DATA_COLLECTION_PLAN.md) but even that is not enforced — the
values that count are the ones written here from the REAL configuration.

Why a manifest and not extra CSV columns: these facts are constant per
session; repeating them on every row bloats the log and invites typos. The
validator cross-checks every row against the manifest instead, so a mid-run
change (frequency, SF outside the declared set, wrong session) is caught.

Channel-condition information (`conditions`, keyed by `context_id`) is METADATA.
It is never an ML feature (see real_schema.assert_no_metadata_features).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Union

from ml.collection._util import UNSET, build, find_unset, to_plain
from ml.collection.real_schema import DATA_ORIGINS, DATA_ORIGIN_REAL, EXPERIMENT_MODES

LINE_OF_SIGHT = ("los", "nlos", "unknown")
MOBILITY = ("static", "pedestrian", "vehicle", "other", "unknown")


@dataclass
class RadioConfig:
    """The radio configuration ACTUALLY used. Every field is UNSET until the
    real hardware/regional configuration is known and written down."""
    region_profile: str = UNSET            # free text naming the real regional plan
    frequency_hz: Union[float, str] = UNSET
    bandwidth_hz: Union[float, str] = UNSET
    coding_rate_denominator: Union[int, str] = UNSET     # 5..8
    preamble_symbols: Union[int, str] = UNSET
    sync_word: Union[int, str] = UNSET
    crc_enabled: Union[bool, str] = UNSET
    explicit_header: Union[bool, str] = UNSET
    tx_power_min_dbm: Union[float, str] = UNSET
    tx_power_max_dbm: Union[float, str] = UNSET
    allowed_sf: Union[List[int], str] = UNSET
    allowed_tp_dbm: Union[List[float], str] = UNSET
    #: Fraction of time on air allowed. null means "no limit applies" and then
    #: `duty_cycle_basis` must say why. UNSET means nobody has looked yet.
    duty_cycle_fraction: Union[float, None, str] = UNSET
    duty_cycle_basis: str = UNSET
    regulatory_confirmation: str = UNSET   # who/what confirmed this is legal here


@dataclass
class HardwareConfig:
    board: str = UNSET
    radio_module: str = UNSET
    firmware_version: str = UNSET
    receiver_description: str = UNSET
    antenna_description: str = UNSET
    #: How energy is measured, or the literal text "none" if it is not.
    energy_measurement_method: str = UNSET
    unit_identifiers: str = UNSET


@dataclass
class ConditionInfo:
    """Description of one block of constant channel conditions (a context_id).
    METADATA — never an ML feature."""
    description: str = UNSET
    environment_type: str = UNSET
    line_of_sight: str = UNSET
    mobility: str = UNSET
    approx_distance_m: Union[float, None, str] = UNSET
    temperature_c: Union[float, None, str] = None
    interference_note: str = ""


@dataclass
class SessionManifest:
    manifest_version: int = 1
    data_origin: str = UNSET
    session_id: str = UNSET
    device_id: str = UNSET
    experiment_mode: str = UNSET
    scenario_id: str = UNSET
    repetition: Union[int, str] = UNSET
    block_index: Union[int, str] = UNSET
    operator: str = UNSET
    start_utc: str = UNSET
    end_utc: str = ""
    radio: RadioConfig = field(default_factory=RadioConfig)
    hardware: HardwareConfig = field(default_factory=HardwareConfig)
    conditions: Dict[str, ConditionInfo] = field(default_factory=dict)
    notes: str = ""

    # -- serialisation ---------------------------------------------------
    def to_dict(self) -> dict:
        return to_plain(self)

    @classmethod
    def from_dict(cls, data: dict) -> "SessionManifest":
        return build(cls, data)

    @classmethod
    def from_json_file(cls, path) -> "SessionManifest":
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))

    def to_json_file(self, path) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2)
            fh.write("\n")

    # -- validation --------------------------------------------------------
    def unresolved(self) -> List[str]:
        return find_unset(self)

    def problems(self, strict: bool = False, allow_synthetic_test: bool = False) -> List[str]:
        """Structural problems always; in strict mode also every UNSET, and the
        data origin must be real_hardware (unless allow_synthetic_test)."""
        out = radio_problems(self.radio)
        if self.data_origin != UNSET and self.data_origin not in DATA_ORIGINS:
            out.append(f"data_origin {self.data_origin!r} not in {DATA_ORIGINS}")
        if self.experiment_mode != UNSET and self.experiment_mode not in EXPERIMENT_MODES:
            out.append(f"experiment_mode {self.experiment_mode!r} not in {EXPERIMENT_MODES}")
        for cid, c in self.conditions.items():
            if not cid:
                out.append("a condition has an empty context_id")
            if c.line_of_sight != UNSET and c.line_of_sight not in LINE_OF_SIGHT:
                out.append(f"conditions[{cid}].line_of_sight {c.line_of_sight!r} not in {LINE_OF_SIGHT}")
            if c.mobility != UNSET and c.mobility not in MOBILITY:
                out.append(f"conditions[{cid}].mobility {c.mobility!r} not in {MOBILITY}")
        if strict:
            for path in self.unresolved():
                out.append(f"UNSET: {path} — fill in from the real hardware/experiment; never guess")
            if self.experiment_mode == "sweep" and not self.conditions:
                out.append("sweep sessions must declare at least one condition (context_id)")
            if self.data_origin == DATA_ORIGIN_REAL or allow_synthetic_test:
                pass
            elif self.data_origin != UNSET:
                out.append(f"strict mode requires data_origin='real_hardware' (got {self.data_origin!r})")
        return out


def _is_num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def radio_problems(r: RadioConfig) -> List[str]:
    """Structural checks that apply to any value that HAS been set. Never
    compares against a regional plan: none is assumed."""
    out: List[str] = []
    for name in ("frequency_hz", "bandwidth_hz", "tx_power_min_dbm", "tx_power_max_dbm",
                 "preamble_symbols", "sync_word"):
        v = getattr(r, name)
        if v != UNSET and not _is_num(v):
            out.append(f"radio.{name} must be a number or UNSET (got {v!r})")
    for name in ("frequency_hz", "bandwidth_hz"):
        v = getattr(r, name)
        if _is_num(v) and v <= 0:
            out.append(f"radio.{name} must be positive")
    if r.coding_rate_denominator != UNSET and r.coding_rate_denominator not in (5, 6, 7, 8):
        out.append("radio.coding_rate_denominator must be 5, 6, 7 or 8")
    for name in ("crc_enabled", "explicit_header"):
        v = getattr(r, name)
        if v != UNSET and not isinstance(v, bool):
            out.append(f"radio.{name} must be true/false or UNSET")
    if r.allowed_sf != UNSET:
        if not (isinstance(r.allowed_sf, list) and r.allowed_sf
                and all(isinstance(s, int) and 5 <= s <= 12 for s in r.allowed_sf)):
            out.append("radio.allowed_sf must be a non-empty list of integers 5..12")
    if r.allowed_tp_dbm != UNSET:
        if not (isinstance(r.allowed_tp_dbm, list) and r.allowed_tp_dbm
                and all(_is_num(t) for t in r.allowed_tp_dbm)):
            out.append("radio.allowed_tp_dbm must be a non-empty list of numbers")
        elif _is_num(r.tx_power_min_dbm) and _is_num(r.tx_power_max_dbm):
            bad = [t for t in r.allowed_tp_dbm
                   if not r.tx_power_min_dbm <= t <= r.tx_power_max_dbm]
            if bad:
                out.append(f"radio.allowed_tp_dbm {bad} outside the declared "
                           f"[{r.tx_power_min_dbm}, {r.tx_power_max_dbm}] dBm limits")
    if (_is_num(r.tx_power_min_dbm) and _is_num(r.tx_power_max_dbm)
            and r.tx_power_min_dbm > r.tx_power_max_dbm):
        out.append("radio.tx_power_min_dbm exceeds tx_power_max_dbm")
    d = r.duty_cycle_fraction
    if d not in (UNSET, None) and not (_is_num(d) and 0 < d <= 1):
        out.append("radio.duty_cycle_fraction must be in (0, 1], null (no limit) or UNSET")
    if d is None and r.duty_cycle_basis in (UNSET, ""):
        out.append("radio.duty_cycle_fraction is null (no limit) but duty_cycle_basis does not say why")
    return out


def to_labeling_radio_params(r: RadioConfig, payload_bytes: Optional[int] = None):
    """Convert to the CP03 `RadioParams` for airtime arithmetic. Refuses UNSET
    rather than falling back to CP03's defaults — those defaults are
    placeholders, not the real radio."""
    from ml.labeling.config import RadioParams

    needed = {"bandwidth_hz": r.bandwidth_hz,
              "coding_rate_denominator": r.coding_rate_denominator,
              "preamble_symbols": r.preamble_symbols,
              "explicit_header": r.explicit_header, "crc_enabled": r.crc_enabled}
    missing = [k for k, v in needed.items() if v == UNSET]
    if missing:
        raise ValueError(f"cannot compute airtime: radio field(s) {missing} are UNSET. "
                         "The CP03 defaults are placeholders and are deliberately not used.")
    kw = dict(needed)
    if payload_bytes is not None:
        kw["payload_bytes_default"] = int(payload_bytes)
    p = RadioParams(**kw)
    p.validate()
    return p
