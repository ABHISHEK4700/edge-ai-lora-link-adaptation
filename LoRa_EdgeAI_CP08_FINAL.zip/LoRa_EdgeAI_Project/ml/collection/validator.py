"""
validator.py

Checkpoint 8 — Validates a real-hardware log CSV against the real-data schema,
the session manifest, and a provenance gate. Nothing is dropped or repaired:
a problem is REPORTED, with the offending CSV line numbers.

*** The statistics it prints are DATA-QUALITY statistics, not results. ***
A packet-delivery fraction in `stats` describes the file being checked; it is
not an evaluation of any policy and must not be quoted as one.

WHAT IT CHECKS
  fields       required columns, types, nullability, ranges, allowed values
  consistency  attempts == retry_count + 1; link source 'none' <=> no RSSI/SNR;
               failed packets have no latency/ACK; latency matches the clocks;
               acked-but-not-received is impossible; energy_source vs value
  sequence     per (device, session, boot): packet_seq strictly increasing,
               device_millis non-decreasing, timestamps parse; sequence GAPS are
               reported as log loss (a missing row is not a failed packet)
  provenance   data_origin allowed and uniform; with require_real (the DEFAULT)
               'synthetic_test' is rejected AND synthetic signatures in ids/notes
               are rejected even if data_origin claims real
  manifest     every row against the manifest's frequency/bandwidth/coding rate,
               allowed SF/TP, session/device/mode/scenario; strict manifest checks
  sweep        per context: configurations seen, packets per configuration against
               the number the labeler's reliability threshold needs, and how
               blocked (rather than interleaved) the sweep was

Survivorship check: failures with no link measurement are counted; a file with
NO failed packets is flagged, because success-rate statistics from it would be
~1.0 for the wrong reason.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd

from ml.collection.manifest import SessionManifest
from ml.collection.planner import min_packets_for_reliability
from ml.collection.real_schema import (
    DATA_ORIGIN_REAL, MODE_SWEEP, REAL_FIELD_BY_NAME, REAL_REQUIRED_COLUMNS,
    REAL_SCHEMA, SYNTHETIC_SIGNATURES,
)

LATENCY_TOLERANCE_MS = 1.0     # rounding tolerance between the two clocks' difference and latency_ms
GAP_WARN_FRACTION = 0.0        # any sequence gap is reported; this is the fraction above which it is loud


@dataclass
class ValidationResult:
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    stats: Dict = field(default_factory=dict)
    sweep_coverage: Optional[Dict] = None

    @property
    def ok(self) -> bool:
        return not self.errors

    def summary(self) -> str:
        head = "VALID" if self.ok else f"INVALID ({len(self.errors)} error(s))"
        lines = [head] + [f"  ERROR: {e}" for e in self.errors] + [f"  warning: {w}" for w in self.warnings]
        return "\n".join(lines)


def _lines(df: pd.DataFrame, mask) -> str:
    idx = [int(i) + 2 for i in df.index[mask][:5]]          # +2: header row, 1-based
    more = "" if int(mask.sum()) <= 5 else ", ..."
    return "CSV line(s) " + ", ".join(map(str, idx)) + more


def _numeric(df: pd.DataFrame) -> pd.DataFrame:
    """Numeric view: empty string -> NaN; unparseable -> NaN (reported separately)."""
    n = pd.DataFrame(index=df.index)
    for f in REAL_SCHEMA:
        if f.name in df.columns and f.dtype in (int, float):
            n[f.name] = pd.to_numeric(df[f.name].replace("", pd.NA), errors="coerce")
    return n


def check_fields(df: pd.DataFrame) -> List[str]:
    """Column presence, nullability, type, range and allowed-value checks."""
    errs: List[str] = []
    missing = [c for c in REAL_REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        return [f"missing required column(s): {missing}"]
    num = _numeric(df)
    for f in REAL_SCHEMA:
        if f.name not in df.columns:
            continue
        raw = df[f.name]
        empty = raw.eq("") | raw.isna()
        if not f.nullable and f.required and empty.any():
            errs.append(f"column {f.name}: {int(empty.sum())} empty value(s) but not nullable ({_lines(df, empty)})")
        if f.dtype in (int, float):
            col = num[f.name]
            unparse = (~empty) & col.isna()
            if unparse.any():
                errs.append(f"column {f.name}: {int(unparse.sum())} non-numeric value(s) ({_lines(df, unparse)})")
            if f.dtype is int:
                frac = col.notna() & (col != col.round())
                if frac.any():
                    errs.append(f"column {f.name}: {int(frac.sum())} non-integer value(s) ({_lines(df, frac)})")
            if f.valid_range is not None:
                lo, hi = f.valid_range
                out = col.notna() & ((col < lo) | (col > hi))
                if out.any():
                    errs.append(f"column {f.name}: {int(out.sum())} value(s) outside [{lo}, {hi}] ({_lines(df, out)})")
            if f.allowed_values is not None:
                bad = col.notna() & ~col.isin(list(f.allowed_values))
                if bad.any():
                    errs.append(f"column {f.name}: {int(bad.sum())} value(s) not in {f.allowed_values} ({_lines(df, bad)})")
        elif f.allowed_values is not None:
            bad = (~empty) & ~raw.isin(list(f.allowed_values))
            if bad.any():
                errs.append(f"column {f.name}: {int(bad.sum())} value(s) not in {f.allowed_values} ({_lines(df, bad)})")
    return errs


def check_consistency(df: pd.DataFrame) -> List[str]:
    """Cross-field rules. Skipped silently if the fields they need are broken
    (those are already reported by check_fields)."""
    errs: List[str] = []
    n = _numeric(df)
    need = ["retry_count", "attempts", "packet_success", "rssi_dbm", "snr_db"]
    if any(c not in n.columns for c in need):
        return errs

    def rule(mask, msg):
        if mask.any():
            errs.append(f"{msg} ({int(mask.sum())} row(s); {_lines(df, mask)})")

    rule(n["attempts"].notna() & n["retry_count"].notna() & (n["attempts"] != n["retry_count"] + 1),
         "attempts must equal retry_count + 1")
    src = df.get("link_measurement_source", pd.Series("", index=df.index))
    has_link = n["rssi_dbm"].notna() & n["snr_db"].notna()
    no_link = n["rssi_dbm"].isna() & n["snr_db"].isna()
    rule((src == "none") & ~no_link, "link_measurement_source 'none' but rssi/snr present")
    rule((src.isin(["gateway_uplink", "ack_downlink"])) & ~has_link,
         "link_measurement_source names a source but rssi/snr are empty")
    rule(n["rssi_dbm"].notna() ^ n["snr_db"].notna(), "rssi_dbm and snr_db must be both present or both empty")
    fail = n["packet_success"] == 0
    if "latency_ms" in n.columns:
        rule(fail & n["latency_ms"].notna(), "failed packet has a latency_ms")
    if "ack_rx_millis" in n.columns:
        rule(fail & n["ack_rx_millis"].notna(), "failed packet has an ack_rx_millis")
    if all(c in n.columns for c in ("latency_ms", "ack_rx_millis", "device_millis")):
        both = n["latency_ms"].notna() & n["ack_rx_millis"].notna() & n["device_millis"].notna()
        rule(both & (n["ack_rx_millis"] < n["device_millis"]), "ack_rx_millis earlier than device_millis")
        rule(both & ((n["ack_rx_millis"] - n["device_millis"] - n["latency_ms"]).abs() > LATENCY_TOLERANCE_MS),
             f"latency_ms disagrees with ack_rx_millis - device_millis by more than {LATENCY_TOLERANCE_MS} ms")
    if "rx_confirmed" in n.columns:
        rule((n["rx_confirmed"] == 0) & (n["packet_success"] == 1),
             "acknowledged packet marked as not received (impossible)")
    if "tx_energy_mj" in n.columns and "energy_source" in df.columns:
        es = df["energy_source"]
        rule((es == "not_measured") & n["tx_energy_mj"].notna(), "energy present but energy_source is not_measured")
        rule((es.isin(["measured_inline", "measured_external", "estimated_from_airtime_model"]))
             & n["tx_energy_mj"].isna(), "energy_source says an energy value exists but tx_energy_mj is empty")
    if "experiment_mode" in df.columns and "context_id" in df.columns:
        rule((df["experiment_mode"] == MODE_SWEEP) & (df["context_id"].eq("") | df["context_id"].isna()),
             "sweep rows need a context_id")
    return errs


def check_sequence(df: pd.DataFrame):
    """Per (device, session, boot): ordering, duplicates, gaps, timestamps."""
    errs: List[str] = []
    warns: List[str] = []
    gap_rows = 0
    keys = ["device_id", "session_id", "boot_id", "packet_seq", "device_millis", "timestamp_utc"]
    if any(k not in df.columns for k in keys):
        return errs, warns, gap_rows
    n = _numeric(df)
    work = pd.DataFrame({"dev": df["device_id"], "ses": df["session_id"], "boot": n["boot_id"],
                         "seq": n["packet_seq"], "ms": n["device_millis"]})
    ts = pd.to_datetime(df["timestamp_utc"], errors="coerce", utc=True)
    bad_ts = ts.isna()
    if bad_ts.any():
        errs.append(f"timestamp_utc not parseable as ISO 8601 ({int(bad_ts.sum())} row(s); {_lines(df, bad_ts)})")
    work["ts"] = ts
    for (dev, ses, boot), g in work.groupby(["dev", "ses", "boot"], sort=False):
        label = f"device {dev!r} session {ses!r} boot {boot:g}" if pd.notna(boot) else f"device {dev!r} session {ses!r}"
        d = g["seq"].diff().dropna()
        if (d == 0).any():
            errs.append(f"duplicate packet_seq in {label}")
        if (d < 0).any():
            errs.append(f"packet_seq decreases in {label} (reboot without a new boot_id?)")
        gaps = d[d > 1]
        if len(gaps):
            missing = int((gaps - 1).sum())
            gap_rows += missing
            warns.append(f"{missing} sequence number(s) missing in {label}: LOG LOSS, not failed packets")
        if (g["ms"].diff().dropna() < 0).any():
            errs.append(f"device_millis goes backwards in {label}")
        if (g["ts"].diff().dropna() < pd.Timedelta(0)).any():
            warns.append(f"timestamp_utc goes backwards in {label} (host/device clock adjustment?)")
    for (dev, ses), g in work.groupby(["dev", "ses"], sort=False):
        if (g["boot"].diff().dropna() < 0).any():
            errs.append(f"boot_id decreases within device {dev!r} session {ses!r}")
    return errs, warns, gap_rows


def check_provenance(df: pd.DataFrame, require_real: bool):
    errs: List[str] = []
    warns: List[str] = []
    if "data_origin" not in df.columns:
        return errs, warns
    origins = sorted(set(df["data_origin"]) - {""})
    if len(origins) > 1:
        errs.append(f"file mixes data origins {origins}: real and synthetic rows must never share a file")
    if require_real:
        bad = df["data_origin"] != DATA_ORIGIN_REAL
        if bad.any():
            errs.append("real-data mode requires data_origin='real_hardware'; found "
                        f"{sorted(set(df.loc[bad, 'data_origin']))} ({_lines(df, bad)})")
        for col in ("session_id", "device_id", "scenario_id", "notes", "context_id"):
            if col in df.columns:
                hit = df[col].astype(str).str.lower().apply(
                    lambda s: any(sig in s for sig in SYNTHETIC_SIGNATURES))
                if hit.any():
                    errs.append(f"column {col}: {int(hit.sum())} value(s) carry a synthetic signature "
                                f"{SYNTHETIC_SIGNATURES} although real data was required ({_lines(df, hit)})")
    elif origins == ["synthetic_test"]:
        warns.append("data_origin is synthetic_test: this is software-test data and can never be evidence")
    return errs, warns


def check_manifest(df: pd.DataFrame, m: SessionManifest, strict: bool, require_real: bool) -> List[str]:
    errs = [f"manifest: {p}" for p in m.problems(strict=strict, allow_synthetic_test=not require_real)]
    n = _numeric(df)
    r = m.radio

    def differ(col, expected, label):
        if expected != "UNSET" and col in n.columns:
            bad = n[col].notna() & ((n[col] - float(expected)).abs() > 1e-9)
            if bad.any():
                errs.append(f"{label}: {int(bad.sum())} row(s) differ from the manifest value {expected} ({_lines(df, bad)})")

    differ("channel_freq_hz", r.frequency_hz, "channel_freq_hz")
    differ("bandwidth_hz", r.bandwidth_hz, "bandwidth_hz")
    differ("coding_rate_denominator", r.coding_rate_denominator, "coding_rate_denominator")
    if isinstance(r.allowed_sf, list) and "sf" in n.columns:
        bad = n["sf"].notna() & ~n["sf"].isin(r.allowed_sf)
        if bad.any():
            errs.append(f"sf outside the manifest's allowed set {r.allowed_sf} ({_lines(df, bad)})")
    if isinstance(r.allowed_tp_dbm, list) and "tp_dbm" in n.columns:
        bad = n["tp_dbm"].notna() & ~n["tp_dbm"].apply(lambda v: any(abs(v - a) < 1e-9 for a in r.allowed_tp_dbm))
        if bad.any():
            errs.append(f"tp_dbm outside the manifest's allowed set {r.allowed_tp_dbm} ({_lines(df, bad)})")
    for col, val in (("session_id", m.session_id), ("device_id", m.device_id),
                     ("experiment_mode", m.experiment_mode), ("scenario_id", m.scenario_id),
                     ("data_origin", m.data_origin)):
        if val != "UNSET" and col in df.columns:
            bad = df[col] != val
            if bad.any():
                errs.append(f"{col}: {int(bad.sum())} row(s) differ from the manifest value {val!r} ({_lines(df, bad)})")
    if "context_id" in df.columns and m.conditions:
        undeclared = sorted(set(df["context_id"]) - {""} - set(m.conditions))
        if undeclared:
            errs.append(f"context_id(s) {undeclared} not described in the manifest's conditions")
    return errs


def sweep_coverage_report(df: pd.DataFrame, min_packets_per_config: Optional[int] = None,
                          max_run_length: Optional[int] = None,
                          expected_configs: Optional[List[tuple]] = None) -> Dict:
    """Per-context sweep quality for sweep-mode files (CP03's labeler needs
    several configurations measured under comparable conditions)."""
    need = min_packets_per_config if min_packets_per_config is not None else min_packets_for_reliability()
    n = _numeric(df)
    work = pd.DataFrame({"ctx": df["context_id"], "ses": df["session_id"], "boot": n["boot_id"],
                         "seq": n["packet_seq"], "sf": n["sf"], "tp": n["tp_dbm"]})
    work = work.sort_values(["ses", "boot", "seq"], kind="mergesort")
    contexts, warnings = {}, []
    for ctx, g in work.groupby("ctx", sort=True):
        cfg = list(zip(g["sf"], g["tp"]))
        counts: Dict[tuple, int] = {}
        for c in cfg:
            counts[c] = counts.get(c, 0) + 1
        longest = cur = 0
        prev = None
        for c in cfg:
            cur = cur + 1 if c == prev else 1
            longest, prev = max(longest, cur), c
        missing = [c for c in (expected_configs or []) if c not in counts]
        thin = {f"SF{int(k[0])}/{k[1]:g}dBm": v for k, v in counts.items() if v < need}
        contexts[ctx] = {"n_configs": len(counts), "packets_per_config": {f"SF{int(k[0])}/{k[1]:g}dBm": v for k, v in counts.items()},
                         "min_packets": min(counts.values()), "longest_same_config_run": longest,
                         "missing_expected_configs": missing}
        if len(counts) < 2:
            warnings.append(f"context {ctx!r}: only {len(counts)} configuration — the labeler refuses to label a context with no alternatives")
        if thin:
            warnings.append(f"context {ctx!r}: configuration(s) below {need} packets {thin}: none can clear the labeler's reliability threshold")
        if missing:
            warnings.append(f"context {ctx!r}: expected configuration(s) never measured {missing}")
        if max_run_length is not None and longest > max_run_length:
            warnings.append(f"context {ctx!r}: longest same-configuration run is {longest} > {max_run_length}: "
                            "the sweep looks BLOCKED, not interleaved, so channel drift can masquerade as a configuration effect")
    return {"min_packets_required": need, "contexts": contexts, "warnings": warnings}


def validate_real_csv(path, manifest: Optional[SessionManifest] = None, strict: bool = False,
                      require_real: bool = True, max_run_length: Optional[int] = None,
                      min_packets_per_config: Optional[int] = None) -> ValidationResult:
    """Validate one real-hardware log. `require_real` defaults to True so a
    synthetic file cannot be accepted as real by forgetting a flag."""
    res = ValidationResult()
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    res.errors += check_fields(df)
    if res.errors and any(e.startswith("missing required column") for e in res.errors):
        return res
    res.errors += check_consistency(df)
    e, w, gap_rows = check_sequence(df)
    res.errors += e
    res.warnings += w
    e, w = check_provenance(df, require_real)
    res.errors += e
    res.warnings += w
    for col in ("experiment_mode", "scenario_id"):
        bad = [s for s, g in df.groupby("session_id") if g[col].nunique() > 1]
        if bad:
            res.errors.append(f"{col} changes within session(s) {bad}: one session, one {col}")
    if manifest is not None:
        res.errors += check_manifest(df, manifest, strict, require_real)

    n = _numeric(df)
    fail = n["packet_success"] == 0 if "packet_success" in n.columns else pd.Series(False, index=df.index)
    ok = n["packet_success"] == 1 if "packet_success" in n.columns else pd.Series(False, index=df.index)
    no_link = n["rssi_dbm"].isna() | n["snr_db"].isna() if "rssi_dbm" in n.columns else pd.Series(False, index=df.index)
    res.stats = {
        "NOTE": "data-quality statistics describing THIS FILE; not an evaluation of any policy",
        "rows": int(len(df)), "sessions": int(df["session_id"].nunique()),
        "rows_success": int(ok.sum()), "rows_failure": int(fail.sum()),
        "failures_without_link_measurement": int((fail & no_link).sum()),
        "successes_without_link_measurement": int((ok & no_link).sum()),
        "sequence_numbers_missing": int(gap_rows),
        "energy_sources": df["energy_source"].value_counts().to_dict() if "energy_source" in df.columns else {},
        "origins": sorted(set(df["data_origin"]) - {""}) if "data_origin" in df.columns else [],
    }
    if int(fail.sum()) == 0 and len(df):
        res.warnings.append("the file contains NO failed packets: success-rate history would be ~1.0 for the wrong "
                            "reason (log loss or survivorship bias?) — check before using it")
    if int((fail & no_link).sum()):
        res.warnings.append(f"{int((fail & no_link).sum())} failed packet(s) have no RSSI/SNR (expected on real "
                            "hardware): the CP02 cleaner would DROP them — convert with ml.collection.adapter "
                            "and an explicit missing-link policy")
    if "experiment_mode" in df.columns and set(df["experiment_mode"]) == {MODE_SWEEP} and not res.errors:
        expected = None
        if manifest is not None and isinstance(manifest.radio.allowed_sf, list) and isinstance(manifest.radio.allowed_tp_dbm, list):
            expected = [(float(s), float(t)) for s in manifest.radio.allowed_sf for t in manifest.radio.allowed_tp_dbm]
        res.sweep_coverage = sweep_coverage_report(df, min_packets_per_config, max_run_length, expected)
        res.warnings += res.sweep_coverage["warnings"]
    return res


def validate_row(row: Dict[str, object], require_real: bool = False) -> List[str]:
    """Field-level and cross-field problems of ONE row (used by the logger).
    Sequence/provenance-across-rows checks need the whole file and are not run."""
    df = pd.DataFrame([{k: ("" if v is None else str(v)) for k, v in row.items()}])
    errs = check_fields(df)
    if not errs:
        errs += check_consistency(df)
        e, _ = check_provenance(df, require_real)
        errs += e
    return errs
