"""
readiness.py

Checkpoint 8 — One command that answers two DIFFERENT questions honestly:

  1. SOFTWARE ready?   Is the collection code itself consistent (schema compatible
                       with CP02, every measurement covered, templates in sync, no
                       region assumed, data/ free of data)?
  2. COLLECTION ready? Is a given manifest / experiment config complete enough to
                       start a REAL run (strict validation: no UNSET anywhere)?

Passing (1) says nothing about (2). Right now (2) is false for every template on
purpose: the radio, region, hardware and experiment values do not exist yet.

    python -m ml.collection.readiness
    python -m ml.collection.readiness --manifest m.json --config sweep.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

from ml.collection import real_schema as rs
from ml.collection.experiment_config import (
    BaselineConfig, EdgeAIConfig, SweepConfig, load_config, problems as config_problems,
)
from ml.collection._util import UNSET, to_plain
from ml.collection.manifest import RadioConfig, SessionManifest

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

TEMPLATES = {
    "sweep_template.json": SweepConfig,
    "baseline_template.json": BaselineConfig,
    "edge_ai_template.json": EdgeAIConfig,
    "session_manifest_template.json": SessionManifest,
}


def write_templates(outdir) -> List[str]:
    """(Re)generate every template from the code defaults, so they cannot drift."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    for name, cls in TEMPLATES.items():
        cls().to_json_file(outdir / name)
    return sorted(TEMPLATES)


def templates_in_sync(outdir) -> List[str]:
    """Names of committed templates that differ from what the code generates."""
    bad = []
    for name, cls in TEMPLATES.items():
        p = Path(outdir) / name
        if not p.exists() or json.loads(p.read_text(encoding="utf-8")) != to_plain(cls()):
            bad.append(name)
    return bad


def software_checks() -> List[Dict]:
    out: List[Dict] = []

    def add(name, ok, detail=""):
        out.append({"check": name, "ok": bool(ok), "detail": detail})

    probs = rs.cp02_compatibility_problems()
    add("real schema is a CP02-compatible superset", not probs, "; ".join(probs))
    unmapped = {c: [x for x in cols if x not in rs.REAL_FIELD_BY_NAME]
                for c, cols in rs.REQUIRED_MEASUREMENT_CATEGORIES.items()}
    unmapped = {k: v for k, v in unmapped.items() if v}
    add("every required measurement category has a column", not unmapped, str(unmapped))
    r = to_plain(RadioConfig())
    add("no radio/region value is assumed (all RadioConfig defaults UNSET)",
        all(v == UNSET for v in r.values()), "")
    drift = templates_in_sync(PROJECT_ROOT / "experiments" / "configs")
    add("committed templates match the code defaults", not drift, str(drift))
    data_ok, found = True, []
    for sub in ("raw", "processed", "sample"):
        d = PROJECT_ROOT / "data" / sub
        extra = [x.name for x in d.iterdir() if x.name not in (".gitkeep", "README.md")] if d.exists() else []
        found += [f"{sub}/{e}" for e in extra]
    add("data/ holds no data files (no real data exists yet)", not found, str(found))
    return out


def collection_blockers() -> Dict[str, List[str]]:
    """What still has to be filled in before a REAL run, per template."""
    cfg_dir = PROJECT_ROOT / "experiments" / "configs"
    res = {}
    for name, cls in TEMPLATES.items():
        p = cfg_dir / name
        obj = SessionManifest.from_json_file(p) if cls is SessionManifest else load_config(p)
        res[name] = obj.unresolved()
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Readiness report for real-hardware data collection.")
    ap.add_argument("--manifest", action="append", default=[], help="a filled manifest to check strictly")
    ap.add_argument("--config", action="append", default=[], help="a filled experiment config to check strictly")
    a = ap.parse_args(argv)

    print("=" * 72)
    print("CP08 readiness — NO REAL HARDWARE DATA EXISTS; nothing here is a measurement")
    print("=" * 72)
    checks = software_checks()
    for c in checks:
        print(f"[{'OK ' if c['ok'] else 'FAIL'}] {c['check']}" + (f"  -> {c['detail']}" if c["detail"] else ""))
    software_ok = all(c["ok"] for c in checks)
    print(f"\n1. SOFTWARE READY: {'YES' if software_ok else 'NO'}")

    collection_ok = True
    for path in a.manifest:
        probs = SessionManifest.from_json_file(path).problems(strict=True)
        print(f"   manifest {path}: {'OK' if not probs else str(len(probs)) + ' problem(s)'}")
        for p in probs[:8]:
            print("     -", p)
        collection_ok &= not probs
    for path in a.config:
        probs = config_problems(load_config(path), strict=True)
        print(f"   config {path}: {'OK' if not probs else str(len(probs)) + ' problem(s)'}")
        for p in probs[:8]:
            print("     -", p)
        collection_ok &= not probs
    if not a.manifest and not a.config:
        blockers = collection_blockers()
        n = sum(len(v) for v in blockers.values())
        print(f"2. COLLECTION READY: NO — {n} value(s) across the templates are UNSET on purpose "
              "(they depend on the real hardware, region and experiment):")
        for name, paths in blockers.items():
            print(f"   {name}: {len(paths)} unresolved")
        collection_ok = False
    else:
        print(f"2. COLLECTION READY (for the files given): {'YES' if collection_ok else 'NO'}")
    return 0 if software_ok else 1


if __name__ == "__main__":
    sys.exit(main())
