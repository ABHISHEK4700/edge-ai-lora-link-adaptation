# Firmware Logging Specification (Checkpoint 8)

> **NO FIRMWARE EXISTS YET** (`esp32/` is empty). This is the CONTRACT the future
> ESP32 firmware must meet so that its serial output feeds `ml/collection/logger.py`
> unchanged. It is not a description of existing behaviour, and the numbers in the
> example below are **arbitrary test values, not a measurement**.

## 1. Line protocol (version 1)

One line per logical packet, once its final outcome (ACK or give-up) is known:

```
LORALOG1,<field1>,...,<field22>*<HH>
```

* Fields are comma-separated, in the exact order of section 2. **An empty field means
  "no value"** (e.g. no RSSI for a lost packet). Never write `0`, `-999` or `nan` as a
  stand-in: the logger would read it as a measurement.
* `HH` is the two-digit **uppercase hex XOR of every character before the `*`**
  (including the `LORALOG1,` prefix), NMEA style. A corrupted byte makes the line fail
  the checksum and be rejected and logged, instead of silently becoming a wrong
  measurement.
* Any line that does not start with `LORALOG1,` or `LORACTX1,` is ignored, so ordinary
  debug prints are allowed.
* Terminate lines with `\n`. One record per line; no multi-line records.

C reference for the checksum:

```c
uint8_t x = 0;
for (const char *p = body; *p; ++p) x ^= (uint8_t)*p;   // body = text before '*'
```

Illustrative format example (TEST VALUES, produced by the Python reference encoder):

```
LORALOG1,1,0,0,7,2.0,125000.0,5,433000000.0,20,-90,8,gateway_uplink,0,1,1,,170,170.0,,,not_measured,*6C
```

## 2. The 22 device fields (in order)

| # | field | type | empty? | meaning |
|---|---|---|---|---|
| 1 | `boot_id` | int | required | Increments on every device boot (persist in NVS). A reboot resets packet_seq and device_millis; boot_id keeps that visible. |
| 2 | `packet_seq` | int | required | Strictly increasing within (device_id, session_id, boot_id). |
| 3 | `device_millis` | int | required | Device monotonic clock (ms since boot) at the START of the first attempt. Always available, unlike wall-clock time. |
| 4 | `sf` | int | required | Spreading factor used for this packet (same range as CP02). |
| 5 | `tp_dbm` | float | required | Transmit power setting in dBm (CP02 sanity range; the ACTUAL allowed set comes from the manifest, never from this range). |
| 6 | `bandwidth_hz` | float | required | Channel bandwidth used. Needed for airtime; never assumed. |
| 7 | `coding_rate_denominator` | int | required | 5, 6, 7 or 8 for coding rate 4/5 ... 4/8. |
| 8 | `channel_freq_hz` | float | required | Carrier frequency used (optional in CP02, required here so a mid-run frequency change cannot go unnoticed). Compared with the manifest; no band is assumed. |
| 9 | `payload_bytes` | int | required | Payload size (optional in CP02, required here: airtime/energy need it). |
| 10 | `rssi_dbm` | float | empty allowed | RSSI associated with this packet. EMPTY when none exists (e.g. lost packet, no ACK) - see link_measurement_source. |
| 11 | `snr_db` | float | empty allowed | SNR associated with this packet. EMPTY when none exists. |
| 12 | `link_measurement_source` | str | required | Where rssi/snr came from: gateway_uplink (receiver measured the uplink), ack_downlink (sender measured the ACK), none (both columns empty). |
| 13 | `retry_count` | int | required | Retransmissions of this packet (CP02 definition). |
| 14 | `attempts` | int | required | Total transmissions of this packet. Must equal retry_count + 1 (a redundancy that catches logging bugs). |
| 15 | `packet_success` | int | required | 1 if acknowledged at the SENDER (what a deployed device can know), else 0. |
| 16 | `rx_confirmed` | int | empty allowed | Receiver-side ground truth, when a receiver log exists: 1 received, 0 not received, empty unknown. Acked-but-not-received (0 with packet_success=1) is impossible and rejected. |
| 17 | `ack_rx_millis` | int | empty allowed | device_millis when the ACK arrived. Empty for failed packets. |
| 18 | `latency_ms` | float | empty allowed | ack_rx_millis - device_millis (first attempt start to ACK). Empty unless the packet was acknowledged. |
| 19 | `airtime_ms` | float | empty allowed | Per-attempt time on air, if the firmware reports it; otherwise empty (ml.labeling.airtime can compute it from the radio parameters). |
| 20 | `tx_energy_mj` | float | empty allowed | Energy for this packet (all attempts) in millijoules. EMPTY iff energy_source = not_measured. |
| 21 | `energy_source` | str | required | not_measured | measured_inline | measured_external | estimated_from_airtime_model. Estimated values are NOT measurements. |
| 22 | `energy_window_ms` | float | empty allowed | Length of the measurement window the energy covers. |

Everything else in the real-data schema (`data_origin`, `session_id`, `device_id`,
`experiment_mode`, `scenario_id`, `context_id`, `timestamp_utc`, `timestamp_source`,
`notes`) is supplied by the host from the session manifest, the context markers and
the host clock. The firmware does not send them.

## 3. Context markers

```
LORACTX1,<context_id>*<HH>
```

Switches the current block of constant channel conditions (for example, a new fixed
position). It can be injected by the operator's tooling or typed in a terminal; the
firmware does not know where it is. Every `context_id` used must be described in the
session manifest. Example: `LORACTX1,pos_01*70`. In a `sweep` session, records arriving before any
context marker are rejected.

## 4. Rules the firmware must follow

1. **SF and TX power are constant across all attempts of one packet.** Retries reuse the
   configuration chosen for the packet. `attempts` must equal `retry_count + 1`.
2. **`boot_id` increments on every boot** (persist it in non-volatile storage). A reboot
   resets `packet_seq` and `device_millis`; `boot_id` makes that visible instead of
   looking like corrupt data. `packet_seq` is strictly increasing within a boot.
3. **`device_millis` is the monotonic clock at the START of the first attempt.**
   `ack_rx_millis` is the same clock when the ACK arrived; `latency_ms` is their
   difference. Failed packets have neither.
4. **`packet_success` means acknowledged at the sender** — what a deployed device can know.
5. **Report the true source of RSSI/SNR** (`gateway_uplink`, `ack_downlink`, or `none` with
   both fields empty). A lost packet normally has none. Do not copy the previous value
   forward in firmware: carrying a stale value forward is a documented, reported
   decision made by `ml/collection/adapter.py`, not something to hide in the log.
6. **Energy honesty.** `energy_source` is `not_measured` (and `tx_energy_mj` empty) unless a
   real instrument measured it (`measured_inline` / `measured_external`).
   `estimated_from_airtime_model` is allowed but is not a measurement and is never pooled
   with measured energy.
7. **Never invent a value to fill a field.** Empty is always correct when unknown.
8. **The radio configuration logged must be the one actually programmed** (bandwidth,
   coding rate, frequency). The host compares every row to the manifest and rejects
   mismatches, so a silent mid-run reconfiguration cannot go unnoticed.
9. **The baseline and Edge-AI firmware paths must differ only in how SF/TX power are
   chosen** — same logging, same payload, same ACK handling, same timeouts — see
   `experiments/EXPERIMENT_PROCEDURE.md`.

## 5. Capturing the lines

Any tool that saves the serial text works (terminal logging, `cat /dev/ttyUSB0 > capture.txt`,
PuTTY session logging). Then:

```bash
python -m ml.collection.logger --manifest <manifest.json> --out data/raw/<session_id>.csv --input capture.txt
```

or pipe the live serial stream into `--input -`. No serial library is required, so
`requirements.txt` is unchanged. The logger refuses to start unless the manifest is
fully filled in, refuses to overwrite an existing CSV, and writes every rejected line
and its reason to `<out>.rejects.log`.
