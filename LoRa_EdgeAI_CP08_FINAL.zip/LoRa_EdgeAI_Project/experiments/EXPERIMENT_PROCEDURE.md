# Experimental Procedure (Checkpoint 8)

> **NO REAL DATA HAS BEEN COLLECTED. NO RESULT EXISTS.** This is a procedure to be
> followed once hardware exists. Nothing here claims that the Edge-AI policy improves
> packet delivery ratio, latency or energy; that question is answered only by real
> measurements analysed under the plan fixed in section 5, *before* the data is
> looked at.
>
> **Only data measured on this project's own hardware may be used.** External or public
> LoRa datasets are not used, and synthetic rows never enter `data/`.

Machine-readable counterparts live in `ml/collection/` and `experiments/configs/`.
Check any filled-in file with `python -m ml.collection.readiness --manifest ... --config ...`.

---

## 1. Three kinds of session, and why they are kept apart

| mode | purpose | may become training data? |
|---|---|---|
| `sweep` | step through the (SF, TX-power) grid under controlled conditions so the CP03 labeler can find the best measured configuration | **yes — the only mode that can** |
| `baseline` | run the baseline policy | no — evaluation only |
| `edge_ai` | run the trained model's policy | no — evaluation only |

A policy-driven session cannot be labelled: it mostly contains the configuration the
policy chose, so a model trained on it learns that policy (behavioural cloning), and
an Edge-AI session would train the model on its own decisions. `ml/collection/adapter.py`
enforces this: `purpose="training"` refuses anything but `sweep`;
`purpose="evaluation"` refuses `sweep`. Mixed files are refused.

## 2. Before any real collection (pre-flight)

Nothing below can be skipped; the tooling refuses to proceed while any value is `UNSET`.

1. **Radio and region.** A person confirms the frequency, bandwidth, coding rate, preamble,
   sync word, power limits and duty-cycle rule that are *actually permitted and actually
   configured*, and writes them — with who/what confirmed them — into the manifest
   (`radio.*`). No region is assumed anywhere in the code; in particular nothing is
   hard-coded to EU868 or any other band plan.
2. **Hardware identity.** Board, radio module, receiver, antennas, firmware version or
   commit, and how energy is measured (or the literal text `none`) go in `hardware.*`.
3. **Firmware meets `experiments/FIRMWARE_LOGGING_SPEC.md`**, verified by capturing a short
   run and passing it through `ml.collection.logger` and `validator`.
4. **Clock sanity.** Record `timestamp_source`. Rely on `device_millis` for ordering and latency.
5. **Plan the budget** with `ml.collection.planner.plan_sweep(...)` using the real radio values.
   It derives the minimum packets per configuration from the labeler's own settings
   (25 at the current defaults: 25/25 successes is the least that clears a 0.90 Wilson bound)
   and the time the declared duty-cycle needs.
6. **Freeze the configuration.** Fill in and strictly validate every config; store the
   hashes. Do not edit a config mid-experiment — start a new one.

## 3. Phase 1 — sweep (produces the training data)

1. Choose several **contexts**: blocks of constant channel conditions (for example fixed
   positions). Describe each in the manifest (`conditions[<context_id>]`): environment,
   line of sight, mobility, approximate distance, temperature, interference notes. This
   is **metadata** and never an ML feature.
2. In each context, send packets **round-robin (interleaved) across the whole grid** —
   one packet per configuration, repeated — **not** 25 packets at one configuration and
   then 25 at the next. If conditions drift during a blocked sweep, the last
   configuration is measured on a different link than the first and the sweep order
   becomes the result. The validator reports the longest same-configuration run.
3. At least the planner's minimum packets per configuration in every context; constant payload;
   retries reuse the packet's configuration; same retry limit and ACK timeout throughout.
4. Log with `ml.collection.logger` → `data/raw/<session_id>.csv` (+ manifest, rejects log,
   summary). Never edit a raw log.
5. `validator` — read the warnings (log loss, missing RSSI/SNR on failures, thin or blocked
   sweeps, files with no failures).
6. Convert for the existing pipeline **with an explicit policy for missing link
   measurements**:
   ```
   to_cp02_raw(real_csv, out_csv, purpose="training",
               missing_link_policy="carry_forward", max_carry_forward_packets=<decided>)
   ```
   A lost packet usually has no RSSI/SNR, and the CP02 cleaner deletes such rows — which
   would remove essentially every failure and make every configuration look reliable.
   `carry_forward` uses the last *measured* value (what a deployed device would know) no
   older than the limit you choose; the report counts what was filled or dropped per
   outcome. The conversion refuses if failures existed and none survive.
7. CP02 preprocessing → CP03 labeling (`context_strategy="explicit_column"` uses
   `context_id`). **Review the oracle table and the `label_status` breakdown before
   training anything.** Revisit the labeling defaults — they are placeholders.
8. Train all three candidates (CP04–CP06) on training sessions only, then re-run the CP07
   comparison framework **on the real data**. The framework reports characteristics per
   factor and never selects; a human decides, and records the basis in
   `edge_ai.policy.selection_basis`.

## 4. Phase 2 — evaluation: baseline versus Edge-AI under the same conditions

The two arms must differ **only in how SF and TX power are chosen.**

1. Both configs share identical `radio` and `conditions` blocks (scenarios, payload,
   interval, packets per block, blocks per arm, retry limit, ACK timeout, block order).
   `check_arm_parity(baseline, edge_ai)` lists every difference and must report none.
2. **Interleave the arms in time.** Run alternating blocks (A B A B …), counterbalanced
   (A B B A …) or seeded-random order, as `conditions.block_order` declares. Running
   all baseline blocks and then all Edge-AI blocks confounds the policy with channel
   drift, which is the same trap as a blocked sweep.
3. One session per block, each with a manifest recording `repetition` and `block_index`,
   at the same positions and in the same scenarios for both arms.
4. The Edge-AI arm uses a **frozen model**: record `model_artifact_sha256`; no retraining
   or threshold changes during evaluation.
5. **Training/evaluation separation.** `training_session_ids` and `evaluation_session_ids`
   must not overlap (a config with overlap is invalid). Sharing a *scenario* between
   them is reported as a weakening of the generalisation claim, not hidden.
6. Convert with `purpose="evaluation"`. The arm-comparison analysis code is **not part of
   Checkpoint 8**.

## 5. Analysis plan (declare before looking at the data)

Set in `analysis.*` of the configs and frozen before any evaluation data is reviewed
(`plan_frozen_before_data_review`):

* **Primary metrics:** packet delivery ratio (acknowledged at the sender; `rx_confirmed`
  quantifies lost ACKs when a receiver log exists) and mean latency of acknowledged packets
  (which includes retries). **Energy is a metric only if it was measured**
  (`energy_source` is `measured_inline` or `measured_external`); estimated energy is never
  pooled with measured energy and `energy_metric_enabled` stays false otherwise.
* The comparison method, the significance level and the minimum blocks per arm are named
  in advance. Adjacent baseline/Edge-AI blocks are natural pairs.
* Report every block, including bad ones; report uncertainty, not just means. A result
  against the Edge-AI policy is a result.
* **Claims policy (fixed in code, validated):** no statement that Edge-AI improves PDR,
  latency or energy until real hardware measurements, analysed under this plan, support it.

## 6. Data hygiene

* Raw logs are append-only evidence: validate, never edit. Fix problems by re-collecting.
* Keep every manifest and the `.rejects.log` / `.session_summary.json` beside its CSV.
* A **missing row** (log loss) is not a **failed packet** (a row with `packet_success=0`);
  the validator reports sequence gaps and never interprets them as failures.
* A reboot shows up as a new `boot_id`; the adapter then starts a new session
  (`<session_id>__b<boot_id>`) because a rebooted device really does lose its history.
* A file containing no failed packets is flagged: its success history would be ~1.0 for
  the wrong reason.

## 7. What Checkpoint 8 does not provide

Firmware; hardware measurements; any trained-on-real-data model; the arm-comparison
analysis code; a chosen model; any result. Those are later work, and the readiness report
(`python -m ml.collection.readiness`) states what is still unresolved.
