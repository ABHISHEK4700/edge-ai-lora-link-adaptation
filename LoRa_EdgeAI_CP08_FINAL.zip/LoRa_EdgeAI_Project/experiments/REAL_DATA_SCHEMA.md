# Real-Data Schema (Checkpoint 8)

> **Generated from `ml/collection/real_schema.py` — do not edit by hand.**
> A test fails if this file drifts from the code.

> **NO REAL DATA EXISTS YET.** This is the contract real ESP32 + LoRa logs must follow. Nothing here is a measurement.

One row = one logical packet (retries summarised in the row). `REAL_SCHEMA` is a strict superset of the CP02 raw schema.

## provenance

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `data_origin` | str | yes | no | one of real_hardware, synthetic_test | 'real_hardware' for rows logged from physical hardware; 'synthetic_test' for software-test rows. Never mixed in one file; real-data mode rejects 'synthetic_test'. |
| `session_id` | str | yes | no | - | One continuous run. Matches the manifest's session_id. |
| `device_id` | str | yes | no | - | Physical end device that logged the row. |
| `experiment_mode` | str | yes | no | one of sweep, baseline, edge_ai | 'sweep' (configuration sweep for labelling/training), 'baseline' or 'edge_ai' (evaluation arms). |
| `scenario_id` | str | yes | no | - | Controlled scenario this row belongs to. Identical across baseline and edge_ai arms so they are compared under the same conditions. |
| `context_id` | str | no | yes | - | Identifier of a block of constant channel conditions (e.g. a fixed position). Required (non-empty) in sweep mode. This is the column `LabelingConfig(context_strategy='explicit_column')` reads. Described per-context in the manifest. |

## sequence

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `boot_id` | int | yes | no | 0 to inf | Increments on every device boot (persist in NVS). A reboot resets packet_seq and device_millis; boot_id keeps that visible. |
| `packet_seq` | int | yes | no | 0 to inf | Strictly increasing within (device_id, session_id, boot_id). |
| `device_millis` | int | yes | no | 0 to inf | Device monotonic clock (ms since boot) at the START of the first attempt. Always available, unlike wall-clock time. |
| `timestamp_utc` | str | yes | no | - | ISO 8601 UTC, e.g. 2026-09-19T05:30:12.345Z. May be host-stamped. |
| `timestamp_source` | str | yes | no | one of device_rtc, host_receipt, gateway, other | Who produced timestamp_utc. An ESP32 without an RTC/NTP cannot be trusted for absolute time; say which clock this is. |

## radio

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `sf` | int | yes | no | 7 to 12 | Spreading factor used for this packet (same range as CP02). |
| `tp_dbm` | float | yes | no | -4 to 22 | Transmit power setting in dBm (CP02 sanity range; the ACTUAL allowed set comes from the manifest, never from this range). |
| `bandwidth_hz` | float | yes | no | 1 to 1e+07 | Channel bandwidth used. Needed for airtime; never assumed. |
| `coding_rate_denominator` | int | yes | no | one of 5, 6, 7, 8 | 5, 6, 7 or 8 for coding rate 4/5 ... 4/8. |
| `channel_freq_hz` | float | yes | no | 0 to inf | Carrier frequency used (optional in CP02, required here so a mid-run frequency change cannot go unnoticed). Compared with the manifest; no band is assumed. |
| `payload_bytes` | int | yes | no | 0 to 256 | Payload size (optional in CP02, required here: airtime/energy need it). |

## link

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `rssi_dbm` | float | yes | yes | -150 to 0 | RSSI associated with this packet. EMPTY when none exists (e.g. lost packet, no ACK) - see link_measurement_source. |
| `snr_db` | float | yes | yes | -30 to 20 | SNR associated with this packet. EMPTY when none exists. |
| `link_measurement_source` | str | yes | no | one of gateway_uplink, ack_downlink, none | Where rssi/snr came from: gateway_uplink (receiver measured the uplink), ack_downlink (sender measured the ACK), none (both columns empty). |

## outcome

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `retry_count` | int | yes | no | 0 to 255 | Retransmissions of this packet (CP02 definition). |
| `attempts` | int | yes | no | 1 to 256 | Total transmissions of this packet. Must equal retry_count + 1 (a redundancy that catches logging bugs). |
| `packet_success` | int | yes | no | one of 0, 1 | 1 if acknowledged at the SENDER (what a deployed device can know), else 0. |
| `rx_confirmed` | int | no | yes | one of 0, 1 | Receiver-side ground truth, when a receiver log exists: 1 received, 0 not received, empty unknown. Acked-but-not-received (0 with packet_success=1) is impossible and rejected. |

## latency

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `ack_rx_millis` | int | no | yes | 0 to inf | device_millis when the ACK arrived. Empty for failed packets. |
| `latency_ms` | float | no | yes | 0 to inf | ack_rx_millis - device_millis (first attempt start to ACK). Empty unless the packet was acknowledged. |
| `airtime_ms` | float | no | yes | 0 to inf | Per-attempt time on air, if the firmware reports it; otherwise empty (ml.labeling.airtime can compute it from the radio parameters). |

## energy

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `tx_energy_mj` | float | no | yes | 0 to inf | Energy for this packet (all attempts) in millijoules. EMPTY iff energy_source = not_measured. |
| `energy_source` | str | yes | no | one of not_measured, measured_inline, measured_external, estimated_from_airtime_model | not_measured | measured_inline | measured_external | estimated_from_airtime_model. Estimated values are NOT measurements. |
| `energy_window_ms` | float | no | yes | 0 to inf | Length of the measurement window the energy covers. |

## notes

| column | type | required | nullable | constraint | meaning |
|---|---|---|---|---|---|
| `notes` | str | no | yes | - | Free text. |

## Measurement coverage

| needed measurement | column(s) |
|---|---|
| RSSI | `rssi_dbm` |
| SNR | `snr_db` |
| packet success/failure | `packet_success` |
| retry count | `retry_count`, `attempts` |
| spreading factor | `sf` |
| transmit power | `tp_dbm` |
| timestamp / sequence | `timestamp_utc`, `device_millis`, `packet_seq`, `boot_id` |
| energy (where supported) | `tx_energy_mj`, `energy_source` |
| latency | `latency_ms`, `ack_rx_millis` |
| radio configuration | `bandwidth_hz`, `coding_rate_denominator`, `channel_freq_hz`, `payload_bytes` |
| channel-condition identity | `scenario_id`, `context_id` |

Environmental / channel-condition information (environment type, line of sight, mobility, approximate distance, temperature, interference notes) is recorded per `context_id` in the session manifest as **metadata** — never as an ML feature.
