# CHECKPOINT PROGRESS — Checkpoint 8 (Real-Data Collection Readiness)

This is a **working log**, updated after each major stage, so that an
interrupted session can be resumed without guessing. It is *not* the project's
source of truth — `PROJECT_STATUS.md` is. If the two disagree, trust
`PROJECT_STATUS.md` and the actual files, then fix this one.

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT**
>
> Every model metric produced anywhere in this project (Checkpoints 4-7, and the
> synthetic runs inside the Checkpoint 8 tests) came from fabricated test data.
> It shows the software runs; it says nothing about real LoRa behaviour or about
> which model is better.

> **NO REAL HARDWARE DATA EXISTS. NOTHING IN CHECKPOINT 8 IS A MEASUREMENT.**
>
> CP08 built readiness software in `ml/collection/` (schema, manifest, configs,
> validator, adapter, logger, readiness report) plus `REAL_DATA_SCHEMA`,
> `EXPERIMENT_PROCEDURE` and `FIRMWARE_LOGGING_SPEC` documents. Its tests use
> clearly-marked **synthetic software-test data** only. Future real hardware
> measurements have not been taken. External/public LoRa datasets are not used.
> Every hardware-dependent template value is `UNSET`; the survivorship-bias guard
> is in place. No PDR, latency, energy or RSSI/SNR improvement and no model
> superiority is claimed.
>
> Final model selection: **TBD — to be determined using real data and ESP32 deployment measurements.**

## Current state: CHECKPOINT 8 IS COMPLETE. Checkpoint 9 has NOT been started.

The final archive is `LoRa_EdgeAI_CP08_FINAL.zip`, built from this exact tree
immediately after this file was finalized. Its file-by-file verification
against the working directory is reported in the session reply, because an
archive cannot contain its own verification result.

## Scope reminder

CP08 = make the project ready to receive real ESP32 + LoRa data safely, without
collecting, generating or implying any. Preserve CP01-CP07; assume no region;
use no external datasets; fabricate nothing; do not start CP09.

## Stage status

| Stage | Description | Status |
|---|---|---|
| Before F | CP08 implementation of `ml/collection/`, the three documents, templates, generator and the 27-check suite. Any earlier partial snapshots are not recorded in the files that were uploaded, so none is described here | **DONE** |
| F | Snapshot `LoRa_EdgeAI_CP08_PARTIAL_STAGE_F.zip`: implementation complete, 26 of 27 CP08 checks passing, documentation still describing CP07. This is the ZIP the final session started from | **DONE** |
| G | Final session: inspect actual state; synchronise README, PROJECT_STATUS, CHANGELOG, CHECKPOINT_PROGRESS and `ml/collection/README.md`; full regression; build and verify `LoRa_EdgeAI_CP08_FINAL.zip` | **DONE** (ZIP verification reported in the session reply) |

## What the final session found and did

- Re-ran every suite on the uploaded tree: the seven CP01-CP07 suites passed; the
  CP08 suite had **26 of 27** checks passing. The one failure,
  `check_documentation_synchronised`, was genuine: the four core documents still
  described Checkpoint 7 and the CHANGELOG still held the "(not started)"
  placeholder.
- The hand-over note called the CP08 state "25/25". The suite actually defines
  **27** checks; that count is what is recorded everywhere now.
- Found no functional defect, so **no code, test or fixture was changed**. Only
  documentation was edited: README, PROJECT_STATUS, CHANGELOG, this file and
  `ml/collection/README.md`. `tests/fixtures/README.md` is pinned byte-for-byte
  by the frozen-file check and was deliberately left alone; the CP08 generator is
  documented in `ml/collection/README.md`.
- Spot checks beyond the suite: the firmware-spec example line and context marker
  reproduce their documented checksums (6C, 70); `ml/collection` imports no
  network or dataset library; no `*.csv`/`*.joblib` exists outside
  `tests/fixtures/`; `data/` and `ml/models/` hold only README/.gitkeep.
- `__pycache__` folders created by test runs were removed before archiving.

## Verified results (final tree)

See the verification section of `PROJECT_STATUS.md` (section 3, "Verification
performed during Checkpoint 8") and the CHANGELOG entry: 8 suites, 129 checks
(4 + 6 + 19 + 17 + 13 + 23 + 20 + 27), all passing; 64 CP01-CP07 files
byte-identical. Environment: the container's system stack only (Python 3.12.3,
numpy 2.4.4, pandas 3.0.2, scikit-learn 1.8.0, joblib 1.5.3).

## Next

Checkpoint 9 is **NOT STARTED** and its scope is not defined; do not start it
unless the user asks. Real hardware data collection is hardware work; see
`PROJECT_STATUS.md` section 8.

---

# Appendix — earlier log: Checkpoint 7 (Model Comparison & Selection Framework)

*Preserved from the Checkpoint 7 version of this file. Historical; everything
below refers to Checkpoint 7 and its snapshots.*

### Current state at the end of Checkpoint 7: COMPLETE. Checkpoint 8 has NOT been started.

All stages below are done. The final archive is `LoRa_EdgeAI_CP07_FINAL.zip`
(also delivered, byte-identical, as
`LoRa_EdgeAI_CP07_Model_Comparison_Framework.zip`). It was built from this exact
tree immediately after this file was finalized; its file-by-file verification
against the working directory is reported in the session reply, because an
archive cannot contain its own verification result.

### Scope reminder

CP07 = a model comparison and selection **framework** for Decision Tree,
Logistic Regression and small Random Forest, rerunnable later on real
ESP32+LoRa data. It must **not** declare a winner, must **not** invent hardware
numbers, must **not** train on real data, and must **not** start Checkpoint 8.
Features stay RSSI, SNR, packet success/failure history, retry count. Targets
stay SF and TX power.

### Snapshots (backups) taken

Every snapshot was built from the then-current working directory and verified
file by file (SHA-256 manifest) against it. None is an older checkpoint archive.

| # | File | Taken | State of the code at that moment |
|---|---|---|---|
| 0 | `LoRa_EdgeAI_CP07_Model_Comparison_PARTIAL_CURRENT.zip` | Start of the resumed session 1, before any new change | **Mid-refactor, internally inconsistent — see "Known state of snapshot 0".** 68 files; 5 new files vs CP06; 0 CP06 files modified or removed |
| 1 | `LoRa_EdgeAI_CP07_Model_Comparison_PARTIAL_STAGE1.zip` | End of Stage 1 | Code consistent again; 18 of 19 CP07 checks pass, only the documentation check fails |
| 2 | `LoRa_EdgeAI_CP07_Model_Comparison_PARTIAL_STAGE2A.zip` | Mid Stage 2 | Run record, README, CHANGELOG and the `ml/evaluation/__init__.py` docstring done; `PROJECT_STATUS.md` not yet updated. This is the ZIP re-uploaded when session 2 began |
| 3 | `LoRa_EdgeAI_CP07_Model_Comparison_PARTIAL_STAGE2B.zip` | Start of session 2, before finishing `PROJECT_STATUS.md` | Adds fitted-parameter counts, the 20th CP07 check, regenerated run record, and `PROJECT_STATUS.md` header + sections 0 and 2. Sections 3-9 of `PROJECT_STATUS.md` still described Checkpoint 6 |
| F | `LoRa_EdgeAI_CP07_FINAL.zip` (+ identical copy `LoRa_EdgeAI_CP07_Model_Comparison_Framework.zip`) | End of Stage 3 | Complete. 102 of 102 checks pass across all seven suites |

### Stage status

| Stage | Description | Status |
|---|---|---|
| 0 | Snapshot the working directory as-is (`PARTIAL_CURRENT.zip`) and verify it | **DONE** |
| 1 | Finish the stability-factor refactor; move the report generator and tests to the `context_stability` API | **DONE** |
| 2 | Run record, `README.md`, `PROJECT_STATUS.md` (all sections), `CHANGELOG.md`, `ml/evaluation/__init__.py` docstring; add fitted-parameter counts | **DONE** |
| 3 | Run all seven suites; verify CP01-CP06 sources byte-identical to the original CP06 archive; build the final ZIP; verify it contains the current tree | **DONE** (ZIP verification reported in the session reply) |

### What changed after the Stage 2A snapshot (session 2)

- Added `count_model_parameters()` to `ml/evaluation/resource_profile.py`
  (linear coefficients + intercepts, scaler mean + scale, tree nodes), a
  "Fitted parameters / structures" table in report section A.4, and the 20th
  CP07 check, `check_parameter_counts`. Reason: the request asked for "number of
  parameters/structures where applicable", and Logistic Regression had shown
  only "n/a".
- Regenerated `experiments/CP07_MODEL_COMPARISON_FRAMEWORK_RUN.md`.
- Wrote `PROJECT_STATUS.md` sections 3, 4, 5, 6 (decisions 54-65), 7, 8 and 9,
  and fixed stale wording in README / CHANGELOG / PROJECT_STATUS.
- The documentation test now also requires `LoRa_EdgeAI_CP07_FINAL.zip` to be
  named in `PROJECT_STATUS.md`.

### Resume note (session 2)

The session was resumed by re-uploading `PARTIAL_STAGE2A.zip`. The container's
working directory was found to be a strict superset of it (same 70 files; 7
files newer: `CHANGELOG.md`, `PROJECT_STATUS.md`, `README.md`, the run record,
`generate_comparison_report.py`, `resource_profile.py`, the CP07 test), so work
continued from the working directory and nothing was reverted. Had the working
directory been missing, the uploaded ZIP would have been the base.

### Verified results (final tree)

- All seven suites exit 0 with zero failures: `test_environment` 4,
  `test_preprocessing` 6, `test_labeling` 19, `test_training` 17,
  `test_logistic_regression` 13, `test_random_forest` 23,
  `test_model_comparison_framework` 20 — 102 checks.
- Against a fresh extraction of the original CP06 archive: of its 63 files, 59
  are byte-identical, 4 are modified (`CHANGELOG.md`, `PROJECT_STATUS.md`,
  `README.md`, and the `ml/evaluation/__init__.py` docstring), none removed;
  7 files are new (`CHECKPOINT_PROGRESS.md`, the run record, and the four
  evaluation modules and one test listed in `PROJECT_STATUS.md` section 0.4).
  Nothing under `ml/preprocessing/`, `ml/labeling/` or `ml/training/`, no
  earlier test, no fixture and no `requirements.txt` changed.
- Environment: the container's system stack only (Python 3.12.3, numpy 2.4.4,
  pandas 3.0.2, scikit-learn 1.8.0, joblib 1.5.3); the pinned-bound
  virtual-environment matrix from Checkpoint 6 was not repeated (documented in
  `PROJECT_STATUS.md` section 7).

### Known state of snapshot 0 (read this only if you resume from that ZIP)

At snapshot 0, `decision_framework.py` had been refactored to take
`context_stability`, but `generate_comparison_report.py` and the CP07 tests
still passed the old `beats_baseline` dict, so the CP07 suite was expected to
fail there, and the three documents had not been updated for CP07. Superseded
by every later snapshot.

### Next

Checkpoint 8 — Real Hardware Data Collection — is **NOT STARTED** and must not
be started unless the user asks. See `PROJECT_STATUS.md` section 8.
