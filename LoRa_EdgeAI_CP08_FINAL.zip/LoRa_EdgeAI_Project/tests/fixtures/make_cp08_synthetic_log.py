"""
make_cp08_synthetic_log.py

Generates SYNTHETIC rows in the Checkpoint 8 real-data schema, ONLY so the
validator, adapter and logger can be tested. *** THESE ARE NOT MEASUREMENTS. ***

Every row says so: data_origin = "synthetic_test" and notes begin with
"SYNTHETIC test row". Nothing is written to the repository: tests call
`write_log()` with a temporary directory. The radio values below (125 kHz, CR 4/5,
433 MHz, the SF/TP grid) are arbitrary TEST values chosen to make the arithmetic
checkable; they are not a recommendation and not a region.

Fully deterministic — no random number generator — so every expected result can
be derived on paper. Failed packets carry NO rssi/snr (link source "none"),
which is what real failed packets look like and is exactly the case the CP02
cleaner would silently drop.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List

from ml.collection.manifest import ConditionInfo, HardwareConfig, RadioConfig, SessionManifest
from ml.collection.real_schema import REAL_ALL_COLUMNS

TEST_FREQ_HZ = 433000000.0
TEST_BW_HZ = 125000.0
T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)

#: Deterministic "fail every Nth packet" period per (sf, tp); None = never fails.
#: Chosen so each context has exactly one fully reliable configuration, which lets
#: the CP03 labeler produce a label (25/25 successes clears a 0.90 Wilson bound).
FAIL_PERIOD = {(7, 2.0): 3, (7, 14.0): 5, (9, 2.0): 8, (9, 14.0): None}
DEFAULT_FAIL_PERIOD = 5


def test_radio() -> RadioConfig:
    """A fully-specified radio block of TEST values (nothing UNSET)."""
    return RadioConfig(
        region_profile="TEST ONLY - not a real regional plan",
        frequency_hz=TEST_FREQ_HZ, bandwidth_hz=TEST_BW_HZ, coding_rate_denominator=5,
        preamble_symbols=8, sync_word=18, crc_enabled=True, explicit_header=True,
        tx_power_min_dbm=2.0, tx_power_max_dbm=14.0, allowed_sf=[7, 9], allowed_tp_dbm=[2.0, 14.0],
        duty_cycle_fraction=None, duty_cycle_basis="TEST ONLY - no limit modelled",
        regulatory_confirmation="TEST ONLY - nothing was transmitted")


def test_manifest(session_id="sess_syn_01", device_id="dev_syn_01", mode="sweep",
                  scenario_id="scn_syn_01", contexts=("ctxA", "ctxB")) -> SessionManifest:
    hw = HardwareConfig(board="TEST", radio_module="TEST", firmware_version="TEST",
                        receiver_description="TEST", antenna_description="TEST",
                        energy_measurement_method="none", unit_identifiers="TEST")
    cond = {c: ConditionInfo(description="TEST", environment_type="TEST", line_of_sight="unknown",
                             mobility="static", approx_distance_m=None) for c in contexts}
    return SessionManifest(data_origin="synthetic_test", session_id=session_id, device_id=device_id,
                           experiment_mode=mode, scenario_id=scenario_id, repetition=1, block_index=0,
                           operator="TEST", start_utc="2026-01-01T00:00:00Z", radio=test_radio(),
                           hardware=hw, conditions=cond)


def make_rows(session_id="sess_syn_01", device_id="dev_syn_01", mode="sweep",
              scenario_id="scn_syn_01", contexts=("ctxA", "ctxB"), sfs=(7, 9), tps=(2.0, 14.0),
              packets_per_config=25, boot_id=1, interleave=True) -> List[Dict]:
    rows: List[Dict] = []
    seq = 0
    for ci, ctx in enumerate(contexts):
        configs = [(sf, tp) for sf in sfs for tp in tps]
        order = ([c for _ in range(packets_per_config) for c in configs] if interleave
                 else [c for c in configs for _ in range(packets_per_config)])
        for i, (sf, tp) in enumerate(order):
            period = FAIL_PERIOD.get((sf, tp), DEFAULT_FAIL_PERIOD)
            fail = period is not None and (i + ci + 1) % period == 0
            ms = seq * 5000
            latency = None if fail else 100.0 + sf * 10
            rows.append({
                "data_origin": "synthetic_test", "session_id": session_id, "device_id": device_id,
                "experiment_mode": mode, "scenario_id": scenario_id, "context_id": ctx,
                "boot_id": boot_id, "packet_seq": seq, "device_millis": ms,
                "timestamp_utc": (T0 + timedelta(seconds=5 * seq)).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
                "timestamp_source": "host_receipt", "sf": sf, "tp_dbm": tp,
                "bandwidth_hz": TEST_BW_HZ, "coding_rate_denominator": 5,
                "channel_freq_hz": TEST_FREQ_HZ, "payload_bytes": 20,
                "rssi_dbm": "" if fail else -90 - 5 * ci, "snr_db": "" if fail else 8 - 4 * ci,
                "link_measurement_source": "none" if fail else "gateway_uplink",
                "retry_count": 3 if fail else 0, "attempts": 4 if fail else 1,
                "packet_success": 0 if fail else 1, "rx_confirmed": "",
                "ack_rx_millis": "" if fail else ms + int(latency),
                "latency_ms": "" if fail else latency, "airtime_ms": "",
                "tx_energy_mj": "", "energy_source": "not_measured", "energy_window_ms": "",
                "notes": "SYNTHETIC test row - not a measurement",
            })
            seq += 1
    return rows


def write_log(path, rows=None, **kw) -> Path:
    rows = make_rows(**kw) if rows is None else rows
    path = Path(path)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=REAL_ALL_COLUMNS)
        w.writeheader()
        w.writerows(rows)
    return path
