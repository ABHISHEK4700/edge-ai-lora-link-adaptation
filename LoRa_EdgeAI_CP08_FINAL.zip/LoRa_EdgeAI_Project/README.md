# Lightweight Edge-AI Based Adaptive Spreading Factor and Transmission Power Optimization for LoRa End Devices Under Dynamic Channel Conditions

**Type:** 3rd-Year ECE Final Year Project
**Status:** Checkpoint 7 — Model Comparison & Selection Framework
(no real data collected; no research model trained; final model selection: TBD — to be determined using real data and ESP32 deployment measurements.)

---

## 1. Project Overview

LoRa (Long Range) end devices must choose two key radio parameters for every
transmission:

- **Spreading Factor (SF)** — trades data rate for range/robustness (SF7–SF12)
- **Transmission Power (TP)** — trades energy consumption for link reliability

Today, most LoRa/LoRaWAN deployments pick these using static configuration or
the standard **ADR (Adaptive Data Rate)** algorithm, which reacts slowly and
does not use short-term contextual information well.

This project explores whether a **lightweight, edge-deployable machine
learning model** can learn to predict a good (SF, TP) pair directly on the
end device, using recent link-quality history, so that the device adapts
faster and more efficiently to changing channel conditions (fading, mobility,
interference, distance changes) than static/ADR approaches.

### Inputs (features) the model will eventually use
- **RSSI** (Received Signal Strength Indicator)
- **SNR** (Signal-to-Noise Ratio)
- **Packet success/failure history** (recent delivery outcomes)
- **Retry count** (how many retransmissions were needed)

### Outputs (targets) the model will eventually predict
- **Spreading Factor (SF)**
- **Transmission Power (TP)**

The SF and TX-power *ranges* are deliberately not fixed yet: they depend on
the final SX1278 breakout board and on the regional spectrum configuration,
neither of which is confirmed. See `experiments/LABELING_STRATEGY.md` for how
these targets are derived from measured evidence rather than copied from the
logged configuration column.

### Target deployment
The final trained model is intended to run **locally on an ESP32**
(paired with a LoRa radio module — planned hardware: **SX1278, 433 MHz
band**) as a lightweight on-device inference engine (e.g. via TensorFlow
Lite Micro or a hand-rolled decision function), so the device can make
SF/TP decisions without relying on a network server.

---

## 2. Current Scope — through Checkpoint 8

> ### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Checkpoint 4 built and ran an end-to-end Decision Tree training and
> evaluation pipeline. Checkpoint 5 added a second lightweight candidate,
> Logistic Regression, and Checkpoint 6 added a third, a deliberately small
> Random Forest — each trained on the identical dataset/features/targets,
> plus software-level comparisons between them. Checkpoint 7 added a
> configurable comparison-and-selection **framework** over those three
> candidates. All ran against **fabricated test-fixture data only**. No claim about real LoRa
> communication, packet delivery ratio, latency, energy consumption or
> adaptation speed is supported by any of it, and no model is shown to be
> better than any other — see `experiments/CP05_SOFTWARE_VALIDATION_RUN.md`
> `experiments/CP06_SOFTWARE_VALIDATION_RUN.md` and
> `experiments/CP07_MODEL_COMPARISON_FRAMEWORK_RUN.md`.
>
> ### CHECKPOINT 8 ADDED READINESS SOFTWARE — NOT DATA
>
> Checkpoint 8 (CP08) built the schema, validator, adapter, logger, experiment
> configurations and readiness report that real ESP32 + LoRa measurements will
> need (`ml/collection/`). **No real hardware measurement has been collected.**
> Everything CP08 ran uses clearly-marked **synthetic software-test data**
> (`data_origin = synthetic_test`), which is never written into `data/`. **Future
> real hardware measurements** are what will eventually fill `data/raw/`; until
> then there is no real PDR, latency, energy or RSSI/SNR result and no model-superiority
> claim of any kind. External/public LoRa datasets are not used and stay excluded.

**The project does NOT yet contain:**
- Any collected LoRa measurement data (`data/` is still empty — Checkpoint 8
  built the machinery to receive it, not the data)
- Any external or public LoRa dataset (none is used, and none may be added)
- A research model — nothing trained on real data
- ESP32 firmware or on-device inference code (CP08 only specifies the logging
  contract the firmware must meet: `experiments/FIRMWARE_LOGGING_SPEC.md`)
- Any research results, benchmarks, or performance numbers
- Any model family beyond Decision Tree, Logistic Regression and the small
  Random Forest
- Any exported/quantized model, or any measurement of how large or fast a
  model is on an ESP32
- **A selected model.** Final model selection is **TBD — to be determined using real data and ESP32 deployment measurements.**

**The project DOES contain:**
- Full project scaffolding and documentation *(Checkpoint 1)*
- A defined raw/processed data schema and a working preprocessing pipeline
  *(Checkpoint 2)*
- A documented data collection methodology *(Checkpoint 2, extended in
  Checkpoint 3)*
- A target-label strategy and a configurable labeling framework
  *(Checkpoint 3)* — how a "correct" (SF, TP) target is derived from
  measured link evidence
- **A working Decision Tree training and evaluation pipeline**
  *(Checkpoint 4)* — `ml/training/train_decision_tree.py` and
  `ml/evaluation/`, with model saving, metadata reporting, and a
  causality/leakage guard.
- **A working Logistic Regression training pipeline and a Decision-Tree
  comparison** *(Checkpoint 5)* — `ml/training/train_logistic_regression.py`
  and `ml/evaluation/compare_models.py`, using the SAME dataset, features
  and targets as Checkpoint 4. Verified against synthetic test-only data;
  **software validation only, no superiority claim between the two models**
- **A working small Random Forest training pipeline and a three-model
  comparison** *(Checkpoint 6)* — `ml/training/train_random_forest.py`,
  `ml/evaluation/timing.py` and `ml/evaluation/compare_candidates.py`, using
  the SAME dataset, preprocessing, labeling, features, split and leakage
  guards as Checkpoints 4 and 5. The forest is small by construction
  (configurable, conservative defaults, plus a guard against accidentally
  training a large one), its saved model is reloaded and its training
  reproduced as verification stages, and it is compared against the other two
  models on an identical held-out split. Verified against synthetic test-only
  data; **software validation only, no superiority claim between any of the
  three models**
- **A model comparison and selection framework** *(Checkpoint 7)* —
  `ml/evaluation/resource_profile.py`, `ml/evaluation/context_stability.py`,
  `ml/evaluation/decision_framework.py` and
  `ml/evaluation/generate_comparison_report.py`. It reports predictive
  performance (SF and TX-power metrics, confusion matrices), resource
  characteristics (training time, inference time, serialized size, model
  complexity, desktop-proxy embedded-suitability labels) and reproducibility
  inputs for the three candidates, scores them on six configurable factors,
  and **never selects a winner**: the report separates "SYNTHETIC
  SOFTWARE-VALIDATION RESULTS" from "REAL HARDWARE RESULTS — NOT YET
  AVAILABLE", and the selection status is fixed to TBD. It exists so the
  same comparison can be rerun, unchanged, once real ESP32 + LoRa data and
  on-device measurements exist.
- **Real-data collection readiness** *(Checkpoint 8)* — the package
  `ml/collection/`, three documents (`experiments/REAL_DATA_SCHEMA.md`,
  `experiments/EXPERIMENT_PROCEDURE.md`, `experiments/FIRMWARE_LOGGING_SPEC.md`)
  and four JSON templates in `experiments/configs/`. It defines a 31-column
  real-data schema (a strict superset of the CP02 raw schema), a per-session
  manifest, `sweep` / `baseline` / `edge_ai` experiment configurations, a
  validator with a provenance gate, an adapter that converts validated real logs
  into the CP02 raw format so CP02-CP07 run **unmodified**, a checksummed
  serial-log protocol with an append-safe logger, collection-budget arithmetic,
  and a readiness report. Key guards:
  - **No region or radio value is assumed.** Every hardware-dependent value is
    `UNSET` in the templates and strict validation refuses while any remains
    (129 across the four templates today); nothing is hard-coded to EU868 or any
    other band.
  - **The survivorship-bias guard.** The CP02 cleaner deletes rows with no
    RSSI/SNR, which on real data means most failed packets; the adapter requires
    an explicit missing-link policy, reports what it filled or dropped, and
    refuses if failures existed and none survive.
  - **Training/evaluation separation.** Only `sweep` sessions can become training
    data; `baseline` and `edge_ai` sessions are evaluation-only.
  - **Synthetic data is never accepted as real**, and metadata (environment,
    scenario, distance, energy, latency, provenance) is never a model feature.
  - **No premature claims.** A fixed claims policy and a pre-declared analysis
    plan forbid any statement that Edge-AI improves packet delivery ratio,
    latency or energy until real measurements support it.

  Verified by 27 CP08 checks against **synthetic software-test data only** — see
  `PROJECT_STATUS.md` section 3 for exactly what was and was not verified.

See `PROJECT_STATUS.md` for the detailed project status and `CHANGELOG.md`
for a checkpoint-by-checkpoint record.

---

## 3. Project Structure

```
LoRa_EdgeAI_Project/
├── README.md              # This file
├── PROJECT_STATUS.md       # Detailed status, decisions, and continuation notes
├── CHECKPOINT_PROGRESS.md  # Working log of the Checkpoint 8 completion session and backup snapshots
├── CHANGELOG.md            # Checkpoint-by-checkpoint change log
├── requirements.txt         # Python dependencies for the current checkpoint
├── data/
│   ├── raw/                # Raw LoRa link-quality data — schema defined, no real data yet
│   ├── processed/          # Cleaned/feature-engineered data — no real data yet
│   └── sample/             # Small illustrative samples, once real data exists (empty for now)
├── ml/
│   ├── preprocessing/      # Data cleaning & feature engineering pipeline (implemented, Checkpoint 2)
│   │   ├── schema.py             # Raw/processed data schema definitions
│   │   ├── clean.py              # Raw CSV loading + validation
│   │   ├── feature_engineering.py # Rolling "history" feature computation
│   │   └── pipeline.py           # CLI entry point tying it all together
│   ├── labeling/           # Target-label framework (implemented, Checkpoint 3)
│   │   ├── config.py             # LabelingConfig — every tunable knob
│   │   ├── context.py            # Groups packets into comparable channel contexts
│   │   ├── reliability.py        # Reliability estimation from finite samples
│   │   ├── airtime.py            # LoRa time-on-air formula
│   │   ├── energy.py             # Pluggable energy cost models
│   │   ├── oracle.py             # Evidence table + label selection
│   │   ├── labeler.py            # CLI entry point
│   │   ├── labeling_config.example.json  # Starting config file
│   │   └── README.md             # Documents every configurable knob
│   ├── training/           # Model training (Checkpoint 4, extended Checkpoint 5)
│   │   ├── dataset.py                     # Feature assembly, leakage guard, context split (shared)
│   │   ├── train_decision_tree.py         # CP4: trains + saves + reports metadata
│   │   ├── train_logistic_regression.py   # CP5: trains + saves + reports metadata
│   │   ├── train_random_forest.py         # CP6: small forest; validates config, saves, reloads, reproduces, reports
│   │   └── README.md                      # Causality, splitting rules, model choices
│   ├── evaluation/         # Model evaluation (Checkpoint 4, extended in Checkpoints 5-7)
│   │   ├── metrics.py            # Metrics + the synthetic-data banner (shared)
│   │   ├── evaluate.py           # CP4: standalone evaluation + report generation (model-family-agnostic)
│   │   ├── compare_models.py     # CP5: Decision Tree vs. Logistic Regression comparison report (unchanged)
│   │   ├── timing.py             # CP6: one shared inference-timing harness
│   │   ├── compare_candidates.py # CP6: Decision Tree vs. Logistic Regression vs. Random Forest report
│   │   ├── resource_profile.py   # CP7: resource-only view + desktop-proxy embedded-suitability labels
│   │   ├── context_stability.py  # CP7: per-held-out-context accuracy (stability factor), no retraining
│   │   ├── decision_framework.py # CP7: six-factor scoring; select_candidate() always returns TBD
│   │   └── generate_comparison_report.py # CP7: full report (A synthetic / B real hardware / C framework)
│   ├── collection/         # Real-data collection READINESS (Checkpoint 8) — no real data exists
│   │   ├── real_schema.py        # 31-column real-data schema; superset of the CP02 raw schema
│   │   ├── manifest.py           # Per-session manifest: hardware, radio config, conditions (UNSET until real)
│   │   ├── experiment_config.py  # sweep / baseline / edge_ai configs, arm parity, claims policy
│   │   ├── validator.py          # Validates a real log CSV; provenance gate; sweep coverage
│   │   ├── adapter.py            # Real log -> CP02 raw CSV (explicit purpose + missing-link policy)
│   │   ├── planner.py            # Collection-budget arithmetic (planning, not measurement)
│   │   ├── logger.py             # Checksummed serial-line protocol + append-safe session logger
│   │   ├── readiness.py          # "Software ready?" vs "collection ready?" report
│   │   ├── _util.py              # UNSET marker and find_unset()
│   │   └── README.md             # Module map, quick start, guards
│   ├── models/             # Saved models — empty; see ml/models/README.md
│   └── export/             # Model export (e.g. TFLite conversion) for ESP32 (not started)
├── experiments/
│   ├── DATA_COLLECTION_PLAN.md # Data collection methodology (Checkpoint 2, extended in 3)
│   ├── LABELING_STRATEGY.md    # Why/how SF+TP labels are derived (Checkpoint 3)
│   ├── CP04_SOFTWARE_VALIDATION_RUN.md # Record of one Decision Tree run (Checkpoint 4)
│   ├── CP05_SOFTWARE_VALIDATION_RUN.md # Record of one DT-vs-LR comparison run (Checkpoint 5)
│   ├── CP06_SOFTWARE_VALIDATION_RUN.md # Record of one three-model comparison run (Checkpoint 6)
│   ├── CP07_MODEL_COMPARISON_FRAMEWORK_RUN.md # Record of one framework report run (Checkpoint 7)
│   ├── REAL_DATA_SCHEMA.md     # Real-data schema, generated from code (Checkpoint 8)
│   ├── EXPERIMENT_PROCEDURE.md # Sweep / baseline / Edge-AI procedure and analysis plan (Checkpoint 8)
│   ├── FIRMWARE_LOGGING_SPEC.md # Contract future ESP32 firmware must meet (Checkpoint 8; no firmware exists)
│   └── configs/                # UNSET-filled JSON templates: sweep, baseline, edge_ai, session manifest (Checkpoint 8)
├── esp32/                  # ESP32 firmware / on-device inference code (not started)
└── tests/
    ├── test_environment.py          # Verifies Python + ML library environment (Checkpoint 1)
    ├── test_preprocessing.py        # Verifies preprocessing pipeline against synthetic fixture (Checkpoint 2)
    ├── test_labeling.py             # Verifies labeling framework against synthetic fixture (Checkpoint 3)
    ├── test_training.py             # Verifies Decision Tree training/evaluation pipeline (Checkpoint 4)
    ├── test_logistic_regression.py  # Verifies Logistic Regression training + comparison pipeline (Checkpoint 5)
    ├── test_random_forest.py        # Verifies small Random Forest training + three-way comparison pipeline (Checkpoint 6)
    ├── test_model_comparison_framework.py # Verifies the comparison/selection framework (Checkpoint 7)
    ├── test_real_data_collection.py # Verifies the collection-readiness package, 27 checks (Checkpoint 8)
    └── fixtures/              # Synthetic, clearly-labeled test-only data (incl. make_cp08_synthetic_log.py)
```

Every currently-empty directory contains a `.gitkeep` placeholder file so the
folder structure survives copying/zipping/uploading to git or a new machine.

---

## 4. Setup Instructions

### 4.1 Prerequisites
- Python 3.9–3.11 (recommended)
- `pip`
- (Optional but recommended) a virtual environment tool such as `venv`

### 4.2 Create and activate a virtual environment

```bash
# From inside the LoRa_EdgeAI_Project/ folder
python3 -m venv venv

# Activate it:
# On Linux / macOS:
source venv/bin/activate
# On Windows (PowerShell):
venv\Scripts\Activate.ps1
```

### 4.3 Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4.4 Verify the environment

Run the environment test script:

```bash
python tests/test_environment.py
```

This will check:
- The Python version in use
- That `numpy`, `pandas`, and `scikit-learn` import correctly
- That basic array/DataFrame operations and a tiny scikit-learn model fit
  correctly (a sanity check, not a real model)

If all checks pass you will see `ALL CHECKS PASSED` printed at the end and
the script will exit with code `0`. If anything fails, the script prints
which check failed and exits with a non-zero code.

---

## 5. How to Run

### Checkpoint 1 — environment verification

```bash
python tests/test_environment.py
```

### Checkpoint 2 — preprocessing pipeline

As of Checkpoint 2, `data/raw/` contains **no real data yet** (see
`experiments/DATA_COLLECTION_PLAN.md`). What exists now is the pipeline
itself, verified against a synthetic test fixture:

```bash
# Verify the pipeline logic against synthetic test-only data
python tests/test_preprocessing.py

# Once real raw data exists in data/raw/ (future work), run it through the
# pipeline like this:
python -m ml.preprocessing.pipeline \
    --input data/raw/<session_id>.csv \
    --output data/processed/<session_id>_processed.csv
```

See `data/raw/README.md` for the required raw CSV schema and
`data/processed/README.md` for what the pipeline adds.

### Checkpoint 3 — labeling framework

**Read `experiments/LABELING_STRATEGY.md` before using any of this.** It
explains why the logged `sf`/`tp_dbm` columns cannot be used as training
labels, what is used instead, and what the data collection protocol must
guarantee for the result to be valid.

```bash
# Verify the labeling framework against synthetic test-only data
python tests/test_labeling.py

# Inspect the effective labeling configuration
python -m ml.labeling.labeler --print-config

# Write a fresh config file to edit
python -m ml.labeling.labeler --write-default-config my_labeling_config.json

# Once real processed data exists (future work), derive labels like this:
python -m ml.labeling.labeler \
    --input data/processed/<session_id>_processed.csv \
    --output data/processed/<session_id>_labeled.csv \
    --config ml/labeling/labeling_config.example.json
```

That produces three files: the labeled per-packet rows, plus
`_oracle.csv` (the measured evidence behind every label, so any label can be
traced back to packet counts) and `_labels.csv` (one label per channel
context).

`ml/labeling/README.md` documents every configurable knob — reliability
threshold, candidate SF/TX-power sets, energy method, tie-breaking, and
no-valid-configuration handling are all settable from the config file.

### Checkpoint 4 — Decision Tree training & evaluation

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.** These
> commands run against fabricated fixture data. Read
> `experiments/CP04_SOFTWARE_VALIDATION_RUN.md` section 6 before quoting any
> number they produce.

```bash
# Verify the training/evaluation pipeline against synthetic test-only data
python tests/test_training.py

# Run the full chain end to end
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv \
    --output /tmp/proc.csv
python -m ml.labeling.labeler --input /tmp/proc.csv --output /tmp/lab.csv
python -m ml.training.train_decision_tree --input /tmp/lab.csv --outdir ml/models
python -m ml.evaluation.evaluate \
    --model ml/models/decision_tree_sf_tp.joblib \
    --input /tmp/lab.csv \
    --metadata ml/models/decision_tree_sf_tp_metadata.json \
    --report /tmp/report.md
```

The training step records tree depth, node and leaf counts, model file size,
training time, inference time, and evaluation metrics — all stamped with the
synthetic-data banner. `ml/training/README.md` explains the two rules the
pipeline enforces: **causality** (no feature that is unknowable before
transmitting) and **context-aware splitting** (the effective sample size is
the number of contexts, not the number of rows).

### Checkpoint 5 — Logistic Regression & Decision Tree comparison

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.** These
> commands run against the same fabricated fixture data as Checkpoint 4.
> Read `experiments/CP05_SOFTWARE_VALIDATION_RUN.md` section 4 before
> quoting any number they produce — in particular, nothing here shows one
> model is better than the other.

```bash
# Verify the Logistic Regression + comparison pipeline against synthetic test-only data
python tests/test_logistic_regression.py

# Run the full chain end to end (reusing the Checkpoint 4 chain up to labeling)
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv \
    --output /tmp/proc.csv
python -m ml.labeling.labeler --input /tmp/proc.csv --output /tmp/lab.csv
python -m ml.training.train_decision_tree --input /tmp/lab.csv --outdir ml/models
python -m ml.training.train_logistic_regression --input /tmp/lab.csv --outdir ml/models
python -m ml.evaluation.compare_models \
    --dt-model ml/models/decision_tree_sf_tp.joblib \
    --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \
    --lr-model ml/models/logistic_regression_sf_tp.joblib \
    --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \
    --input /tmp/lab.csv \
    --report /tmp/comparison_report.md
```

Logistic Regression uses the identical dataset, the identical 8 causal
rolling-history features, and the identical (SF, TP) label framework as the
Decision Tree — only the model family differs. Because Logistic Regression
is scale-sensitive, each target's model is an `sklearn.Pipeline` of
`(StandardScaler, LogisticRegression)`, with the scaler fit on the training
split only. `ml/evaluation/compare_models.py` evaluates both saved bundles
on an *identical* held-out split and reports predictive metrics, model file
size, training time and inference time side by side, refusing to compare
bundles trained on different feature sets, and stamping every generated
report with an explicit statement that neither model is shown to be better
than the other on this synthetic data.

### Checkpoint 6 — small Random Forest & three-model comparison

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.** These
> commands run against the same fabricated fixture data as Checkpoints 4 and
> 5. Read `experiments/CP06_SOFTWARE_VALIDATION_RUN.md` before quoting any
> number they produce — in particular, nothing here shows any model is
> better than another, and nothing here says anything about ESP32 size or
> speed.

```bash
# Verify the Random Forest + three-way comparison pipeline against synthetic test-only data
python tests/test_random_forest.py

# Run the full chain end to end (reusing the earlier chain up to labeling)
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv \
    --output /tmp/proc.csv
python -m ml.labeling.labeler --input /tmp/proc.csv --output /tmp/lab.csv
python -m ml.training.train_decision_tree       --input /tmp/lab.csv --outdir ml/models
python -m ml.training.train_logistic_regression --input /tmp/lab.csv --outdir ml/models
python -m ml.training.train_random_forest       --input /tmp/lab.csv --outdir ml/models
python -m ml.evaluation.compare_candidates \
    --dt-model ml/models/decision_tree_sf_tp.joblib \
    --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \
    --lr-model ml/models/logistic_regression_sf_tp.joblib \
    --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \
    --rf-model ml/models/random_forest_sf_tp.joblib \
    --rf-metadata ml/models/random_forest_sf_tp_metadata.json \
    --input /tmp/lab.csv \
    --report /tmp/comparison_report_3way.md

# Change the forest's size (every important hyperparameter is configurable)
python -m ml.training.train_random_forest --input /tmp/lab.csv --no-save \
    --n-estimators 6 --max-depth 4 --min-samples-leaf 10 --max-features 0.5
```

The forest uses the identical dataset, the identical 8 causal rolling-history
features (RSSI, SNR, packet success/failure history, retry count — no GPS,
distance or other experimental metadata) and the identical (SF, TP) label
framework as the other two models, and the trainer does not accept a
caller-supplied feature list, so the feature set cannot drift.

**It is deliberately small.** Defaults are 10 trees, `max_depth=5`,
`min_samples_leaf=5`, `max_features="sqrt"`; a small-forest guard rejects more
than 30 trees, depth above 10, or unlimited depth unless `--allow-large-forest`
is passed, so scikit-learn's default 100-tree unlimited-depth forest cannot be
trained by accident. Those guard limits are project-chosen placeholders, not
measured ESP32 limits. The forest is not tuned.

The pipeline is `dataset -> preprocessing -> labeling -> same context split ->
train -> evaluate -> save -> reload and verify -> reproducibility check`. The
last two are pipeline stages, not just tests: a saved model that does not
match the in-memory one after reload, or a retrain that does not reproduce the
first, raises an error and removes the model file. Out-of-bag scoring is
deliberately not used (it would be optimistic on context-grouped data).

`ml/evaluation/compare_candidates.py` scores all three saved models on an
*identical* held-out split (and asserts it was identical), refuses to compare
models trained on different features, re-measures inference time with one
shared harness for both the SF and TX-power models, and stamps every report
with the synthetic banner and an explicit statement that no model is shown to
be better than any other. `compare_models.py` (Checkpoint 5) is unchanged.

### Checkpoint 7 — model comparison & selection framework

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.** These
> commands run against the same fabricated fixture as Checkpoints 4-6. Read
> `experiments/CP07_MODEL_COMPARISON_FRAMEWORK_RUN.md` before quoting any
> number they produce. Nothing here selects a model, and nothing here is a
> hardware result.

```bash
# Verify the comparison framework against synthetic test-only data
python tests/test_model_comparison_framework.py

# Train the three candidates exactly as in Checkpoint 6, then generate the report
python -m ml.evaluation.generate_comparison_report \
    --dt-model ml/models/decision_tree_sf_tp.joblib \
    --dt-metadata ml/models/decision_tree_sf_tp_metadata.json \
    --lr-model ml/models/logistic_regression_sf_tp.joblib \
    --lr-metadata ml/models/logistic_regression_sf_tp_metadata.json \
    --rf-model ml/models/random_forest_sf_tp.joblib \
    --rf-metadata ml/models/random_forest_sf_tp_metadata.json \
    --input /tmp/lab.csv \
    --report /tmp/comparison_framework_report.md \
    --json /tmp/comparison_framework_result.json
```

The generated report has three separated parts:

- **A. SYNTHETIC SOFTWARE-VALIDATION RESULTS** — SF and TX-power accuracy,
  macro F1, majority-class baselines, joint exact match, consistency across
  held-out contexts, confusion matrices, training time, inference time,
  serialized model size, tree/node and fitted-parameter counts,
  desktop-proxy embedded-suitability labels, and the reproducibility inputs (same dataset, preprocessing,
  labeling, 8 causal features, context-aware split, seeds).
- **B. REAL HARDWARE RESULTS — NOT YET AVAILABLE** — a fixed placeholder
  that contains no numbers, because no ESP32 + SX1278 hardware has been used.
- **C. Decision Framework** — six factors (predictive performance, model size,
  inference latency, memory requirements, embedded feasibility,
  stability/generalisation), each normalised across the candidates in the run,
  and the fixed status **TBD — to be determined using real data and ESP32 deployment measurements.**

Configurable parts (Python API; the command line exposes only
`--include-illustrative-scores`, `--test-size` and `--random-state`):
`FactorWeights` in `ml/evaluation/decision_framework.py` (relative importance
of the six factors) and `SuitabilityThresholds` in
`ml/evaluation/resource_profile.py` (where "compact / moderate / large" and
"fast / moderate / slow" lines fall). Neither can make the framework select a
model — `select_candidate()` returns the fixed TBD status under every
configuration, and a test asserts it. The size, latency and "embedded
suitability" figures are **desktop scikit-learn proxies, not ESP32
measurements**.

### Checkpoint 8 — real-data collection readiness

> **NO REAL DATA EXISTS.** These commands check the *software* and the templates.
> The tests use clearly-marked **synthetic software-test data** generated in a
> temporary directory; none of it is a measurement, and nothing is written to
> `data/`. Read `ml/collection/README.md` first.

```bash
# Verify the collection package (27 checks; also re-runs all seven earlier suites)
python tests/test_real_data_collection.py

# Is the software ready, and what still blocks a REAL run? (every template value is UNSET today)
python -m ml.collection.readiness

# Strictly check a manifest and experiment config once you have filled them in
python -m ml.collection.readiness --manifest m.json --config sweep.json

# Once real firmware exists and real logs are captured (future work):
python -m ml.collection.logger --manifest m.json --out data/raw/<session>.csv --input capture.txt
```

Converting a validated real log for the unchanged CP02 pipeline needs two explicit
decisions, with no defaults — `purpose` (`training` accepts only `sweep` sessions;
`evaluation` accepts only `baseline` / `edge_ai`) and a missing-link policy (to avoid
survivorship bias, see `ml/collection/README.md`). Use
`ml.collection.adapter.to_cp02_raw(...)`; its report states what was filled or dropped.
The procedure for actually collecting data is `experiments/EXPERIMENT_PROCEDURE.md`, the
firmware contract is `experiments/FIRMWARE_LOGGING_SPEC.md`, and the column definitions are
`experiments/REAL_DATA_SCHEMA.md`.

Future checkpoints will add real run instructions for model optimization and ESP32
deployment; real data collection itself still has to be carried out on hardware.

---

## 6. Roadmap (high level, for context only)

1. **Checkpoint 1 (done):** Project foundation & environment setup
2. **Checkpoint 2 (done):** Data schema, preprocessing pipeline, and data
   collection methodology — no real data collected yet
3. **Checkpoint 3 (done):** Target-label strategy & labeling framework — no
   model trained
4. **Checkpoint 4 (done):** Decision Tree training/evaluation pipeline —
   **software validation only**, synthetic data, no research model
5. **Checkpoint 5 (done):** Logistic Regression as a second candidate + a
   software-level comparison with the Decision Tree — **software validation
   only**, synthetic data, no research model, no superiority claim
6. **Checkpoint 6 (done):** Small Random Forest as the third
   candidate + a three-way software-level comparison — **software validation
   only**, synthetic data, no research model, no superiority claim
7. **Checkpoint 7 (done):** Model comparison and selection framework over
   the three candidates — **software validation only**, synthetic data, no
   winner declared, final selection TBD
8. **Checkpoint 8 (done — readiness only):** Real-data collection *readiness*:
   schema, manifest, experiment configurations, validator, adapter, logger,
   firmware logging contract, procedure and readiness report in
   `ml/collection/` — verified on synthetic software-test data only. **No real
   hardware data has been collected.** What remains of the original
   "collect real data, retrain all three models, rerun the Checkpoint 7 framework
   on real data, evaluate honestly" is future work on real hardware; everything
   downstream is still blocked on it.
9. **Checkpoint 9 (future, NOT started):** Model optimization/quantization for
   edge deployment. Its scope has not been confirmed with the user, and it is
   premature before real data exists.
10. **Checkpoint 10 (future):** ESP32 integration & on-device testing
11. **Checkpoint 11 (future):** Field/dynamic-channel evaluation & final report

> *Renumbering note:* real hardware data collection was "Checkpoint 6" in the
> Checkpoint 5 documents. Checkpoint 6 was then explicitly redefined to be
> the Random Forest work, and Checkpoint 7 was then explicitly redefined to be
> the model comparison and selection framework above, so hardware data
> collection and everything after it moved down by one each time. If someone
> refers to a checkpoint by number, check which numbering they mean.

Exact checkpoint boundaries are defined by the course/project supervisor and
may change; see `PROJECT_STATUS.md` for the authoritative "next checkpoint"
note.

---

## 7. Continuing This Project With a Different AI Assistant Session

If you are picking this project up in a new Claude conversation (e.g. after
running out of tokens), **read `PROJECT_STATUS.md` first**. It is written
specifically to let a new assistant session understand exactly what exists,
what doesn't, and what to do next without needing the original conversation.
`CHECKPOINT_PROGRESS.md` is a shorter working log of how Checkpoint 8 was
completed, including which backup snapshots exist.
