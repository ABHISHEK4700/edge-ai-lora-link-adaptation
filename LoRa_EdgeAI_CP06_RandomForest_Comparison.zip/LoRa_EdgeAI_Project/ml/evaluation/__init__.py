"""
ml.evaluation — Checkpoint 4: model evaluation. Checkpoint 5:
Decision-Tree-vs-Logistic-Regression comparison (ml/evaluation/compare_models.py).
Checkpoint 6: a shared inference-timing harness (ml/evaluation/timing.py) and
an N-way comparison of the three candidates — Decision Tree, Logistic
Regression, small Random Forest (ml/evaluation/compare_candidates.py).

Every report produced by this package carries the SYNTHETIC_BANNER from
ml/evaluation/metrics.py, because as of Checkpoint 6 all metrics still come
from fabricated test-fixture data and measure only that the software runs.
compare_models.py and compare_candidates.py additionally carry an explicit
no-superiority-claim in every report they generate — see those modules'
docstrings.
"""
