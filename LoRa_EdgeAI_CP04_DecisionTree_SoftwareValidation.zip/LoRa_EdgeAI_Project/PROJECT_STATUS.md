# PROJECT STATUS

Last updated: Checkpoint 4 — Decision Tree Software Validation
This file is the single source of truth for project state. Read this file
fully before doing any new work, especially if you are a new AI assistant
session with no memory of prior conversations.

---

## 1. Project Objective

Build a **lightweight, edge-deployable machine learning system** that
predicts good **Spreading Factor (SF)** and **Transmission Power (TP)**
settings for a LoRa end device, using:

- RSSI
- SNR
- packet success/failure history
- retry count

as input features, so the device can adapt faster to dynamic channel
conditions (fading, interference, mobility, distance changes) than static
configuration or standard ADR. The trained model is ultimately meant to run
**locally on an ESP32** microcontroller paired with a LoRa radio module.

This is a 3rd-year ECE final year project, developed in checkpoints. Each
checkpoint is reviewed before the next one begins.

---

## 2. Current Checkpoint

**Checkpoint 4 — Decision Tree Training/Evaluation Pipeline
(SOFTWARE VALIDATION ONLY)**

### 2.1 Checkpoint state at a glance

| Checkpoint | State |
|---|---|
| **CP01 — Project foundation / scaffolding** | **COMPLETE** |
| **CP02 — Data schema & preprocessing pipeline** | **COMPLETE** |
| **CP03 — Target-label strategy & labeling framework** | **COMPLETE** |
| **CP04 — Decision Tree software validation** | **COMPLETE** |
| **Real hardware data collection** | **NOT YET DONE — `data/` is empty** |
| **Final research model** | **NOT YET TRAINED** |

### 2.2 What Checkpoint 4 is, and is not

> #### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Checkpoint 4 built the first end-to-end training and evaluation pipeline
> and ran it against **fabricated test-fixture data only**. It demonstrates
> that eight pipeline stages connect, that the context split holds, and that
> a model saves and reloads. It demonstrates **nothing else**.
>
> Specifically it does NOT show improved packet delivery ratio, improved
> latency, improved energy consumption, or faster adaptation than ADR; and
> the model is NOT validated for real LoRa communication. The fixture is
> trivially separable by construction, so its near-perfect scores are the
> expected outcome of a correctly wired pipeline and are not evidence of
> anything about LoRa or about this project's hypothesis.

The pipeline built this checkpoint:

```
sample CSV -> preprocessing (CP2) -> label generation (CP3)
           -> context-aware train/test split -> Decision Tree
           -> prediction -> evaluation -> save model -> metadata report
```

**Scope constraints the user set, and how each was met:**

| Constraint | How it was honoured |
|---|---|
| Software pipeline validation only | Every generated report, the metadata JSON, `README.md`, and this file carry the banner; `explicit_non_claims` is a required metadata field asserted by a test |
| No synthetic performance as research results | `experiments/CP04_SOFTWARE_VALIDATION_RUN.md` states in its preamble that 1.0000 accuracy is expected and is not a finding |
| No claim of validation for real LoRa | Stated in the banner, in `ml/models/README.md`, and in report section 6 |
| No PDR / latency / energy / adaptation claims | Each is disclaimed by name; a test asserts every one appears in the report |
| No synthetic accuracy as evidence of success | Disclaimed by name; majority-class baselines and per-context scoring are reported alongside every accuracy so a number can never stand alone |
| Use the project's intended feature set | RSSI, SNR, success/failure history, retry count — in causal (lagged) form |
| No GPS/distance/contextual features | A test scans the feature list for such tokens and fails if any appear |
| Use the CP3 labeling framework for targets | Targets come from `ml.labeling`; no new labels were invented |
| Record depth, nodes, size, timings, metrics | All present in the metadata; a test asserts each field |
| Do not optimize the model heavily | `tuned: False` in metadata, asserted by a test; no hyperparameter search |
| Do not start Logistic Regression / Random Forest | Only `DecisionTreeClassifier` appears anywhere in the codebase |

### 2.3 One thing that had to change

Checkpoint 3's fixture produces exactly **one** labelled context carrying
**one** (SF, TP) pair. That is correct for testing the labeling framework,
but a classifier cannot be trained on a single class and a train/test split
needs more than one group. Checkpoint 4 therefore added a second, larger
fixture (`tests/fixtures/synthetic_pipeline_fixture_raw.csv`): 36 contexts
across 6 hand-written link tiers, 30 of which are labellable across 5 joint
(SF, TP) classes, with the sixth deliberately unlabellable so the pipeline is
exercised on data where contexts must be excluded. The Checkpoint 3 fixture
is unchanged and still used by `tests/test_labeling.py`.

---

## 3. Completed Work

### Checkpoint 1 — Project Foundation / Software Scaffolding

- [x] Created the full project directory structure:
  `data/{raw,processed,sample}`, `ml/{preprocessing,training,evaluation,models,export}`,
  `experiments/`, `esp32/`, `tests/`
- [x] Added `.gitkeep` placeholders in every currently-empty directory so the
  structure survives zipping/uploading/cloning
- [x] Wrote `README.md` — project description, structure, setup, and run
  instructions
- [x] Wrote `PROJECT_STATUS.md` (this file)
- [x] Wrote `CHANGELOG.md` recording Checkpoint 1
- [x] Wrote `requirements.txt` with only the dependencies needed to verify
  the environment at this stage (numpy, pandas, scikit-learn)
- [x] Wrote `tests/test_environment.py`, a minimal script that verifies:
  - Python version
  - `numpy` import + basic array operation
  - `pandas` import + basic DataFrame operation
  - `scikit-learn` import + fitting a trivial model on synthetic
    placeholder numbers (explicitly labeled as a library sanity check, NOT
    project research data)
- [x] Verified the test script runs successfully in the build environment
  (see "Verification performed" below)

### Verification performed during Checkpoint 1
```
python3 tests/test_environment.py
```
Result: all checks passed, exit code 0.

### Checkpoint 2 — Data Schema, Preprocessing Pipeline & Data Collection Plan

- [x] **Data source decision confirmed with user**: real ESP32+LoRa
  hardware data will be collected later; this checkpoint builds the
  pipeline against a defined schema with no data yet (user chose this
  explicitly over a synthetic-data-generator or public-dataset approach
  when asked).
- [x] Defined the raw data schema (`ml/preprocessing/schema.py`,
  `RAW_SCHEMA`) — the exact CSV column contract that future ESP32 logging
  must produce: `timestamp_utc`, `session_id`, `device_id`, `packet_seq`,
  `sf`, `tp_dbm`, `rssi_dbm`, `snr_db`, `retry_count`, `packet_success`,
  plus optional `payload_bytes`, `channel_freq_hz`, `notes`. Each field has
  a type and, where applicable, a valid range or allowed-value set.
- [x] Documented the schema in human-readable form in `data/raw/README.md`.
- [x] Defined the processed-data schema addition (rolling history features)
  in `ml/preprocessing/schema.py` (`processed_feature_columns`) and
  `data/processed/README.md`.
- [x] Implemented the preprocessing pipeline in `ml/preprocessing/`:
  - `clean.py` — loads a raw CSV and validates it against `RAW_SCHEMA`,
    dropping and reporting (not silently keeping) rows with missing
    required fields, out-of-range values, or disallowed values.
  - `feature_engineering.py` — computes rolling "history" features
    (success rate, retry avg, RSSI avg, SNR avg) over the preceding N
    packets (N = 5 and 10 by default) per `(device_id, session_id)`,
    strictly excluding each packet's own outcome from its own history
    (no leakage).
  - `pipeline.py` — orchestrates clean → feature-engineer → write, with a
    CLI (`python -m ml.preprocessing.pipeline --input ... --output ...`)
    and a `run_pipeline()` function for reuse.
- [x] Wrote `experiments/DATA_COLLECTION_PLAN.md` — the data collection
  methodology: planned hardware setup, session naming convention, planned
  channel-condition scenarios (distance, line-of-sight, mobility,
  interference, indoor/outdoor), and explicit open questions that are
  **not** answered with invented values.
- [x] Added `tests/fixtures/synthetic_test_fixture_raw.csv` — a small,
  deliberately-labeled **synthetic** CSV (12 rows, 3 deliberately invalid)
  used only to test the pipeline code, plus `tests/fixtures/README.md`
  explaining this distinction clearly.
- [x] Wrote `tests/test_preprocessing.py` — verifies schema validation
  correctness, rolling feature correctness (including no self-leakage),
  and that the full pipeline runs end-to-end, all against the synthetic
  fixture only, writing outputs to a temp directory (never touching
  `data/processed/`). Also asserts `data/raw/`, `data/processed/`,
  `data/sample/` remain untouched by the test run.
- [x] Updated `README.md` with Checkpoint 2 structure and run instructions.
- [x] Reviewed `requirements.txt` — no new dependencies were needed
  (pandas/numpy, already present, are sufficient for the pipeline).

### Verification performed during Checkpoint 2
```
python3 tests/test_preprocessing.py
python -m ml.preprocessing.pipeline --input tests/fixtures/synthetic_test_fixture_raw.csv --output <temp path>
python -m ml.preprocessing.pipeline --input data/raw/does_not_exist.csv --output <temp path>   # error-path check
python3 tests/test_environment.py   # re-run to confirm Checkpoint 1 still passes unmodified
```
Results: all checks passed (exit code 0); the pipeline correctly kept 9/12
rows and dropped 3 deliberately-invalid rows from the fixture with
accurate drop reasons; the missing-file case failed cleanly with exit code
1 and no output file created; Checkpoint 1's environment test still passes
unmodified.

### Checkpoint 2 — Correction Pass

Requested by the user after reviewing Checkpoint 2, before Checkpoint 3
began. Three corrections, in order:

**1. `numpy` requirement/verification mismatch fixed.**
`requirements.txt` previously pinned `numpy>=1.24,<2.0`, but an earlier
verification run had numpy 2.3.5 actually installed — the declared
requirement and the actually-tested environment didn't match. Root cause:
an ad hoc `pip install numpy pandas scikit-learn` (no version pins) had
been run directly in the build sandbox for earlier testing, bypassing
`requirements.txt` entirely, so the versions verified against didn't
necessarily reflect the pinned range.

Fix: rather than just re-verifying against an arbitrarily older numpy,
the pin was **widened to `numpy>=1.24,<3.0`**, since numpy 2.x is fully
compatible with the pinned pandas/scikit-learn versions here. This was
confirmed properly, not assumed:
- A clean virtual environment was created and `pip install -r
  requirements.txt` was run with no pre-existing packages. This correctly
  resolved to `numpy 1.26.4`, `pandas 2.3.3`, `scikit-learn 1.9.1` — i.e.
  the *old* pin was never actually broken by pip's own resolution.
- `numpy` was then explicitly upgraded in that same clean venv to
  `2.3.5` (the version the user reported), while keeping the
  `requirements.txt`-resolved `pandas 2.3.3` / `scikit-learn 1.9.1`.
- Both `tests/test_environment.py` and `tests/test_preprocessing.py` were
  re-run against **both** version combinations (numpy 1.26.4 and numpy
  2.3.5) — all checks passed, exit code 0, in both cases.
- `requirements.txt`'s numpy upper bound was then widened to `<3.0` so the
  file honestly reflects what has actually been verified to work, instead
  of a narrower range that a real install might silently exceed.

**2. Synthetic fixture frequency corrected to match planned hardware.**
`tests/fixtures/synthetic_test_fixture_raw.csv` had `channel_freq_hz =
915000000` (915 MHz, US ISM band) in every row. The project's planned
hardware is an **SX1278 module (433 MHz band)**, so a reader skimming the
fixture could have been misled into thinking 915 MHz was the real target
band. Fix:
- All 12 rows in the fixture now use `channel_freq_hz = 433000000` (433
  MHz), matching the planned hardware's band. The fixture remains 100%
  synthetic/fabricated data — only the frequency *number* was aligned to
  avoid implying the wrong hardware band; no row was reinterpreted as real
  data.
- `tests/fixtures/README.md` now explicitly explains why 433 MHz was
  chosen for the fixture (consistency with planned hardware) while
  reiterating the fixture is still entirely synthetic.
- `experiments/DATA_COLLECTION_PLAN.md` section 2 (planned hardware setup)
  updated: the radio module is now stated as confirmed (SX1278, 433 MHz)
  rather than "TBD" (only the exact breakout-board vendor part number
  remains an open question, listed in section 6).
- `README.md`'s "Target deployment" paragraph updated from a generic
  "e.g. SX1276/SX1262" example to the confirmed SX1278 (433 MHz) hardware.
- `ml/preprocessing/schema.py`'s `channel_freq_hz` field description and
  `data/raw/README.md`'s schema table both now note the expected ~433 MHz
  band for real future data, for consistency.

**3. Label-construction strategy intentionally NOT decided.**
Per explicit user instruction, this correction pass did **not** design or
decide how a "correct" SF/TP training label will be derived from logged
history. This remains open, deferred to Checkpoint 3, exactly as it was
before this correction pass — see sections 4, 6, and 8. No preprocessing
logic files (`clean.py`, `feature_engineering.py`, `pipeline.py`) were
modified in this correction pass; only documentation, one schema field
description (non-functional, string-only), the fixture's frequency value,
and `requirements.txt` changed.

### Verification performed during the Correction Pass
```
# System Python (numpy 2.4.4 / pandas 3.0.2 / scikit-learn 1.8.0)
python3 tests/test_environment.py
python3 tests/test_preprocessing.py

# Clean venv, requirements.txt exactly as pinned (numpy 1.26.4 / pandas 2.3.3 / scikit-learn 1.9.1)
python tests/test_environment.py
python tests/test_preprocessing.py

# Same clean venv, numpy upgraded to 2.3.5 (matching the version originally reported)
python tests/test_environment.py
python tests/test_preprocessing.py
```
Results: **all checks passed, exit code 0, in every one of the three
version combinations above.** This directly confirms the numpy
requirement/verification mismatch is resolved, and that the fixture and
documentation edits did not break the preprocessing pipeline's behavior
(schema validation still keeps 9/12 rows and drops the same 3 deliberately
invalid ones; rolling features still compute identically, since
`channel_freq_hz` is not used in any feature-engineering calculation).

### Checkpoint 3 — Target-Label Strategy & Labeling Framework

**The core design decision.** The raw logs contain `sf` and `tp_dbm` — the
settings the device was *told* to use. Those are not labels. Training on them
teaches the model to imitate whatever policy generated the logs: a manual
sweep (so it learns noise), standard ADR (so it can at best clone ADR,
defeating the project's premise), or a fixed setting (so it learns a
constant). The label therefore has to be **derived from measured outcomes**.

The strategy adopted is **retrospective best-configuration labeling**: group
packets into channel contexts, and for each context choose, from the
configurations actually measured there, the lowest-energy one whose measured
reliability cleared a configured threshold. The model becomes a compact
approximation of a measured oracle. Full argument, alternatives considered
and limitations: `experiments/LABELING_STRATEGY.md`.

- [x] Wrote `experiments/LABELING_STRATEGY.md` — the design document: the
  problem statement, why logged SF/TP fails, the five-step strategy, the
  requirements it imposes on data collection, the context-definition
  judgement call (including the circularity that RSSI/SNR are partly a
  *consequence* of the configuration), how "nothing worked" is handled, seven
  named limitations, and five alternatives considered and rejected.
- [x] Implemented `ml/labeling/config.py` — `LabelingConfig`, the single
  source of truth for every knob, with validation, JSON round-tripping, and
  `resolve_candidate_configs()` which derives the candidate space from the
  data when nothing is pinned.
- [x] Implemented `ml/labeling/context.py` — four context strategies
  (`session`, `rssi_snr_bin`, `session_rssi_snr_bin`, `explicit_column`).
- [x] Implemented `ml/labeling/reliability.py` — point estimate and Wilson
  score lower bound, so thin evidence cannot win a label by luck.
- [x] Implemented `ml/labeling/airtime.py` — the published LoRa time-on-air
  formula, with bandwidth, coding rate, preamble, header, CRC and
  low-data-rate-optimization all configurable rather than assumed.
- [x] Implemented `ml/labeling/energy.py` — three pluggable energy methods
  (`airtime_only`, `airtime_x_linear_power`, `measured_current_table`) and
  three cost bases (`per_attempt`, `per_success_pdr`,
  `per_success_retries`).
- [x] Implemented `ml/labeling/oracle.py` — `build_oracle_table()` (measured
  evidence per context/SF/TP) and `select_labels()` (one target per context,
  with configurable tie-breaking and no-valid-configuration handling).
- [x] Implemented `ml/labeling/labeler.py` — `run_labeling()`, `attach_labels()`
  and a CLI with `--config`, `--print-config`, `--write-default-config`.
- [x] Added `ml/labeling/labeling_config.example.json` (generated from the
  code defaults, so it cannot drift) and `ml/labeling/README.md` documenting
  every knob.
- [x] Added `tests/fixtures/make_synthetic_labeling_fixture.py` and the
  210-row `synthetic_labeling_fixture_raw.csv` it generates — fully
  deterministic (no RNG), three sessions exercising three distinct code
  paths, expected labels derivable on paper.
- [x] Wrote `tests/test_labeling.py` — 19 checks covering all six required
  configurable items plus the formula, estimator, guard and error paths.
- [x] Extended `experiments/DATA_COLLECTION_PLAN.md` with section 4a (the
  five requirements the labeling strategy imposes on collection) and four new
  open questions in section 6.
- [x] Updated `tests/fixtures/README.md`, `README.md`, this file, and
  `CHANGELOG.md`.
- [x] Reviewed `requirements.txt` — no new dependencies needed. The framework
  uses only pandas/numpy, both already present. The Wilson bound is
  implemented directly from its closed form rather than pulling in scipy.

**Preserved unchanged:** no file from Checkpoint 1 or Checkpoint 2 had its
logic modified. `clean.py`, `feature_engineering.py`, `pipeline.py`,
`schema.py`, `test_environment.py`, `test_preprocessing.py` and
`synthetic_test_fixture_raw.csv` are byte-identical to their Checkpoint 2
state. `tests/fixtures/README.md`, `README.md`,
`experiments/DATA_COLLECTION_PLAN.md`, `PROJECT_STATUS.md` and `CHANGELOG.md`
were appended to, not rewritten.

### Verification performed during Checkpoint 3

```
python3 tests/test_environment.py     # Checkpoint 1 — still passes unmodified
python3 tests/test_preprocessing.py   # Checkpoint 2 — still passes unmodified
python3 tests/test_labeling.py        # Checkpoint 3 — new
python3 -m ml.labeling.labeler --print-config
python3 -m ml.labeling.labeler --input tests/fixtures/synthetic_labeling_fixture_raw.csv --output <temp path>
python3 -m ml.labeling.labeler --input <nonexistent> --output <temp path>   # error path
```

Results: all three test scripts passed with exit code 0. The 19 Checkpoint 3
checks confirmed, among other things, that:
- the time-on-air formula's symbol time doubles per SF step and scales
  inversely with bandwidth;
- the Wilson bound equals exactly `n / (n + z²)` at a 100% delivery ratio and
  increases with sample size at a constant ratio;
- `measured_current_table` refuses an empty table and refuses to extrapolate
  beyond a supplied one, rather than inventing figures;
- in the fixture's context A the cheapest configuration overall is the one
  that fails the reliability threshold, and the labeler correctly rejects it
  in favour of the cheapest configuration that passed — i.e. the reliability
  constraint genuinely binds;
- changing the threshold, the candidate sets, the energy method or the
  tie-break rules each changes the output, so none of them is decorative;
- all four no-valid-configuration policies behave distinctly;
- a context containing a single perfectly-reliable configuration is *not*
  labelled, and relaxing `min_configs_per_context` to 1 is confirmed to be
  what unblocks it;
- tie-breaking is independent of input row order;
- the example config ships with no SF/TP ranges pinned and an empty
  supply-current table;
- `data/raw/`, `data/processed/` and `data/sample/` remain untouched.

### Checkpoint 4 — Decision Tree Training/Evaluation Pipeline

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.**
> Everything below ran against fabricated fixture data.

- [x] Added `tests/fixtures/make_synthetic_pipeline_fixture.py` and the
  6,480-row `synthetic_pipeline_fixture_raw.csv` it generates — fully
  deterministic (no RNG), 6 hand-written link tiers x 6 sessions = 36
  contexts, configurations interleaved round-robin as
  `DATA_COLLECTION_PLAN.md` section 4a requires of real collection. Five
  tiers are labellable across 5 joint (SF, TP) classes; the sixth is
  deliberately unlabellable.
- [x] Implemented `ml/training/dataset.py` — feature assembly, the
  `BANNED_FEATURE_COLUMNS` leakage guard, context-aware splitting via
  `GroupShuffleSplit`, and `DatasetSummary` which reports rows *and*
  contexts so the effective sample size is visible.
- [x] Implemented `ml/training/train_decision_tree.py` — trains two
  `DecisionTreeClassifier`s (one per target), records structure and timings,
  saves a joblib bundle, and writes a metadata JSON.
- [x] Implemented `ml/evaluation/metrics.py` — the `SYNTHETIC_BANNER`,
  per-class precision/recall/F1, confusion matrices, majority-class
  baselines, joint exact-match, and per-context majority-vote scoring.
- [x] Implemented `ml/evaluation/evaluate.py` — loads a saved bundle,
  evaluates it standalone, and renders a banner-stamped Markdown report.
- [x] Added `ml/training/__init__.py`, `ml/evaluation/__init__.py`,
  `ml/training/README.md`, `ml/models/README.md`.
- [x] Wrote `tests/test_training.py` — 17 checks.
- [x] Generated `experiments/CP04_SOFTWARE_VALIDATION_RUN.md`, a committed
  record of one pipeline run, with a preamble stating that its 1.0000
  accuracy is the expected outcome and not a finding.
- [x] Updated `requirements.txt` — added `joblib>=1.2,<2.0`, now imported
  directly rather than relied on as a scikit-learn transitive dependency.
- [x] Updated `README.md`, this file, and `CHANGELOG.md`.

**Design decisions worth knowing:**

1. **Two trees, not one multi-output tree.** Small independently inspectable
   decision functions suit the eventual ESP32 port, and depth/nodes/size are
   reportable per target. Trade-off: two independent trees can emit a
   combination never seen in training, which is why joint exact-match is
   reported.
2. **Causality is enforced, not assumed.** The device chooses SF and TX power
   *before* transmitting, so the current row's own `packet_success`,
   `retry_count`, `sf` and `tp_dbm` are banned as features and the guard
   raises at both entry points. The default feature set is Checkpoint 2's
   already-shifted rolling history features. The current row's `rssi_dbm` /
   `snr_db` are off by default, because row *i*'s RSSI is measured *during*
   transmission *i* — using it to pick that transmission's configuration
   peeks one step ahead.
3. **Every accuracy is reported next to a majority-class baseline** and a
   per-context score, so a bare number can never stand alone.
4. **No model file is committed.** `ml/models/` ships empty with a README
   explaining that anything appearing there was trained on fabricated data
   and must never be deployed or cited. Regenerating takes seconds.

**Preserved unchanged:** no file from Checkpoints 1, 2 or 3 had its logic
modified. All of `ml/preprocessing/`, all of `ml/labeling/`,
`test_environment.py`, `test_preprocessing.py`, `test_labeling.py`, and both
earlier fixtures are byte-identical to their Checkpoint 3 state.

### Verification performed during Checkpoint 4

```
python3 tests/test_environment.py     # CP1 — still passes unmodified
python3 tests/test_preprocessing.py   # CP2 — still passes unmodified
python3 tests/test_labeling.py        # CP3 — still passes unmodified
python3 tests/test_training.py        # CP4 — new, 17 checks
python3 -m ml.training.train_decision_tree --input <labeled.csv> --outdir <temp>
python3 -m ml.evaluation.evaluate --model <bundle> --input <labeled.csv> --report <temp>
```

All four suites passed with exit code 0. The Checkpoint 4 checks confirmed,
among other things, that:
- all 14 banned columns are refused as features at both entry points;
- the default feature set represents all four project inputs and contains no
  GPS/distance/contextual variable;
- the split leaves zero contexts on both sides — while a naive row-level
  split on the same data would have leaked all 30, which is why the
  discipline matters;
- splitting refuses to run on fewer than two contexts;
- tree depth, node count, leaf count, model file size, training time and
  inference time are all recorded;
- a saved model reloads and predicts identically, and an invalid bundle is
  refused;
- joint accuracy never exceeds either individual accuracy, and an
  all-wrong predictor scores 0.0 (so the metrics measure something);
- the generated report carries the banner three times and disclaims PDR,
  latency, energy, adaptation, real-LoRa validation and project success by
  name;
- a fixed `random_state` reproduces the split, tree structure and metrics;
- `data/` and `ml/models/` are left clean.

---

## 4. Incomplete Work (intentionally NOT done yet)

Carried over from Checkpoint 1 (still true) unless noted otherwise:

- [ ] No data has been collected. `data/raw/`, `data/processed/`, and
  `data/sample/` remain empty except for the README.md files added this
  checkpoint (and `.gitkeep` placeholders).
- [x] ~~No data collection methodology has been finalized~~ → **Partially
  addressed**: `experiments/DATA_COLLECTION_PLAN.md` now documents the
  intended methodology, but several concrete details (exact hardware part
  numbers, logging transport, cadence, final scenario count) remain open
  questions listed in that document — they are not invented.
- [x] ~~No preprocessing / feature engineering code exists~~ → **Done this
  checkpoint** (`ml/preprocessing/`).
- [x] ~~No model architecture has been chosen or implemented~~ → **Done this
  checkpoint** for software-validation purposes: Decision Tree, two
  classifiers, in `ml/training/`. Whether a Decision Tree is the right
  *research* choice is still open and cannot be decided without real data.
- [x] ~~No evaluation metrics/code exist~~ → **Done this checkpoint**
  (`ml/evaluation/`).
- [ ] **No model trained on real data exists.** `ml/models/` ships empty on
  purpose. Anything generated there so far was trained on fabricated fixture
  data and is not a research artifact — see `ml/models/README.md`.
- [ ] **No honest evaluation exists.** Every metric the project has produced
  came from a fixture that is separable by construction. Nothing is known
  about how this approach performs on a real link.
- [ ] No export/quantization (e.g. TFLite Micro conversion) code exists in
  `ml/export/`.
- [ ] No ESP32 firmware or on-device inference code exists in `esp32/`.
- [x] ~~No label-construction strategy has been decided~~ → **Done this
  checkpoint.** The strategy is documented in
  `experiments/LABELING_STRATEGY.md` and implemented in `ml/labeling/`.
  Note what is still open: the framework has never been run on real data,
  because none exists, and its defaults (reliability threshold, context bin
  widths, evidence guards) are placeholders chosen so the code is testable,
  not validated choices.
- [ ] No (SF, TP) candidate grid has been fixed. This is blocked on the final
  SX1278 breakout board and the regional spectrum configuration — see
  `experiments/DATA_COLLECTION_PLAN.md` section 6. The labeling config
  deliberately defaults to deriving candidates from the data.
- [ ] No module supply-current-vs-TX-power table exists, so the physically
  correct energy model (`measured_current_table`) cannot yet be used. The
  table ships empty on purpose.
- [ ] No labels have actually been produced, since there is no real data to
  label.
- [ ] No research results, benchmarks, or performance numbers exist
  anywhere in the project. **Any numbers describing accuracy, latency,
  energy savings, etc. that appear anywhere in this repo before real data
  is collected and a real model is trained would be fabricated and must
  not be added.** (The rolling-window mean values computed by the
  pipeline in tests are arithmetic checks on synthetic fixture data, not
  research results — see `tests/fixtures/README.md`.)

---

## 5. Current Architecture

### Checkpoint 1
Purely folder/documentation scaffolding — no software architecture.

### Checkpoint 2 — Preprocessing pipeline architecture

```
data/raw/<session>.csv                (future: real ESP32 logs; schema in ml/preprocessing/schema.py)
        │
        ▼
ml/preprocessing/clean.py             load_raw_csv() + validate_schema()
        │   - checks required columns present
        │   - coerces dtypes
        │   - drops + reports rows with missing/out-of-range/disallowed values
        ▼
ml/preprocessing/feature_engineering.py   add_rolling_features()
        │   - groups by (device_id, session_id), orders by packet_seq
        │   - computes rolling mean of packet_success / retry_count /
        │     rssi_dbm / snr_db over the preceding W packets (W=5,10)
        │   - shifts by 1 so a packet's own outcome never leaks into its
        │     own history features
        ▼
ml/preprocessing/pipeline.py          run_pipeline() / CLI
        │   - ties the above together
        │   - writes processed CSV to data/processed/
        ▼
data/processed/<session>_processed.csv   (future: once real raw data exists)
```

Tested end-to-end against `tests/fixtures/synthetic_test_fixture_raw.csv`
(synthetic, code-testing only) via `tests/test_preprocessing.py`. No real
data has passed through this pipeline yet, since none exists.

### Checkpoint 3 — Labeling framework architecture

```
data/processed/<session>_processed.csv     (future: Checkpoint 2 output)
        │
        ▼
ml/labeling/context.py            assign_contexts()
        │   groups packets into comparable channel contexts
        │   (session / RSSI-SNR bins / both / explicit column)
        ▼
ml/labeling/oracle.py             build_oracle_table()
        │   one row per (context, SF, TP):
        │     n_packets, n_success, reliability, mean_retry, energy_cost
        │   uses reliability.py  -> Wilson lower bound or point estimate
        │   uses airtime.py      -> LoRa time-on-air formula
        │   uses energy.py       -> pluggable cost model + cost basis
        ▼
ml/labeling/oracle.py             select_labels()
        │   per context: cheapest configuration clearing min_reliability
        │   guards:   min_packets_per_config
        │             min_configs_per_context   <- requires a real sweep
        │             min_packets_per_context
        │   ties:     configurable ordered rules, ending deterministically
        │   failure:  drop / most_reliable / max_robustness / error
        ▼
ml/labeling/labeler.py            attach_labels() + CLI
        │
        ├──> <output>_oracle.csv    measured evidence (audit trail)
        ├──> <output>_labels.csv    one label per context
        └──> <output>               per-packet rows + label_sf, label_tp_dbm,
                                    label_status, selection_reason, context_id
```

Every knob in that diagram is set from `LabelingConfig` (`config.py`), which
round-trips to JSON so a labeling run is reproducible from a committed config
file.

Tested end-to-end against `tests/fixtures/synthetic_labeling_fixture_raw.csv`
(synthetic, code-testing only) via `tests/test_labeling.py`. No real data has
passed through this framework, since none exists.

---

## 6. Important Design Decisions

### Checkpoint 1
1. **No placeholder/synthetic "research" data was created.** The only
   synthetic numbers in the repo were inside `tests/test_environment.py`,
   clearly scoped as a library sanity check, not LoRa research data.
2. **Dependencies kept minimal for this stage** (`numpy`, `pandas`,
   `scikit-learn` only).
3. **Folder structure mirrors the eventual ML lifecycle.**
4. **`.gitkeep` files** preserve empty directories through zip/git.
5. **Documentation-first approach** to survive session/token limits.

### Checkpoint 2
6. **Data source decision was asked, not assumed.** Given the significant
   fork between "build against a schema" vs. "build a synthetic generator"
   vs. "ingest a public dataset," the user was asked explicitly rather than
   guessed. Answer: real ESP32 hardware later; build the pipeline + schema
   now. This shaped every decision below.
7. **Schema-first pipeline design.** `ml/preprocessing/schema.py` is the
   single source of truth for both the raw CSV contract and the processed
   output contract, so `clean.py`/`feature_engineering.py`/`pipeline.py`
   and the human-readable READMEs all derive from (or are checked against)
   one place, avoiding drift between documentation and code.
8. **Validation drops and reports, never silently accepts, bad rows.**
   `clean.validate_schema()` returns both the cleaned DataFrame and a
   `ValidationReport` explaining exactly what was dropped and why. This
   was chosen over silently coercing/imputing bad values, since silent
   coercion could hide real hardware/logging bugs once data collection
   begins.
9. **Rolling history features exclude the current packet's own outcome**
   (via `shift(1)` before the rolling window). This was a deliberate
   choice to avoid label/feature leakage: a future model must predict
   SF/TP from *past* history, not from information only available after
   the fact.
10. **Default rolling window sizes (5 and 10) are placeholders**, not a
    validated hyperparameter choice — flagged explicitly in
    `feature_engineering.py` and section 7 below as something to revisit
    once real data and a chosen model architecture exist.
11. **Synthetic test fixture kept strictly separate from `data/`.** Per
    the same discipline as Checkpoint 1's design decision #1, the fixture
    used to test the pipeline lives only in `tests/fixtures/`, is
    explicitly labeled synthetic in its filename and README, and
    `tests/test_preprocessing.py` actively asserts that running it never
    writes anything into `data/raw/`, `data/processed/`, or `data/sample/`.
12. **Label-construction strategy deliberately deferred.** Deciding *how*
    to turn logged history into a "correct SF/TP" training label is a
    modeling decision, not a preprocessing one, and was left out of this
    checkpoint's scope — see section 4.
13. **No new dependencies added.** The pipeline only needed pandas (and
    its numpy dependency), both already present from Checkpoint 1, so
    `requirements.txt` content is unchanged (only its comment was updated).

### Checkpoint 2 — Correction Pass
14. **Widen, don't arbitrarily pin, when a version mismatch is found.**
    Rather than forcing the environment back to an old numpy version to
    match a narrow pin, the pin itself was widened to `<3.0` after
    confirming (via a clean-venv install plus an explicit numpy 2.3.5
    test) that the actually-used dependency versions all work correctly
    together. The goal was an honest, verified `requirements.txt`, not
    just a cosmetic fix.
15. **Fixture values kept synthetic, but aligned to avoid misleading
    hardware claims.** Once the user confirmed the planned radio hardware
    (SX1278, 433 MHz), the test fixture's `channel_freq_hz` was updated to
    433 MHz purely to prevent a reader from mistaking a fabricated
    900 MHz-band value for the real target band. This is a documentation
    accuracy fix, not a step toward treating the fixture as real data —
    see decision #11 and `tests/fixtures/README.md`.
16. **Label-construction strategy still deliberately deferred**, per
    explicit user instruction — reaffirming decision #12. No
    preprocessing logic was touched in this correction pass.

### Checkpoint 3

17. **Labels are derived from measured evidence, never copied from the
    logged configuration.** The central decision of this checkpoint. Using
    the logged `sf`/`tp_dbm` as targets would be behavioural cloning of
    whatever policy produced the logs — reproducing ADR at best, learning
    noise at worst. See `experiments/LABELING_STRATEGY.md` section 2.
18. **Reliability is a constraint, energy is the objective.** "Be reliable
    enough, then be as cheap as possible" is encoded directly in the
    selection rule, rather than blending the two into a weighted score with
    invented weights. `cost_basis` allows softening this by folding
    reliability back into the cost.
19. **The framework refuses to label a context it has no sweep for.**
    `min_configs_per_context` exists because "the best configuration among
    one configuration" is vacuous, not optimal. This turns a configuration
    sweep from a nice-to-have into a hard data collection requirement, which
    was written back into `DATA_COLLECTION_PLAN.md` section 4a.
20. **Thin evidence is discounted by default.** The Wilson lower bound is the
    default estimator so a configuration measured five times cannot outrank
    one measured five hundred times on a lucky run. Consequence worth
    knowing: at a 100% delivery ratio the bound is `n / (n + z²)`, so ≥25
    packets per configuration are needed to clear a 0.90 threshold.
21. **Hardware-dependent constants are refused, not guessed.** The
    supply-current table ships empty and `measured_current_table` raises a
    descriptive error rather than substituting plausible figures. It also
    refuses to extrapolate beyond a supplied table's range. This mirrors
    Checkpoint 1's decision #1 and Checkpoint 2's decision #11.
22. **SF/TX-power candidate sets default to "derive from the data."**
    Pre-filling them would bake an unverified hardware+regulatory assumption
    into every label the framework ever produces. `regulatory_profile` exists
    as a place to record the constraint once confirmed, and is read by no
    calculation — no regulatory limit is asserted anywhere in this project.
23. **Every label carries its provenance.** `label_status` distinguishes
    evidence-backed labels from fallbacks, and `selection_reason` records the
    human-readable cause. A later checkpoint can filter or down-weight
    fallback labels instead of silently treating them as equivalent.
24. **The energy model's known bias is documented rather than hidden.** The
    default `airtime_x_linear_power` models only radiated power, ignoring PA
    efficiency and the module's fixed baseline current. This *exaggerates*
    the saving from lowering TX power and therefore biases labels toward low
    power. Stated in the code, the package README and the strategy document,
    because it directly affects which configuration wins.
25. **The synthetic fixture is generated by committed, deterministic code.**
    No RNG and no seed, so the CSV is byte-for-byte reproducible and every
    expected label is derivable on paper. The generator is committed next to
    the CSV so the fabricated data is auditable rather than mysterious.
26. **No new dependencies.** The Wilson bound was implemented from its closed
    form rather than adding scipy, keeping `requirements.txt` unchanged for a
    third consecutive checkpoint.

### Checkpoint 4

27. **Two separate trees rather than one multi-output tree.** Small,
    independently inspectable decision functions suit the eventual ESP32
    port, and structure is reportable per target. The trade-off — two
    independent trees can emit an (SF, TP) combination never seen in
    training — is exposed by the joint exact-match metric rather than hidden.
    Predicting the pair as a single joint class remains an option for later.
28. **Causality is enforced in code, not left to discipline.**
    `BANNED_FEATURE_COLUMNS` raises rather than warns, at both entry points.
    A feature that is only knowable after the transmission has happened
    cannot be used, however predictive it looks, because the device must
    choose before transmitting.
29. **The current row's RSSI/SNR are off by default.** In a real log, row
    *i*'s RSSI is measured *during* transmission *i*. Using it to choose
    that transmission's configuration peeks one step ahead.
    `--include-current-link` enables them for comparison and the choice is
    recorded in the metadata.
30. **Accuracy is never reported alone.** Every accuracy is accompanied by a
    majority-class baseline and a per-context score. An 80% accuracy on a
    problem where 80% of contexts want one class is a statement about the
    class distribution, not the model.
31. **Per-context scoring exists because rows are not samples.** One label
    covers ~180 rows, so row-level accuracy over-weights large contexts.
    Aggregating by majority vote per context is much closer to the real
    sample size.
32. **No model artifact is committed.** A stale model trained on fabricated
    data sitting in the repo is exactly the sort of thing that later gets
    mistaken for a real one. `ml/models/` ships empty with a README.
33. **The banner is structural, not decorative.** `SYNTHETIC_BANNER` is
    emitted by the metrics module itself, and a test asserts it appears at
    least three times in any generated report along with each disclaimed
    claim by name. Removing it means failing the suite.
34. **A second fixture was necessary.** Checkpoint 3's fixture yields one
    context and one class, which cannot train a classifier or support a
    split. The new fixture is additive; the old one is untouched.

---

## 7. Known Issues / Limitations

Carried over from Checkpoint 1 (still true):
- No real hardware (ESP32 + LoRa module) has been used or tested yet —
  the radio chip is now chosen (SX1278, 433 MHz — confirmed during the
  Checkpoint 2 correction pass) but no physical unit has been used.
- The exact ML approach has not been chosen.
- `requirements.txt` will need additions later (matplotlib, TensorFlow/TFLite
  or similar, pyserial, etc.) — do not add until actually needed.

New in Checkpoint 2:
- The rolling window sizes (5, 10 packets) are placeholder defaults, not
  validated against real data or a chosen model — may need to change once
  real sessions and a model architecture exist.
- `tp_dbm` and `rssi_dbm` valid ranges in `schema.py` are reasonable
  generic LoRa-module estimates, not yet confirmed against the specific
  SX1278 hardware that will eventually be used. Ranges should be
  revisited once real hardware measurements are available, or a real
  value could get incorrectly rejected/dropped by validation.
- ~~No label-construction strategy exists yet~~ → **Addressed in Checkpoint
  3** (`experiments/LABELING_STRATEGY.md`, `ml/labeling/`). The limitations
  of that strategy are listed below rather than here.
- The preprocessing pipeline has only ever been run against synthetic
  fixture data (12 rows). Its behavior on much larger, messier real data
  (e.g. multi-session files, clock skew, missing sensor readings mid-session)
  is unverified and should be re-checked once real data exists.

Resolved in the Checkpoint 2 correction pass (no longer open issues):
- ~~`numpy` requirement pin (`<2.0`) didn't match the numpy version
  (2.3.5) actually verified against~~ → fixed; pin widened to `<3.0` and
  re-verified against numpy 1.26.4 AND 2.3.5.
- ~~Synthetic fixture used a 915 MHz frequency inconsistent with the
  planned SX1278 433 MHz hardware~~ → fixed; fixture now uses 433 MHz,
  clearly still labeled synthetic.

New in Checkpoint 3 (all also listed, with fuller explanation, in
`experiments/LABELING_STRATEGY.md` section 7):

- **The labeling framework has never been run on real data**, because none
  exists. Everything verified so far is verified against a 210-row synthetic
  fixture designed to exercise specific branches.
- **All labeling defaults are placeholders.** `min_reliability=0.90`, the
  RSSI/SNR bin widths, and the three evidence guards were chosen so the code
  is testable, not validated against anything. Same status as Checkpoint 2's
  placeholder rolling-window sizes.
- **The context definition is the framework's biggest unvalidated
  assumption.** Too coarse and configurations measured under different
  conditions get compared; too fine and nothing clears the coverage guard.
  There is a real circularity too: RSSI and SNR are partly a *consequence* of
  the configuration in use, so binning by them is not configuration-neutral.
- **Mild self-inclusion leakage.** A packet's label derives from statistics
  over its whole context, including that packet. Mitigation is to split
  train/test by `context_id` (`GroupKFold`/`GroupShuffleSplit`), not by row.
  A leave-one-out variant was considered and not implemented.
- **The oracle can only ever pick a configuration that was measured.** If the
  sweep omits the genuinely optimal setting, labels are
  optimal-within-what-was-tried and nothing in the pipeline can detect it.
- **The default energy model is biased toward low TX power** (see design
  decision #24). Switch to `measured_current_table` before quoting any energy
  figure as a result — which requires datasheet or bench measurements that do
  not exist yet.
- **Airtime parameters are configured, not measured.** If bandwidth, coding
  rate, preamble, header or CRC settings disagree with what the ESP32
  firmware actually sets, every energy comparison is biased. Verify once
  firmware exists.
- **Class imbalance is likely.** If most contexts turn out to be easy links,
  one configuration will dominate the labels and a model could score well by
  always predicting it. Evaluation must report per-class performance.
- **Sweep confounding cannot be detected in code.** Whether a session
  interleaved configurations round-robin or blocked them is a protocol
  property; the labeler cannot tell the difference from the CSV.

New in Checkpoint 4:

- **Every metric the project has ever produced is meaningless as evidence.**
  The fixture assigns each link tier a distinct RSSI/SNR band with one
  correct answer, so it is separable by construction. The pipeline scores
  perfectly on it; that is the expected outcome of correct wiring and says
  nothing about LoRa.
- **Effective sample size is tiny.** 5,370 usable rows across 30 contexts is
  a 30-sample problem, split 21/9. Nine test contexts cannot support any
  confident statement, even on real data. Real collection needs far more
  distinct channel conditions, not just more packets.
- **Two independent trees can emit an unseen (SF, TP) combination.** Joint
  exact-match exposes it; nothing currently prevents it.
- **Decision Tree was chosen for validation, not selected on merit.** No
  model comparison has been run. Whether a tree is the right family is an
  open question for after real data exists.
- **Hyperparameters are arbitrary.** `max_depth=6`, `min_samples_leaf=5`,
  `test_size=0.3` were set to keep trees inspectable, not tuned.
- **Inference timing is from the build machine, not an ESP32.** The 3 KB
  joblib figure is desktop serialisation, not an embedded footprint. Neither
  number transfers to the target hardware.
- **The current-row RSSI/SNR question is unresolved.** Off by default for
  causality, but which lag a real device can actually act on depends on
  firmware behaviour that does not exist yet.
- **Class balance in the fixture is artificial.** Six contexts per class,
  because it was written that way. Real conditions will not be balanced, and
  the majority-class baseline will matter much more.

---

## 8. Next Checkpoint

**Checkpoint 5 (NOT started): Real Hardware Data Collection**

Everything downstream is blocked on this. The software path is now complete
end to end — preprocessing, labeling, training, evaluation all run — and has
been validated on fabricated data. What it has never seen is a real link.

Before anything else is worth doing:

- Collect real ESP32 + SX1278 data per `experiments/DATA_COLLECTION_PLAN.md`,
  **including the section 4a sweep requirements** (interleaved round-robin
  configuration sweep within each channel condition, ≥25 packets per
  configuration, enough distinct conditions to give a usable number of
  contexts)
- Resolve the open hardware/regulatory questions in that document's section
  6: the (SF, TP) grid, the regional configuration, the supply-current table,
  and the firmware's actual airtime parameters
- Run the existing pipeline over it and **review the oracle table and the
  `label_status` breakdown before training** — that will reveal whether the
  collection protocol actually produced labellable data
- Revisit the labeling defaults (threshold, context strategy, bin widths,
  evidence guards) against real data; they are placeholders
- Retrain, re-evaluate honestly, and only then consider removing the
  synthetic-data banner

**Explicitly deferred, per user instruction:** Logistic Regression and Random
Forest comparisons were NOT started in Checkpoint 4 and should not be started
without an explicit request. Model comparison is also premature before real
data exists — comparing models on a fixture that is separable by construction
would tell you only that they all score 1.0.

**Do not start Checkpoint 5 work until explicitly instructed.**

---

## 9. Instructions for a New Claude Account/Session to Continue This Project

If you are a new Claude session picking up this project (e.g. the user
uploaded this project folder because a previous session ran out of tokens),
follow this exact process:

1. **Read this entire file (`PROJECT_STATUS.md`) first**, then skim
   `README.md` and `CHANGELOG.md`.
2. **Do not assume any work exists beyond what section 3 ("Completed Work")
   of this file lists.** Verify by actually inspecting the folder structure
   and file contents rather than trusting summaries alone.
3. **Do not fabricate or backfill research data, results, or benchmarks**
   for any checkpoint, past or future. If the user asks for results that
   don't exist yet, say so plainly instead of inventing plausible-looking
   numbers.
4. **Only work on the checkpoint the user explicitly asks for.** Check
   section 8 ("Next Checkpoint") for what is expected next, but confirm
   with the user before assuming that's what they want right now — they
   may want to revise Checkpoint 1, ask questions, or jump to something
   else.
5. **Preserve this checkpoint discipline going forward:** after finishing
   whatever checkpoint you're asked to do, update `PROJECT_STATUS.md` (all
   relevant sections, especially Completed/Incomplete/Next Checkpoint) and
   append an entry to `CHANGELOG.md`, then stop and wait for explicit
   instruction before continuing to the next checkpoint — mirroring how
   Checkpoint 1 was handled.
6. **Keep the project portable.** At the end of any checkpoint, offer to
   package the complete, current project folder as a downloadable zip
   (naming convention: `LoRa_EdgeAI_CP<NN>_<short-description>.zip`), so the
   user can continue in a fresh session if needed. Checkpoint 1 produced
   `LoRa_EdgeAI_CP01_Project_Setup.zip`; Checkpoint 2 produced
   `LoRa_EdgeAI_CP02_Data_Pipeline.zip`, later corrected and re-delivered as
   `LoRa_EdgeAI_CP02_Data_Pipeline_v2.zip` after a user-requested
   correction pass (numpy pin, fixture frequency — see section 3);
   Checkpoint 3 produced `LoRa_EdgeAI_CP03_Labeling_Framework.zip`;
   Checkpoint 4 produced
   `LoRa_EdgeAI_CP04_DecisionTree_SoftwareValidation.zip`.
7. **When in doubt about scope, ask the user rather than guessing** —
   especially before adding new dependencies, choosing a model architecture,
   or claiming something is "done." (Checkpoint 2 did this: it asked the
   user, via a single clarifying question, whether data would come from
   real hardware, a synthetic generator, or a public dataset, before
   building anything — see section 6, decision 6.)
8. **Before starting Checkpoint 5**, note that it is real hardware data
   collection (see section 8), which is outside what an AI session can do.
   Confirm with the user how they want to proceed rather than assuming.
8a. **Never present a metric from fixture data as a result.** Every number
   this project has produced so far came from a fixture that is separable by
   construction. The `SYNTHETIC_BANNER` in `ml/evaluation/metrics.py` is
   emitted structurally and `tests/test_training.py` asserts its presence —
   if a future session finds it inconvenient, that is the guard working, not
   a bug. It comes off only when metrics genuinely come from hardware.
9. **Do not weaken the labeling framework's honesty guards.** Several things
   in `ml/labeling/` deliberately refuse to produce output rather than
   guessing: the empty supply-current table, the candidate sets defaulting to
   "derive from data", `min_configs_per_context`, and the extrapolation
   refusal in the current-table lookup. If a future session finds one of
   these inconvenient, the correct response is to get the real value from the
   user or the datasheet — not to fill in a plausible default. Tests in
   `tests/test_labeling.py` assert several of these guards, so silently
   removing one will fail the suite.
10. **Numbers the labeling code produces are not results.** Anything computed
   from `tests/fixtures/` is arithmetic over fabricated data used to verify
   the code. It must never appear in a report as a finding.
