"""
ml.evaluation — Checkpoint 4: model evaluation.

Every report produced by this package carries the SYNTHETIC_BANNER from
ml/evaluation/metrics.py, because as of Checkpoint 4 all metrics come from
fabricated test-fixture data and measure only that the software runs.
"""
