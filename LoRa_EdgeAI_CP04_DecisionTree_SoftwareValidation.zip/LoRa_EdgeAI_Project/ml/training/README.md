# `ml/training/` — Model Training (Checkpoint 4)

> **SOFTWARE PIPELINE VALIDATION ONLY.** The project has no real LoRa data
> yet. Everything this package produces demonstrates that the pipeline
> executes — nothing more.

## Pipeline position

```
data/raw/<session>.csv
   -> ml/preprocessing/pipeline.py    (CP2)  clean + rolling history features
   -> ml/labeling/labeler.py          (CP3)  derive (SF, TP) targets
   -> ml/training/train_decision_tree.py  (CP4)  train, save, report
   -> ml/evaluation/evaluate.py       (CP4)  reload, score, write report
```

## Modules

| File | Responsibility |
|---|---|
| `dataset.py` | Feature assembly, the leakage guard, and context-aware splitting |
| `train_decision_tree.py` | Trains the two trees, saves the bundle, writes metadata |

## Two rules this package enforces

**1. Causality.** The device picks SF and TX power *before* transmitting, so
any feature only knowable afterwards is unusable. `BANNED_FEATURE_COLUMNS`
rejects the current row's own `packet_success` and `retry_count` (outcomes of
the transmission being decided) and its own `sf` / `tp_dbm` (the decision
itself). The guard raises rather than warns, at both entry points.

The default feature set is Checkpoint 2's rolling history features, which are
already shifted by one packet. They carry all four project inputs — RSSI,
SNR, success/failure history, retry count — in lagged form.

The current row's `rssi_dbm` / `snr_db` are off by default: in a real log,
row *i*'s RSSI is measured *during* transmission *i*, so using it to choose
that transmission's configuration peeks one step ahead. `--include-current-link`
turns them on for comparison.

**2. Context-aware splitting.** One label covers every row of a context, so a
random row split would put the same context on both sides and let the model
score by recognition. All splitting is by `context_id`.

This also means **the effective sample size is the number of contexts, not
the number of rows.** 5,400 rows across 30 contexts is a 30-sample problem.
Every report states both.

## Model choice

Two separate `DecisionTreeClassifier`s, one per target, rather than one
multi-output tree — small independently inspectable decision functions suit
the eventual ESP32 port, and depth/nodes/size are reportable per target. The
trade-off is that two independent trees can emit a combination never seen in
training; the joint exact-match metric exists to expose that.

**Not tuned.** No hyperparameter search, no pruning sweep, no class
weighting. `max_depth=6` and `min_samples_leaf=5` keep the trees inspectable,
not optimal. Tuning belongs after real data exists.

## Usage

```bash
# Train (writes model + metadata)
python -m ml.training.train_decision_tree \
    --input <labeled.csv> --outdir ml/models

# Train without saving anything
python -m ml.training.train_decision_tree --input <labeled.csv> --no-save

# Verify the whole pipeline against synthetic test-only data
python tests/test_training.py
```
