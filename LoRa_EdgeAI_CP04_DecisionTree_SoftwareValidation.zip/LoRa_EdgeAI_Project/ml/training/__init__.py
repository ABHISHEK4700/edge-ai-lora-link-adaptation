"""
ml.training — Checkpoint 4: model training.

SOFTWARE PIPELINE VALIDATION ONLY. As of Checkpoint 4 the only data in this
project is fabricated test-fixture data, so nothing produced here is a
research result or a claim about real LoRa behaviour.

Read ml/training/README.md before using any of this.
"""
