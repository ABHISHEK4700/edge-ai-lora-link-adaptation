# `ml/models/` — Saved Model Artifacts

**Nothing in this folder is a research artifact.**

As of Checkpoint 4 the project has collected no real LoRa data. Any model
file that appears here was trained on the fabricated fixtures in
`tests/fixtures/`, which exist to prove the software runs. Such a model:

- is **not** validated for real LoRa communication
- does **not** demonstrate improved PDR, latency, energy, or adaptation
- must **never** be deployed, benchmarked, or cited as a project result

## What lands here

Running the Checkpoint 4 training script writes two files:

```bash
python -m ml.training.train_decision_tree \
    --input <labeled.csv> --outdir ml/models
```

- `decision_tree_sf_tp.joblib` — the model bundle (SF tree, TX-power tree,
  the feature column list, and provenance)
- `decision_tree_sf_tp_metadata.json` — tree depth, node and leaf counts,
  file size, training time, inference time, and evaluation metrics, all
  stamped with the synthetic-data banner

Neither is committed to the repository. The folder ships empty apart from
this README and a `.gitkeep`, so a stale synthetic-trained model can never be
mistaken later for a real one. Regenerate on demand — it takes seconds.

## Before a model here means anything

1. Real data collected per `experiments/DATA_COLLECTION_PLAN.md`, including
   the section 4a sweep requirements
2. Labeling defaults revisited against that data
   (`experiments/LABELING_STRATEGY.md`)
3. Retrained, re-evaluated, and the banner removed only once the metrics
   genuinely come from hardware
