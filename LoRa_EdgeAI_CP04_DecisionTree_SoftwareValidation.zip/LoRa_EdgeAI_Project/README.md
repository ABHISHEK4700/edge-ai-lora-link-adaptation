# Lightweight Edge-AI Based Adaptive Spreading Factor and Transmission Power Optimization for LoRa End Devices Under Dynamic Channel Conditions

**Type:** 3rd-Year ECE Final Year Project
**Status:** Checkpoint 4 — Decision Tree Software Validation
(no real data collected; no research model trained)

---

## 1. Project Overview

LoRa (Long Range) end devices must choose two key radio parameters for every
transmission:

- **Spreading Factor (SF)** — trades data rate for range/robustness (SF7–SF12)
- **Transmission Power (TP)** — trades energy consumption for link reliability

Today, most LoRa/LoRaWAN deployments pick these using static configuration or
the standard **ADR (Adaptive Data Rate)** algorithm, which reacts slowly and
does not use short-term contextual information well.

This project explores whether a **lightweight, edge-deployable machine
learning model** can learn to predict a good (SF, TP) pair directly on the
end device, using recent link-quality history, so that the device adapts
faster and more efficiently to changing channel conditions (fading, mobility,
interference, distance changes) than static/ADR approaches.

### Inputs (features) the model will eventually use
- **RSSI** (Received Signal Strength Indicator)
- **SNR** (Signal-to-Noise Ratio)
- **Packet success/failure history** (recent delivery outcomes)
- **Retry count** (how many retransmissions were needed)

### Outputs (targets) the model will eventually predict
- **Spreading Factor (SF)**
- **Transmission Power (TP)**

The SF and TX-power *ranges* are deliberately not fixed yet: they depend on
the final SX1278 breakout board and on the regional spectrum configuration,
neither of which is confirmed. See `experiments/LABELING_STRATEGY.md` for how
these targets are derived from measured evidence rather than copied from the
logged configuration column.

### Target deployment
The final trained model is intended to run **locally on an ESP32**
(paired with a LoRa radio module — planned hardware: **SX1278, 433 MHz
band**) as a lightweight on-device inference engine (e.g. via TensorFlow
Lite Micro or a hand-rolled decision function), so the device can make
SF/TP decisions without relying on a network server.

---

## 2. Current Scope — through Checkpoint 4

> ### SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT
>
> Checkpoint 4 built and ran an end-to-end Decision Tree training and
> evaluation pipeline. It ran against **fabricated test-fixture data only**.
> No claim about real LoRa communication, packet delivery ratio, latency,
> energy consumption or adaptation speed is supported by any of it. The
> fixture is trivially separable by construction, so the near-perfect scores
> it produces are expected and mean only that the code runs.

**The project does NOT yet contain:**
- Any collected LoRa measurement data (`data/` is still empty)
- A research model — nothing trained on real data
- ESP32 firmware or on-device inference code
- Any research results, benchmarks, or performance numbers

**The project DOES contain:**
- Full project scaffolding and documentation *(Checkpoint 1)*
- A defined raw/processed data schema and a working preprocessing pipeline
  *(Checkpoint 2)*
- A documented data collection methodology *(Checkpoint 2, extended in
  Checkpoint 3)*
- A target-label strategy and a configurable labeling framework
  *(Checkpoint 3)* — how a "correct" (SF, TP) target is derived from
  measured link evidence
- **A working Decision Tree training and evaluation pipeline**
  *(Checkpoint 4)* — `ml/training/` and `ml/evaluation/`, with model saving,
  metadata reporting, and a causality/leakage guard. Verified against
  synthetic test-only data; **software validation only**

See `PROJECT_STATUS.md` for the detailed project status and `CHANGELOG.md`
for a checkpoint-by-checkpoint record.

---

## 3. Project Structure

```
LoRa_EdgeAI_Project/
├── README.md              # This file
├── PROJECT_STATUS.md       # Detailed status, decisions, and continuation notes
├── CHANGELOG.md            # Checkpoint-by-checkpoint change log
├── requirements.txt         # Python dependencies for the current checkpoint
├── data/
│   ├── raw/                # Raw LoRa link-quality data — schema defined, no real data yet
│   ├── processed/          # Cleaned/feature-engineered data — no real data yet
│   └── sample/             # Small illustrative samples, once real data exists (empty for now)
├── ml/
│   ├── preprocessing/      # Data cleaning & feature engineering pipeline (implemented, Checkpoint 2)
│   │   ├── schema.py             # Raw/processed data schema definitions
│   │   ├── clean.py              # Raw CSV loading + validation
│   │   ├── feature_engineering.py # Rolling "history" feature computation
│   │   └── pipeline.py           # CLI entry point tying it all together
│   ├── labeling/           # Target-label framework (implemented, Checkpoint 3)
│   │   ├── config.py             # LabelingConfig — every tunable knob
│   │   ├── context.py            # Groups packets into comparable channel contexts
│   │   ├── reliability.py        # Reliability estimation from finite samples
│   │   ├── airtime.py            # LoRa time-on-air formula
│   │   ├── energy.py             # Pluggable energy cost models
│   │   ├── oracle.py             # Evidence table + label selection
│   │   ├── labeler.py            # CLI entry point
│   │   ├── labeling_config.example.json  # Starting config file
│   │   └── README.md             # Documents every configurable knob
│   ├── training/           # Model training (implemented, Checkpoint 4)
│   │   ├── dataset.py            # Feature assembly, leakage guard, context split
│   │   ├── train_decision_tree.py # Trains + saves + reports metadata
│   │   └── README.md             # Causality and splitting rules
│   ├── evaluation/         # Model evaluation (implemented, Checkpoint 4)
│   │   ├── metrics.py            # Metrics + the synthetic-data banner
│   │   └── evaluate.py           # Standalone evaluation + report generation
│   ├── models/             # Saved models — empty; see ml/models/README.md
│   └── export/             # Model export (e.g. TFLite conversion) for ESP32 (not started)
├── experiments/
│   ├── DATA_COLLECTION_PLAN.md # Data collection methodology (Checkpoint 2, extended in 3)
│   ├── LABELING_STRATEGY.md    # Why/how SF+TP labels are derived (Checkpoint 3)
│   └── CP04_SOFTWARE_VALIDATION_RUN.md # Record of one pipeline run (Checkpoint 4)
├── esp32/                  # ESP32 firmware / on-device inference code (not started)
└── tests/
    ├── test_environment.py  # Verifies Python + ML library environment (Checkpoint 1)
    ├── test_preprocessing.py # Verifies preprocessing pipeline against synthetic fixture (Checkpoint 2)
    ├── test_labeling.py      # Verifies labeling framework against synthetic fixture (Checkpoint 3)
    ├── test_training.py      # Verifies training/evaluation pipeline against synthetic fixture (Checkpoint 4)
    └── fixtures/              # Synthetic, clearly-labeled test-only data
```

Every currently-empty directory contains a `.gitkeep` placeholder file so the
folder structure survives copying/zipping/uploading to git or a new machine.

---

## 4. Setup Instructions

### 4.1 Prerequisites
- Python 3.9–3.11 (recommended)
- `pip`
- (Optional but recommended) a virtual environment tool such as `venv`

### 4.2 Create and activate a virtual environment

```bash
# From inside the LoRa_EdgeAI_Project/ folder
python3 -m venv venv

# Activate it:
# On Linux / macOS:
source venv/bin/activate
# On Windows (PowerShell):
venv\Scripts\Activate.ps1
```

### 4.3 Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4.4 Verify the environment

Run the environment test script:

```bash
python tests/test_environment.py
```

This will check:
- The Python version in use
- That `numpy`, `pandas`, and `scikit-learn` import correctly
- That basic array/DataFrame operations and a tiny scikit-learn model fit
  correctly (a sanity check, not a real model)

If all checks pass you will see `ALL CHECKS PASSED` printed at the end and
the script will exit with code `0`. If anything fails, the script prints
which check failed and exits with a non-zero code.

---

## 5. How to Run

### Checkpoint 1 — environment verification

```bash
python tests/test_environment.py
```

### Checkpoint 2 — preprocessing pipeline

As of Checkpoint 2, `data/raw/` contains **no real data yet** (see
`experiments/DATA_COLLECTION_PLAN.md`). What exists now is the pipeline
itself, verified against a synthetic test fixture:

```bash
# Verify the pipeline logic against synthetic test-only data
python tests/test_preprocessing.py

# Once real raw data exists in data/raw/ (future work), run it through the
# pipeline like this:
python -m ml.preprocessing.pipeline \
    --input data/raw/<session_id>.csv \
    --output data/processed/<session_id>_processed.csv
```

See `data/raw/README.md` for the required raw CSV schema and
`data/processed/README.md` for what the pipeline adds.

### Checkpoint 3 — labeling framework

**Read `experiments/LABELING_STRATEGY.md` before using any of this.** It
explains why the logged `sf`/`tp_dbm` columns cannot be used as training
labels, what is used instead, and what the data collection protocol must
guarantee for the result to be valid.

```bash
# Verify the labeling framework against synthetic test-only data
python tests/test_labeling.py

# Inspect the effective labeling configuration
python -m ml.labeling.labeler --print-config

# Write a fresh config file to edit
python -m ml.labeling.labeler --write-default-config my_labeling_config.json

# Once real processed data exists (future work), derive labels like this:
python -m ml.labeling.labeler \
    --input data/processed/<session_id>_processed.csv \
    --output data/processed/<session_id>_labeled.csv \
    --config ml/labeling/labeling_config.example.json
```

That produces three files: the labeled per-packet rows, plus
`_oracle.csv` (the measured evidence behind every label, so any label can be
traced back to packet counts) and `_labels.csv` (one label per channel
context).

`ml/labeling/README.md` documents every configurable knob — reliability
threshold, candidate SF/TX-power sets, energy method, tie-breaking, and
no-valid-configuration handling are all settable from the config file.

### Checkpoint 4 — Decision Tree training & evaluation

> **SYNTHETIC SOFTWARE-VALIDATION RESULT — NOT A RESEARCH RESULT.** These
> commands run against fabricated fixture data. Read
> `experiments/CP04_SOFTWARE_VALIDATION_RUN.md` section 6 before quoting any
> number they produce.

```bash
# Verify the training/evaluation pipeline against synthetic test-only data
python tests/test_training.py

# Run the full chain end to end
python -m ml.preprocessing.pipeline \
    --input tests/fixtures/synthetic_pipeline_fixture_raw.csv \
    --output /tmp/proc.csv
python -m ml.labeling.labeler --input /tmp/proc.csv --output /tmp/lab.csv
python -m ml.training.train_decision_tree --input /tmp/lab.csv --outdir ml/models
python -m ml.evaluation.evaluate \
    --model ml/models/decision_tree_sf_tp.joblib \
    --input /tmp/lab.csv \
    --metadata ml/models/decision_tree_sf_tp_metadata.json \
    --report /tmp/report.md
```

The training step records tree depth, node and leaf counts, model file size,
training time, inference time, and evaluation metrics — all stamped with the
synthetic-data banner. `ml/training/README.md` explains the two rules the
pipeline enforces: **causality** (no feature that is unknowable before
transmitting) and **context-aware splitting** (the effective sample size is
the number of contexts, not the number of rows).

Future checkpoints will add real run instructions for hardware data
collection, model optimization, and ESP32 deployment.

---

## 6. Roadmap (high level, for context only)

1. **Checkpoint 1 (done):** Project foundation & environment setup
2. **Checkpoint 2 (done):** Data schema, preprocessing pipeline, and data
   collection methodology — no real data collected yet
3. **Checkpoint 3 (done):** Target-label strategy & labeling framework — no
   model trained
4. **Checkpoint 4 (this checkpoint):** Decision Tree training/evaluation
   pipeline — **software validation only**, synthetic data, no research model
5. **Checkpoint 5 (future):** Real hardware data collection, then retraining
   and honest evaluation on it. Everything downstream is blocked on this.
6. **Checkpoint 6 (future):** Model optimization/quantization for edge deployment
7. **Checkpoint 7 (future):** ESP32 integration & on-device testing
8. **Checkpoint 8 (future):** Field/dynamic-channel evaluation & final report

Exact checkpoint boundaries are defined by the course/project supervisor and
may change; see `PROJECT_STATUS.md` for the authoritative "next checkpoint"
note.

---

## 7. Continuing This Project With a Different AI Assistant Session

If you are picking this project up in a new Claude conversation (e.g. after
running out of tokens), **read `PROJECT_STATUS.md` first**. It is written
specifically to let a new assistant session understand exactly what exists,
what doesn't, and what to do next without needing the original conversation.
